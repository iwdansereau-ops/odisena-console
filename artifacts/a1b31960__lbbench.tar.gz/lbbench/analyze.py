#!/usr/bin/env python3
"""Aggregate go test -bench output into per-benchmark median/mean/stddev,
compute RWMutex-vs-Atomic deltas, and emit CSV + Markdown summary tables."""

import re
import statistics
import sys
from collections import defaultdict
from pathlib import Path

RAW = Path("bench_raw.txt")

# Line shape: BenchmarkName-N  <iters>  <ns/op> ns/op  ...
LINE_RE = re.compile(
    r"^(Benchmark\S+?)-(\d+)\s+(\d+)\s+([\d.]+)\s+ns/op"
)

runs = defaultdict(list)  # bench_name -> [ns/op, ...]

for line in RAW.read_text().splitlines():
    m = LINE_RE.match(line)
    if not m:
        continue
    name, gomaxprocs, iters, nsop = m.groups()
    runs[name].append(float(nsop))

def summary(vals):
    return {
        "n": len(vals),
        "min": min(vals),
        "median": statistics.median(vals),
        "mean": statistics.mean(vals),
        "stddev": statistics.stdev(vals) if len(vals) > 1 else 0.0,
        "max": max(vals),
    }

# Pair RWMutex vs Atomic by suffix (Workers1, Workers4, ..., Workers64_WithWriter)
paired = []
for suffix in [
    "Workers1", "Workers4", "Workers8", "Workers16",
    "Workers32", "Workers64", "Workers128", "Workers64_WithWriter",
]:
    rw = runs.get(f"BenchmarkRWMutex_{suffix}")
    at = runs.get(f"BenchmarkAtomic_{suffix}")
    if not (rw and at):
        continue
    rw_s = summary(rw)
    at_s = summary(at)
    speedup = rw_s["median"] / at_s["median"]
    delta_pct = 100.0 * (rw_s["median"] - at_s["median"]) / rw_s["median"]
    paired.append((suffix, rw_s, at_s, speedup, delta_pct))

# ---- CSV ----
csv_path = Path("results.csv")
with csv_path.open("w") as f:
    f.write(
        "workload,rw_median_ns,rw_stddev_ns,atomic_median_ns,atomic_stddev_ns,"
        "speedup_x,latency_reduction_pct\n"
    )
    for suffix, rw, at, sp, dp in paired:
        f.write(
            f"{suffix},{rw['median']:.2f},{rw['stddev']:.2f},"
            f"{at['median']:.2f},{at['stddev']:.2f},"
            f"{sp:.3f},{dp:.2f}\n"
        )

# ---- Markdown table (portable, no external deps) ----
md = ["# RWMutex vs atomic.Pointer — Benchmark Results", ""]
md.append(f"- Runs per configuration: **{paired[0][1]['n']}** (Go `-count=5`)")
md.append(f"- GOMAXPROCS: **2** (sandbox constraint — see note below)")
md.append(f"- Backend endpoints in ring: **32** (each with 100 virtual nodes)")
md.append(f"- Trace-ID generator: xorshift64* per goroutine (no lock contention on RNG)")
md.append("")
md.append("## Latency per lookup (ns/op)")
md.append("")
md.append("| Workload | RWMutex median | RWMutex σ | atomic.Pointer median | atomic.Pointer σ | Speedup | Latency ↓ |")
md.append("|---|---:|---:|---:|---:|---:|---:|")
for suffix, rw, at, sp, dp in paired:
    md.append(
        f"| {suffix} | {rw['median']:.1f} | ±{rw['stddev']:.1f} | "
        f"{at['median']:.1f} | ±{at['stddev']:.1f} | "
        f"**{sp:.2f}×** | **{dp:.1f}%** |"
    )

md.append("")
md.append("## Throughput (ops/sec at median latency, single-goroutine equivalent)")
md.append("")
md.append("| Workload | RWMutex ops/sec | atomic.Pointer ops/sec | Additional ops/sec |")
md.append("|---|---:|---:|---:|")
for suffix, rw, at, sp, dp in paired:
    rw_ops = 1e9 / rw["median"]
    at_ops = 1e9 / at["median"]
    md.append(
        f"| {suffix} | {rw_ops:,.0f} | {at_ops:,.0f} | +{at_ops - rw_ops:,.0f} |"
    )

Path("summary.md").write_text("\n".join(md))
print(f"Wrote {csv_path} and summary.md")
print()
for suffix, rw, at, sp, dp in paired:
    print(
        f"{suffix:>28s}  rw={rw['median']:7.2f} ns  atomic={at['median']:7.2f} ns"
        f"  speedup={sp:5.2f}x  reduction={dp:5.1f}%"
    )
