# RWMutex vs atomic.Pointer — Benchmark Results

- Runs per configuration: **5** (Go `-count=5`)
- GOMAXPROCS: **2** (sandbox constraint — see note below)
- Backend endpoints in ring: **32** (each with 100 virtual nodes)
- Trace-ID generator: xorshift64* per goroutine (no lock contention on RNG)

## Latency per lookup (ns/op)

| Workload | RWMutex median | RWMutex σ | atomic.Pointer median | atomic.Pointer σ | Speedup | Latency ↓ |
|---|---:|---:|---:|---:|---:|---:|
| Workers1 | 184.4 | ±3.6 | 179.9 | ±1.2 | **1.03×** | **2.4%** |
| Workers4 | 165.7 | ±4.8 | 97.3 | ±2.0 | **1.70×** | **41.3%** |
| Workers8 | 161.0 | ±2.0 | 94.3 | ±1.4 | **1.71×** | **41.4%** |
| Workers16 | 154.2 | ±3.6 | 92.1 | ±1.7 | **1.67×** | **40.2%** |
| Workers32 | 147.6 | ±3.5 | 89.0 | ±1.4 | **1.66×** | **39.7%** |
| Workers64 | 153.0 | ±4.9 | 89.5 | ±0.8 | **1.71×** | **41.5%** |
| Workers128 | 154.3 | ±8.2 | 88.8 | ±1.6 | **1.74×** | **42.4%** |
| Workers64_WithWriter | 151.6 | ±3.8 | 91.7 | ±1.0 | **1.65×** | **39.5%** |

## Throughput (ops/sec at median latency, single-goroutine equivalent)

| Workload | RWMutex ops/sec | atomic.Pointer ops/sec | Additional ops/sec |
|---|---:|---:|---:|
| Workers1 | 5,422,993 | 5,558,644 | +135,650 |
| Workers4 | 6,035,003 | 10,278,549 | +4,243,546 |
| Workers8 | 6,211,180 | 10,606,703 | +4,395,523 |
| Workers16 | 6,485,084 | 10,853,050 | +4,367,965 |
| Workers32 | 6,775,068 | 11,238,481 | +4,463,413 |
| Workers64 | 6,535,948 | 11,173,184 | +4,637,237 |
| Workers128 | 6,480,881 | 11,258,726 | +4,777,844 |
| Workers64_WithWriter | 6,596,306 | 10,906,315 | +4,310,009 |