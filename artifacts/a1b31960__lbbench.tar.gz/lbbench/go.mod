module lbbench

go 1.23.4
