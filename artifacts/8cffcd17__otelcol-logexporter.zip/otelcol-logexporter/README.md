# otelcol-logexporter

A minimal, runnable template for building a **custom OpenTelemetry Collector
exporter** in Go and assembling it into a Collector binary using the
[OpenTelemetry Collector Builder (OCB)](https://opentelemetry.io/docs/collector/custom-collector/).

The exporter itself — called `log` — is deliberately simple: for every batch of
OTLP traces it receives, it emits structured log lines through the Collector's
own logger. That makes it a great scaffold for building your own real backend
integration: swap `pushTraces` for whatever your destination needs (HTTP, gRPC,
Kafka, a SaaS SDK, …) and keep everything else.

## Repository layout

```
otelcol-logexporter/
├── exporter/
│   └── logexporter/          # The custom component (its own Go module)
│       ├── go.mod
│       ├── config.go         # Config struct + Validate()
│       ├── factory.go        # NewFactory() + exporterhelper wiring
│       ├── exporter.go       # pushTraces implementation (logs each span)
│       └── factory_test.go   # Smoke tests
├── builder/
│   └── manifest.yaml         # OCB build manifest
├── config.yaml               # Runtime Collector config that uses `log:`
└── README.md
```

The `exporter/logexporter` directory is a **separate Go module** on purpose:
OCB expects each component to be independently `go get`-able, and keeping it
isolated means you can publish just the exporter without dragging in the
Collector distribution's build files.

## Prerequisites

- Go 1.23 or newer.
- `ocb` (the OpenTelemetry Collector Builder). Install the version that matches
  `otelcol_version` in `builder/manifest.yaml`:

  ```bash
  go install go.opentelemetry.io/collector/cmd/builder@v0.155.0
  # The binary is installed as `builder`; the docs call it `ocb`. Either works.
  # Optionally alias it: alias ocb=builder
  ```

  Or grab a prebuilt release from the
  [collector-releases](https://github.com/open-telemetry/opentelemetry-collector-releases/releases)
  page.

## Build the custom Collector

From the repository root:

```bash
# 1. Tidy the exporter module so its go.sum is up to date.
(cd exporter/logexporter && go mod tidy)

# 2. Run OCB against the manifest. This generates ./dist/ containing a
#    fully-formed Collector program that imports your exporter, then compiles
#    it into ./dist/otelcol-custom.
ocb --config builder/manifest.yaml
```

The important bits of `builder/manifest.yaml`:

```yaml
dist:
  name: otelcol-custom
  output_path: ./dist
  otelcol_version: 0.155.0

exporters:
  - gomod: github.com/example/otelcol-logexporter/exporter/logexporter v0.1.0
    path: ../exporter/logexporter        # <- local path replaces the module
  - gomod: go.opentelemetry.io/collector/exporter/debugexporter v0.155.0
```

The `path:` field on the first exporter is what lets OCB pick up your local,
unpublished code. Remove it once you publish the module to a real import path.

## Run it end-to-end

1. **Start the Collector** using the provided `config.yaml`:

   ```bash
   ./dist/otelcol-custom --config config.yaml
   ```

   You should see startup lines including:

   ```
   info    logexporter    log exporter started    {"verbosity": "normal"}
   info    service ...    Everything is ready. Begin running and processing data.
   ```

2. **Send some test traces.** The easiest way is `telemetrygen`:

   ```bash
   go install github.com/open-telemetry/opentelemetry-collector-contrib/cmd/telemetrygen@latest
   telemetrygen traces --otlp-insecure --duration 5s
   ```

   You can also point any OpenTelemetry-instrumented app at `localhost:4317`
   (gRPC) or `localhost:4318` (HTTP).

3. **Watch the exporter log spans.** In the Collector's stdout you'll see one
   line per span with fields like `trace_id`, `span_id`, `name`, `kind`, and
   `duration`. At `verbosity: detailed`, resource + span attributes are
   included too. `verbosity: basic` collapses each batch into a single line —
   useful for high-volume smoke tests.

## Configuration reference

```yaml
exporters:
  log:
    # basic   -> one line per batch
    # normal  -> one line per span with core fields (default)
    # detailed-> one line per span with resource + span attributes
    verbosity: normal

    # Standard exporterhelper knobs; you get these for free.
    timeout: 5s
    sending_queue:
      enabled: true
      num_consumers: 2
      queue_size: 1000
    retry_on_failure:
      enabled: true
      initial_interval: 1s
      max_interval: 10s
      max_elapsed_time: 60s
```

## How the pieces fit together

- `factory.go` calls `exporter.NewFactory(...)` with a
  `component.MustNewType("log")` identifier — that's the string users type
  under `exporters:` in `config.yaml`.
- `createTracesExporter` wraps the concrete implementation with
  `exporterhelper.NewTraces`, which layers timeout, retry, and queue behavior
  on top of your `pushTraces` function. You don't have to implement those
  yourself.
- `exporter.go` holds `pushTraces`, the hot path. It walks
  `ResourceSpans -> ScopeSpans -> Spans` and emits one zap log line per span.
- OCB reads `builder/manifest.yaml`, generates a `main.go` that imports
  `logexporter.NewFactory`, and compiles everything into a single binary.

## Extending to metrics and logs

Add two more create functions in `factory.go`, register them with
`exporter.WithMetrics` and `exporter.WithLogs`, and implement `pushMetrics` /
`pushLogs` in `exporter.go` — the shape mirrors `pushTraces` but iterates over
`pmetric.Metrics` and `plog.Logs` respectively.

## Running the tests

```bash
cd exporter/logexporter
go test ./...
```

## Continuous integration

`.github/workflows/ci.yml` runs the full local cycle on every push and pull
request to `main`:

1. **Tidy check** — runs `go mod tidy` in `exporter/logexporter` and fails if
   `go.mod` / `go.sum` are not already up to date.
2. **Lint** — [`golangci-lint`](https://golangci-lint.run) v2 using the
   checked-in `.golangci.yml`, plus `go vet`.
3. **Unit tests** — `go test -race -covermode=atomic` with the coverage
   profile uploaded as an artifact.
4. **OCB build** — installs
   `go.opentelemetry.io/collector/cmd/builder` at the pinned version and
   runs `ocb --config builder/manifest.yaml`; the resulting binary is
   uploaded as an artifact.
5. **Smoke test** — starts `./dist/otelcol-custom` against the repo's
   `config.yaml`, waits for port `4317`, pushes 50 spans through
   [`telemetrygen`](https://github.com/open-telemetry/opentelemetry-collector-contrib/tree/main/cmd/telemetrygen),
   and asserts three things in the Collector log:
     - `log exporter started` (component wired in),
     - at least a couple of `logexporter` span lines (traces flowed through),
     - no `error` / `fatal` / `panic` lines.

   The Collector log is uploaded as an artifact (`smoke-test-logs`) whether
   the job passes or fails, so you can inspect a broken run without
   reproducing locally.
6. **Binary size check** — see below.

Bumping the Collector version is a one-line change: update `OCB_VERSION` at
the top of `ci.yml` and the pinned `v0.155.0` entries in
`builder/manifest.yaml` together.

### Binary size regression check

Every run records the size of `dist/otelcol-custom` (bytes + human-readable)
as `size.json`, publishes it as a `size-report` workflow artifact, and adds a
summary line to the run's Summary tab.

The **baseline** — the size of the last successful `main` build — lives on a
dedicated orphan branch named `binary-size` (configurable via
`SIZE_BASELINE_BRANCH`). No external service, no artifact-retention gotchas,
and you get a full history via `git log binary-size`.

- **On `main` pushes**: after a successful build, the `binary-size-check` job
  updates `size.json` on the `binary-size` branch. The first successful main
  run seeds the branch as an orphan (no shared history with `main`).
- **On pull requests**: the job fetches the baseline, computes the delta, and
  posts a **sticky comment** on the PR (updated in place on each new push)
  with a table of old vs. new size, absolute delta, and percentage.
- **The 5% gate**: if the PR's binary is more than
  `SIZE_INCREASE_THRESHOLD_PCT` (default `5`) larger than the baseline, the
  job fails the PR check. Adjust the threshold at the top of `ci.yml`.

Example PR comment:

> ## 🚨 Binary size check
>
> Binary grew by 7.42% (threshold: 5%)
>
> | Metric | Value |
> |---|---|
> | New size (`this PR`) | `132456789` bytes (`126.32MiB`) |
> | Baseline (`main`)    | `123211456` bytes (`117.51MiB`) |
> | Delta                | `+8.81MiB` (`7.42%`) |
> | Threshold            | `5%` |

**Notes and gotchas**

- The size job needs `contents: write` (to push the baseline) and
  `pull-requests: write` (to comment). Both are scoped to the
  `binary-size-check` job only — the rest of the workflow stays read-only.
- Pull requests from **forks** run with a read-only `GITHUB_TOKEN` by
  default, so the comment/gate will be skipped for those without failing the
  run. If you need forked-PR enforcement, switch the trigger to
  `pull_request_target` — but read the [GitHub security guidance](https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions)
  first, because that event runs against `main`'s workflow with the target
  repo's write token.
- If you protect the `main` branch with required status checks, add
  `binary-size-check` to the required list to make the gate effective.
- To reset the baseline (e.g. after an intentional big change like adding
  many components), delete the `binary-size` branch; the next successful
  `main` build will seed it again.

## Weekly performance benchmark

A separate workflow — `.github/workflows/benchmark.yml` — runs a **5-minute
trace load test** against `dist/otelcol-custom` every Monday at 13:00 UTC
(9 AM EDT / 8 AM EST) and every time you trigger `workflow_dispatch`. It:

1. Builds `otelcol-custom` with OCB.
2. Runs `benchmarks/scripts/run_benchmark.sh`, which starts the Collector with
   `benchmarks/config/config.bench.yaml`, pushes ~1000 spans/sec via
   `telemetrygen` for 5 minutes, samples CPU/RSS with `pidstat`, and scrapes
   the Collector's internal Prometheus metrics on `:8888`.
3. Emits `benchmarks/reports/latest.json` (per-run summary) and appends
   `benchmarks/history/<yyyy-mm-dd>.json`.
4. Runs `benchmarks/scripts/compare_and_update.py`, which compares the run
   against the rolling baseline (default: mean of the last 4 runs) and writes
   `benchmarks/reports/regressions.json` — empty on green, populated when any
   of `mean_cpu_pct`, `peak_rss_bytes`, `p95_export_latency_ms`, or
   `mean_throughput_sps` deviates by more than **10%** in the bad direction.
5. Commits the refreshed `baseline/` and `history/` back to `main` so next
   week's run compares against fresh data.

**Slack alerting** is intentionally driven by a separate Perplexity scheduled
task (see below) rather than baked into the workflow, so the pipeline needs
no Slack credentials and green runs stay silent. See
[`benchmarks/README.md`](./benchmarks/README.md) for the full metric list and
reset instructions.

## Troubleshooting

- **`ocb: cannot find module`** — make sure the `path:` field in
  `manifest.yaml` is correct relative to the location of `manifest.yaml`
  itself, not the working directory.
- **`unknown exporter type: log`** — you're running an official Collector
  distribution instead of `./dist/otelcol-custom`. Only the OCB-built binary
  has the custom exporter compiled in.
- **Version mismatch errors during `ocb`** — pin every
  `go.opentelemetry.io/collector/...` line in `manifest.yaml` to the same
  `otelcol_version`, and use the matching `v1.x.y` line for `component`,
  `pdata`, and `confmap` modules (they release on a separate cadence).
