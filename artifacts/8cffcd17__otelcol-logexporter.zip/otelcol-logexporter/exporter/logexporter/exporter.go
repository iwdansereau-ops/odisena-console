package logexporter

import (
	"context"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/exporter"
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"go.uber.org/zap"
)

// logExporter is the concrete implementation. It is intentionally small: on
// each batch of traces it writes structured log lines through the Collector's
// own zap logger, which makes the output show up in the standard Collector log
// stream alongside receivers, processors, and other exporters.
type logExporter struct {
	cfg    *Config
	logger *zap.Logger
}

func newLogExporter(cfg *Config, set exporter.Settings) *logExporter {
	return &logExporter{
		cfg:    cfg,
		logger: set.Logger.Named("logexporter"),
	}
}

// start is called once when the Collector starts. No external resources are
// required, so this is a no-op that just announces liveness.
func (e *logExporter) start(_ context.Context, _ component.Host) error {
	e.logger.Info("log exporter started",
		zap.String("verbosity", e.cfg.Verbosity),
	)
	return nil
}

// shutdown is called when the Collector is stopping.
func (e *logExporter) shutdown(_ context.Context) error {
	e.logger.Info("log exporter stopped")
	return nil
}

// Capabilities advertises whether this consumer mutates data. We only read
// spans, so returning false lets the pipeline share the same pdata across
// multiple exporters without an extra copy.
func (e *logExporter) Capabilities() consumer.Capabilities {
	return consumer.Capabilities{MutatesData: false}
}

// pushTraces is the hot path: exporterhelper calls this for every batch that
// has passed timeout, retry, and queue policy.
func (e *logExporter) pushTraces(_ context.Context, td ptrace.Traces) error {
	rss := td.ResourceSpans()

	// Basic verbosity: emit a single line per batch and return.
	if e.cfg.Verbosity == "basic" {
		e.logger.Info("received traces",
			zap.Int("resource_spans", rss.Len()),
			zap.Int("spans", td.SpanCount()),
		)
		return nil
	}

	// Normal / detailed: walk resource -> scope -> span.
	for i := 0; i < rss.Len(); i++ {
		rs := rss.At(i)
		resourceAttrs := attrsToFields(rs.Resource().Attributes(), "resource")

		sss := rs.ScopeSpans()
		for j := 0; j < sss.Len(); j++ {
			ss := sss.At(j)
			scopeName := ss.Scope().Name()

			spans := ss.Spans()
			for k := 0; k < spans.Len(); k++ {
				span := spans.At(k)

				fields := []zap.Field{
					zap.String("scope", scopeName),
					zap.String("trace_id", span.TraceID().String()),
					zap.String("span_id", span.SpanID().String()),
					zap.String("parent_span_id", span.ParentSpanID().String()),
					zap.String("name", span.Name()),
					zap.String("kind", span.Kind().String()),
					zap.Time("start", span.StartTimestamp().AsTime()),
					zap.Time("end", span.EndTimestamp().AsTime()),
					zap.Duration("duration",
						span.EndTimestamp().AsTime().Sub(span.StartTimestamp().AsTime())),
					zap.String("status_code", span.Status().Code().String()),
				}

				if e.cfg.Verbosity == "detailed" {
					fields = append(fields, resourceAttrs...)
					fields = append(fields, attrsToFields(span.Attributes(), "attr")...)
					fields = append(fields, zap.Int("events", span.Events().Len()))
					fields = append(fields, zap.Int("links", span.Links().Len()))
				}

				e.logger.Info("span", fields...)
			}
		}
	}

	return nil
}

// attrsToFields flattens a pcommon.Map into zap fields with a common prefix so
// the log output is grep-friendly (e.g. `resource.service.name=...`).
func attrsToFields(m pcommon.Map, prefix string) []zap.Field {
	fields := make([]zap.Field, 0, m.Len())
	m.Range(func(k string, v pcommon.Value) bool {
		fields = append(fields, zap.String(prefix+"."+k, v.AsString()))
		return true
	})
	return fields
}
