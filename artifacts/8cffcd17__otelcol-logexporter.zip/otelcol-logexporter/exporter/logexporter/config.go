package logexporter

import (
	"errors"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/exporter/exporterhelper"
)

// Config defines the configuration for the log exporter.
//
// It intentionally stays small: this exporter's job is to log every batch of
// OTLP traces it receives so that operators can inspect the pipeline without
// standing up an external backend. Timeout, retry, and sending-queue settings
// are wired through exporterhelper so this component behaves like any other
// production exporter.
type Config struct {
	// Verbosity controls how much detail is emitted per span.
	//   "basic"    -> one log line per batch (counts only)
	//   "normal"   -> one log line per span with core fields
	//   "detailed" -> one log line per span including attributes and events
	Verbosity string `mapstructure:"verbosity"`

	// TimeoutSettings for outgoing "send" (a no-op here, but kept for parity
	// with real exporters and so the standard `timeout:` config key works).
	TimeoutSettings exporterhelper.TimeoutConfig `mapstructure:",squash"`

	// QueueSettings enables the standard `sending_queue:` config block.
	QueueSettings exporterhelper.QueueBatchConfig `mapstructure:"sending_queue"`

	// BackOffConfig enables the standard `retry_on_failure:` config block.
	BackOffConfig exporterhelper.RetryConfig `mapstructure:"retry_on_failure"`
}

// Validate implements component.ConfigValidator.
func (cfg *Config) Validate() error {
	switch cfg.Verbosity {
	case "basic", "normal", "detailed":
		return nil
	default:
		return errors.New(`verbosity must be one of "basic", "normal", "detailed"`)
	}
}

// Ensure the interface is satisfied at compile time.
var _ component.Config = (*Config)(nil)
