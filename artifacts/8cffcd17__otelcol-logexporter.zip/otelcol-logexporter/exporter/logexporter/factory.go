package logexporter

import (
	"context"
	"fmt"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/exporter"
	"go.opentelemetry.io/collector/exporter/exporterhelper"
)

// componentType is the unique identifier for this exporter in Collector
// configuration files. Users reference it as `exporters.log:` in config.yaml.
var componentType = component.MustNewType("log")

const (
	// stability describes the maturity of this component. Alpha is appropriate
	// for a fresh template; bump to Beta / Stable as you harden it.
	stability = component.StabilityLevelAlpha
)

// NewFactory returns a factory for the log exporter. This is the symbol the
// OpenTelemetry Collector Builder (OCB) wires into the generated
// `components.go` file when it sees this module in `manifest.yaml`.
func NewFactory() exporter.Factory {
	return exporter.NewFactory(
		componentType,
		createDefaultConfig,
		exporter.WithTraces(createTracesExporter, stability),
		// To support metrics/logs signals, add:
		//   exporter.WithMetrics(createMetricsExporter, stability),
		//   exporter.WithLogs(createLogsExporter, stability),
	)
}

// createDefaultConfig returns the config struct populated with defaults.
// The Collector calls this before unmarshalling the user's YAML on top.
func createDefaultConfig() component.Config {
	return &Config{
		Verbosity:       "normal",
		TimeoutSettings: exporterhelper.NewDefaultTimeoutConfig(),
		QueueSettings:   exporterhelper.NewDefaultQueueConfig(),
		BackOffConfig:   exporterhelper.NewDefaultRetryConfig(),
	}
}

// createTracesExporter builds a traces exporter and wraps it with
// exporterhelper so it inherits timeout, retry, and queueing behavior for
// free.
func createTracesExporter(
	ctx context.Context,
	set exporter.Settings,
	cfg component.Config,
) (exporter.Traces, error) {
	c, ok := cfg.(*Config)
	if !ok {
		return nil, fmt.Errorf("unexpected config type: %T", cfg)
	}

	le := newLogExporter(c, set)

	return exporterhelper.NewTraces(
		ctx,
		set,
		cfg,
		le.pushTraces,
		exporterhelper.WithStart(le.start),
		exporterhelper.WithShutdown(le.shutdown),
		exporterhelper.WithCapabilities(le.Capabilities()),
		exporterhelper.WithTimeout(c.TimeoutSettings),
		exporterhelper.WithRetry(c.BackOffConfig),
		exporterhelper.WithQueue(c.QueueSettings),
	)
}
