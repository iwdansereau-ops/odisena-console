package logexporter

import (
	"context"
	"testing"

	"go.opentelemetry.io/collector/component/componenttest"
	"go.opentelemetry.io/collector/exporter/exportertest"
)

// TestCreateDefaultConfig verifies the default config passes validation.
func TestCreateDefaultConfig(t *testing.T) {
	cfg := createDefaultConfig().(*Config)
	if err := cfg.Validate(); err != nil {
		t.Fatalf("default config should be valid, got: %v", err)
	}
}

// TestCreateTracesExporter verifies the factory produces a working traces
// exporter that can be started and shut down cleanly.
func TestCreateTracesExporter(t *testing.T) {
	factory := NewFactory()
	cfg := factory.CreateDefaultConfig()

	exp, err := factory.CreateTraces(
		context.Background(),
		exportertest.NewNopSettings(factory.Type()),
		cfg,
	)
	if err != nil {
		t.Fatalf("failed to create traces exporter: %v", err)
	}

	if err := exp.Start(context.Background(), componenttest.NewNopHost()); err != nil {
		t.Fatalf("failed to start exporter: %v", err)
	}
	if err := exp.Shutdown(context.Background()); err != nil {
		t.Fatalf("failed to shut down exporter: %v", err)
	}
}
