module github.com/example/otelcol-logexporter/exporter/logexporter

go 1.23.0

require (
	go.opentelemetry.io/collector/component v1.21.0
	go.opentelemetry.io/collector/consumer v1.21.0
	go.opentelemetry.io/collector/exporter v0.155.0
	go.opentelemetry.io/collector/pdata v1.21.0
	go.uber.org/zap v1.27.0
)
