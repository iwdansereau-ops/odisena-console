# benchmarks/

Weekly performance benchmarking for `otelcol-custom`.

```
benchmarks/
├── config/
│   └── config.bench.yaml        # Collector config used during benchmarks (basic verbosity + :8888 Prometheus)
├── scripts/
│   ├── run_benchmark.sh         # 5-min telemetrygen load; writes reports/latest.json
│   └── compare_and_update.py    # Diff vs. baseline; write regressions.json; refresh baseline
├── baseline/
│   └── baseline.json            # Rolling mean of the last N runs (N=4). The "weekly norm".
├── history/                     # One JSON per successful run (yyyy-mm-dd.json). Used to recompute baseline.
└── reports/
    ├── latest.json              # Most-recent run report (metrics only)
    ├── regressions.json         # Empty {"regressions":[]} on green; populated when >10% deviation
    └── collector.log            # Raw Collector stderr from the most recent run
```

## What gets measured

| Metric | Source | Direction that regresses |
|---|---|---|
| `mean_cpu_pct`         | `pidstat -u -p <pid> 1s` samples, mean of `%CPU` | up |
| `peak_rss_bytes`       | `pidstat -r ... 1s` samples, peak of `RSS`       | up |
| `p95_export_latency_ms`| `otelcol_exporter_send_latency_bucket` histogram scraped from `:8888/metrics` | up |
| `mean_throughput_sps`  | Δ`otelcol_receiver_accepted_spans` / duration     | **down** |

Regression = deviation exceeds `THRESHOLD_PCT` (default `10`) in the bad
direction, compared to the rolling baseline.

## Running locally

```bash
# Build the binary first (or reuse dist/otelcol-custom from CI).
builder --config builder/manifest.yaml

# Install prerequisites once.
sudo apt-get install -y sysstat jq
go install github.com/open-telemetry/opentelemetry-collector-contrib/cmd/telemetrygen@latest

# Run a 60-second smoke benchmark instead of the full 5 minutes.
BENCH_DURATION_SEC=60 bash benchmarks/scripts/run_benchmark.sh
python3 benchmarks/scripts/compare_and_update.py
jq . benchmarks/reports/regressions.json
```

## Automation

- **`.github/workflows/benchmark.yml`** runs every Monday at 13:00 UTC
  (9:00 AM EDT / 8:00 AM EST) and commits the updated `history/` +
  `baseline/baseline.json` back to `main`. Manually triggerable via
  `workflow_dispatch` with custom duration/threshold.
- **A separate Perplexity scheduled task** fetches the freshest
  `regressions.json` from `main` shortly after the workflow finishes and
  DMs the user on Slack **only if** it is non-empty. That decoupling means
  the workflow never depends on Slack credentials and Slack never fires on
  green runs.

## Resetting

- **Rebase the baseline**: `rm benchmarks/baseline/baseline.json` and delete
  the `history/*.json` entries you no longer want to average in, then run the
  benchmark again. The next run seeds fresh state.
- **Change the window size**: bump `BASELINE_WINDOW` in
  `.github/workflows/benchmark.yml` (default `4`, meaning ~1 month of Monday
  runs).
- **Change the threshold**: bump `THRESHOLD_PCT` in the same workflow (default
  `10`) or pass a different value via `workflow_dispatch`.
