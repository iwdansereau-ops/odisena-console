# Environmental Factor Correlation Report

**Window:** last 30 days &nbsp;·&nbsp; **Observations:** 440 &nbsp;·&nbsp; **Metrics analyzed:** 2

## Environmental factors ranked by impact on CI budget stability

Impact score = eta² × 1.5 when Levene's test detects significantly unequal variance across levels (heteroscedastic factors break adaptive threshold gating).

| Rank | Factor | Metric | eta² | Class | Levene p | Kruskal p | Hetero | Impact |
|---:|---|---|---:|:---:|---:|---:|:---:|---:|
| 1 | availability_zone | memory_mib_per_kspans | 0.2152 | large | 3.45e-26 | 0.00103 | ✔ | 0.3228 |
| 2 | instance_type | memory_mib_per_kspans | 0.0660 | medium | 1.19e-12 | 0.317 | ✔ | 0.0990 |
| 3 | hyperthreading | memory_mib_per_kspans | 0.0659 | medium | 1.31e-13 | 0.175 | ✔ | 0.0989 |
| 4 | cpu_governor | memory_mib_per_kspans | 0.0659 | medium | 1.31e-13 | 0.175 | ✔ | 0.0989 |
| 5 | availability_zone | e2e_p99_latency_ms | 0.0404 | small | 1.47e-21 | 0.0234 | ✔ | 0.0606 |
| 6 | region | memory_mib_per_kspans | 0.0342 | small | 3.61e-07 | 0.177 | ✔ | 0.0514 |
| 7 | tenancy | memory_mib_per_kspans | 0.0268 | small | 1.31e-06 | 0.866 | ✔ | 0.0402 |
| 8 | background_tasks | memory_mib_per_kspans | 0.0224 | small | 0.000308 | 0.219 | ✔ | 0.0336 |
| 9 | instance_type | e2e_p99_latency_ms | 0.0112 | small | 1.49e-10 | 0.458 | ✔ | 0.0168 |
| 10 | hyperthreading | e2e_p99_latency_ms | 0.0111 | small | 2.31e-11 | 0.258 | ✔ | 0.0166 |
| 11 | cpu_governor | e2e_p99_latency_ms | 0.0111 | small | 2.31e-11 | 0.258 | ✔ | 0.0166 |
| 12 | region | e2e_p99_latency_ms | 0.0074 | negligible | 5.49e-07 | 0.195 | ✔ | 0.0111 |
| 13 | background_tasks | e2e_p99_latency_ms | 0.0039 | negligible | 0.00202 | 0.445 | ✔ | 0.0059 |
| 14 | cpu_generation | memory_mib_per_kspans | 0.0046 | negligible | 0.0709 | 0.811 | · | 0.0046 |
| 15 | tenancy | e2e_p99_latency_ms | 0.0027 | negligible | 1.25e-05 | 0.94 | ✔ | 0.0040 |

## Recommendations

- 🟢 **availability_zone** on *e2e_p99_latency_ms* — eta²=0.040 (small). Noisiest: `us-west-2c` (CV 6.14%). Quietest: `us-east-1a` (CV 0.73%). **Action:** Pin runners to the quietest AZ (`us-east-1a`) or spread across multiple to average out AZ-level noise.
- 🟢 **instance_type** on *e2e_p99_latency_ms* — eta²=0.011 (small). Noisiest: `m6i.2xlarge` (CV 4.47%). Quietest: `m6i.4xlarge` (CV 0.97%). **Action:** Standardize on the quietest instance type (`m6i.4xlarge`) for perf runners; mixing types adds structural variance.
- 🟢 **hyperthreading** on *e2e_p99_latency_ms* — eta²=0.011 (small). Noisiest: `enabled` (CV 4.47%). Quietest: `disabled` (CV 1.08%). **Action:** Disable SMT/hyperthreading on affected runners — shared execution units cause per-core interference.
- 🔴 **availability_zone** on *memory_mib_per_kspans* — eta²=0.215 (large). Noisiest: `us-west-2c` (CV 6.25%). Quietest: `us-east-1c` (CV 0.81%). **Action:** Pin runners to the quietest AZ (`us-east-1c`) or spread across multiple to average out AZ-level noise.
- 🟡 **instance_type** on *memory_mib_per_kspans* — eta²=0.066 (medium). Noisiest: `m6i.2xlarge` (CV 4.98%). Quietest: `m6i.4xlarge` (CV 0.91%). **Action:** Standardize on the quietest instance type (`m6i.4xlarge`) for perf runners; mixing types adds structural variance.
- 🟡 **hyperthreading** on *memory_mib_per_kspans* — eta²=0.066 (medium). Noisiest: `enabled` (CV 4.98%). Quietest: `disabled` (CV 0.96%). **Action:** Disable SMT/hyperthreading on affected runners — shared execution units cause per-core interference.

## Per-metric factor breakdown

### e2e_p99_latency_ms

#### availability_zone (eta² 0.040, small)
_CV ranges 0.73% (us-east-1a) → 6.14% (us-west-2c). eta² = 0.040 (small). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `us-west-2c` | 7 | 35 | 192.914 | 11.847 | 6.14% | 194.135 | 209.026 |
| `us-west-2a` | 7 | 35 | 190.433 | 2.616 | 1.37% | 190.670 | 193.502 |
| `us-east-1b` | 7 | 35 | 190.745 | 2.222 | 1.17% | 191.075 | 193.316 |
| `us-west-2b` | 7 | 35 | 189.997 | 1.888 | 0.99% | 190.111 | 192.823 |
| `us-east-1c` | 7 | 35 | 189.930 | 1.722 | 0.91% | 190.058 | 192.276 |
| `us-east-1a` | 7 | 35 | 189.987 | 1.395 | 0.73% | 189.788 | 191.818 |

#### instance_type (eta² 0.011, small)
_CV ranges 0.97% (m6i.4xlarge) → 4.47% (m6i.2xlarge). eta² = 0.011 (small). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `m6i.2xlarge` | 14 | 70 | 191.455 | 8.549 | 4.47% | 190.736 | 205.497 |
| `c7g.4xlarge` | 7 | 35 | 190.433 | 2.616 | 1.37% | 190.670 | 193.502 |
| `m6i.4xlarge` | 23 | 115 | 190.263 | 1.853 | 0.97% | 190.285 | 193.090 |

#### hyperthreading (eta² 0.011, small)
_CV ranges 1.08% (disabled) → 4.47% (enabled). eta² = 0.011 (small). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `enabled` | 14 | 70 | 191.455 | 8.549 | 4.47% | 190.736 | 205.497 |
| `disabled` | 30 | 150 | 190.303 | 2.048 | 1.08% | 190.296 | 193.151 |

#### cpu_governor (eta² 0.011, small)
_CV ranges 1.08% (performance) → 4.47% (ondemand). eta² = 0.011 (small). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `ondemand` | 14 | 70 | 191.455 | 8.549 | 4.47% | 190.736 | 205.497 |
| `performance` | 30 | 150 | 190.303 | 2.048 | 1.08% | 190.296 | 193.151 |

#### region (eta² 0.007, negligible)
_CV ranges 0.96% (us-east-1) → 3.74% (us-west-2). eta² = 0.007 (negligible). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `us-west-2` | 21 | 105 | 191.115 | 7.138 | 3.74% | 190.719 | 202.660 |
| `us-east-1` | 21 | 105 | 190.221 | 1.833 | 0.96% | 190.254 | 193.034 |

#### background_tasks (eta² 0.004, negligible)
_CV ranges 1.15% (idle) → 3.24% (active). eta² = 0.004 (negligible). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `active` | 28 | 140 | 190.911 | 6.191 | 3.24% | 190.476 | 201.397 |
| `idle` | 16 | 80 | 190.247 | 2.194 | 1.15% | 190.211 | 193.235 |

#### tenancy (eta² 0.003, negligible)
_CV ranges 1.12% (dedicated) → 3.70% (default). eta² = 0.003 (negligible). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `default` | 21 | 105 | 190.947 | 7.069 | 3.70% | 190.361 | 202.660 |
| `dedicated` | 23 | 115 | 190.416 | 2.131 | 1.12% | 190.481 | 193.178 |

#### cpu_generation (eta² 0.000, negligible)
_CV ranges 1.37% (graviton3) → 2.87% (ice_lake). eta² = 0.000 (negligible)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `ice_lake` | 37 | 185 | 190.714 | 5.465 | 2.87% | 190.376 | 200.546 |
| `graviton3` | 7 | 35 | 190.433 | 2.616 | 1.37% | 190.670 | 193.502 |

#### day_bucket (eta² 0.000, negligible)
_CV ranges 2.66% (weekend) → 2.70% (weekday). eta² = 0.000 (negligible)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `weekday` | 32 | 160 | 190.706 | 5.147 | 2.70% | 190.354 | 198.908 |
| `weekend` | 12 | 60 | 190.573 | 5.071 | 2.66% | 190.476 | 199.452 |


### memory_mib_per_kspans

#### availability_zone (eta² 0.215, large)
_CV ranges 0.81% (us-east-1c) → 6.25% (us-west-2c). eta² = 0.215 (large). Variance differs significantly across levels (Levene p<α). Median differs significantly across levels (Kruskal p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `us-west-2c` | 7 | 35 | 14.438 | 0.902 | 6.25% | 14.514 | 15.920 |
| `us-west-2a` | 7 | 35 | 13.923 | 0.155 | 1.11% | 13.933 | 14.157 |
| `us-west-2b` | 7 | 35 | 13.858 | 0.146 | 1.06% | 13.867 | 14.070 |
| `us-east-1a` | 7 | 35 | 13.920 | 0.135 | 0.97% | 13.906 | 14.161 |
| `us-east-1b` | 7 | 35 | 13.931 | 0.129 | 0.93% | 13.925 | 14.146 |
| `us-east-1c` | 7 | 35 | 13.888 | 0.113 | 0.81% | 13.872 | 14.074 |

#### instance_type (eta² 0.066, medium)
_CV ranges 0.91% (m6i.4xlarge) → 4.98% (m6i.2xlarge). eta² = 0.066 (medium). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `m6i.2xlarge` | 14 | 70 | 14.148 | 0.705 | 4.98% | 13.945 | 15.438 |
| `c7g.4xlarge` | 7 | 35 | 13.923 | 0.155 | 1.11% | 13.933 | 14.157 |
| `m6i.4xlarge` | 23 | 115 | 13.912 | 0.127 | 0.91% | 13.897 | 14.141 |

#### hyperthreading (eta² 0.066, medium)
_CV ranges 0.96% (disabled) → 4.98% (enabled). eta² = 0.066 (medium). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `enabled` | 14 | 70 | 14.148 | 0.705 | 4.98% | 13.945 | 15.438 |
| `disabled` | 30 | 150 | 13.915 | 0.133 | 0.96% | 13.903 | 14.151 |

#### cpu_governor (eta² 0.066, medium)
_CV ranges 0.96% (performance) → 4.98% (ondemand). eta² = 0.066 (medium). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `ondemand` | 14 | 70 | 14.148 | 0.705 | 4.98% | 13.945 | 15.438 |
| `performance` | 30 | 150 | 13.915 | 0.133 | 0.96% | 13.903 | 14.151 |

#### region (eta² 0.034, small)
_CV ranges 0.90% (us-east-1) → 4.20% (us-west-2). eta² = 0.034 (small). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `us-west-2` | 21 | 105 | 14.073 | 0.591 | 4.20% | 13.936 | 15.146 |
| `us-east-1` | 21 | 105 | 13.913 | 0.126 | 0.90% | 13.898 | 14.144 |

#### tenancy (eta² 0.027, small)
_CV ranges 0.99% (dedicated) → 4.20% (default). eta² = 0.027 (small). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `default` | 21 | 105 | 14.062 | 0.591 | 4.20% | 13.900 | 15.146 |
| `dedicated` | 23 | 115 | 13.923 | 0.138 | 0.99% | 13.908 | 14.157 |

#### background_tasks (eta² 0.022, small)
_CV ranges 0.97% (idle) → 3.69% (active). eta² = 0.022 (small). Variance differs significantly across levels (Levene p<α)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `active` | 28 | 140 | 14.037 | 0.517 | 3.69% | 13.926 | 15.022 |
| `idle` | 16 | 80 | 13.905 | 0.135 | 0.97% | 13.899 | 14.146 |

#### cpu_generation (eta² 0.005, negligible)
_CV ranges 1.11% (graviton3) → 3.27% (ice_lake). eta² = 0.005 (negligible)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `ice_lake` | 37 | 185 | 14.001 | 0.458 | 3.27% | 13.900 | 14.890 |
| `graviton3` | 7 | 35 | 13.923 | 0.155 | 1.11% | 13.933 | 14.157 |

#### day_bucket (eta² 0.002, negligible)
_CV ranges 2.98% (weekday) → 3.20% (weekend). eta² = 0.002 (negligible)._

| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `weekend` | 12 | 60 | 14.017 | 0.448 | 3.20% | 13.931 | 14.843 |
| `weekday` | 32 | 160 | 13.978 | 0.417 | 2.98% | 13.903 | 14.808 |


## Methodology

- **eta² (eta-squared):** fraction of total variance in the metric explained by group membership. Cohen's benchmarks: small=0.01, medium=0.06, large=0.14.
- **Levene's test (median-centered):** null hypothesis that all groups have equal variance. p<α ⇒ heteroscedastic ⇒ factor destabilizes CI thresholds.
- **Kruskal-Wallis H-test:** non-parametric alternative to one-way ANOVA for equal medians; robust to the non-normality typical of benchmark data.
- **Impact score:** eta² × 1.5 (heteroscedastic) or ×1.0 (homoscedastic). Ranks factors that both explain a lot of variance AND cause unequal spread — the exact pattern that breaks CV-adaptive gating.
- Groups with fewer than `min_group_size` distinct runs are dropped to prevent single-outlier factor levels from dominating.
