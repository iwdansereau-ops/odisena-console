# OTel Nightly Performance Scorecard

**Overall:** ⚠️ **WARN** (0 fail, 2 warn, 10 pass)

| Metric | Current | Baseline | Drift | Warn | Fail | p | Status |
|---|---:|---:|---:|---:|---:|---:|:---:|
| End-to-end P50 latency | 42.460 ms | 41.443 | +2.45% | 5.00% | 10.00% | 0.00359 | ✅ |
| End-to-end P95 latency | 98.720 ms | 95.043 | +3.87% | 5.00% | 10.00% | 0.000563 | ✅ |
| End-to-end P99 latency | 189.640 ms | 180.786 | +4.90% | 7.00% | 15.00% | 0.00159 | ✅ |
| Sustained throughput (spans/sec) | 19831.000 spans_per_sec | 19992.857 | +0.81% | 5.00% | 10.00% | 0.00211 | ✅ |
| Peak sustainable throughput before refusal | 21528.000 spans_per_sec | 21711.429 | +0.84% | 5.00% | 10.00% | 0.00232 | ✅ |
| CPU cores per 1000 spans/sec | 0.087 cores_per_kspans | 0.082 | +5.79% | 5.00% | 10.00% | 0.00011 | ⚠️ |
| Memory (MiB) per 1000 spans/sec | 14.240 mib_per_kspans | 13.857 | +2.76% | 5.00% | 10.00% | 0.000176 | ✅ |
| Heap allocation bytes per span (GC pressure) | 3119.000 bytes | 2967.857 | +5.09% | 5.00% | 10.00% | 2.02e-07 | ⚠️ |
| Receiver refused spans / sec | 0.000 spans_per_sec | 0.000 | +0.00% | 0.00% | 0.00% | — | ✅ |
| Exporter send-failed spans / sec | 0.000 spans_per_sec | 0.000 | +0.00% | 0.00% | 0.00% | — | ✅ |
| Exporter queue saturation (fraction) | 0.132 ratio | 0.116 | +14.07% | 16.87% | 25.00% | 0.0479 | ✅ |
| Batch send size (P50) - regressions imply inefficient batching | 7924.000 items | 8030.000 | +1.32% | 15.00% | 30.00% | 2e-05 | ✅ |

## Warnings
- **CPU cores per 1000 spans/sec** — drift +5.79% exceeds warn threshold 5.00%
- **Heap allocation bytes per span (GC pressure)** — drift +5.09% exceeds warn threshold 5.00%