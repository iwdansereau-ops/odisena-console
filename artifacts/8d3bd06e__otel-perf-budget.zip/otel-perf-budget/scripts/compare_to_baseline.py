#!/usr/bin/env python3
"""
compare_to_baseline.py
======================
Compares a nightly OTel pipeline benchmark run against the rolling
7-day baseline defined in config/performance-budget.yaml.

Design notes
------------
* Baseline is a **trimmed mean** of the last N successful production runs
  (default N=7 days, trim 10%). Trimming removes the "surprise reboot"
  outliers common on cloud CI (see bheisler.github.io benchmarking study
  and MongoDB perf-team guidance summarized at dev.to/kienmarkdo).
* We refuse to fail on noise: the raw drift threshold is *adapted* upward
  when observed baseline CV would otherwise produce a false-positive rate
  >1% (Codspeed 2025-07 analysis).
* For efficiency metrics we ALSO run Welch's t-test between the run's
  per-sample distribution and the baseline distribution; both the mean
  drift threshold AND p < alpha must be satisfied to fail.
* A canary workload runs first. If canary drifts >canary_max_drift_pct,
  we mark the *entire* nightly as "infra-noise" and exit 0 (don't block).

Exit codes
----------
0 - PASS or WARN (nightly may merge)
1 - FAIL (block merge)
2 - INFRA_NOISE (canary regressed; skip gating, page infra team)
3 - CONFIG or IO error
"""
from __future__ import annotations

import argparse
import json
import math
import os
import statistics
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:
    print("PyYAML required: pip install pyyaml", file=sys.stderr)
    sys.exit(3)

try:
    from scipy import stats  # type: ignore
    HAVE_SCIPY = True
except ImportError:
    HAVE_SCIPY = False


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------
@dataclass
class MetricResult:
    id: str
    title: str
    unit: str
    direction: str
    current: float
    baseline_mean: float
    baseline_cv: float
    drift_pct: float
    effective_warn_pct: float
    effective_fail_pct: float
    p_value: float | None
    status: str  # PASS | WARN | FAIL
    reason: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def trimmed_mean(values: list[float], trim_pct: float) -> float:
    if not values:
        return float("nan")
    if len(values) < 3 or trim_pct <= 0:
        return statistics.fmean(values)
    k = int(len(values) * trim_pct / 100)
    sorted_v = sorted(values)
    trimmed = sorted_v[k : len(sorted_v) - k] if k else sorted_v
    return statistics.fmean(trimmed)


def coefficient_of_variation(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    m = statistics.fmean(values)
    if m == 0:
        return 0.0
    return statistics.stdev(values) / abs(m)


def iqr_filter(values: list[float], k: float = 1.5) -> list[float]:
    if len(values) < 4:
        return values
    s = sorted(values)
    q1 = s[len(s) // 4]
    q3 = s[(3 * len(s)) // 4]
    iqr = q3 - q1
    lo, hi = q1 - k * iqr, q3 + k * iqr
    return [v for v in values if lo <= v <= hi]


def welch_t_p(sample_a: list[float], sample_b: list[float]) -> float | None:
    """Two-sided Welch's t-test p-value. Returns None if scipy missing."""
    if not HAVE_SCIPY or len(sample_a) < 3 or len(sample_b) < 3:
        return None
    result = stats.ttest_ind(sample_a, sample_b, equal_var=False)
    return float(result.pvalue)


def signed_drift(current: float, baseline: float, direction: str) -> float:
    """Return positive drift when the change is BAD, negative when GOOD."""
    if baseline == 0:
        return 0.0
    raw = (current - baseline) / baseline * 100
    return raw if direction == "higher_is_worse" else -raw


# ---------------------------------------------------------------------------
# Adaptive threshold logic
# ---------------------------------------------------------------------------
def adapt_threshold(base_pct: float, cv_pct: float, floor_multiplier: float) -> float:
    """
    Never let the effective threshold drop below floor_multiplier * observed CV.
    E.g. if CV is 4% and base threshold is 5%, floor_multiplier=2 -> 8%.
    This keeps the false-positive rate under ~1% for normal-distributed noise.
    """
    return max(base_pct, floor_multiplier * cv_pct)


# ---------------------------------------------------------------------------
# Core comparison
# ---------------------------------------------------------------------------
def evaluate_metric(
    metric_cfg: dict[str, Any],
    current_samples: list[float],
    baseline_run_means: list[float],
    baseline_all_samples: list[float],
    noise_cfg: dict[str, Any],
) -> MetricResult:
    direction = metric_cfg["direction"]
    warn_pct = float(metric_cfg["warn_pct"])
    fail_pct = float(metric_cfg["fail_pct"])
    floor = float(metric_cfg.get("absolute_floor", 0.0))

    # 1) Clean noise from the current run
    filtered_current = (
        iqr_filter(current_samples, noise_cfg.get("iqr_multiplier", 1.5))
        if noise_cfg.get("outlier_filter") == "iqr"
        else current_samples
    )
    current = statistics.fmean(filtered_current) if filtered_current else float("nan")

    # 2) Baseline aggregate
    if len(baseline_run_means) < int(noise_cfg.get("min_samples_baseline", 5)):
        return MetricResult(
            id=metric_cfg["id"], title=metric_cfg["title"], unit=metric_cfg["unit"],
            direction=direction, current=current, baseline_mean=float("nan"),
            baseline_cv=0.0, drift_pct=0.0,
            effective_warn_pct=warn_pct, effective_fail_pct=fail_pct,
            p_value=None, status="PASS",
            reason="insufficient baseline samples — advisory only",
        )
    baseline = trimmed_mean(
        baseline_run_means, float(noise_cfg.get("trim_pct", 10))
    )
    cv = coefficient_of_variation(baseline_run_means) * 100

    # 3) Adaptive thresholds (never below N * observed CV)
    floor_mult = float(noise_cfg.get("min_threshold_multiplier_of_cv", 2.0))
    eff_warn = adapt_threshold(warn_pct, cv, floor_mult)
    eff_fail = adapt_threshold(fail_pct, cv, floor_mult)

    # 4) Absolute floor: don't alert on near-zero values
    if abs(current) < floor and abs(baseline) < floor:
        return MetricResult(
            id=metric_cfg["id"], title=metric_cfg["title"], unit=metric_cfg["unit"],
            direction=direction, current=current, baseline_mean=baseline,
            baseline_cv=cv, drift_pct=0.0,
            effective_warn_pct=eff_warn, effective_fail_pct=eff_fail,
            p_value=None, status="PASS",
            reason=f"below absolute_floor ({floor} {metric_cfg['unit']})",
        )

    drift = signed_drift(current, baseline, direction)

    # 5) Statistical significance gate (when we have per-sample data)
    p_value = welch_t_p(filtered_current, baseline_all_samples)
    alpha = float(noise_cfg.get("alpha", 0.01))
    significant = (p_value is None) or (p_value < alpha)

    # 6) Verdict
    if drift >= eff_fail and significant:
        status, reason = "FAIL", (
            f"drift {drift:+.2f}% exceeds fail threshold {eff_fail:.2f}% "
            f"(base {fail_pct}%, adapted for CV {cv:.2f}%); "
            f"p={p_value if p_value is not None else 'n/a'}"
        )
    elif drift >= eff_warn:
        status, reason = "WARN", (
            f"drift {drift:+.2f}% exceeds warn threshold {eff_warn:.2f}%"
        )
    else:
        status, reason = "PASS", f"drift {drift:+.2f}% within budget"

    return MetricResult(
        id=metric_cfg["id"], title=metric_cfg["title"], unit=metric_cfg["unit"],
        direction=direction, current=current, baseline_mean=baseline,
        baseline_cv=cv, drift_pct=drift,
        effective_warn_pct=eff_warn, effective_fail_pct=eff_fail,
        p_value=p_value, status=status, reason=reason,
    )


# ---------------------------------------------------------------------------
# Canary
# ---------------------------------------------------------------------------
def canary_ok(canary_current: float, canary_baseline: float, max_pct: float) -> bool:
    if canary_baseline == 0:
        return True
    drift = abs(canary_current - canary_baseline) / canary_baseline * 100
    return drift <= max_pct


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, help="performance-budget.yaml")
    ap.add_argument("--current", required=True, help="current run JSON")
    ap.add_argument("--baseline", required=True, help="baseline history JSON")
    ap.add_argument("--out-json", default="reports/scorecard.json")
    ap.add_argument("--out-md",   default="reports/scorecard.md")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    current = json.loads(Path(args.current).read_text())
    baseline = json.loads(Path(args.baseline).read_text())

    noise_cfg = cfg["noise_control"]
    noise_cfg["min_samples_baseline"] = cfg["baseline"]["min_samples"]
    noise_cfg["trim_pct"] = cfg["baseline"]["trim_pct"]

    # ---- Canary short-circuit ---------------------------------------------
    canary = current.get("canary")
    canary_base = baseline.get("canary")
    if canary is not None and canary_base is not None:
        if not canary_ok(canary, canary_base, float(noise_cfg["canary_max_drift_pct"])):
            payload = {
                "status": "INFRA_NOISE",
                "reason": (
                    f"Canary drifted from {canary_base:.3f} to {canary:.3f}; "
                    f"suspecting CI-infrastructure noise. Nightly NOT gated."
                ),
                "canary_current": canary,
                "canary_baseline": canary_base,
            }
            Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
            Path(args.out_json).write_text(json.dumps(payload, indent=2))
            print(payload["reason"], file=sys.stderr)
            return 2

    # ---- Evaluate each metric ---------------------------------------------
    results: list[MetricResult] = []
    for m in cfg["metrics"]:
        mid = m["id"]
        cur_samples = current["metrics"].get(mid, {}).get("samples", [])
        base_hist = baseline["metrics"].get(mid, {})
        base_run_means = base_hist.get("run_means", [])
        base_all_samples = base_hist.get("all_samples", [])
        if not cur_samples:
            continue
        results.append(evaluate_metric(m, cur_samples, base_run_means, base_all_samples, noise_cfg))

    # ---- Roll up verdict --------------------------------------------------
    fails = [r for r in results if r.status == "FAIL"]
    warns = [r for r in results if r.status == "WARN"]
    overall = "FAIL" if fails else ("WARN" if warns else "PASS")

    payload = {
        "status": overall,
        "commit": os.environ.get("GITHUB_SHA", "local"),
        "run_url": os.environ.get("GITHUB_RUN_URL", ""),
        "results": [asdict(r) for r in results],
        "summary": {"total": len(results), "fail": len(fails), "warn": len(warns)},
    }
    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out_json).write_text(json.dumps(payload, indent=2))

    # ---- Markdown scorecard ----------------------------------------------
    md = ["# OTel Nightly Performance Scorecard", ""]
    icon = {"PASS": "✅", "WARN": "⚠️", "FAIL": "❌"}
    md.append(f"**Overall:** {icon[overall]} **{overall}** "
              f"({len(fails)} fail, {len(warns)} warn, {len(results) - len(fails) - len(warns)} pass)")
    md.append("")
    md.append("| Metric | Current | Baseline | Drift | Warn | Fail | p | Status |")
    md.append("|---|---:|---:|---:|---:|---:|---:|:---:|")
    for r in results:
        p_str = "—" if r.p_value is None else f"{r.p_value:.3g}"
        md.append(
            f"| {r.title} | {r.current:.3f} {r.unit} | {r.baseline_mean:.3f} | "
            f"{r.drift_pct:+.2f}% | {r.effective_warn_pct:.2f}% | "
            f"{r.effective_fail_pct:.2f}% | {p_str} | {icon[r.status]} |"
        )
    md.append("")
    if fails:
        md.append("## Failures")
        for r in fails:
            md.append(f"- **{r.title}** — {r.reason}")
    if warns:
        md.append("## Warnings")
        for r in warns:
            md.append(f"- **{r.title}** — {r.reason}")
    Path(args.out_md).write_text("\n".join(md))

    return 1 if overall == "FAIL" else 0


if __name__ == "__main__":
    sys.exit(main())
