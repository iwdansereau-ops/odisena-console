#!/usr/bin/env python3
"""
Generate a deterministic 7-day synthetic scorecard corpus for testing
analyze_runner_variance.py.

Fleet:
  - perf-runner-01..05 : healthy   (CV ~ 1%)
  - perf-runner-06     : degraded  (CV ~ 6% on CPU/memory/latency)
  - perf-runner-07     : new host  (only 2 runs - INSUFFICIENT_DATA)
"""
from __future__ import annotations

import json
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys

METRICS = [
    ("e2e_p99_latency_ms", 190.0),
    ("sustained_throughput_sps", 20000.0),
    ("cpu_cores_per_kspans", 0.083),
    ("memory_mib_per_kspans", 13.9),
    ("alloc_bytes_per_span", 2970.0),
]

# Per-runner noise profile: (mean_shift_pct, per_sample_cv_pct)
PROFILES = {
    "perf-runner-01": (0.0, 1.0),
    "perf-runner-02": (0.2, 1.1),
    "perf-runner-03": (-0.1, 0.9),
    "perf-runner-04": (0.1, 1.2),
    "perf-runner-05": (-0.2, 1.0),
    "perf-runner-06": (1.5, 6.0),   # <-- noisy neighbor
    "perf-runner-07": (0.0, 1.0),   # healthy but only 2 runs
}


def gen_run(runner: str, day_offset: int, seed: int, out_dir: Path) -> None:
    rng = random.Random(seed)
    shift_pct, cv_pct = PROFILES[runner]
    ts = (datetime(2026, 6, 30, 6, 0, tzinfo=timezone.utc) -
          timedelta(days=day_offset)).isoformat().replace("+00:00", "Z")

    results = []
    for mid, base in METRICS:
        mean = base * (1 + shift_pct / 100)
        std = mean * cv_pct / 100
        samples = [rng.gauss(mean, std) for _ in range(5)]
        results.append({
            "id": mid,
            "current": sum(samples) / len(samples),
            "samples": samples,
            "unit": "n/a",
            "direction": "higher_is_worse",
            "status": "PASS",
        })

    doc = {
        "commit": f"{runner}-{day_offset}",
        "started_at": ts,
        "runner": {"name": runner, "labels": ["self-hosted", "otel-perf-runner"]},
        "results": results,
    }
    out = out_dir / f"scorecard-{runner}-{day_offset}.json"
    out.write_text(json.dumps(doc, indent=2))


def main(out_dir: str) -> int:
    d = Path(out_dir)
    d.mkdir(parents=True, exist_ok=True)
    seed = 42
    for runner in PROFILES:
        # Most runners get 7 daily runs; perf-runner-07 only gets 2 to
        # exercise INSUFFICIENT_DATA handling.
        n_days = 2 if runner == "perf-runner-07" else 7
        for day in range(n_days):
            gen_run(runner, day, seed, d)
            seed += 1
    print(f"Wrote fixtures to {d}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "testdata/scorecards"))
