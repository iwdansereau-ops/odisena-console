#!/usr/bin/env python3
"""
analyze_environmental_factors.py
================================
Join nightly scorecard history with runner cloud-provider metadata, then
rank environmental factors by how much they explain variance in target
metrics (P99 latency, memory-per-kspans, etc.).

Statistical approach
--------------------
For each factor (region, instance_type, hour_bucket, tenancy, ...):

  1. Group scorecard samples by factor level.
  2. Report per-level mean, CV, and n.
  3. Compute eta-squared: fraction of total variance in the metric that
     is between-groups rather than within-groups. This is the primary
     "impact score" — 0 means the factor explains nothing, 1 means it
     explains everything. Cohen's classification:
        small  eta^2 >= 0.01
        medium eta^2 >= 0.06
        large  eta^2 >= 0.14
  4. Levene's test for equal variance (is the *spread* different across
     levels?) — matters because CI stability depends on consistent
     variance, not just consistent means.
  5. Kruskal-Wallis H-test for equal medians — a non-parametric check
     that doesn't assume normality (benchmark data rarely is).
  6. Impact ranking = eta-squared × (Levene significant ? 1.5 : 1.0),
     boosting factors that cause heteroscedasticity because those are
     the ones that break adaptive thresholding.

Outputs
-------
    reports/environmental/environmental_factors.json
    reports/environmental/environmental_factors.md

Exit codes
----------
    0  Ran successfully (report may recommend action).
    2  No scorecards or metadata usable — nothing to analyze.
    3  Config error.
"""
from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

try:
    import yaml
except ImportError:
    print("PyYAML required: pip install pyyaml", file=sys.stderr)
    sys.exit(3)

try:
    from scipy import stats  # type: ignore
    HAVE_SCIPY = True
except ImportError:
    HAVE_SCIPY = False


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------
@dataclass
class LevelStats:
    level: str
    n_runs: int
    n_samples: int
    mean: float
    stdev: float
    cv_pct: float
    p50: float
    p95: float


@dataclass
class FactorAnalysis:
    factor: str
    metric: str
    levels: list[LevelStats]
    eta_squared: float
    eta_squared_class: str      # negligible | small | medium | large
    levene_p: float | None       # variance equality test
    kruskal_p: float | None      # median equality test
    heteroscedastic: bool
    impact_score: float          # composite ranking metric
    interpretation: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def parse_ts(ts: str) -> datetime:
    if ts.endswith("Z"):
        ts = ts[:-1] + "+00:00"
    return datetime.fromisoformat(ts)


def cv_pct(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    m = statistics.fmean(values)
    if m == 0:
        return 0.0
    return statistics.stdev(values) / abs(m) * 100.0


def percentile(sorted_values: list[float], p: float) -> float:
    if not sorted_values:
        return 0.0
    if len(sorted_values) == 1:
        return sorted_values[0]
    k = (len(sorted_values) - 1) * p
    f = int(k)
    c = min(f + 1, len(sorted_values) - 1)
    return sorted_values[f] + (sorted_values[c] - sorted_values[f]) * (k - f)


def eta_squared(groups: list[list[float]]) -> float:
    """Fraction of total variance explained by group membership."""
    all_values = [v for g in groups for v in g]
    if len(all_values) < 2 or len(groups) < 2:
        return 0.0
    grand_mean = statistics.fmean(all_values)
    ss_total = sum((v - grand_mean) ** 2 for v in all_values)
    if ss_total == 0:
        return 0.0
    ss_between = sum(
        len(g) * (statistics.fmean(g) - grand_mean) ** 2
        for g in groups if g
    )
    return ss_between / ss_total


def classify_eta(eta: float, thresholds: dict[str, float]) -> str:
    if eta >= thresholds["large"]:
        return "large"
    if eta >= thresholds["medium"]:
        return "medium"
    if eta >= thresholds["small"]:
        return "small"
    return "negligible"


def levene_p(groups: list[list[float]]) -> float | None:
    if not HAVE_SCIPY or len(groups) < 2 or any(len(g) < 2 for g in groups):
        return None
    try:
        return float(stats.levene(*groups, center="median").pvalue)
    except Exception:
        return None


def kruskal_p(groups: list[list[float]]) -> float | None:
    if not HAVE_SCIPY or len(groups) < 2:
        return None
    if sum(len(g) for g in groups) < 5:
        return None
    try:
        return float(stats.kruskal(*groups).pvalue)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Loading & joining
# ---------------------------------------------------------------------------
def load_scorecards(input_dir: Path, window_days: int) -> list[dict[str, Any]]:
    cutoff = datetime.now(timezone.utc) - timedelta(days=window_days)
    out: list[dict[str, Any]] = []
    for p in sorted(input_dir.rglob("*.json")):
        try:
            doc = json.loads(p.read_text())
        except (json.JSONDecodeError, OSError):
            continue
        if "runner" not in doc or "results" not in doc:
            continue
        started = doc.get("started_at")
        if not started:
            continue
        try:
            if parse_ts(started) < cutoff:
                continue
        except ValueError:
            continue
        out.append(doc)
    return out


def load_metadata(config_path: Path) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    doc = yaml.safe_load(config_path.read_text()) or {}
    runners = {r["name"]: r for r in doc.get("runners", [])}
    settings = doc.get("environmental_analysis", {})
    return runners, settings


def hour_bucket(started_at: str, buckets: list[dict[str, Any]]) -> str:
    """Map a UTC RFC-3339 timestamp to a named hour window."""
    try:
        h = parse_ts(started_at).astimezone(timezone.utc).hour
    except ValueError:
        return "unknown"
    for b in buckets:
        if b["start"] <= h < b["end"]:
            return b["name"]
    return "unknown"


def day_bucket(started_at: str, grouping: str) -> str:
    try:
        dow = parse_ts(started_at).astimezone(timezone.utc).weekday()
    except ValueError:
        return "unknown"
    if grouping == "weekday_weekend":
        return "weekend" if dow >= 5 else "weekday"
    return ["mon", "tue", "wed", "thu", "fri", "sat", "sun"][dow]


def background_tasks_active(runner_meta: dict[str, Any], started_at: str) -> str:
    """Return 'active' if any cron-scheduled background task ran within +-1h of started_at."""
    try:
        t = parse_ts(started_at).astimezone(timezone.utc)
    except ValueError:
        return "unknown"
    for task in runner_meta.get("background_tasks", []) or []:
        sched = task.get("schedule", "")
        if sched == "continuous":
            return "active"
        # Very small cron subset: "M H * * *" or "*/N * * * *"
        parts = sched.split()
        if len(parts) == 5:
            m_field, h_field = parts[0], parts[1]
            if h_field.isdigit():
                task_hour = int(h_field)
                delta = abs(t.hour - task_hour)
                delta = min(delta, 24 - delta)   # circular distance
                if delta <= 1:
                    return "active"
    return "idle"


def build_observations(
    scorecards: list[dict[str, Any]],
    runners: dict[str, dict[str, Any]],
    settings: dict[str, Any],
    target_metrics: list[str],
) -> list[dict[str, Any]]:
    """One observation per (scorecard, metric, sample) with all factor labels."""
    obs: list[dict[str, Any]] = []
    time_buckets = settings.get("time_of_day_buckets", [])
    dow_grouping = settings.get("day_of_week_grouping", "weekday_weekend")

    for sc in scorecards:
        rname = sc["runner"].get("name", "unknown")
        meta = runners.get(rname, {})
        started = sc.get("started_at", "")

        factors = {
            "runner": rname,
            "instance_type":   meta.get("instance_type", "unknown"),
            "region":          meta.get("region", "unknown"),
            "availability_zone": meta.get("availability_zone", "unknown"),
            "tenancy":         meta.get("tenancy", "unknown"),
            "cpu_generation":  meta.get("cpu_generation", "unknown"),
            "hyperthreading":  meta.get("hyperthreading", "unknown"),
            "cpu_governor":    meta.get("cpu_governor", "unknown"),
            "hour_bucket":     hour_bucket(started, time_buckets),
            "day_bucket":      day_bucket(started, dow_grouping),
            "background_tasks": background_tasks_active(meta, started),
        }

        for r in sc.get("results", []):
            if r["id"] not in target_metrics:
                continue
            samples = r.get("samples") or ([r["current"]] if "current" in r else [])
            for s in samples:
                obs.append({
                    "metric": r["id"],
                    "value": float(s),
                    "started_at": started,
                    **factors,
                })
    return obs


# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------
FACTORS = [
    "region",
    "availability_zone",
    "instance_type",
    "tenancy",
    "cpu_generation",
    "hyperthreading",
    "cpu_governor",
    "hour_bucket",
    "day_bucket",
    "background_tasks",
]


def analyze_factor(
    factor: str,
    metric: str,
    observations: list[dict[str, Any]],
    settings: dict[str, Any],
) -> FactorAnalysis | None:
    min_n = int(settings.get("min_group_size", 3))
    alpha = float(settings.get("significance_alpha", 0.01))
    eta_thresholds = settings.get("effect_size_thresholds",
                                  {"small": 0.01, "medium": 0.06, "large": 0.14})

    # Bucket samples by level
    buckets: dict[str, list[float]] = defaultdict(list)
    runs_per_level: dict[str, set[str]] = defaultdict(set)
    for o in observations:
        if o["metric"] != metric:
            continue
        level = o[factor]
        buckets[level].append(o["value"])
        runs_per_level[level].add(o["started_at"] + "|" + o["runner"])

    # Drop tiny groups
    buckets = {
        lvl: vals for lvl, vals in buckets.items()
        if lvl != "unknown" and len(runs_per_level[lvl]) >= min_n
    }
    if len(buckets) < 2:
        return None

    # Per-level stats
    level_rows: list[LevelStats] = []
    for lvl, vals in buckets.items():
        sv = sorted(vals)
        level_rows.append(LevelStats(
            level=lvl,
            n_runs=len(runs_per_level[lvl]),
            n_samples=len(vals),
            mean=statistics.fmean(vals),
            stdev=statistics.stdev(vals) if len(vals) > 1 else 0.0,
            cv_pct=cv_pct(vals),
            p50=percentile(sv, 0.5),
            p95=percentile(sv, 0.95),
        ))
    level_rows.sort(key=lambda r: r.cv_pct, reverse=True)

    # Tests
    groups = list(buckets.values())
    eta = eta_squared(groups)
    eta_class = classify_eta(eta, eta_thresholds)
    lev_p = levene_p(groups)
    krus_p = kruskal_p(groups)

    hetero = (lev_p is not None) and (lev_p < alpha)
    impact = eta * (1.5 if hetero else 1.0)

    # Human-readable interpretation
    cv_min = min(r.cv_pct for r in level_rows)
    cv_max = max(r.cv_pct for r in level_rows)
    hi_lvl = next(r for r in level_rows if r.cv_pct == cv_max)
    lo_lvl = next(r for r in level_rows if r.cv_pct == cv_min)
    interp = (
        f"CV ranges {cv_min:.2f}% ({lo_lvl.level}) → {cv_max:.2f}% ({hi_lvl.level}). "
        f"eta² = {eta:.3f} ({eta_class})."
    )
    if hetero:
        interp += " Variance differs significantly across levels (Levene p<α)."
    if krus_p is not None and krus_p < alpha:
        interp += " Median differs significantly across levels (Kruskal p<α)."

    return FactorAnalysis(
        factor=factor,
        metric=metric,
        levels=level_rows,
        eta_squared=eta,
        eta_squared_class=eta_class,
        levene_p=lev_p,
        kruskal_p=krus_p,
        heteroscedastic=hetero,
        impact_score=impact,
        interpretation=interp,
    )


def analyze_all(
    observations: list[dict[str, Any]],
    settings: dict[str, Any],
    target_metrics: list[str],
) -> dict[str, list[FactorAnalysis]]:
    out: dict[str, list[FactorAnalysis]] = {}
    for metric in target_metrics:
        rows: list[FactorAnalysis] = []
        for factor in FACTORS:
            fa = analyze_factor(factor, metric, observations, settings)
            if fa:
                rows.append(fa)
        rows.sort(key=lambda r: r.impact_score, reverse=True)
        out[metric] = rows
    return out


# ---------------------------------------------------------------------------
# Recommendations
# ---------------------------------------------------------------------------
def recommend(analyses: dict[str, list[FactorAnalysis]]) -> list[str]:
    """Distill actionable recommendations from the top-ranked factors."""
    recs: list[str] = []
    seen: set[str] = set()

    for metric, rows in analyses.items():
        for fa in rows[:3]:  # top-3 factors per metric
            if fa.eta_squared_class == "negligible":
                continue
            key = f"{fa.factor}:{fa.metric}"
            if key in seen:
                continue
            seen.add(key)

            # Find the noisiest level to name it explicitly
            noisiest = fa.levels[0]  # already sorted by CV desc
            quietest = fa.levels[-1]

            action = _factor_action(fa.factor, noisiest.level, quietest.level, fa.metric)
            severity = "🔴" if fa.eta_squared_class == "large" else ("🟡" if fa.eta_squared_class == "medium" else "🟢")
            recs.append(
                f"{severity} **{fa.factor}** on *{fa.metric}* — "
                f"eta²={fa.eta_squared:.3f} ({fa.eta_squared_class}). "
                f"Noisiest: `{noisiest.level}` (CV {noisiest.cv_pct:.2f}%). "
                f"Quietest: `{quietest.level}` (CV {quietest.cv_pct:.2f}%). "
                f"**Action:** {action}"
            )
    if not recs:
        recs.append("✅ No environmental factor exceeds Cohen's small-effect threshold. "
                    "Fleet appears well-homogenized.")
    return recs


def _factor_action(factor: str, noisy: str, quiet: str, metric: str) -> str:
    if factor == "tenancy":
        return (f"Migrate `{noisy}`-tenancy runners to dedicated tenancy — "
                "shared tenancy exposes you to noisy-neighbor variance.")
    if factor == "hyperthreading":
        if noisy == "enabled":
            return "Disable SMT/hyperthreading on affected runners — shared execution units cause per-core interference."
        return "Investigate why SMT-disabled runners are noisier (unexpected — usually the reverse)."
    if factor == "cpu_governor":
        if noisy != "performance":
            return f"Set CPU governor to `performance` (currently `{noisy}`) to eliminate frequency scaling."
        return "Governor already `performance`; investigate other sources."
    if factor == "hour_bucket":
        return (f"Reschedule nightly runs away from `{noisy}` window "
                f"(consider `{quiet}` instead) or investigate what runs at that time.")
    if factor == "day_bucket":
        return f"Weekday/weekend variance detected — check for weekly maintenance jobs on runners."
    if factor == "background_tasks":
        return "Quiesce or reschedule background tasks (security scans, log shippers) around nightly perf windows."
    if factor == "region":
        return f"Consolidate perf-runners in the quietest region (`{quiet}`); cross-region variance suggests different underlying capacity."
    if factor == "availability_zone":
        return f"Pin runners to the quietest AZ (`{quiet}`) or spread across multiple to average out AZ-level noise."
    if factor == "instance_type":
        return f"Standardize on the quietest instance type (`{quiet}`) for perf runners; mixing types adds structural variance."
    if factor == "cpu_generation":
        return f"Retire runners on `{noisy}` CPUs in favor of `{quiet}`; different microarchitectures behave differently under the same workload."
    return "Investigate."


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------
def write_reports(
    analyses: dict[str, list[FactorAnalysis]],
    obs_count: int,
    window_days: int,
    out_md: Path,
    out_json: Path,
    target_metrics: list[str],
) -> None:
    md: list[str] = ["# Environmental Factor Correlation Report", ""]
    md.append(f"**Window:** last {window_days} days &nbsp;·&nbsp; "
              f"**Observations:** {obs_count} &nbsp;·&nbsp; "
              f"**Metrics analyzed:** {len(target_metrics)}")
    md.append("")

    # Overall ranking (across all target metrics)
    combined: list[FactorAnalysis] = []
    for rows in analyses.values():
        combined.extend(rows)
    combined.sort(key=lambda r: r.impact_score, reverse=True)

    md.append("## Environmental factors ranked by impact on CI budget stability")
    md.append("")
    md.append("Impact score = eta² × 1.5 when Levene's test detects "
              "significantly unequal variance across levels (heteroscedastic factors "
              "break adaptive threshold gating).")
    md.append("")
    md.append("| Rank | Factor | Metric | eta² | Class | Levene p | Kruskal p | Hetero | Impact |")
    md.append("|---:|---|---|---:|:---:|---:|---:|:---:|---:|")
    for i, fa in enumerate(combined[:15], 1):
        lev = "—" if fa.levene_p is None else f"{fa.levene_p:.3g}"
        kru = "—" if fa.kruskal_p is None else f"{fa.kruskal_p:.3g}"
        het = "✔" if fa.heteroscedastic else "·"
        md.append(f"| {i} | {fa.factor} | {fa.metric} | {fa.eta_squared:.4f} | "
                  f"{fa.eta_squared_class} | {lev} | {kru} | {het} | {fa.impact_score:.4f} |")
    md.append("")

    # Recommendations
    md.append("## Recommendations")
    md.append("")
    for rec in recommend(analyses):
        md.append(f"- {rec}")
    md.append("")

    # Per-metric breakdown
    md.append("## Per-metric factor breakdown")
    md.append("")
    for metric in target_metrics:
        rows = analyses.get(metric, [])
        if not rows:
            md.append(f"### {metric}")
            md.append("_No factors met the min-group-size threshold._")
            md.append("")
            continue
        md.append(f"### {metric}")
        md.append("")
        for fa in rows:
            md.append(f"#### {fa.factor} (eta² {fa.eta_squared:.3f}, {fa.eta_squared_class})")
            md.append(f"_{fa.interpretation}_")
            md.append("")
            md.append("| Level | Runs | Samples | Mean | Stdev | CV | P50 | P95 |")
            md.append("|---|---:|---:|---:|---:|---:|---:|---:|")
            for L in fa.levels:
                md.append(f"| `{L.level}` | {L.n_runs} | {L.n_samples} | "
                          f"{L.mean:.3f} | {L.stdev:.3f} | {L.cv_pct:.2f}% | "
                          f"{L.p50:.3f} | {L.p95:.3f} |")
            md.append("")
        md.append("")

    md.append("## Methodology")
    md.append("")
    md.append("- **eta² (eta-squared):** fraction of total variance in the metric "
              "explained by group membership. Cohen's benchmarks: small=0.01, medium=0.06, large=0.14.")
    md.append("- **Levene's test (median-centered):** null hypothesis that all groups "
              "have equal variance. p<α ⇒ heteroscedastic ⇒ factor destabilizes CI thresholds.")
    md.append("- **Kruskal-Wallis H-test:** non-parametric alternative to one-way ANOVA "
              "for equal medians; robust to the non-normality typical of benchmark data.")
    md.append("- **Impact score:** eta² × 1.5 (heteroscedastic) or ×1.0 (homoscedastic). "
              "Ranks factors that both explain a lot of variance AND cause unequal spread — "
              "the exact pattern that breaks CV-adaptive gating.")
    md.append("- Groups with fewer than `min_group_size` distinct runs are dropped to prevent "
              "single-outlier factor levels from dominating.")

    out_md.parent.mkdir(parents=True, exist_ok=True)
    out_md.write_text("\n".join(md) + "\n")

    payload = {
        "window_days": window_days,
        "observations": obs_count,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "target_metrics": target_metrics,
        "ranking": [asdict(fa) for fa in combined],
        "per_metric": {m: [asdict(fa) for fa in rows] for m, rows in analyses.items()},
        "recommendations": recommend(analyses),
    }
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(payload, indent=2, default=str))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.strip().split("\n")[0])
    ap.add_argument("--input-dir", required=True, type=Path,
                    help="Directory of scorecard*.json (recursive).")
    ap.add_argument("--metadata", required=True, type=Path,
                    help="runner_metadata.yaml describing each runner.")
    ap.add_argument("--window-days", type=int, default=None,
                    help="Days of history to consider (default 30).")
    ap.add_argument("--target-metrics", nargs="*", default=None,
                    help="Override target metrics list from config.")
    ap.add_argument("--out-json", type=Path,
                    default=Path("reports/environmental/environmental_factors.json"))
    ap.add_argument("--out-md", type=Path,
                    default=Path("reports/environmental/environmental_factors.md"))
    args = ap.parse_args()

    if not args.metadata.exists():
        print(f"Metadata file not found: {args.metadata}", file=sys.stderr)
        return 3

    runners, settings = load_metadata(args.metadata)
    if not runners:
        print("No runners in metadata file.", file=sys.stderr)
        return 3

    window_days = args.window_days or settings.get("window_days", 30)
    target_metrics = args.target_metrics or settings.get(
        "target_metrics", ["e2e_p99_latency_ms", "memory_mib_per_kspans"]
    )

    scorecards = load_scorecards(args.input_dir, window_days)
    if not scorecards:
        print(f"No scorecards in {args.input_dir} within {window_days}d.", file=sys.stderr)
        return 2

    obs = build_observations(scorecards, runners, settings, target_metrics)
    if not obs:
        print("No observations produced — none of the target metrics were present.",
              file=sys.stderr)
        return 2

    analyses = analyze_all(obs, settings, target_metrics)
    write_reports(analyses, len(obs), window_days, args.out_md, args.out_json, target_metrics)

    if not HAVE_SCIPY:
        print("warn: scipy not installed — Levene/Kruskal p-values omitted.",
              file=sys.stderr)

    # Console summary
    ranked = sorted(
        [fa for rows in analyses.values() for fa in rows],
        key=lambda r: r.impact_score, reverse=True,
    )
    large = [fa for fa in ranked if fa.eta_squared_class == "large"]
    medium = [fa for fa in ranked if fa.eta_squared_class == "medium"]
    print(f"Factors with large effect: {len(large)}; medium: {len(medium)}; "
          f"total ranked: {len(ranked)} ({len(scorecards)} scorecards, "
          f"{len(obs)} observations, {window_days}d)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
