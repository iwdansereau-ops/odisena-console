# OTel Tuner — GitHub Action

Analyze an OpenTelemetry Collector configuration against a workload budget
and post a diagnostic report as a pull-request comment.

The action extracts every network exporter's `sending_queue` and
`retry_on_failure` settings, cross-references them against your declared
throughput, batch size, backend latency, and memory budget, and flags queue
saturation and memory over-allocation risks before they reach production.

The sizing rules follow the community exporterhelper guidance:

- `num_consumers ≈ ceil(req/s × latency × 1.5)` — Little's Law with a 1.5× safety margin
- `queue_size ≈ req/s × outage_buffer_seconds` — how many seconds of ingest to absorb during a backend stall
- `memory ≈ queue × batch × bytes_per_event + consumer overhead + 10%`
- Retry window bounded to the queue depth so re-enqueued requests don't compete with fresh arrivals

## Usage

```yaml
# .github/workflows/otel-config-check.yml
name: OTel config check

on:
  pull_request:
    paths:
      - "collector/**.yaml"
      - "**/otel-collector*.yaml"

permissions:
  contents: read
  pull-requests: write   # required to post/update the PR comment

jobs:
  analyze:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Analyze OTel Collector config
        uses: your-org/otel-tuner-action@v1
        with:
          config-path: collector/otel-collector.yaml
          throughput: 10000        # events / second
          batch-size: 512          # items / request
          latency-ms: 250          # backend P50 latency
          memory-mb: 512           # queue memory budget
          # optional:
          bytes-per-event: 500
          buffer-seconds: 30
          fail-on: danger          # 'danger' | 'warn' | 'never'
```

The action:

1. Parses the config (env placeholders like `${env:TOKEN}` are handled).
2. Extracts each exporter's `sending_queue` and `retry_on_failure` block.
3. Computes recommended values from the workload budget.
4. Emits a table + per-exporter findings to the job summary and as a PR comment.
5. Exits non-zero when `fail-on` severity is present (defaults to `danger`).

Re-running the workflow **updates the existing comment in place** — no comment spam.

## Inputs

| Name | Required | Default | Description |
| --- | --- | --- | --- |
| `config-path` | ✓ | — | Path to the Collector YAML file to analyze. |
| `throughput` | ✓ | — | Target throughput in events per second. |
| `batch-size` | ✓ | — | Average items per request. |
| `latency-ms` | ✓ | — | Expected backend P50 latency in ms. |
| `memory-mb` | ✓ | — | Memory budget for the queue, in MB. |
| `bytes-per-event` | | `500` | Estimated serialized bytes per event. |
| `buffer-seconds` | | `30` | Outage window the queue should absorb. |
| `comment-on-pr` | | `true` | Post/update a PR comment. |
| `fail-on` | | `danger` | Exit non-zero on `danger`, `warn`, or `never`. |
| `github-token` | | `${{ github.token }}` | Token used to post the comment. |

## Outputs

| Name | Description |
| --- | --- |
| `status` | `ok`, `warn`, or `critical`. |
| `danger_count` | Number of critical diagnostics. |
| `warn_count` | Number of warning diagnostics. |
| `ok_count` | Number of passing checks. |
| `exporter_count` | Number of network exporters analyzed. |
| `report-path` | Path to the Markdown report inside `$RUNNER_TEMP`. |
| `json-path` | Path to the JSON report inside `$RUNNER_TEMP`. |

## Diagnostic codes

| Code | Level | What it flags |
| --- | --- | --- |
| `queue_disabled` | critical | `sending_queue.enabled: false` on a network exporter. |
| `queue_size_zero` | critical | `queue_size: 0` — permanently blocks the exporter. |
| `drain_underprovisioned` | critical | `num_consumers / latency` cannot keep up with ingest. |
| `memory_over_budget` | critical | Queue × batch × bytes exceeds the declared memory budget. |
| `drain_tight` | warn | Consumer pool has <30% burst headroom. |
| `memory_tight` | warn | Queue uses >75% of the memory budget. |
| `outage_tolerance_low` / `outage_tolerance_short` | critical / warn | Queue fills in seconds during a backend stall. |
| `queue_consumer_ratio` | warn | `queue_size / num_consumers` < 4 — consumers may idle. |
| `retry_window_mismatch` | warn | `retry_on_failure.max_elapsed_time` outlives queue depth. |
| `retry_disabled` | warn | `retry_on_failure.enabled: false` on a network exporter. |
| `timeout_too_short` | warn | Exporter `timeout` < 2× backend latency. |
| `compression_off` | warn | Network exporter without `compression: gzip`. |
| `consumers_high` | warn | `num_consumers ≥ 100` — may overwhelm the backend pool. |

## Example PR comment

> ### OTel exporterhelper diagnostic
>
> **Config:** `collector/otel-collector.yaml` — ❌ **3 critical**, 1 warnings
>
> **Workload budget**
> - Throughput: `10,000` events/s · Avg batch: `512` · Backend latency: `250ms` · Memory budget: `512 MB` · Outage buffer: `30s`
>
> | Exporter | Consumers | Queue | Memory | Drain | Status |
> | --- | --- | --- | --- | --- | --- |
> | `otlp/backend` | 2 (rec 8) | 50000 requests (rec 586 req) | 13.4 GB (2623%) | 41% | ❌ |
>
> - ❌ **Consumers cannot keep up (41% of ingest)** — `num_consumers=2` at 250ms latency drains ~8 req/s but ingest is 20 req/s. Recommend `num_consumers=8`.
> - ❌ **Memory footprint exceeds budget (2623%)** — Estimated 13.4 GB vs 512 MB. Recommend `queue_size=586` or enable persistent storage.
> - ⚠️ **Compression not enabled** — Recommend `compression: gzip`.

## Matrix example — validate several configs at once

```yaml
jobs:
  analyze:
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        target:
          - { path: collector/gateway.yaml,   throughput: 50000, batch: 1024, latency: 400, memory: 1024 }
          - { path: collector/agent.yaml,     throughput: 5000,  batch: 256,  latency: 150, memory: 256  }
    steps:
      - uses: actions/checkout@v4
      - uses: your-org/otel-tuner-action@v1
        with:
          config-path: ${{ matrix.target.path }}
          throughput: ${{ matrix.target.throughput }}
          batch-size: ${{ matrix.target.batch }}
          latency-ms: ${{ matrix.target.latency }}
          memory-mb: ${{ matrix.target.memory }}
```

## Local usage

The analyzer is a plain Python script — you can run it outside CI:

```bash
pip install pyyaml
python scripts/analyze.py \
  --config examples/collector-bad.yaml \
  --throughput 10000 --batch-size 512 \
  --latency-ms 250 --memory-mb 512 \
  --md-out report.md --json-out report.json
```

## Testing

```bash
pip install pyyaml
python -m unittest discover -s tests -v
```

## License

MIT
