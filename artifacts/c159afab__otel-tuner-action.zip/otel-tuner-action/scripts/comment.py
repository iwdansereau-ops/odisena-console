#!/usr/bin/env python3
"""
Upsert a PR comment. Finds an existing comment authored by github-actions[bot]
containing the marker string and edits it in place; otherwise creates a new one.

Uses only the standard library so no extra pip install is needed.
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request

MARKER = "<!-- otel-tuner-action:comment -->"


def _api(method: str, url: str, token: str, body: dict | None = None) -> dict | list:
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("X-GitHub-Api-Version", "2022-11-28")
    req.add_header("User-Agent", "otel-tuner-action")
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        raise SystemExit(f"GitHub API {method} {url} failed: {e.code} {detail}")


def main() -> int:
    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        print("ERROR: GITHUB_TOKEN not set — cannot post PR comment.", file=sys.stderr)
        return 2

    event_path = os.environ.get("GITHUB_EVENT_PATH")
    repo = os.environ.get("GITHUB_REPOSITORY")
    if not event_path or not repo:
        print("ERROR: GITHUB_EVENT_PATH / GITHUB_REPOSITORY not set.", file=sys.stderr)
        return 2

    body_path = os.environ.get("OTEL_TUNER_MARKDOWN")
    if not body_path or not os.path.exists(body_path):
        print(f"ERROR: markdown body not found at {body_path}", file=sys.stderr)
        return 2

    with open(event_path, "r", encoding="utf-8") as f:
        event = json.load(f)

    pr_number = None
    if isinstance(event.get("pull_request"), dict):
        pr_number = event["pull_request"].get("number")
    if pr_number is None:
        pr_number = event.get("number")
    if pr_number is None:
        print("Not a pull_request event — skipping comment.")
        return 0

    with open(body_path, "r", encoding="utf-8") as f:
        body_text = f.read()

    full_body = f"{MARKER}\n{body_text}"

    api_root = os.environ.get("GITHUB_API_URL", "https://api.github.com")
    list_url = f"{api_root}/repos/{repo}/issues/{pr_number}/comments?per_page=100"

    existing_id = None
    page = 1
    while True:
        url = f"{list_url}&page={page}"
        comments = _api("GET", url, token)
        if not isinstance(comments, list) or not comments:
            break
        for c in comments:
            if MARKER in (c.get("body") or ""):
                existing_id = c["id"]
                break
        if existing_id or len(comments) < 100:
            break
        page += 1

    if existing_id:
        url = f"{api_root}/repos/{repo}/issues/comments/{existing_id}"
        _api("PATCH", url, token, {"body": full_body})
        print(f"Updated PR comment #{existing_id} on PR #{pr_number}.")
    else:
        url = f"{api_root}/repos/{repo}/issues/{pr_number}/comments"
        result = _api("POST", url, token, {"body": full_body})
        print(f"Created PR comment #{result.get('id')} on PR #{pr_number}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
