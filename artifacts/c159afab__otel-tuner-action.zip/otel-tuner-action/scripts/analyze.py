#!/usr/bin/env python3
"""
OpenTelemetry Collector exporterhelper analyzer.

Reads a Collector YAML config, extracts every exporter's `sending_queue` and
`retry_on_failure` block, cross-references them against a workload budget
(target throughput, average batch size, backend latency, memory budget),
and produces a diagnostic report as JSON + Markdown.

Sizing model matches the reference implementation:

  requests_per_sec = throughput / batch_size
  ideal_consumers  = ceil(requests_per_sec * latency_sec * 1.5)   (Little's Law + 1.5x safety)
  ideal_queue      = ceil(requests_per_sec * outage_buffer_seconds)
  memory footprint = queue_requests * batch_size * bytes_per_event
                     + num_consumers * 8 KiB
                     + 10% overhead

Diagnostics fire when the *configured* values in the YAML fall outside safe
ranges relative to the workload.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
from dataclasses import dataclass, field, asdict
from typing import Any

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML is required. Install with: pip install pyyaml", file=sys.stderr)
    sys.exit(2)


# ---------------------------------------------------------------------------
# Duration parsing (Go time.ParseDuration subset)
# ---------------------------------------------------------------------------

_DURATION_RE = re.compile(r"^\s*(-?\d+(?:\.\d+)?)\s*(ns|us|µs|ms|s|m|h)?\s*$")
_DURATION_UNITS = {
    "ns": 1e-9, "us": 1e-6, "µs": 1e-6, "ms": 1e-3,
    "s": 1.0, "m": 60.0, "h": 3600.0,
}


def parse_duration_seconds(value: Any, default: float | None = None) -> float | None:
    """Parse Go-style duration strings like '5s', '30s', '10m'."""
    if value is None:
        return default
    if isinstance(value, (int, float)):
        return float(value)
    if not isinstance(value, str):
        return default
    m = _DURATION_RE.match(value)
    if not m:
        return default
    num, unit = m.groups()
    return float(num) * _DURATION_UNITS.get(unit or "s", 1.0)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class Workload:
    throughput: float          # events / second
    batch: int                 # items / request
    latency_ms: float          # backend latency ms
    memory_mb: float           # memory budget MB
    bytes_per_event: int = 500
    buffer_seconds: int = 30

    @property
    def requests_per_sec(self) -> float:
        return self.throughput / self.batch

    @property
    def latency_sec(self) -> float:
        return self.latency_ms / 1000.0


@dataclass
class ExporterConfig:
    """Extracted exporterhelper settings for a single exporter instance."""
    name: str
    kind: str                                # 'otlp', 'otlphttp', 'kafka', etc.
    # sending_queue
    queue_enabled: bool = True
    queue_size: int = 1000                   # default from exporterhelper
    num_consumers: int = 10                  # default from exporterhelper
    sizer: str = "requests"
    storage: str | None = None
    block_on_overflow: bool = False
    # retry_on_failure
    retry_enabled: bool = True
    initial_interval_s: float = 5.0
    max_interval_s: float = 30.0
    max_elapsed_s: float = 300.0
    multiplier: float = 1.5
    # exporter-level
    timeout_s: float = 5.0
    compression: str | None = None


@dataclass
class Diagnostic:
    level: str                 # 'ok' | 'warn' | 'danger'
    code: str                  # short machine code
    title: str
    detail: str
    exporter: str


@dataclass
class ExporterReport:
    name: str
    kind: str
    config: dict
    computed: dict
    diagnostics: list[Diagnostic] = field(default_factory=list)


# ---------------------------------------------------------------------------
# YAML extraction
# ---------------------------------------------------------------------------

def _get(d: dict | None, key: str, default: Any = None) -> Any:
    if not isinstance(d, dict):
        return default
    return d.get(key, default)


def extract_exporters(config: dict) -> list[ExporterConfig]:
    """Walk `exporters:` block and pull exporterhelper-relevant fields."""
    out: list[ExporterConfig] = []
    exporters = _get(config, "exporters", {}) or {}
    if not isinstance(exporters, dict):
        return out

    for name, body in exporters.items():
        if not isinstance(body, dict):
            continue
        # skip non-network exporters that don't use exporterhelper
        kind = str(name).split("/", 1)[0].lower()
        if kind in {"debug", "logging", "nop", "file"}:
            # file exporter supports sending_queue but rarely needs tuning
            if kind != "file":
                continue

        sq = body.get("sending_queue") or {}
        rf = body.get("retry_on_failure") or {}

        cfg = ExporterConfig(
            name=str(name),
            kind=kind,
            queue_enabled=bool(_get(sq, "enabled", True)),
            queue_size=int(_get(sq, "queue_size", 1000)),
            num_consumers=int(_get(sq, "num_consumers", 10)),
            sizer=str(_get(sq, "sizer", "requests")),
            storage=_get(sq, "storage"),
            block_on_overflow=bool(_get(sq, "block_on_overflow", False)),
            retry_enabled=bool(_get(rf, "enabled", True)),
            initial_interval_s=parse_duration_seconds(_get(rf, "initial_interval"), 5.0),
            max_interval_s=parse_duration_seconds(_get(rf, "max_interval"), 30.0),
            max_elapsed_s=parse_duration_seconds(_get(rf, "max_elapsed_time"), 300.0),
            multiplier=float(_get(rf, "multiplier", 1.5)),
            timeout_s=parse_duration_seconds(body.get("timeout"), 5.0),
            compression=body.get("compression"),
        )
        out.append(cfg)
    return out


# ---------------------------------------------------------------------------
# Sizing engine
# ---------------------------------------------------------------------------

def compute(workload: Workload, cfg: ExporterConfig) -> dict:
    """Compute derived metrics for an exporter against the workload."""
    req_per_sec = workload.requests_per_sec
    lat_s = workload.latency_sec

    # Ideal settings (what the tool WOULD recommend)
    ideal_consumers = max(1, min(200, math.ceil(req_per_sec * lat_s * 1.5)))
    ideal_queue_req = max(ideal_consumers * 2, math.ceil(req_per_sec * workload.buffer_seconds))

    # Convert configured queue_size to an equivalent number of requests
    # so memory can be modeled uniformly.
    sizer = (cfg.sizer or "requests").lower()
    if sizer == "items":
        cfg_queue_requests = max(1, cfg.queue_size // max(1, workload.batch))
    elif sizer == "bytes":
        cfg_queue_requests = max(1, cfg.queue_size // max(1, workload.batch * workload.bytes_per_event))
    else:
        cfg_queue_requests = cfg.queue_size

    # Memory footprint from the *configured* values
    queue_bytes = cfg_queue_requests * workload.batch * workload.bytes_per_event
    overhead_bytes = cfg.num_consumers * 8 * 1024 + queue_bytes * 0.10
    mem_mb = (queue_bytes + overhead_bytes) / (1024 * 1024)
    mem_pct = (mem_mb / workload.memory_mb) * 100 if workload.memory_mb > 0 else float("inf")

    # Drain capacity
    drain_req_per_sec = cfg.num_consumers / lat_s if lat_s > 0 else float("inf")
    drain_ratio = drain_req_per_sec / req_per_sec if req_per_sec > 0 else float("inf")

    # Seconds of ingest the queue can absorb during a full stall
    seconds_to_fill = cfg_queue_requests / req_per_sec if req_per_sec > 0 else float("inf")

    return {
        "requests_per_sec": req_per_sec,
        "ideal_num_consumers": ideal_consumers,
        "ideal_queue_size_requests": ideal_queue_req,
        "configured_queue_requests": cfg_queue_requests,
        "memory_mb": round(mem_mb, 2),
        "memory_pct_of_budget": round(mem_pct, 1),
        "drain_req_per_sec": round(drain_req_per_sec, 2),
        "drain_ratio": round(drain_ratio, 3),
        "seconds_to_fill_on_stall": round(seconds_to_fill, 1),
    }


# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------

def diagnose(workload: Workload, cfg: ExporterConfig, m: dict) -> list[Diagnostic]:
    diags: list[Diagnostic] = []

    def push(level: str, code: str, title: str, detail: str) -> None:
        diags.append(Diagnostic(level=level, code=code, title=title, detail=detail, exporter=cfg.name))

    # 0. Queue disabled — data loss on any backend hiccup
    if not cfg.queue_enabled:
        push("danger", "queue_disabled",
             f"`sending_queue` is disabled on `{cfg.name}`",
             "With the queue disabled, any transient backend failure drops data immediately. "
             "Enable `sending_queue` for all network exporters.")
        return diags  # further metrics are meaningless

    # 1. Drain capacity vs ingest (Little's Law)
    if m["drain_ratio"] < 1.0:
        eta = "immediately" if m["drain_ratio"] == 0 else (
            f"in ~{m['configured_queue_requests'] / max(0.001, m['requests_per_sec'] - m['drain_req_per_sec']):.0f}s"
        )
        push("danger", "drain_underprovisioned",
             f"Consumers cannot keep up on `{cfg.name}` ({m['drain_ratio']*100:.0f}% of ingest)",
             f"`num_consumers={cfg.num_consumers}` at {workload.latency_ms:.0f}ms latency drains "
             f"~{m['drain_req_per_sec']:.1f} req/s but ingest is {m['requests_per_sec']:.1f} req/s. "
             f"Queue will saturate {eta}. Recommend `num_consumers={m['ideal_num_consumers']}`.")
    elif m["drain_ratio"] < 1.3:
        push("warn", "drain_tight",
             f"Thin drain headroom on `{cfg.name}` ({m['drain_ratio']*100:.0f}% of ingest)",
             f"Under 30% burst headroom. Recommend `num_consumers={m['ideal_num_consumers']}` "
             f"(currently {cfg.num_consumers}).")
    else:
        push("ok", "drain_ok",
             f"`{cfg.name}` drain has {(m['drain_ratio']-1)*100:.0f}% headroom",
             f"{cfg.num_consumers} consumers drain ~{m['drain_req_per_sec']:.1f} req/s "
             f"against {m['requests_per_sec']:.1f} req/s ingest.")

    # 2. Memory over-allocation
    if m["memory_pct_of_budget"] > 100:
        push("danger", "memory_over_budget",
             f"Memory footprint on `{cfg.name}` exceeds budget ({m['memory_pct_of_budget']:.0f}%)",
             f"Estimated {m['memory_mb']:.1f} MB vs {workload.memory_mb:.0f} MB budget. "
             f"Recommend `queue_size={m['ideal_queue_size_requests']}` (currently {cfg.queue_size} {cfg.sizer}). "
             f"Or enable a persistent queue with `storage: file_storage`.")
    elif m["memory_pct_of_budget"] > 75:
        push("warn", "memory_tight",
             f"Memory footprint tight on `{cfg.name}` ({m['memory_pct_of_budget']:.0f}% of budget)",
             f"{m['memory_mb']:.1f} MB of {workload.memory_mb:.0f} MB used. Leaves little room for "
             f"GC overhead and other processors.")
    else:
        push("ok", "memory_ok",
             f"`{cfg.name}` memory fits ({m['memory_pct_of_budget']:.0f}% of budget)",
             f"{m['memory_mb']:.1f} MB of {workload.memory_mb:.0f} MB.")

    # 3. Outage tolerance (seconds to fill on full stall)
    if m["seconds_to_fill_on_stall"] < 5:
        push("danger", "outage_tolerance_low",
             f"`{cfg.name}` queue fills in {m['seconds_to_fill_on_stall']:.1f}s on backend stall",
             f"Even a brief backend hiccup will hit 'sending queue is full'. "
             f"Recommend `queue_size={m['ideal_queue_size_requests']}` or enable persistent storage.")
    elif m["seconds_to_fill_on_stall"] < 15:
        push("warn", "outage_tolerance_short",
             f"Short outage tolerance on `{cfg.name}` ({m['seconds_to_fill_on_stall']:.1f}s)",
             f"Queue fills within {m['seconds_to_fill_on_stall']:.0f}s of complete backend downtime. "
             f"Consider enabling `storage: file_storage` for durability.")

    # 4. queue_size / num_consumers ratio (OTel maintainer guidance ≥ 3-4)
    ratio = m["configured_queue_requests"] / max(1, cfg.num_consumers)
    if ratio < 3:
        push("warn", "queue_consumer_ratio",
             f"`{cfg.name}` has queue/consumers ratio {ratio:.1f}",
             f"With {m['configured_queue_requests']} queue requests and {cfg.num_consumers} consumers, "
             f"consumers may sit idle. OTel maintainers suggest this ratio ≥ 4.")

    # 5. Retry window vs queue depth
    if cfg.retry_enabled and cfg.max_elapsed_s > m["seconds_to_fill_on_stall"] * 3:
        push("warn", "retry_window_mismatch",
             f"`{cfg.name}` retry window ({cfg.max_elapsed_s:.0f}s) outlives queue depth ({m['seconds_to_fill_on_stall']:.0f}s)",
             f"Retries can hold requests longer than the queue can buffer new arrivals. "
             f"Reduce `retry_on_failure.max_elapsed_time` or enable persistent storage.")

    # 6. Retry disabled — network exporters should almost always have it on
    if not cfg.retry_enabled:
        push("warn", "retry_disabled",
             f"`retry_on_failure` disabled on `{cfg.name}`",
             "Transient network errors will be dropped after one attempt. "
             "Enable `retry_on_failure` unless you have an explicit reason not to.")

    # 7. Timeout sanity vs backend latency
    if cfg.timeout_s < workload.latency_sec * 2:
        push("warn", "timeout_too_short",
             f"`{cfg.name}` timeout ({cfg.timeout_s:.0f}s) is close to backend latency ({workload.latency_ms:.0f}ms)",
             f"Timeout should be ≥ 2-4× the P50 backend latency to tolerate tail requests. "
             f"Recommend `timeout: {max(5, math.ceil(workload.latency_sec * 4))}s`.")

    # 8. Compression not enabled on network exporter
    if cfg.compression in (None, "", "none"):
        push("warn", "compression_off",
             f"Compression not enabled on `{cfg.name}`",
             "Network exporters should almost always use `compression: gzip` — reduces bandwidth 70-90% "
             "and typically pays for its CPU cost.")

    # 9. High absolute consumer count
    if cfg.num_consumers >= 100:
        push("warn", "consumers_high",
             f"`{cfg.name}` uses {cfg.num_consumers} consumers",
             "Very high `num_consumers` can overwhelm backend connection pools. Consider raising "
             "batch size to reduce req/s or splitting the pipeline across multiple exporter instances.")

    # 10. queue_size = 0 (would drop everything)
    if cfg.queue_size == 0:
        push("danger", "queue_size_zero",
             f"`{cfg.name}` has `queue_size: 0`",
             "A queue size of 0 permanently blocks the exporter and drops all data. Set to a positive value.")

    return diags


# ---------------------------------------------------------------------------
# Report rendering
# ---------------------------------------------------------------------------

_LEVEL_ORDER = {"danger": 0, "warn": 1, "ok": 2}
_ICONS = {"ok": "✅", "warn": "⚠️", "danger": "❌"}


def summarize(reports: list[ExporterReport]) -> dict:
    counts = {"ok": 0, "warn": 0, "danger": 0}
    for r in reports:
        for d in r.diagnostics:
            counts[d.level] = counts.get(d.level, 0) + 1
    return counts


def build_markdown(workload: Workload, reports: list[ExporterReport], config_path: str) -> str:
    counts = summarize(reports)
    total_diags = sum(counts.values())
    if counts["danger"]:
        headline = f"❌ **{counts['danger']} critical**, {counts['warn']} warnings"
        status = "critical"
    elif counts["warn"]:
        headline = f"⚠️ {counts['warn']} warnings, no critical issues"
        status = "warn"
    else:
        headline = "✅ All checks passed"
        status = "ok"

    lines: list[str] = []
    lines.append("### OTel exporterhelper diagnostic")
    lines.append("")
    lines.append(f"**Config:** `{config_path}` — {headline}")
    lines.append("")
    lines.append("**Workload budget**")
    lines.append(
        f"- Throughput: `{workload.throughput:,.0f}` events/s · "
        f"Avg batch: `{workload.batch}` · "
        f"Backend latency: `{workload.latency_ms:.0f}ms` · "
        f"Memory budget: `{workload.memory_mb:.0f} MB` · "
        f"Outage buffer: `{workload.buffer_seconds}s`"
    )
    lines.append("")

    if not reports:
        lines.append("_No network exporters found in the config._")
        return "\n".join(lines)

    # Per-exporter table
    lines.append("| Exporter | Consumers | Queue | Memory | Drain | Status |")
    lines.append("| --- | --- | --- | --- | --- | --- |")
    for r in reports:
        worst = min((_LEVEL_ORDER[d.level] for d in r.diagnostics), default=2)
        badge = ["❌", "⚠️", "✅"][worst]
        lines.append(
            f"| `{r.name}` | {r.config['num_consumers']} "
            f"(rec {r.computed['ideal_num_consumers']}) "
            f"| {r.config['queue_size']} {r.config['sizer']} "
            f"(rec {r.computed['ideal_queue_size_requests']} req) "
            f"| {r.computed['memory_mb']:.1f} MB "
            f"({r.computed['memory_pct_of_budget']:.0f}%) "
            f"| {r.computed['drain_ratio']*100:.0f}% "
            f"| {badge} |"
        )
    lines.append("")

    # Detailed findings, only non-ok by default; ok collapsed
    for r in reports:
        lines.append(f"#### `{r.name}`")
        non_ok = [d for d in r.diagnostics if d.level != "ok"]
        ok_only = [d for d in r.diagnostics if d.level == "ok"]
        if not non_ok:
            lines.append("_No issues found for this exporter._")
        for d in sorted(non_ok, key=lambda x: _LEVEL_ORDER[x.level]):
            lines.append(f"- {_ICONS[d.level]} **{d.title}** — {d.detail}")
        if ok_only:
            lines.append("")
            lines.append("<details><summary>Passing checks</summary>")
            lines.append("")
            for d in ok_only:
                lines.append(f"- ✅ {d.title}")
            lines.append("")
            lines.append("</details>")
        lines.append("")

    lines.append("---")
    lines.append(
        "_Generated by [otel-tuner-action](https://github.com/marketplace/actions/otel-tuner). "
        f"Total: {total_diags} checks across {len(reports)} exporter(s)._"
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    # Expand ${env:VAR} style placeholders to a dummy string so parsing succeeds
    text = re.sub(r"\$\{env:[^}]+\}", "PLACEHOLDER", text)
    text = re.sub(r"\$\{[^}]+\}", "PLACEHOLDER", text)
    data = yaml.safe_load(text)
    if not isinstance(data, dict):
        raise ValueError(f"Config at {path} did not parse as a mapping.")
    return data


def build_reports(workload: Workload, cfgs: list[ExporterConfig]) -> list[ExporterReport]:
    reports: list[ExporterReport] = []
    for cfg in cfgs:
        m = compute(workload, cfg)
        diags = diagnose(workload, cfg, m)
        reports.append(ExporterReport(
            name=cfg.name, kind=cfg.kind,
            config=asdict(cfg), computed=m, diagnostics=diags,
        ))
    return reports


def main() -> int:
    p = argparse.ArgumentParser(description="Analyze an OTel Collector config against a workload budget.")
    p.add_argument("--config", required=True, help="Path to OTel Collector YAML config")
    p.add_argument("--throughput", type=float, required=True, help="Target throughput (events/second)")
    p.add_argument("--batch-size", type=int, required=True, help="Average batch size (items/request)")
    p.add_argument("--latency-ms", type=float, required=True, help="Expected backend latency (ms)")
    p.add_argument("--memory-mb", type=float, required=True, help="Memory budget for the sending queue (MB)")
    p.add_argument("--bytes-per-event", type=int, default=500, help="Estimated serialized bytes per event")
    p.add_argument("--buffer-seconds", type=int, default=30, help="Outage buffer window (seconds)")
    p.add_argument("--fail-on", choices=["danger", "warn", "never"], default="danger",
                   help="Exit non-zero when this severity is present. Default: danger.")
    p.add_argument("--json-out", help="Path to write the full JSON report")
    p.add_argument("--md-out", help="Path to write the Markdown comment")
    args = p.parse_args()

    workload = Workload(
        throughput=args.throughput, batch=args.batch_size,
        latency_ms=args.latency_ms, memory_mb=args.memory_mb,
        bytes_per_event=args.bytes_per_event, buffer_seconds=args.buffer_seconds,
    )

    try:
        data = load_config(args.config)
    except FileNotFoundError:
        print(f"ERROR: config not found: {args.config}", file=sys.stderr)
        return 2
    except yaml.YAMLError as e:
        print(f"ERROR: could not parse YAML: {e}", file=sys.stderr)
        return 2

    cfgs = extract_exporters(data)
    reports = build_reports(workload, cfgs)
    md = build_markdown(workload, reports, args.config)
    counts = summarize(reports)

    payload = {
        "config": args.config,
        "workload": asdict(workload),
        "summary": counts,
        "exporters": [
            {
                "name": r.name, "kind": r.kind,
                "config": r.config, "computed": r.computed,
                "diagnostics": [asdict(d) for d in r.diagnostics],
            } for r in reports
        ],
    }

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
    if args.md_out:
        with open(args.md_out, "w", encoding="utf-8") as f:
            f.write(md)

    # Emit outputs for GitHub Actions consumption
    gh_out = os.environ.get("GITHUB_OUTPUT")
    if gh_out:
        with open(gh_out, "a", encoding="utf-8") as f:
            f.write(f"danger_count={counts['danger']}\n")
            f.write(f"warn_count={counts['warn']}\n")
            f.write(f"ok_count={counts['ok']}\n")
            f.write(f"exporter_count={len(reports)}\n")
            if counts["danger"]:
                f.write("status=critical\n")
            elif counts["warn"]:
                f.write("status=warn\n")
            else:
                f.write("status=ok\n")

    # Console summary (always)
    print(md)

    # Exit code policy
    if args.fail_on == "danger" and counts["danger"] > 0:
        return 1
    if args.fail_on == "warn" and (counts["danger"] > 0 or counts["warn"] > 0):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
