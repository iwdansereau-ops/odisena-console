"""Unit tests for scripts/analyze.py — exercised via `python -m unittest`."""

from __future__ import annotations

import os
import sys
import tempfile
import textwrap
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, os.pardir, "scripts"))

import analyze  # noqa: E402


def _cfg(text: str) -> str:
    """Write a config to a temp file and return its path."""
    fd, path = tempfile.mkstemp(suffix=".yaml")
    with os.fdopen(fd, "w") as f:
        f.write(textwrap.dedent(text))
    return path


class DurationTests(unittest.TestCase):
    def test_seconds(self):
        self.assertEqual(analyze.parse_duration_seconds("5s"), 5.0)

    def test_ms(self):
        self.assertAlmostEqual(analyze.parse_duration_seconds("250ms"), 0.25)

    def test_minutes(self):
        self.assertEqual(analyze.parse_duration_seconds("10m"), 600.0)

    def test_bare_number(self):
        self.assertEqual(analyze.parse_duration_seconds(30), 30.0)

    def test_invalid(self):
        self.assertEqual(analyze.parse_duration_seconds("banana", default=7.0), 7.0)


class ExtractTests(unittest.TestCase):
    def test_defaults_when_omitted(self):
        path = _cfg("""
            exporters:
              otlp:
                endpoint: x:4317
            service:
              pipelines: {}
        """)
        cfgs = analyze.extract_exporters(analyze.load_config(path))
        self.assertEqual(len(cfgs), 1)
        c = cfgs[0]
        self.assertEqual(c.queue_size, 1000)
        self.assertEqual(c.num_consumers, 10)
        self.assertTrue(c.queue_enabled)
        self.assertEqual(c.max_elapsed_s, 300.0)

    def test_skips_debug_exporters(self):
        path = _cfg("""
            exporters:
              debug:
                verbosity: normal
              logging: {}
              otlp:
                endpoint: x:4317
        """)
        cfgs = analyze.extract_exporters(analyze.load_config(path))
        self.assertEqual([c.name for c in cfgs], ["otlp"])

    def test_env_placeholders_do_not_crash_parse(self):
        path = _cfg("""
            exporters:
              otlp:
                endpoint: ${env:OTEL_ENDPOINT}
                headers:
                  authorization: ${env:OTEL_TOKEN}
                sending_queue:
                  queue_size: 5000
        """)
        cfgs = analyze.extract_exporters(analyze.load_config(path))
        self.assertEqual(cfgs[0].queue_size, 5000)


class DiagnoseTests(unittest.TestCase):
    """End-to-end: run the pipeline against the shipped good/bad examples."""

    def setUp(self):
        self.examples = os.path.join(HERE, os.pardir, "examples")
        self.workload = analyze.Workload(
            throughput=10000, batch=512, latency_ms=250, memory_mb=512,
        )

    def test_good_config_all_ok(self):
        data = analyze.load_config(os.path.join(self.examples, "collector-good.yaml"))
        cfgs = analyze.extract_exporters(data)
        reports = analyze.build_reports(self.workload, cfgs)
        counts = analyze.summarize(reports)
        self.assertEqual(counts["danger"], 0, f"unexpected danger in good config: {reports}")
        # A couple of soft warnings are acceptable but no critical issues.
        self.assertLessEqual(counts["warn"], 2)

    def test_bad_config_fires_expected_criticals(self):
        data = analyze.load_config(os.path.join(self.examples, "collector-bad.yaml"))
        cfgs = analyze.extract_exporters(data)
        reports = analyze.build_reports(self.workload, cfgs)
        counts = analyze.summarize(reports)
        self.assertGreater(counts["danger"], 0)

        codes = {d.code for r in reports for d in r.diagnostics}
        # bad config MUST trip these three:
        self.assertIn("drain_underprovisioned", codes)
        self.assertIn("memory_over_budget", codes)
        self.assertIn("queue_disabled", codes)

    def test_zero_queue_flagged(self):
        path = _cfg("""
            exporters:
              otlp:
                endpoint: x:4317
                sending_queue:
                  enabled: true
                  queue_size: 0
                  num_consumers: 4
        """)
        cfgs = analyze.extract_exporters(analyze.load_config(path))
        reports = analyze.build_reports(self.workload, cfgs)
        codes = {d.code for r in reports for d in r.diagnostics}
        self.assertIn("queue_size_zero", codes)


class MarkdownTests(unittest.TestCase):
    def test_markdown_has_summary_and_marker_friendly(self):
        wl = analyze.Workload(throughput=10000, batch=512, latency_ms=250, memory_mb=512)
        path = os.path.join(os.path.dirname(HERE), "examples", "collector-good.yaml")
        cfgs = analyze.extract_exporters(analyze.load_config(path))
        reports = analyze.build_reports(wl, cfgs)
        md = analyze.build_markdown(wl, reports, path)
        self.assertIn("OTel exporterhelper diagnostic", md)
        self.assertIn("Workload budget", md)
        self.assertIn("otlp/primary", md)


if __name__ == "__main__":
    unittest.main()
