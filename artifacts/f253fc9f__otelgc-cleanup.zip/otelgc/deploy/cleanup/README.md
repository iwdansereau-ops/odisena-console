# PROFILE_DIR cleanup sidecar

Keeps the gcpressure monitor's capture directory bounded so the collector's
volume stays within its allocated storage, even during prolonged GC-pressure
episodes when captures can arrive every 30 s.

## What ships in here

```
gcprofile-cleanup.sh            the cleanup script itself
alerts.yml                      Prometheus alerts for cleanup health
cron/gcprofile-cleanup.cron     /etc/cron.d drop-in
systemd/*.service, *.timer      systemd unit + persistent timer
k8s/cleanup-sidecar.yaml        pod-sidecar Deployment patch + CronJob
```

## What the script does

1. Walks `$PROFILE_DIR` and groups files by their shared base name
   (`gc-<reason>-<timestamp>` → `.meta.txt` + `.heap.pprof` + `.stacks.txt`).
2. For each group, deletes it only when
   * every file is older than `MAX_AGE_HOURS` (default **48 h**), AND
   * the newest file in the group was last modified more than
     `SETTLING_SECONDS` ago (default **60 s**) — this window protects an
     in-flight capture whose `.heap.pprof` may still be streaming.
3. Appends a single-line, machine-parseable status record to
   `$PROFILE_DIR/.cleanup.log`, rotating that log in place to the last
   `MAX_LOG_LINES` entries (default **1000**).
4. Optionally emits a Prometheus textfile (`$TEXTFILE_OUT`) with 8 gauges
   suitable for `node_exporter --collector.textfile.directory`.

Example status log line (space-separated `key=value`, easy to grep/jq/awk):

```
ts=2026-07-02T05:25:11Z mode=live dir=/var/lib/otelcol/gcprofiles \
  scanned_triplets=42 deleted_files=27 kept_files=15 \
  bytes_freed=213909504 bytes_in_use=98304000 oldest_kept_age_h=41 \
  duration_s=1 cap_hit=0 exit=0
```

## Safety properties

| Property | How it's enforced |
| --- | --- |
| Never deletes an in-flight capture | 60 s settling window on newest mtime |
| Never runs twice concurrently | `flock` on `$PROFILE_DIR/.cleanup.lock` |
| Bounded blast radius | `MAX_DELETES_PER_RUN=5000` hard cap |
| Refuses dangerous paths | Rejects `/`, `/var`, `/etc`, `$HOME`, … |
| Disk-full is loud, not silent | Falls back to stderr + `logger(1)` |
| Textfile writes are atomic | `.tmp.$$ → mv -f` (Prometheus requirement) |
| Deletes are group-level | Only deletes the *set* — no half-triplets |
| Time zones don't confuse mtime | All comparisons use epoch seconds |

## Tunables

Every knob is an environment variable so the same script works under cron,
systemd, and containers with no source edits:

| Var | Default | Purpose |
| --- | --- | --- |
| `PROFILE_DIR` | `/var/lib/otelcol/gcprofiles` | Directory to scan |
| `MAX_AGE_HOURS` | `48` | Delete-eligibility threshold |
| `SETTLING_SECONDS` | `60` | Don't delete groups touched more recently than this |
| `MAX_DELETES_PER_RUN` | `5000` | Hard blast-radius cap |
| `STATUS_LOG` | `$PROFILE_DIR/.cleanup.log` | Machine-parseable audit log |
| `MAX_LOG_LINES` | `1000` | Rotate the status log to this many lines |
| `LOCK_FILE` | `$PROFILE_DIR/.cleanup.lock` | flock target |
| `TEXTFILE_OUT` | *(unset)* | If set, emit Prom textfile-collector metrics |

Flags:

| Flag | Purpose |
| --- | --- |
| `--dry-run` | Print what *would* be deleted, then exit 0. No side effects. |
| `-h` / `--help` | Print header comment as help text |

## Choosing a deployment shape

* **Bare-metal / VM (single collector)** — use the systemd timer. It gets
  boot-persistence, journald integration, and the hardening sandbox for
  free.
* **Bare-metal / VM (RHEL 6 style, no systemd)** — use the cron drop-in.
* **Kubernetes with a single collector pod** — use the sidecar in
  `k8s/cleanup-sidecar.yaml`. Ships as a second container inside the
  collector's pod so both see the same `emptyDir`.
* **Kubernetes with an HPA'd collector Deployment sharing a PVC** — use the
  CronJob variant in the same file. It runs as an independent scheduled
  workload rather than duplicating a sidecar per collector replica.

## Verifying the deployment

```bash
# 1. First run — dry mode. Nothing should be deleted; log line should appear.
sudo -u otelcol PROFILE_DIR=/var/lib/otelcol/gcprofiles \
  /usr/local/sbin/gcprofile-cleanup.sh --dry-run

# 2. First real run.
sudo -u otelcol /usr/local/sbin/gcprofile-cleanup.sh
tail -1 /var/lib/otelcol/gcprofiles/.cleanup.log

# 3. Systemd: verify the timer scheduled the next run.
systemctl list-timers gcprofile-cleanup.timer
```

## Prometheus wire-up

Add to `node_exporter` command line:

```
--collector.textfile.directory=/var/lib/node_exporter/textfile
```

Then in the cleanup config, set:

```
TEXTFILE_OUT=/var/lib/node_exporter/textfile/gcprofile_cleanup.prom
```

Prometheus will now scrape 8 gauges every time it scrapes node_exporter.
Merge `deploy/cleanup/alerts.yml` into your Prometheus rule files to get:

* `GCProfileCleanupStale` — no run in > 1h (cron/timer broken)
* `GCProfileCleanupFailing` — last run exited non-zero
* `GCProfileVolumeGrowing` — bytes-in-use trending up despite runs (capture
  rate has outrun `MAX_DELETES_PER_RUN` or retention is too generous)
* `GCProfileRetentionMiss` — oldest kept > 60 h against a 48 h target

## Capacity planning

Rough numbers for right-sizing the volume:

* Typical capture triplet: ~3–20 MiB (heap dump dominates; scales with
  live-heap size at capture time).
* Monitor rate limit: 1 capture per `min_capture_interval` (default 30 s),
  so worst case ~120 captures/hour.
* Worst-case daily volume: `120 × 24 × 20 MiB ≈ 57 GiB/day`.
* With `MAX_AGE_HOURS=48`, worst-case steady-state footprint is ~114 GiB.
* In practice a healthy collector produces zero captures per day. Sizing at
  10 GiB is generous for most production deployments — the alert
  `GCProfileVolumeGrowing` will fire long before you hit the ceiling if that
  assumption breaks.
