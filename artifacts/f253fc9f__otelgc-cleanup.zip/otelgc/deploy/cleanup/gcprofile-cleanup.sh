#!/usr/bin/env bash
#
# gcprofile-cleanup.sh
# ------------------------------------------------------------------
# Periodic cleanup for the gcpressure monitor's PROFILE_DIR.
#
# What it does:
#   * Scans PROFILE_DIR for gc-<reason>-<ts>.meta.txt / .heap.pprof / .stacks.txt
#     triplets written by internal/gcpressure/monitor.go.
#   * Groups files by their shared base name.
#   * Deletes a group only when:
#       - every member is older than MAX_AGE_HOURS (default 48), AND
#       - no member has been modified in the last SETTLING_SECONDS (default 60)
#         — protects an in-flight capture whose writes are still in progress.
#   * Emits a single-line status record to STATUS_LOG on every run
#     (rotated in-script to keep the last MAX_LOG_LINES entries).
#   * Optionally emits a Prometheus textfile-collector .prom snapshot so
#     Prometheus can alert on cleanup health without a separate exporter.
#
# Safe by design:
#   * Refuses to run against dangerous paths (/, /var, /etc, $HOME, ...).
#   * Serializes concurrent runs via flock on a lockfile.
#   * Hard cap of MAX_DELETES_PER_RUN files removed per run.
#   * Fails LOUDLY on disk-full: if writing the status log fails, the
#     script still exits with a non-zero code and writes to stderr / syslog
#     so cron/systemd/monitoring notice.
#   * --dry-run prints the plan without touching any files.
#
# Usage:
#   gcprofile-cleanup.sh                       # normal run, defaults
#   gcprofile-cleanup.sh --dry-run             # show what would be deleted
#   PROFILE_DIR=/mnt/pprof MAX_AGE_HOURS=24 gcprofile-cleanup.sh
#
# Deploy as:
#   * cron:    deploy/cleanup/cron/gcprofile-cleanup.cron
#   * systemd: deploy/cleanup/systemd/gcprofile-cleanup.{service,timer}
#   * k8s:     deploy/cleanup/k8s/cleanup-sidecar.yaml
# ------------------------------------------------------------------

set -Eeuo pipefail

# ---- tunables (env-overridable) ---------------------------------------------

PROFILE_DIR="${PROFILE_DIR:-/var/lib/otelcol/gcprofiles}"
MAX_AGE_HOURS="${MAX_AGE_HOURS:-48}"
SETTLING_SECONDS="${SETTLING_SECONDS:-60}"
MAX_DELETES_PER_RUN="${MAX_DELETES_PER_RUN:-5000}"
STATUS_LOG="${STATUS_LOG:-${PROFILE_DIR}/.cleanup.log}"
MAX_LOG_LINES="${MAX_LOG_LINES:-1000}"
LOCK_FILE="${LOCK_FILE:-${PROFILE_DIR}/.cleanup.lock}"
TEXTFILE_OUT="${TEXTFILE_OUT:-}"        # set to a path under a Prometheus
                                        # node_exporter --collector.textfile.directory
                                        # to emit metrics (optional).
DRY_RUN=0

# ---- refuse to run against dangerous paths ----------------------------------

_dangerous_paths=(
  "/" "/root" "/etc" "/var" "/usr" "/bin" "/sbin" "/boot" "/dev" "/proc" "/sys"
  "/home" "${HOME:-}"
)
for bad in "${_dangerous_paths[@]}"; do
  if [ -n "$bad" ] && [ "$(realpath -m -- "$PROFILE_DIR")" = "$(realpath -m -- "$bad")" ]; then
    echo "REFUSING to clean dangerous path: $PROFILE_DIR" >&2
    exit 2
  fi
done

# ---- argument parsing -------------------------------------------------------

while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run) DRY_RUN=1 ;;
    --help|-h)
      sed -n '2,40p' "$0"
      exit 0
      ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
  shift
done

# ---- helpers ----------------------------------------------------------------

_ts() { date -u +'%Y-%m-%dT%H:%M:%SZ'; }
_epoch() { date -u +%s; }

# _log_local writes a line to $STATUS_LOG, rotates it, and — critically —
# falls back to stderr + logger(1) if the volume is full. That way a
# disk-full condition (the exact scenario this script is meant to prevent
# in the first place) is *never* silently swallowed.
_log_local() {
  local line="$1"
  local tmp="${STATUS_LOG}.tmp.$$"

  # Try to append. On failure we still want the message visible.
  if ! printf '%s\n' "$line" >> "$STATUS_LOG" 2>/dev/null; then
    echo "gcprofile-cleanup: could not append to $STATUS_LOG (disk full?): $line" >&2
    command -v logger >/dev/null 2>&1 && \
      logger -t gcprofile-cleanup -p daemon.warning -- "$line" || true
    return
  fi

  # Rotate in place: keep the tail of MAX_LOG_LINES. Use a temp file +
  # atomic rename so a truncation cannot corrupt readers.
  local n
  n=$(wc -l < "$STATUS_LOG" 2>/dev/null || echo 0)
  if [ "$n" -gt "$MAX_LOG_LINES" ]; then
    if tail -n "$MAX_LOG_LINES" "$STATUS_LOG" > "$tmp" 2>/dev/null \
       && mv -f "$tmp" "$STATUS_LOG" 2>/dev/null; then
      :
    else
      rm -f "$tmp" 2>/dev/null || true
    fi
  fi
}

# _emit_textfile writes a Prometheus textfile snapshot atomically.
# Prometheus's textfile collector requires atomic renames — never a partial
# write, or the scrape will pick up truncated content.
_emit_textfile() {
  [ -z "$TEXTFILE_OUT" ] && return
  local scanned="$1" deleted="$2" kept="$3" oldest_age_h="$4" \
        bytes_freed="$5" bytes_used="$6" run_seconds="$7" exit_code="$8"
  local tmp="${TEXTFILE_OUT}.tmp.$$"
  {
    echo "# HELP gcprofile_cleanup_last_run_timestamp_seconds Unix timestamp of the most recent cleanup run."
    echo "# TYPE gcprofile_cleanup_last_run_timestamp_seconds gauge"
    echo "gcprofile_cleanup_last_run_timestamp_seconds $(_epoch)"
    echo "# HELP gcprofile_cleanup_last_run_exit_code Exit code of the most recent cleanup run (0 = success)."
    echo "# TYPE gcprofile_cleanup_last_run_exit_code gauge"
    echo "gcprofile_cleanup_last_run_exit_code ${exit_code}"
    echo "# HELP gcprofile_cleanup_run_duration_seconds Wall-clock duration of the most recent cleanup run."
    echo "# TYPE gcprofile_cleanup_run_duration_seconds gauge"
    echo "gcprofile_cleanup_run_duration_seconds ${run_seconds}"
    echo "# HELP gcprofile_cleanup_capture_triplets_scanned Number of triplets found in PROFILE_DIR."
    echo "# TYPE gcprofile_cleanup_capture_triplets_scanned gauge"
    echo "gcprofile_cleanup_capture_triplets_scanned ${scanned}"
    echo "# HELP gcprofile_cleanup_files_deleted_total Files deleted by the most recent run."
    echo "# TYPE gcprofile_cleanup_files_deleted_total gauge"
    echo "gcprofile_cleanup_files_deleted_total ${deleted}"
    echo "# HELP gcprofile_cleanup_files_kept Files retained after the most recent run."
    echo "# TYPE gcprofile_cleanup_files_kept gauge"
    echo "gcprofile_cleanup_files_kept ${kept}"
    echo "# HELP gcprofile_cleanup_oldest_kept_age_hours Age of the oldest retained triplet, in hours."
    echo "# TYPE gcprofile_cleanup_oldest_kept_age_hours gauge"
    echo "gcprofile_cleanup_oldest_kept_age_hours ${oldest_age_h}"
    echo "# HELP gcprofile_cleanup_bytes_freed Bytes freed by the most recent run."
    echo "# TYPE gcprofile_cleanup_bytes_freed gauge"
    echo "gcprofile_cleanup_bytes_freed ${bytes_freed}"
    echo "# HELP gcprofile_cleanup_bytes_in_use Bytes currently used by retained triplets."
    echo "# TYPE gcprofile_cleanup_bytes_in_use gauge"
    echo "gcprofile_cleanup_bytes_in_use ${bytes_used}"
  } > "$tmp" 2>/dev/null && mv -f "$tmp" "$TEXTFILE_OUT" 2>/dev/null || {
    rm -f "$tmp" 2>/dev/null || true
    echo "gcprofile-cleanup: could not emit textfile $TEXTFILE_OUT" >&2
  }
}

# ---- main body wrapped so we can trap and record exit code ------------------

RUN_STARTED=$(_epoch)
SCANNED=0
DELETED=0
KEPT=0
BYTES_FREED=0
BYTES_USED=0
OLDEST_AGE_HOURS=0
EXIT_CODE=0
DELETE_CAP_HIT=0

_finish() {
  EXIT_CODE=$?
  local run_seconds=$(( $(_epoch) - RUN_STARTED ))
  local mode="live"
  [ "$DRY_RUN" = 1 ] && mode="dry-run"
  local line
  line=$(printf 'ts=%s mode=%s dir=%s scanned_triplets=%d deleted_files=%d kept_files=%d bytes_freed=%d bytes_in_use=%d oldest_kept_age_h=%s duration_s=%d cap_hit=%d exit=%d' \
    "$(_ts)" "$mode" "$PROFILE_DIR" "$SCANNED" "$DELETED" "$KEPT" \
    "$BYTES_FREED" "$BYTES_USED" "$OLDEST_AGE_HOURS" \
    "$run_seconds" "$DELETE_CAP_HIT" "$EXIT_CODE")
  _log_local "$line"
  _emit_textfile "$SCANNED" "$DELETED" "$KEPT" "$OLDEST_AGE_HOURS" \
                 "$BYTES_FREED" "$BYTES_USED" "$run_seconds" "$EXIT_CODE"
  exit "$EXIT_CODE"
}
trap _finish EXIT
trap 'echo "gcprofile-cleanup: interrupted" >&2; exit 130' INT TERM

# ---- preflight --------------------------------------------------------------

if [ ! -d "$PROFILE_DIR" ]; then
  echo "gcprofile-cleanup: PROFILE_DIR=$PROFILE_DIR does not exist" >&2
  exit 3
fi

# Acquire an exclusive advisory lock. flock(1) is standard on Linux; on
# platforms without it we fall back to a mkdir-based lock.
if command -v flock >/dev/null 2>&1; then
  exec 9>"$LOCK_FILE"
  if ! flock -n 9; then
    echo "gcprofile-cleanup: another run holds $LOCK_FILE; skipping" >&2
    exit 0
  fi
else
  MKDIR_LOCK="${LOCK_FILE}.d"
  if ! mkdir "$MKDIR_LOCK" 2>/dev/null; then
    echo "gcprofile-cleanup: another run holds $MKDIR_LOCK; skipping" >&2
    exit 0
  fi
  trap 'rmdir "$MKDIR_LOCK" 2>/dev/null || true; _finish' EXIT
fi

# ---- discover triplets ------------------------------------------------------

NOW=$(_epoch)
CUTOFF=$(( NOW - MAX_AGE_HOURS * 3600 ))
SETTLE_CUTOFF=$(( NOW - SETTLING_SECONDS ))

# Collect base names (strip the known suffixes) via a single find pass.
# We tolerate any of the three files being missing (partial writes).
declare -A BASE_MTIME
declare -A BASE_SIZE
declare -A BASE_COUNT
declare -A BASE_HAS_META

while IFS= read -r -d '' f; do
  fn=${f##*/}
  case "$fn" in
    gc-*.meta.txt)      base="${f%.meta.txt}"      ; is_meta=1 ;;
    gc-*.heap.pprof)    base="${f%.heap.pprof}"    ; is_meta=0 ;;
    gc-*.stacks.txt)    base="${f%.stacks.txt}"    ; is_meta=0 ;;
    *) continue ;;
  esac

  # mtime and size for each file. Use stat's portable-ish -c form; if the
  # OS ships BSD stat, fall back accordingly.
  if mt=$(stat -c '%Y' -- "$f" 2>/dev/null); then
    sz=$(stat -c '%s' -- "$f" 2>/dev/null || echo 0)
  else
    mt=$(stat -f '%m' -- "$f" 2>/dev/null || echo 0)
    sz=$(stat -f '%z' -- "$f" 2>/dev/null || echo 0)
  fi

  # Track the *newest* mtime of the group (settling window is against this)
  # and the *oldest* mtime (age eligibility is against this).
  prev_new=${BASE_MTIME[$base.new]:-0}
  prev_old=${BASE_MTIME[$base.old]:-$mt}
  [ "$mt" -gt "$prev_new" ] && BASE_MTIME[$base.new]=$mt || BASE_MTIME[$base.new]=$prev_new
  [ "$mt" -lt "$prev_old" ] && BASE_MTIME[$base.old]=$mt || BASE_MTIME[$base.old]=$prev_old

  BASE_SIZE[$base]=$(( ${BASE_SIZE[$base]:-0} + sz ))
  BASE_COUNT[$base]=$(( ${BASE_COUNT[$base]:-0} + 1 ))
  [ "$is_meta" = 1 ] && BASE_HAS_META[$base]=1
done < <(find "$PROFILE_DIR" -maxdepth 1 -type f \
           \( -name 'gc-*.meta.txt' -o -name 'gc-*.heap.pprof' -o -name 'gc-*.stacks.txt' \) \
           -print0)

SCANNED=${#BASE_COUNT[@]}

# ---- decide what to delete --------------------------------------------------

OLDEST_KEPT=$NOW

for base in "${!BASE_COUNT[@]}"; do
  oldest=${BASE_MTIME[$base.old]}
  newest=${BASE_MTIME[$base.new]}
  size=${BASE_SIZE[$base]}

  age_h=$(( (NOW - oldest) / 3600 ))

  # Eligibility: all files must be older than CUTOFF, and the newest file
  # in the group must be settled (not modified in the last SETTLING_SECONDS).
  if [ "$oldest" -le "$CUTOFF" ] && [ "$newest" -le "$SETTLE_CUTOFF" ]; then
    if [ "$DELETED" -ge "$MAX_DELETES_PER_RUN" ]; then
      DELETE_CAP_HIT=1
      # Count remaining as kept so metrics reflect actual state.
      KEPT=$(( KEPT + 1 ))
      BYTES_USED=$(( BYTES_USED + size ))
      [ "$oldest" -lt "$OLDEST_KEPT" ] && OLDEST_KEPT=$oldest
      continue
    fi

    # Delete each member of the triplet.
    for suf in .meta.txt .heap.pprof .stacks.txt; do
      target="${base}${suf}"
      if [ -e "$target" ]; then
        if [ "$DRY_RUN" = 1 ]; then
          echo "would delete: $target"
        else
          rm -f -- "$target" 2>/dev/null || {
            echo "gcprofile-cleanup: rm failed for $target" >&2
            continue
          }
        fi
        DELETED=$(( DELETED + 1 ))
      fi
    done
    BYTES_FREED=$(( BYTES_FREED + size ))
  else
    KEPT=$(( KEPT + 1 ))
    BYTES_USED=$(( BYTES_USED + size ))
    [ "$oldest" -lt "$OLDEST_KEPT" ] && OLDEST_KEPT=$oldest
  fi
done

if [ "$KEPT" -gt 0 ]; then
  OLDEST_AGE_HOURS=$(( (NOW - OLDEST_KEPT) / 3600 ))
fi

# Print a human summary to stdout (cron will mail this; systemd will
# journal it; the status log gets the machine-parseable version).
cat <<EOF
gcprofile-cleanup summary
  profile_dir       : $PROFILE_DIR
  mode              : $( [ "$DRY_RUN" = 1 ] && echo dry-run || echo live )
  max_age_hours     : $MAX_AGE_HOURS
  settling_seconds  : $SETTLING_SECONDS
  triplets_scanned  : $SCANNED
  files_deleted     : $DELETED
  files_kept        : $KEPT (bytes: $BYTES_USED)
  bytes_freed       : $BYTES_FREED
  oldest_kept_age_h : $OLDEST_AGE_HOURS
  cap_hit           : $DELETE_CAP_HIT
  status_log        : $STATUS_LOG
EOF
