#!/usr/bin/env bash
#
# manual-rollback.sh — break-glass rollback when the Slack bot is unhealthy.
#
# Run this directly via kubectl. Requires the same RBAC as the bot's
# ServiceAccount, plus a kubeconfig context pointed at the target cluster.
#
# Usage:
#   ./manual-rollback.sh <reason>
#
# Example:
#   ./manual-rollback.sh "bot-down; p99-regression-observed-manually"

set -euo pipefail

REASON="${1:-manual-unspecified}"
NAMESPACE="${K8S_NAMESPACE:-observability}"
CANARY="${K8S_CANARY_DEPLOYMENT:-otel-collector-canary}"
BASELINE="${K8S_BASELINE_DEPLOYMENT:-otel-collector-baseline}"
BASELINE_REPLICAS="${K8S_BASELINE_REPLICAS:-50}"

echo "===> rolling back canary in namespace ${NAMESPACE}"
echo "     reason: ${REASON}"
echo "     initiated: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "     kubectl context: $(kubectl config current-context)"
echo

read -r -p "Type 'ROLLBACK' to confirm: " confirm
if [[ "$confirm" != "ROLLBACK" ]]; then
  echo "aborted"
  exit 1
fi

echo "===> step 1/3: scale ${CANARY} -> 0"
kubectl -n "${NAMESPACE}" scale "deployment/${CANARY}" --replicas=0

echo "===> step 2/3: scale ${BASELINE} -> ${BASELINE_REPLICAS}"
kubectl -n "${NAMESPACE}" scale "deployment/${BASELINE}" --replicas="${BASELINE_REPLICAS}"

echo "===> step 3/3: wait for baseline rollout"
kubectl -n "${NAMESPACE}" rollout status "deployment/${BASELINE}" --timeout=180s

echo
echo "===> rollback complete."
echo "     next: file an incident, attach the last hour of Grafana dashboard 'OTel Canary v1'"

# Emit an audit record even in break-glass mode. Same schema as the bot's log.
audit_line=$(jq -n \
  --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  --arg reason "${REASON}" \
  --arg user "$(whoami)@$(hostname)" \
  --arg ns "${NAMESPACE}" \
  '{event:"rollback_complete_manual", ts:$ts, reason:$reason,
    user_id:$user, namespace:$ns}')
echo "${audit_line}"
if [[ -w /var/log/canary-rollback.jsonl ]]; then
  echo "${audit_line}" >> /var/log/canary-rollback.jsonl
fi
