package aggregatorprocessor

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.uber.org/zap/zaptest"
)

// -----------------------------------------------------------------------------
// Config tests
// -----------------------------------------------------------------------------

func TestConfigValidate(t *testing.T) {
	cases := []struct {
		name    string
		cfg     Config
		wantErr bool
	}{
		{"default is valid", *createDefaultConfig().(*Config), false},
		{"zero flush", Config{FlushInterval: 0, TTL: time.Second, EvictionInterval: time.Second}, true},
		{"zero ttl", Config{FlushInterval: time.Second, TTL: 0, EvictionInterval: time.Second}, true},
		{"zero eviction", Config{FlushInterval: time.Second, TTL: time.Second, EvictionInterval: 0}, true},
		{"negative max", Config{FlushInterval: time.Second, TTL: time.Second, EvictionInterval: time.Second, MaxSeries: -1}, true},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.cfg.Validate()
			if (err != nil) != tc.wantErr {
				t.Fatalf("Validate() err=%v wantErr=%v", err, tc.wantErr)
			}
		})
	}
}

// -----------------------------------------------------------------------------
// Aggregation-logic tests
// -----------------------------------------------------------------------------

// newTestProcessor constructs a processor with tight intervals and a
// deterministic clock, suitable for unit tests.
func newTestProcessor(t *testing.T, cfg *Config) (*aggregatorProcessor, *mockConsumer) {
	t.Helper()
	if cfg == nil {
		cfg = &Config{
			FlushInterval:     50 * time.Millisecond,
			TTL:               200 * time.Millisecond,
			EvictionInterval:  25 * time.Millisecond,
			AlignmentInterval: time.Second,
		}
	}
	if err := cfg.Validate(); err != nil {
		t.Fatalf("bad test config: %v", err)
	}
	sink := &mockConsumer{}
	p := newAggregatorProcessor(cfg, zaptest.NewLogger(t), sink)
	return p, sink
}

// TestSumAggregationSameSeries verifies that N inputs with identical identity
// but different values collapse into a single output point whose value is the
// arithmetic sum.
func TestSumAggregationSameSeries(t *testing.T) {
	p, sink := newTestProcessor(t, nil)
	if err := p.Start(context.Background(), nil); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = p.Shutdown(context.Background()) })

	ts := time.Unix(1_700_000_000, 0)
	resAttrs := map[string]string{"service.name": "checkout"}
	pointAttrs := map[string]string{"route": "/pay"}

	var expected int64
	for i := 1; i <= 100; i++ {
		md := buildSumMetric("http.requests", resAttrs, pointAttrs, int64(i), ts)
		if err := p.ConsumeMetrics(context.Background(), md); err != nil {
			t.Fatal(err)
		}
		expected += int64(i)
	}

	if err := p.flush(context.Background()); err != nil {
		t.Fatal(err)
	}

	got := sumSumMetricInts(sink.received(), "http.requests")
	if got != expected {
		t.Fatalf("aggregated sum=%d, want=%d", got, expected)
	}

	// After a flush, state should be drained.
	if n := p.state.len(); n != 0 {
		t.Fatalf("state should be drained after flush, got %d entries", n)
	}
}

// TestSumAggregationSeparateSeries ensures points with distinct attribute
// sets are NOT collapsed.
func TestSumAggregationSeparateSeries(t *testing.T) {
	p, sink := newTestProcessor(t, nil)
	_ = p.Start(context.Background(), nil)
	t.Cleanup(func() { _ = p.Shutdown(context.Background()) })

	ts := time.Unix(1_700_000_000, 0)
	res := map[string]string{"service.name": "checkout"}

	for _, route := range []string{"/pay", "/cart", "/home"} {
		for i := 1; i <= 10; i++ {
			md := buildSumMetric("http.requests", res, map[string]string{"route": route}, int64(i), ts)
			if err := p.ConsumeMetrics(context.Background(), md); err != nil {
				t.Fatal(err)
			}
		}
	}

	if err := p.flush(context.Background()); err != nil {
		t.Fatal(err)
	}

	// Expect exactly one metric with 3 data points, each summing to 55.
	m, ok := findMetric(sink.received()[0], "http.requests")
	if !ok {
		t.Fatal("http.requests not found in output")
	}
	if got := m.Sum().DataPoints().Len(); got != 3 {
		t.Fatalf("want 3 series, got %d", got)
	}
	dps := m.Sum().DataPoints()
	for i := 0; i < dps.Len(); i++ {
		if dps.At(i).IntValue() != 55 {
			t.Fatalf("series %d: want 55, got %d", i, dps.At(i).IntValue())
		}
	}
}

// TestGaugeLastWriteWins verifies that gauge aggregation keeps the most
// recent observed value rather than summing.
func TestGaugeLastWriteWins(t *testing.T) {
	p, sink := newTestProcessor(t, nil)
	_ = p.Start(context.Background(), nil)
	t.Cleanup(func() { _ = p.Shutdown(context.Background()) })

	ts := time.Unix(1_700_000_000, 0)
	res := map[string]string{"host": "h1"}
	pa := map[string]string{"cpu": "0"}

	for _, v := range []float64{0.1, 0.5, 0.9, 0.42} {
		md := buildGaugeMetric("cpu.util", res, pa, v, ts)
		_ = p.ConsumeMetrics(context.Background(), md)
	}
	_ = p.flush(context.Background())

	m, ok := findMetric(sink.received()[0], "cpu.util")
	if !ok {
		t.Fatal("cpu.util not found")
	}
	if m.Gauge().DataPoints().Len() != 1 {
		t.Fatalf("want 1 point, got %d", m.Gauge().DataPoints().Len())
	}
	if got := m.Gauge().DataPoints().At(0).DoubleValue(); got != 0.42 {
		t.Fatalf("last-write-wins broken: got %v want 0.42", got)
	}
}

// TestHistogramBucketMerge verifies bucket counts are summed and sum/count
// track total observations.
func TestHistogramBucketMerge(t *testing.T) {
	p, sink := newTestProcessor(t, nil)
	_ = p.Start(context.Background(), nil)
	t.Cleanup(func() { _ = p.Shutdown(context.Background()) })

	ts := time.Unix(1_700_000_000, 0)
	bounds := []float64{10, 50, 100}
	// counts has len(bounds)+1
	md1 := buildHistogramMetric("latency", map[string]string{"op": "read"}, bounds, []uint64{1, 2, 3, 4}, 500, ts)
	md2 := buildHistogramMetric("latency", map[string]string{"op": "read"}, bounds, []uint64{4, 3, 2, 1}, 300, ts)

	_ = p.ConsumeMetrics(context.Background(), md1)
	_ = p.ConsumeMetrics(context.Background(), md2)
	_ = p.flush(context.Background())

	m, ok := findMetric(sink.received()[0], "latency")
	if !ok {
		t.Fatal("latency not found")
	}
	dp := m.Histogram().DataPoints().At(0)
	wantCounts := []uint64{5, 5, 5, 5}
	got := dp.BucketCounts().AsRaw()
	if len(got) != len(wantCounts) {
		t.Fatalf("bucket count len: got %d want %d", len(got), len(wantCounts))
	}
	for i := range wantCounts {
		if got[i] != wantCounts[i] {
			t.Fatalf("bucket %d: got %d want %d", i, got[i], wantCounts[i])
		}
	}
	if dp.Sum() != 800 {
		t.Fatalf("sum: got %v want 800", dp.Sum())
	}
	if dp.Count() != 20 {
		t.Fatalf("count: got %d want 20", dp.Count())
	}
}

// TestTTLEviction drives the eviction loop directly and verifies stale
// entries disappear from the state map.
func TestTTLEviction(t *testing.T) {
	fakeNow := time.Unix(1_700_000_000, 0)
	p, _ := newTestProcessor(t, &Config{
		FlushInterval:     time.Hour, // effectively disabled
		TTL:               100 * time.Millisecond,
		EvictionInterval:  time.Hour, // we call manually
		AlignmentInterval: time.Second,
	})
	// Inject deterministic clock.
	p.nowFn = func() time.Time { return fakeNow }

	// No Start(): we manipulate state directly to keep the test hermetic.
	ts := time.Unix(1_700_000_000, 0)
	md := buildSumMetric("x", nil, map[string]string{"k": "v"}, 1, ts)
	_ = p.ConsumeMetrics(context.Background(), md)
	if p.state.len() != 1 {
		t.Fatalf("want 1 entry, got %d", p.state.len())
	}

	// Advance clock past the TTL and run eviction.
	fakeNow = fakeNow.Add(500 * time.Millisecond)
	evicted := p.state.evictOlderThan(p.nowFn().Add(-p.cfg.TTL))
	if evicted != 1 {
		t.Fatalf("want 1 evicted, got %d", evicted)
	}
	if p.state.len() != 0 {
		t.Fatalf("state not empty after eviction: %d", p.state.len())
	}
}

// TestMaxSeriesCap verifies that new series are dropped once the cap is
// reached, while existing series continue to accept updates.
func TestMaxSeriesCap(t *testing.T) {
	p, _ := newTestProcessor(t, &Config{
		FlushInterval:     time.Hour,
		TTL:               time.Hour,
		EvictionInterval:  time.Hour,
		AlignmentInterval: time.Second,
		MaxSeries:         3,
	})
	ts := time.Unix(1_700_000_000, 0)

	// Insert 3 distinct series — all should be accepted.
	for _, r := range []string{"a", "b", "c"} {
		_ = p.ConsumeMetrics(context.Background(),
			buildSumMetric("m", nil, map[string]string{"r": r}, 1, ts))
	}
	if p.state.len() != 3 {
		t.Fatalf("want 3 series, got %d", p.state.len())
	}

	// New series "d" must be dropped, but updates to "a" must still land.
	_ = p.ConsumeMetrics(context.Background(),
		buildSumMetric("m", nil, map[string]string{"r": "d"}, 1, ts))
	_ = p.ConsumeMetrics(context.Background(),
		buildSumMetric("m", nil, map[string]string{"r": "a"}, 99, ts))

	if p.state.len() != 3 {
		t.Fatalf("cap not enforced: %d series", p.state.len())
	}

	_ = p.flush(context.Background())
}

// TestFullPipelineViaFactory exercises the factory and verifies the
// component.Component / consumer.Metrics interfaces are satisfied.
func TestFullPipelineViaFactory(t *testing.T) {
	factory := NewFactory()
	cfg := factory.CreateDefaultConfig().(*Config)
	cfg.FlushInterval = 25 * time.Millisecond
	cfg.EvictionInterval = 25 * time.Millisecond

	sink := &mockConsumer{}
	set := processorSettingsForTest(t)
	proc, err := factory.CreateMetrics(context.Background(), set, cfg, sink)
	if err != nil {
		t.Fatal(err)
	}
	if err := proc.Start(context.Background(), nil); err != nil {
		t.Fatal(err)
	}
	defer func() { _ = proc.Shutdown(context.Background()) }()

	// Verify interface compliance at run-time.
	var _ component.Component = proc

	ts := time.Now()
	for i := 0; i < 20; i++ {
		_ = proc.ConsumeMetrics(context.Background(),
			buildSumMetric("requests", map[string]string{"svc": "s"}, map[string]string{"code": "200"}, 1, ts))
	}

	// Wait long enough for the flush loop to tick at least once.
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		if len(sink.received()) > 0 {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if len(sink.received()) == 0 {
		t.Fatal("no flushed batches received")
	}
	if got := sumSumMetricInts(sink.received(), "requests"); got != 20 {
		t.Fatalf("aggregated sum=%d, want 20", got)
	}
}

// -----------------------------------------------------------------------------
// Concurrency / high-cardinality safety tests
// -----------------------------------------------------------------------------

// TestConcurrentHighCardinality launches many goroutines each producing
// samples across a large attribute space, then verifies that the total
// aggregate is exactly correct (no double-counting, no dropped updates)
// and that the process is race-free.
//
// Run with `-race` to fully exercise this test.
func TestConcurrentHighCardinality(t *testing.T) {
	const (
		producers      = 32
		samplesEach    = 500
		distinctRoutes = 200
	)

	p, sink := newTestProcessor(t, &Config{
		FlushInterval:     20 * time.Millisecond,
		TTL:               5 * time.Second,
		EvictionInterval:  50 * time.Millisecond,
		AlignmentInterval: time.Second,
	})
	if err := p.Start(context.Background(), nil); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = p.Shutdown(context.Background()) })

	ts := time.Unix(1_700_000_000, 0)
	var totalSent int64

	var wg sync.WaitGroup
	wg.Add(producers)
	for w := 0; w < producers; w++ {
		go func(worker int) {
			defer wg.Done()
			for i := 0; i < samplesEach; i++ {
				route := fmt.Sprintf("/r/%d", (worker*samplesEach+i)%distinctRoutes)
				md := buildSumMetric(
					"requests",
					map[string]string{"svc": "checkout"},
					map[string]string{"route": route},
					1, ts,
				)
				if err := p.ConsumeMetrics(context.Background(), md); err != nil {
					t.Errorf("ConsumeMetrics: %v", err)
					return
				}
				atomic.AddInt64(&totalSent, 1)
			}
		}(w)
	}
	wg.Wait()

	// Shut down — Shutdown does a final flush, so all state ends up in the
	// sink.
	if err := p.Shutdown(context.Background()); err != nil {
		t.Fatalf("shutdown: %v", err)
	}

	got := sumSumMetricInts(sink.received(), "requests")
	if got != totalSent {
		t.Fatalf("aggregate mismatch: got %d, sent %d (delta=%d)",
			got, totalSent, totalSent-got)
	}

	// Also verify the number of distinct series matches.
	seriesCount := 0
	seen := map[string]struct{}{}
	for _, b := range sink.received() {
		m, ok := findMetric(b, "requests")
		if !ok {
			continue
		}
		dps := m.Sum().DataPoints()
		for i := 0; i < dps.Len(); i++ {
			route, _ := dps.At(i).Attributes().Get("route")
			key := route.AsString()
			if _, dup := seen[key]; !dup {
				seen[key] = struct{}{}
				seriesCount++
			}
		}
	}
	if seriesCount != distinctRoutes {
		t.Fatalf("distinct series: got %d, want %d", seriesCount, distinctRoutes)
	}
}

// TestConcurrentFlushDuringIngest exercises the interleaving between
// producer goroutines and the async flush loop. The invariant is: every
// sample sent must appear in exactly one output batch (no loss, no
// duplication).
func TestConcurrentFlushDuringIngest(t *testing.T) {
	p, sink := newTestProcessor(t, &Config{
		FlushInterval:     5 * time.Millisecond, // aggressive flushing
		TTL:               time.Second,
		EvictionInterval:  20 * time.Millisecond,
		AlignmentInterval: time.Second,
	})
	if err := p.Start(context.Background(), nil); err != nil {
		t.Fatal(err)
	}

	const (
		producers   = 16
		samplesEach = 1000
	)

	ts := time.Unix(1_700_000_000, 0)
	var wg sync.WaitGroup
	wg.Add(producers)
	var sent int64
	for w := 0; w < producers; w++ {
		go func(worker int) {
			defer wg.Done()
			for i := 0; i < samplesEach; i++ {
				md := buildSumMetric("hits",
					map[string]string{"svc": "s"},
					map[string]string{"shard": fmt.Sprintf("%d", worker%8)},
					1, ts)
				_ = p.ConsumeMetrics(context.Background(), md)
				atomic.AddInt64(&sent, 1)
			}
		}(w)
	}
	wg.Wait()

	// Final flush via Shutdown.
	if err := p.Shutdown(context.Background()); err != nil {
		t.Fatalf("shutdown: %v", err)
	}

	got := sumSumMetricInts(sink.received(), "hits")
	if got != sent {
		t.Fatalf("hits: got %d sent %d", got, sent)
	}
}

// -----------------------------------------------------------------------------
// Identity / hash tests
// -----------------------------------------------------------------------------

// TestIdentityAttributeOrderIndependence proves that attribute insertion
// order doesn't affect the series key.
func TestIdentityAttributeOrderIndependence(t *testing.T) {
	ib := newIdentityBuilder(int64(time.Second))

	// Two maps with same content, different insertion order.
	md1 := buildSumMetric("m",
		map[string]string{"a": "1", "b": "2", "c": "3"},
		map[string]string{"x": "9", "y": "8"},
		1, time.Unix(1_700_000_000, 0))
	md2 := buildSumMetric("m",
		map[string]string{"c": "3", "a": "1", "b": "2"},
		map[string]string{"y": "8", "x": "9"},
		1, time.Unix(1_700_000_000, 0))

	rm1 := md1.ResourceMetrics().At(0)
	dp1 := rm1.ScopeMetrics().At(0).Metrics().At(0).Sum().DataPoints().At(0)
	rm2 := md2.ResourceMetrics().At(0)
	dp2 := rm2.ScopeMetrics().At(0).Metrics().At(0).Sum().DataPoints().At(0)

	k1, _ := ib.buildKey(rm1.Resource().Attributes(), rm1.ScopeMetrics().At(0).Scope(),
		"m", "1", pmetric.MetricTypeSum, dp1.Attributes(), uint64(dp1.Timestamp()))
	k2, _ := ib.buildKey(rm2.Resource().Attributes(), rm2.ScopeMetrics().At(0).Scope(),
		"m", "1", pmetric.MetricTypeSum, dp2.Attributes(), uint64(dp2.Timestamp()))

	if k1 != k2 {
		t.Fatalf("keys differ despite identical content: %+v vs %+v", k1, k2)
	}
}

// TestIdentityDifferentAttributesDistinct verifies distinct attributes
// produce distinct keys.
func TestIdentityDifferentAttributesDistinct(t *testing.T) {
	ib := newIdentityBuilder(int64(time.Second))
	base := time.Unix(1_700_000_000, 0)

	md1 := buildSumMetric("m", nil, map[string]string{"k": "a"}, 1, base)
	md2 := buildSumMetric("m", nil, map[string]string{"k": "b"}, 1, base)

	dp1 := md1.ResourceMetrics().At(0).ScopeMetrics().At(0).Metrics().At(0).Sum().DataPoints().At(0)
	dp2 := md2.ResourceMetrics().At(0).ScopeMetrics().At(0).Metrics().At(0).Sum().DataPoints().At(0)

	k1, _ := ib.buildKey(md1.ResourceMetrics().At(0).Resource().Attributes(),
		md1.ResourceMetrics().At(0).ScopeMetrics().At(0).Scope(),
		"m", "1", pmetric.MetricTypeSum, dp1.Attributes(), uint64(dp1.Timestamp()))
	k2, _ := ib.buildKey(md2.ResourceMetrics().At(0).Resource().Attributes(),
		md2.ResourceMetrics().At(0).ScopeMetrics().At(0).Scope(),
		"m", "1", pmetric.MetricTypeSum, dp2.Attributes(), uint64(dp2.Timestamp()))

	if k1 == k2 {
		t.Fatal("keys collided across different attributes")
	}
}

// TestAlignmentBucketing verifies that two timestamps within the same
// alignment window map to the same key.
func TestAlignmentBucketing(t *testing.T) {
	ib := newIdentityBuilder(int64(10 * time.Second))
	base := time.Unix(1_700_000_000, 0)

	md1 := buildSumMetric("m", nil, map[string]string{"k": "v"}, 1, base)
	md2 := buildSumMetric("m", nil, map[string]string{"k": "v"}, 1, base.Add(3*time.Second))
	md3 := buildSumMetric("m", nil, map[string]string{"k": "v"}, 1, base.Add(20*time.Second))

	getDP := func(md pmetric.Metrics) pmetric.NumberDataPoint {
		return md.ResourceMetrics().At(0).ScopeMetrics().At(0).Metrics().At(0).Sum().DataPoints().At(0)
	}
	dp1, dp2, dp3 := getDP(md1), getDP(md2), getDP(md3)

	k1, _ := ib.buildKey(md1.ResourceMetrics().At(0).Resource().Attributes(),
		md1.ResourceMetrics().At(0).ScopeMetrics().At(0).Scope(),
		"m", "1", pmetric.MetricTypeSum, dp1.Attributes(), uint64(dp1.Timestamp()))
	k2, _ := ib.buildKey(md2.ResourceMetrics().At(0).Resource().Attributes(),
		md2.ResourceMetrics().At(0).ScopeMetrics().At(0).Scope(),
		"m", "1", pmetric.MetricTypeSum, dp2.Attributes(), uint64(dp2.Timestamp()))
	k3, _ := ib.buildKey(md3.ResourceMetrics().At(0).Resource().Attributes(),
		md3.ResourceMetrics().At(0).ScopeMetrics().At(0).Scope(),
		"m", "1", pmetric.MetricTypeSum, dp3.Attributes(), uint64(dp3.Timestamp()))

	if k1 != k2 {
		t.Fatal("same bucket: keys should be equal")
	}
	if k1 == k3 {
		t.Fatal("different bucket: keys should differ")
	}
}
