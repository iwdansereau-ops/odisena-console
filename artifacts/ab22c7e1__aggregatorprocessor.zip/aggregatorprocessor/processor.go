package aggregatorprocessor

import (
	"context"
	"math"
	"sync"
	"time"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.uber.org/zap"
)

// aggregatorProcessor is the main type. It satisfies both component.Component
// (Start/Shutdown lifecycle) and consumer.Metrics (ConsumeMetrics ingestion).
type aggregatorProcessor struct {
	cfg    *Config
	logger *zap.Logger
	next   consumer.Metrics

	state    *stateMap
	identity *identityBuilder

	// Lifecycle plumbing for the background goroutines.
	cancel   context.CancelFunc
	bgCtx    context.Context
	bgWG     sync.WaitGroup
	stopOnce sync.Once

	// nowFn is injectable for deterministic tests.
	nowFn func() time.Time
}

// Compile-time assertions.
var (
	_ component.Component = (*aggregatorProcessor)(nil)
	_ consumer.Metrics    = (*aggregatorProcessor)(nil)
)

// newAggregatorProcessor constructs an aggregator wired to the given next
// consumer. Public entry point used by the factory.
func newAggregatorProcessor(cfg *Config, logger *zap.Logger, next consumer.Metrics) *aggregatorProcessor {
	if logger == nil {
		logger = zap.NewNop()
	}
	return &aggregatorProcessor{
		cfg:      cfg,
		logger:   logger,
		next:     next,
		state:    newStateMap(cfg.MaxSeries),
		identity: newIdentityBuilder(int64(cfg.AlignmentInterval)),
		nowFn:    time.Now,
	}
}

// Capabilities reports that this processor does not mutate incoming data in
// place — it consumes it, produces new pdata on flush, and passes through
// unmodified. This lets upstream components share buffers safely.
func (p *aggregatorProcessor) Capabilities() consumer.Capabilities {
	return consumer.Capabilities{MutatesData: false}
}

// Start launches the periodic flush + TTL eviction goroutines.
func (p *aggregatorProcessor) Start(ctx context.Context, _ component.Host) error {
	p.bgCtx, p.cancel = context.WithCancel(context.Background())

	p.bgWG.Add(2)
	go p.runFlushLoop()
	go p.runEvictionLoop()

	p.logger.Info("aggregator processor started",
		zap.Duration("flush_interval", p.cfg.FlushInterval),
		zap.Duration("ttl", p.cfg.TTL),
		zap.Duration("eviction_interval", p.cfg.EvictionInterval),
		zap.Int("max_series", p.cfg.MaxSeries))
	_ = ctx
	return nil
}

// Shutdown flushes any pending aggregates and stops background goroutines.
func (p *aggregatorProcessor) Shutdown(ctx context.Context) error {
	var err error
	p.stopOnce.Do(func() {
		if p.cancel != nil {
			p.cancel()
		}
		p.bgWG.Wait()
		// Final flush so we don't drop what's in memory on graceful stop.
		err = p.flush(ctx)
	})
	return err
}

// runFlushLoop periodically drains the state map and forwards aggregated
// metrics to the next consumer.
func (p *aggregatorProcessor) runFlushLoop() {
	defer p.bgWG.Done()
	t := time.NewTicker(p.cfg.FlushInterval)
	defer t.Stop()
	for {
		select {
		case <-p.bgCtx.Done():
			return
		case <-t.C:
			if err := p.flush(p.bgCtx); err != nil {
				p.logger.Warn("flush failed", zap.Error(err))
			}
		}
	}
}

// runEvictionLoop periodically removes series that have not been touched
// within cfg.TTL. This is what prevents unbounded memory growth in the face
// of high-cardinality label churn.
func (p *aggregatorProcessor) runEvictionLoop() {
	defer p.bgWG.Done()
	t := time.NewTicker(p.cfg.EvictionInterval)
	defer t.Stop()
	for {
		select {
		case <-p.bgCtx.Done():
			return
		case <-t.C:
			cutoff := p.nowFn().Add(-p.cfg.TTL)
			n := p.state.evictOlderThan(cutoff)
			if n > 0 {
				p.logger.Debug("evicted stale series",
					zap.Int("count", n),
					zap.Int("remaining", p.state.len()))
			}
		}
	}
}

// ConsumeMetrics is the ingestion path. It walks the pdata tree, hashes
// each data point into a series key, and merges into the state map. No
// downstream call is made here — flushing is handled asynchronously.
func (p *aggregatorProcessor) ConsumeMetrics(_ context.Context, md pmetric.Metrics) error {
	now := p.nowFn()

	rms := md.ResourceMetrics()
	for i := 0; i < rms.Len(); i++ {
		rm := rms.At(i)
		resAttrs := rm.Resource().Attributes()

		sms := rm.ScopeMetrics()
		for j := 0; j < sms.Len(); j++ {
			sm := sms.At(j)
			scope := sm.Scope()

			metrics := sm.Metrics()
			for k := 0; k < metrics.Len(); k++ {
				m := metrics.At(k)
				p.ingestMetric(resAttrs, scope, m, now)
			}
		}
	}
	return nil
}

// ingestMetric dispatches on metric type and folds each data point into
// state.
func (p *aggregatorProcessor) ingestMetric(
	resAttrs pcommon.Map,
	scope pcommon.InstrumentationScope,
	m pmetric.Metric,
	now time.Time,
) {
	switch m.Type() {
	case pmetric.MetricTypeSum:
		p.ingestNumeric(resAttrs, scope, m, m.Sum().DataPoints(),
			pmetric.MetricTypeSum, m.Sum().IsMonotonic(), m.Sum().AggregationTemporality(), now)
	case pmetric.MetricTypeGauge:
		p.ingestNumeric(resAttrs, scope, m, m.Gauge().DataPoints(),
			pmetric.MetricTypeGauge, false, pmetric.AggregationTemporalityUnspecified, now)
	case pmetric.MetricTypeHistogram:
		p.ingestHistogram(resAttrs, scope, m, now)
	default:
		// ExponentialHistogram / Summary intentionally unsupported here —
		// they belong in a dedicated processor. Silently pass through.
	}
}

func (p *aggregatorProcessor) ingestNumeric(
	resAttrs pcommon.Map,
	scope pcommon.InstrumentationScope,
	m pmetric.Metric,
	dps pmetric.NumberDataPointSlice,
	mtype pmetric.MetricType,
	isMonotonic bool,
	temporality pmetric.AggregationTemporality,
	now time.Time,
) {
	for i := 0; i < dps.Len(); i++ {
		dp := dps.At(i)
		key, bucketNanos := p.identity.buildKey(
			resAttrs, scope, m.Name(), m.Unit(), mtype,
			dp.Attributes(), uint64(dp.Timestamp()),
		)

		isInt := dp.ValueType() == pmetric.NumberDataPointValueTypeInt
		var vFloat float64
		var vInt int64
		if isInt {
			vInt = dp.IntValue()
		} else {
			vFloat = dp.DoubleValue()
		}

		// Snapshot identity fields once, in a closure the state map calls
		// only on first insertion. Copies detach us from source pdata.
		build := func() *aggregatedSeries {
			as := &aggregatedSeries{
				resourceAttrs: pcommon.NewMap(),
				scopeName:     scope.Name(),
				scopeVersion:  scope.Version(),
				scopeAttrs:    pcommon.NewMap(),
				metricName:    m.Name(),
				metricDesc:    m.Description(),
				metricUnit:    m.Unit(),
				metricType:    mtype,
				isMonotonic:   isMonotonic,
				temporality:   temporality,
				pointAttrs:    pcommon.NewMap(),
				isInt:         isInt,
				startTime:     dp.StartTimestamp(),
				bucketTime:    pcommon.Timestamp(bucketNanos),
			}
			resAttrs.CopyTo(as.resourceAttrs)
			scope.Attributes().CopyTo(as.scopeAttrs)
			dp.Attributes().CopyTo(as.pointAttrs)
			return as
		}

		if !p.state.upsertNumeric(key, build, isInt, vFloat, vInt, now) {
			p.logger.Debug("dropping data point due to max_series cap",
				zap.String("metric", m.Name()))
		}
	}
}

func (p *aggregatorProcessor) ingestHistogram(
	resAttrs pcommon.Map,
	scope pcommon.InstrumentationScope,
	m pmetric.Metric,
	now time.Time,
) {
	dps := m.Histogram().DataPoints()
	temporality := m.Histogram().AggregationTemporality()

	for i := 0; i < dps.Len(); i++ {
		dp := dps.At(i)
		key, bucketNanos := p.identity.buildKey(
			resAttrs, scope, m.Name(), m.Unit(), pmetric.MetricTypeHistogram,
			dp.Attributes(), uint64(dp.Timestamp()),
		)

		bounds := dp.ExplicitBounds().AsRaw()
		counts := dp.BucketCounts().AsRaw()

		var minV, maxV float64
		hasMinMax := dp.HasMin() && dp.HasMax()
		if hasMinMax {
			minV, maxV = dp.Min(), dp.Max()
		}

		build := func() *aggregatedSeries {
			as := &aggregatedSeries{
				resourceAttrs: pcommon.NewMap(),
				scopeName:     scope.Name(),
				scopeVersion:  scope.Version(),
				scopeAttrs:    pcommon.NewMap(),
				metricName:    m.Name(),
				metricDesc:    m.Description(),
				metricUnit:    m.Unit(),
				metricType:    pmetric.MetricTypeHistogram,
				temporality:   temporality,
				pointAttrs:    pcommon.NewMap(),
				startTime:     dp.StartTimestamp(),
				bucketTime:    pcommon.Timestamp(bucketNanos),
			}
			resAttrs.CopyTo(as.resourceAttrs)
			scope.Attributes().CopyTo(as.scopeAttrs)
			dp.Attributes().CopyTo(as.pointAttrs)
			return as
		}

		if !p.state.upsertHistogram(key, build, bounds, counts, dp.Sum(), minV, maxV, hasMinMax, now) {
			p.logger.Debug("dropping histogram point due to max_series cap",
				zap.String("metric", m.Name()))
		}
	}
}

// flush drains every accumulated series into a freshly-built pmetric.Metrics
// object and forwards it to the next consumer. Series are grouped by
// (resourceAttrs, scope) so we emit well-formed ResourceMetrics /
// ScopeMetrics tuples.
func (p *aggregatorProcessor) flush(ctx context.Context) error {
	drained := p.state.drain()
	if len(drained) == 0 {
		return nil
	}
	out := p.buildOutput(drained)
	return p.next.ConsumeMetrics(ctx, out)
}

// buildOutput materializes drained series into a pmetric.Metrics tree.
// Grouping is done by a string join of (resource fingerprint, scope name/ver)
// to keep the code simple; identity was already established at hash time.
func (p *aggregatorProcessor) buildOutput(drained []*aggregatedSeries) pmetric.Metrics {
	out := pmetric.NewMetrics()

	type scopeBucket struct {
		sm     pmetric.ScopeMetrics
		byName map[string]pmetric.Metric
	}
	type resBucket struct {
		rm     pmetric.ResourceMetrics
		scopes map[string]*scopeBucket
	}

	resBuckets := map[string]*resBucket{}

	for _, as := range drained {
		resFP := attrFingerprint(as.resourceAttrs)
		rb, ok := resBuckets[resFP]
		if !ok {
			rm := out.ResourceMetrics().AppendEmpty()
			as.resourceAttrs.CopyTo(rm.Resource().Attributes())
			rb = &resBucket{rm: rm, scopes: map[string]*scopeBucket{}}
			resBuckets[resFP] = rb
		}

		scopeFP := as.scopeName + "\x00" + as.scopeVersion
		sb, ok := rb.scopes[scopeFP]
		if !ok {
			sm := rb.rm.ScopeMetrics().AppendEmpty()
			sm.Scope().SetName(as.scopeName)
			sm.Scope().SetVersion(as.scopeVersion)
			as.scopeAttrs.CopyTo(sm.Scope().Attributes())
			sb = &scopeBucket{sm: sm, byName: map[string]pmetric.Metric{}}
			rb.scopes[scopeFP] = sb
		}

		metricFP := as.metricName + "\x00" + as.metricUnit + "\x00" + as.metricType.String()
		m, ok := sb.byName[metricFP]
		if !ok {
			m = sb.sm.Metrics().AppendEmpty()
			m.SetName(as.metricName)
			m.SetDescription(as.metricDesc)
			m.SetUnit(as.metricUnit)
			switch as.metricType {
			case pmetric.MetricTypeSum:
				s := m.SetEmptySum()
				s.SetIsMonotonic(as.isMonotonic)
				// We always emit delta — this processor produces fresh
				// deltas each flush interval by draining state.
				s.SetAggregationTemporality(pmetric.AggregationTemporalityDelta)
			case pmetric.MetricTypeGauge:
				m.SetEmptyGauge()
			case pmetric.MetricTypeHistogram:
				h := m.SetEmptyHistogram()
				h.SetAggregationTemporality(pmetric.AggregationTemporalityDelta)
			}
			sb.byName[metricFP] = m
		}

		appendPoint(m, as)
	}

	return out
}

// appendPoint materializes one aggregatedSeries into a data point on m.
func appendPoint(m pmetric.Metric, as *aggregatedSeries) {
	switch as.metricType {
	case pmetric.MetricTypeSum:
		dp := m.Sum().DataPoints().AppendEmpty()
		as.pointAttrs.CopyTo(dp.Attributes())
		dp.SetStartTimestamp(as.startTime)
		dp.SetTimestamp(as.bucketTime)
		if as.isInt {
			dp.SetIntValue(as.sumInt)
		} else {
			dp.SetDoubleValue(as.sumFloat)
		}
	case pmetric.MetricTypeGauge:
		dp := m.Gauge().DataPoints().AppendEmpty()
		as.pointAttrs.CopyTo(dp.Attributes())
		dp.SetStartTimestamp(as.startTime)
		dp.SetTimestamp(as.bucketTime)
		if as.isInt {
			dp.SetIntValue(as.gaugeLastI)
		} else {
			dp.SetDoubleValue(as.gaugeLastF)
		}
	case pmetric.MetricTypeHistogram:
		dp := m.Histogram().DataPoints().AppendEmpty()
		as.pointAttrs.CopyTo(dp.Attributes())
		dp.SetStartTimestamp(as.startTime)
		dp.SetTimestamp(as.bucketTime)
		dp.SetCount(sumCounts(as.histCounts))
		dp.SetSum(as.histSum)
		if !math.IsInf(as.histMin, 1) {
			dp.SetMin(as.histMin)
		}
		if !math.IsInf(as.histMax, -1) {
			dp.SetMax(as.histMax)
		}
		dp.ExplicitBounds().FromRaw(append([]float64(nil), as.histBounds...))
		dp.BucketCounts().FromRaw(append([]uint64(nil), as.histCounts...))
	}
}

func sumCounts(cs []uint64) uint64 {
	var n uint64
	for _, c := range cs {
		n += c
	}
	return n
}

// attrFingerprint returns a stable string for grouping resource maps at
// flush time. Uses the same key-sorting as identityBuilder for consistency.
func attrFingerprint(m pcommon.Map) string {
	if m.Len() == 0 {
		return ""
	}
	keys := make([]string, 0, m.Len())
	m.Range(func(k string, _ pcommon.Value) bool {
		keys = append(keys, k)
		return true
	})
	// Small n; a sort is fine.
	for i := 1; i < len(keys); i++ {
		for j := i; j > 0 && keys[j-1] > keys[j]; j-- {
			keys[j-1], keys[j] = keys[j], keys[j-1]
		}
	}
	buf := make([]byte, 0, 64)
	for _, k := range keys {
		v, _ := m.Get(k)
		buf = append(buf, k...)
		buf = append(buf, 0x1f)
		buf = append(buf, v.AsString()...)
		buf = append(buf, 0x1e)
	}
	return string(buf)
}
