package aggregatorprocessor

import (
	"context"
	"fmt"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/processor"
)

// typeStr is the config identifier for this processor.
const typeStr = "aggregator"

// NewFactory returns a component.Factory for the aggregator processor.
// This is the entry point a collector build would import.
func NewFactory() processor.Factory {
	return processor.NewFactory(
		component.MustNewType(typeStr),
		createDefaultConfig,
		processor.WithMetrics(createMetricsProcessor, component.StabilityLevelBeta),
	)
}

func createMetricsProcessor(
	_ context.Context,
	set processor.Settings,
	rawCfg component.Config,
	next consumer.Metrics,
) (processor.Metrics, error) {
	cfg, ok := rawCfg.(*Config)
	if !ok {
		return nil, fmt.Errorf("unexpected config type %T", rawCfg)
	}
	return newAggregatorProcessor(cfg, set.Logger, next), nil
}
