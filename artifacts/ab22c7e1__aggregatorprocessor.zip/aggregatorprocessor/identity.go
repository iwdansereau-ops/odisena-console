package aggregatorprocessor

import (
	"encoding/binary"
	"hash/fnv"
	"sort"

	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/pmetric"
)

// seriesKey is the map key for the aggregation state. It is a 128-bit
// composite so we can effectively treat it as collision-free for realistic
// workloads without holding a full string identity in memory.
type seriesKey struct {
	hi uint64
	lo uint64
}

// identityBuilder builds a stable hash for a metric data point. The hash is
// order-independent over attribute maps (keys are sorted before hashing).
//
// Fields folded into the hash:
//   - resource attributes
//   - instrumentation scope name + version
//   - metric name + unit + type
//   - data point attributes
//   - aligned timestamp bucket
type identityBuilder struct {
	alignmentNanos int64
}

func newIdentityBuilder(alignmentNanos int64) *identityBuilder {
	return &identityBuilder{alignmentNanos: alignmentNanos}
}

// buildKey computes the seriesKey and also returns the aligned timestamp
// (in unix nanos) that identifies the bucket this point falls into.
func (ib *identityBuilder) buildKey(
	resAttrs pcommon.Map,
	scope pcommon.InstrumentationScope,
	metricName, metricUnit string,
	metricType pmetric.MetricType,
	pointAttrs pcommon.Map,
	tsNanos uint64,
) (seriesKey, uint64) {
	// Two independent hashes → 128 bits.
	h1 := fnv.New64a()
	h2 := fnv.New64()

	writeMap := func(m pcommon.Map) {
		// Collect + sort keys so the hash is order-independent.
		keys := make([]string, 0, m.Len())
		m.Range(func(k string, _ pcommon.Value) bool {
			keys = append(keys, k)
			return true
		})
		sort.Strings(keys)
		for _, k := range keys {
			v, _ := m.Get(k)
			h1.Write([]byte(k))
			h1.Write([]byte{0x1f})
			h1.Write([]byte(v.AsString()))
			h1.Write([]byte{0x1e})
			h2.Write([]byte(k))
			h2.Write([]byte{0x1f})
			h2.Write([]byte(v.AsString()))
			h2.Write([]byte{0x1e})
		}
	}

	writeStr := func(s string) {
		h1.Write([]byte(s))
		h1.Write([]byte{0x1d})
		h2.Write([]byte(s))
		h2.Write([]byte{0x1d})
	}

	// Align timestamp into a bucket.
	var bucket uint64
	if ib.alignmentNanos > 0 {
		bucket = tsNanos - (tsNanos % uint64(ib.alignmentNanos))
	} else {
		bucket = tsNanos
	}

	writeMap(resAttrs)
	writeStr(scope.Name())
	writeStr(scope.Version())
	writeStr(metricName)
	writeStr(metricUnit)

	var typeByte [1]byte
	typeByte[0] = byte(metricType)
	h1.Write(typeByte[:])
	h2.Write(typeByte[:])

	writeMap(pointAttrs)

	var tsBuf [8]byte
	binary.BigEndian.PutUint64(tsBuf[:], bucket)
	h1.Write(tsBuf[:])
	h2.Write(tsBuf[:])

	return seriesKey{hi: h1.Sum64(), lo: h2.Sum64()}, bucket
}
