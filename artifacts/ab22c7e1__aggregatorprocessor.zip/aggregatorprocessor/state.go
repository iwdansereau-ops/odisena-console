package aggregatorprocessor

import (
	"math"
	"sync"
	"time"

	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/pmetric"
)

// aggregatedSeries holds the running state for one time series bucket.
//
// The struct captures enough context to reconstruct a full pdata.Metric on
// flush (resource + scope + metric metadata + attributes), plus the running
// numeric aggregate. Only one of {sumInt, sumFloat, gaugeLast*, histogram}
// is used, determined by metricType/isMonotonic/isInt.
type aggregatedSeries struct {
	// Identity — copied on first insertion so the source pdata can be
	// released immediately.
	resourceAttrs pcommon.Map
	scopeName     string
	scopeVersion  string
	scopeAttrs    pcommon.Map
	metricName    string
	metricDesc    string
	metricUnit    string
	metricType    pmetric.MetricType
	isMonotonic   bool
	temporality   pmetric.AggregationTemporality
	pointAttrs    pcommon.Map

	// Running aggregate values.
	isInt      bool
	sumInt     int64
	sumFloat   float64
	count      uint64
	gaugeLastF float64
	gaugeLastI int64

	// Histogram running state (simple bucket-wise sum). Only populated for
	// Histogram metric type.
	histBounds []float64
	histCounts []uint64
	histSum    float64
	histMin    float64
	histMax    float64

	// Timestamps.
	startTime  pcommon.Timestamp
	bucketTime pcommon.Timestamp // aligned event time this series represents
	lastUpdate time.Time         // wall-clock, used by TTL evictor
}

// LockObserver is an optional hook invoked around every state-map mutex
// critical section. Implementations MUST be non-blocking; they run inside
// the hot path. Use them for latency accounting, not for logging or I/O.
//
// op is one of: "upsert", "drain", "evict", "len".
// waited is the time spent blocked on Lock().
// held is the time spent inside the critical section.
type LockObserver interface {
	OnLock(op string, waited, held time.Duration)
}

// stateMap is the mutex-protected aggregation store.
type stateMap struct {
	mu     sync.Mutex
	series map[seriesKey]*aggregatedSeries
	// maxSeries caps the map size. Zero == unlimited.
	maxSeries int
	// observer is optional; nil means "no instrumentation". Reading a nil
	// interface value in the hot path is essentially free.
	observer LockObserver
}

func newStateMap(maxSeries int) *stateMap {
	return &stateMap{
		series:    make(map[seriesKey]*aggregatedSeries),
		maxSeries: maxSeries,
	}
}

// setObserver installs a lock observer. Should be called before the state
// map begins accepting traffic; not safe for concurrent modification.
func (s *stateMap) setObserver(o LockObserver) { s.observer = o }

// lockAndTime acquires s.mu and returns (waited, lockedAt). Callers pair
// this with unlockAndReport in a defer for observable critical sections.
func (s *stateMap) lockAndTime() (waited time.Duration, lockedAt time.Time) {
	if s.observer == nil {
		s.mu.Lock()
		return 0, time.Time{}
	}
	start := time.Now()
	s.mu.Lock()
	lockedAt = time.Now()
	waited = lockedAt.Sub(start)
	return waited, lockedAt
}

func (s *stateMap) unlockAndReport(op string, waited time.Duration, lockedAt time.Time) {
	if s.observer == nil {
		s.mu.Unlock()
		return
	}
	held := time.Since(lockedAt)
	s.mu.Unlock()
	s.observer.OnLock(op, waited, held)
}

// upsertNumeric merges a numeric (Sum/Gauge) point into the state map.
// The returned bool is false if the series was dropped due to a MaxSeries
// cap. The caller should not retain any references to the input pdata.
func (s *stateMap) upsertNumeric(
	key seriesKey,
	build func() *aggregatedSeries,
	isInt bool,
	valFloat float64,
	valInt int64,
	now time.Time,
) bool {
	waited, lockedAt := s.lockAndTime()
	defer s.unlockAndReport("upsert", waited, lockedAt)

	existing, ok := s.series[key]
	if !ok {
		if s.maxSeries > 0 && len(s.series) >= s.maxSeries {
			return false
		}
		existing = build()
		s.series[key] = existing
	}
	existing.lastUpdate = now
	existing.count++

	switch existing.metricType {
	case pmetric.MetricTypeSum:
		if isInt {
			existing.sumInt += valInt
		} else {
			existing.sumFloat += valFloat
		}
	case pmetric.MetricTypeGauge:
		// For gauges we track "last write wins" plus a running mean via
		// sumFloat/count if the caller wants a smoothed value. Here we keep
		// last as the emitted value.
		if isInt {
			existing.gaugeLastI = valInt
		} else {
			existing.gaugeLastF = valFloat
		}
	}
	return true
}

// upsertHistogram merges a histogram observation into the state map. The
// caller is expected to have decomposed a raw pdata HistogramDataPoint into
// (bounds, counts, sum, min, max).
func (s *stateMap) upsertHistogram(
	key seriesKey,
	build func() *aggregatedSeries,
	bounds []float64,
	counts []uint64,
	sum, min, max float64,
	hasMinMax bool,
	now time.Time,
) bool {
	waited, lockedAt := s.lockAndTime()
	defer s.unlockAndReport("upsert", waited, lockedAt)

	existing, ok := s.series[key]
	if !ok {
		if s.maxSeries > 0 && len(s.series) >= s.maxSeries {
			return false
		}
		existing = build()
		// Copy bucket layout on first sight.
		existing.histBounds = append([]float64(nil), bounds...)
		existing.histCounts = make([]uint64, len(counts))
		existing.histMin = math.Inf(1)
		existing.histMax = math.Inf(-1)
		s.series[key] = existing
	}
	existing.lastUpdate = now
	existing.count++

	// If bucket layouts differ, fall back to summing only sum/count so we
	// never silently combine incompatible histograms.
	if len(existing.histBounds) == len(bounds) {
		layoutMatches := true
		for i := range bounds {
			if bounds[i] != existing.histBounds[i] {
				layoutMatches = false
				break
			}
		}
		if layoutMatches && len(existing.histCounts) == len(counts) {
			for i := range counts {
				existing.histCounts[i] += counts[i]
			}
		}
	}
	existing.histSum += sum
	if hasMinMax {
		if min < existing.histMin {
			existing.histMin = min
		}
		if max > existing.histMax {
			existing.histMax = max
		}
	}
	return true
}

// drain removes and returns every series currently in the map. Used at flush
// time for delta-temporality output.
func (s *stateMap) drain() []*aggregatedSeries {
	waited, lockedAt := s.lockAndTime()
	defer s.unlockAndReport("drain", waited, lockedAt)
	out := make([]*aggregatedSeries, 0, len(s.series))
	for k, v := range s.series {
		out = append(out, v)
		delete(s.series, k)
	}
	return out
}

// evictOlderThan removes series whose lastUpdate is older than cutoff.
// Returns the number of entries evicted.
func (s *stateMap) evictOlderThan(cutoff time.Time) int {
	waited, lockedAt := s.lockAndTime()
	defer s.unlockAndReport("evict", waited, lockedAt)
	n := 0
	for k, v := range s.series {
		if v.lastUpdate.Before(cutoff) {
			delete(s.series, k)
			n++
		}
	}
	return n
}

// len returns the current size of the aggregation map. Used by tests and
// internal metrics.
func (s *stateMap) len() int {
	waited, lockedAt := s.lockAndTime()
	n := len(s.series)
	s.unlockAndReport("len", waited, lockedAt)
	return n
}
