package aggregatorprocessor

import (
	"context"
	"fmt"
	"math/rand"
	"runtime"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.uber.org/zap"
)

// -----------------------------------------------------------------------------
// Memory-measurement helpers
//
// We use runtime.ReadMemStats around GC to get a stable "live heap" reading.
// The pattern is:
//
//   1. Force GC + release memory to the OS baseline.
//   2. Do work (populate state).
//   3. Force GC again to drop transient allocations.
//   4. Read HeapAlloc.
//
// The delta (step-4 minus step-1) is a reasonable proxy for the retained
// footprint of the objects we care about. It is not perfectly precise —
// Go's runtime carries per-P caches and background allocations — but for a
// 1M-series test the signal dominates the noise by 2+ orders of magnitude.
// -----------------------------------------------------------------------------

// memStats returns HeapAlloc after two GC cycles.
func memStats() runtime.MemStats {
	runtime.GC()
	runtime.GC()
	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)
	return ms
}

// reportMemDelta records B/op-style numbers as custom benchmark metrics so
// `go test -bench` output shows them directly.
func reportMemDelta(b *testing.B, label string, before, after runtime.MemStats, n int) {
	b.Helper()
	heapDelta := int64(after.HeapAlloc) - int64(before.HeapAlloc)
	objDelta := int64(after.HeapObjects) - int64(before.HeapObjects)
	if n <= 0 {
		n = 1
	}
	b.ReportMetric(float64(heapDelta)/float64(n), label+"_bytes/series")
	b.ReportMetric(float64(objDelta)/float64(n), label+"_objs/series")
	b.ReportMetric(float64(heapDelta)/(1024*1024), label+"_total_MiB")
}

// newNullConsumer returns a zero-cost consumer.Metrics used when we want to
// isolate state-map cost from downstream serialization cost. Unlike
// mockConsumer in testhelpers_test.go this one does not clone the incoming
// batch — it only counts data points.
func newNullConsumer() *bareConsumer { return &bareConsumer{} }

// -----------------------------------------------------------------------------
// State-map micro-benchmarks
//
// These benchmarks target the aggregation store directly (no goroutines, no
// pdata construction) so we can isolate the per-series memory footprint.
// -----------------------------------------------------------------------------

// BenchmarkStateMap_Insert1M inserts 1,000,000 unique series into the state
// map and reports bytes/series and objects/series.
//
// Expected output includes custom metrics like:
//
//	statemap_bytes/series      ~ 300-500
//	statemap_objs/series       ~ 6-10
//	statemap_total_MiB         ~ 300-500
func BenchmarkStateMap_Insert1M(b *testing.B) {
	const target = 1_000_000

	for i := 0; i < b.N; i++ {
		b.StopTimer()
		before := memStats()

		state := newStateMap(0)
		build := func(seed int) func() *aggregatedSeries {
			return func() *aggregatedSeries {
				// Minimal series — matches what ingestNumeric would produce
				// for a Sum with a single point attribute.
				as := newBenchSeries(seed)
				return as
			}
		}

		b.StartTimer()
		now := time.Now()
		for s := 0; s < target; s++ {
			key := seriesKey{hi: uint64(s), lo: uint64(s) * 0x9E3779B97F4A7C15}
			state.upsertNumeric(key, build(s), true, 0, 1, now)
		}
		b.StopTimer()

		after := memStats()
		reportMemDelta(b, "statemap", before, after, target)

		if got := state.len(); got != target {
			b.Fatalf("state size: got %d want %d", got, target)
		}

		// Release before next iteration so successive b.N runs don't
		// accumulate.
		state = nil //nolint:ineffassign
		runtime.GC()
	}
}

// BenchmarkStateMap_LookupHot measures throughput of upserting into an
// already-populated 1M-series map (the steady-state path).
func BenchmarkStateMap_LookupHot(b *testing.B) {
	const target = 1_000_000
	state := newStateMap(0)
	now := time.Now()
	for s := 0; s < target; s++ {
		key := seriesKey{hi: uint64(s), lo: uint64(s) * 0x9E3779B97F4A7C15}
		state.upsertNumeric(key, func() *aggregatedSeries { return newBenchSeries(s) },
			true, 0, 1, now)
	}
	// Sanity check.
	if state.len() != target {
		b.Fatalf("setup: want %d entries, got %d", target, state.len())
	}

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		s := i % target
		key := seriesKey{hi: uint64(s), lo: uint64(s) * 0x9E3779B97F4A7C15}
		state.upsertNumeric(key, func() *aggregatedSeries {
			b.Fatal("hot path should never call build()")
			return nil
		}, true, 0, 1, now)
	}
}

// BenchmarkStateMap_Eviction1M measures how long it takes the TTL scanner
// to walk and clear a 1M-series map in one pass.
func BenchmarkStateMap_Eviction1M(b *testing.B) {
	const target = 1_000_000

	for i := 0; i < b.N; i++ {
		b.StopTimer()

		state := newStateMap(0)
		base := time.Unix(1_700_000_000, 0)
		for s := 0; s < target; s++ {
			key := seriesKey{hi: uint64(s), lo: uint64(s) * 0x9E3779B97F4A7C15}
			state.upsertNumeric(key, func() *aggregatedSeries { return newBenchSeries(s) },
				true, 0, 1, base)
		}

		before := memStats()

		b.StartTimer()
		// Cutoff in the future: every entry is stale.
		evicted := state.evictOlderThan(base.Add(time.Hour))
		b.StopTimer()

		after := memStats()
		if evicted != target {
			b.Fatalf("evicted %d, want %d", evicted, target)
		}
		if state.len() != 0 {
			b.Fatalf("state not empty: %d", state.len())
		}
		// Measure how much memory was released.
		heapReclaimed := int64(before.HeapAlloc) - int64(after.HeapAlloc)
		b.ReportMetric(float64(heapReclaimed)/(1024*1024), "reclaimed_MiB")
		b.ReportMetric(float64(evicted), "evicted_series")
	}
}

// -----------------------------------------------------------------------------
// End-to-end processor benchmarks — with churn and eviction loop running.
// -----------------------------------------------------------------------------

// BenchmarkProcessor_Churn1M simulates a workload where the aggregator sees
// 1M unique series over the course of the benchmark, but the working set at
// any moment is bounded by the TTL. This is the classic "high-cardinality
// churn" scenario: labels come and go, and we rely on eviction to keep
// memory flat.
//
// The benchmark asserts that after the workload the state map has fewer
// than a threshold (proving eviction actually ran) and reports peak heap
// during the workload.
func BenchmarkProcessor_Churn1M(b *testing.B) {
	const (
		totalSeries = 1_000_000
		batchSize   = 1_000 // series per ConsumeMetrics call
	)

	for iter := 0; iter < b.N; iter++ {
		b.StopTimer()
		before := memStats()

		cfg := &Config{
			FlushInterval:     100 * time.Millisecond,
			TTL:               50 * time.Millisecond, // aggressive TTL: forces frequent eviction
			EvictionInterval:  25 * time.Millisecond,
			AlignmentInterval: time.Second,
		}
		sink := newNullConsumer()
		p := newAggregatorProcessor(cfg, zap.NewNop(), sink)
		if err := p.Start(context.Background(), nil); err != nil {
			b.Fatal(err)
		}

		b.StartTimer()

		var peakHeap uint64
		var samplePoints atomic.Int64

		// Sample heap periodically in a background goroutine.
		stopSampler := make(chan struct{})
		samplerDone := make(chan struct{})
		go func() {
			defer close(samplerDone)
			t := time.NewTicker(20 * time.Millisecond)
			defer t.Stop()
			var ms runtime.MemStats
			for {
				select {
				case <-stopSampler:
					return
				case <-t.C:
					runtime.ReadMemStats(&ms)
					if ms.HeapAlloc > peakHeap {
						peakHeap = ms.HeapAlloc
					}
					samplePoints.Add(1)
				}
			}
		}()

		// Feed 1M unique series in batches. Each new batch's series
		// timestamps advance so previous series age out under the TTL.
		start := time.Now()
		for produced := 0; produced < totalSeries; produced += batchSize {
			md := buildBatch("churn.metric", produced, batchSize, start)
			if err := p.ConsumeMetrics(context.Background(), md); err != nil {
				b.Fatal(err)
			}
			// Small pause to let the eviction loop run and to spread work
			// across wall-clock time — the whole point of the churn
			// workload is that the TTL sees series age.
			if produced%(batchSize*50) == 0 {
				time.Sleep(1 * time.Millisecond)
			}
		}

		close(stopSampler)
		<-samplerDone

		// Give TTL one full window past the last insert so everything
		// should be evictable.
		time.Sleep(3 * cfg.TTL)

		// Trigger a synchronous eviction to guarantee determinism.
		p.state.evictOlderThan(time.Now().Add(-cfg.TTL))
		remaining := p.state.len()

		if err := p.Shutdown(context.Background()); err != nil {
			b.Fatal(err)
		}

		b.StopTimer()
		after := memStats()

		// Assertions:
		//
		//   1. The residual state map must be much smaller than
		//      totalSeries. If it isn't, eviction never fired and the
		//      benchmark is meaningless.
		//
		//   2. Peak heap must be bounded — a small multiple of the
		//      per-series cost times a plausible working set.
		if remaining > totalSeries/10 {
			b.Fatalf("eviction did not run: %d series remain of %d", remaining, totalSeries)
		}

		b.ReportMetric(float64(peakHeap)/(1024*1024), "peak_heap_MiB")
		b.ReportMetric(float64(after.HeapAlloc-before.HeapAlloc)/(1024*1024), "residual_heap_MiB")
		b.ReportMetric(float64(remaining), "residual_series")
		b.ReportMetric(float64(sink.consumed()), "downstream_datapoints")
	}
}

// BenchmarkProcessor_MaxSeriesCap validates that when MaxSeries is set, the
// aggregation map's memory usage does NOT grow beyond a bounded ceiling
// regardless of how many unique series the pipeline ingests.
//
// We push 5x MaxSeries unique series through the processor and verify:
//
//   - state.len() never exceeds MaxSeries
//   - heap usage stays within a small multiple of the cap's steady-state cost
//   - Shutdown flushes everything cleanly
func BenchmarkProcessor_MaxSeriesCap(b *testing.B) {
	const (
		maxSeries    = 100_000
		toIngest     = maxSeries * 5
		ingestBatchN = 1_000
	)

	for iter := 0; iter < b.N; iter++ {
		b.StopTimer()
		before := memStats()

		cfg := &Config{
			FlushInterval:     time.Hour, // effectively disable auto-flush
			TTL:               time.Hour, // effectively disable eviction
			EvictionInterval:  time.Hour,
			AlignmentInterval: time.Second,
			MaxSeries:         maxSeries,
		}
		sink := newNullConsumer()
		p := newAggregatorProcessor(cfg, zap.NewNop(), sink)
		if err := p.Start(context.Background(), nil); err != nil {
			b.Fatal(err)
		}

		var peakHeap uint64
		var peakLen int

		b.StartTimer()

		start := time.Now()
		for produced := 0; produced < toIngest; produced += ingestBatchN {
			md := buildBatch("capped.metric", produced, ingestBatchN, start)
			if err := p.ConsumeMetrics(context.Background(), md); err != nil {
				b.Fatal(err)
			}
			if l := p.state.len(); l > peakLen {
				peakLen = l
			}
			if produced%(ingestBatchN*20) == 0 {
				var ms runtime.MemStats
				runtime.ReadMemStats(&ms)
				if ms.HeapAlloc > peakHeap {
					peakHeap = ms.HeapAlloc
				}
			}
		}

		b.StopTimer()
		after := memStats()

		if peakLen > maxSeries {
			b.Fatalf("cap breached: peak state size %d > MaxSeries %d",
				peakLen, maxSeries)
		}
		if p.state.len() != maxSeries {
			b.Fatalf("cap not saturated: state size %d, want %d",
				p.state.len(), maxSeries)
		}

		if err := p.Shutdown(context.Background()); err != nil {
			b.Fatal(err)
		}

		b.ReportMetric(float64(peakHeap)/(1024*1024), "peak_heap_MiB")
		b.ReportMetric(float64(peakLen), "peak_series")
		b.ReportMetric(float64(after.HeapAlloc-before.HeapAlloc)/(1024*1024), "residual_heap_MiB")
	}
}

// BenchmarkProcessor_ConcurrentChurn combines high-cardinality producers
// with an active eviction loop and reports the sustained memory profile.
//
// This is the closest analog to a real production workload — many
// concurrent producers, aggressive TTL, and we care whether memory
// stabilizes rather than growing without bound.
func BenchmarkProcessor_ConcurrentChurn(b *testing.B) {
	const (
		producers    = 16
		perProducer  = 62_500 // 16 * 62_500 = 1_000_000 unique series
		batchPerCall = 500
	)

	for iter := 0; iter < b.N; iter++ {
		b.StopTimer()
		before := memStats()

		cfg := &Config{
			FlushInterval:     50 * time.Millisecond,
			TTL:               75 * time.Millisecond,
			EvictionInterval:  25 * time.Millisecond,
			AlignmentInterval: time.Second,
		}
		sink := newNullConsumer()
		p := newAggregatorProcessor(cfg, zap.NewNop(), sink)
		if err := p.Start(context.Background(), nil); err != nil {
			b.Fatal(err)
		}

		var peakHeap uint64
		var peakLen int
		var peakMu sync.Mutex

		stopSampler := make(chan struct{})
		samplerDone := make(chan struct{})
		go func() {
			defer close(samplerDone)
			t := time.NewTicker(10 * time.Millisecond)
			defer t.Stop()
			var ms runtime.MemStats
			for {
				select {
				case <-stopSampler:
					return
				case <-t.C:
					runtime.ReadMemStats(&ms)
					l := p.state.len()
					peakMu.Lock()
					if ms.HeapAlloc > peakHeap {
						peakHeap = ms.HeapAlloc
					}
					if l > peakLen {
						peakLen = l
					}
					peakMu.Unlock()
				}
			}
		}()

		b.StartTimer()

		start := time.Now()
		var wg sync.WaitGroup
		wg.Add(producers)
		for w := 0; w < producers; w++ {
			go func(worker int) {
				defer wg.Done()
				base := worker * perProducer
				for produced := 0; produced < perProducer; produced += batchPerCall {
					md := buildBatch("concurrent.metric",
						base+produced, batchPerCall, start)
					if err := p.ConsumeMetrics(context.Background(), md); err != nil {
						b.Errorf("consume: %v", err)
						return
					}
				}
			}(w)
		}
		wg.Wait()

		// Let eviction settle.
		time.Sleep(4 * cfg.TTL)

		close(stopSampler)
		<-samplerDone

		final := p.state.len()
		if err := p.Shutdown(context.Background()); err != nil {
			b.Fatal(err)
		}

		b.StopTimer()
		after := memStats()

		peakMu.Lock()
		ph, pl := peakHeap, peakLen
		peakMu.Unlock()

		// The steady-state working set should be a small fraction of the
		// total unique series — anything more means eviction lost the race.
		if pl > producers*perProducer/2 {
			b.Fatalf("working set unbounded: peak state size %d of %d unique",
				pl, producers*perProducer)
		}

		b.ReportMetric(float64(ph)/(1024*1024), "peak_heap_MiB")
		b.ReportMetric(float64(pl), "peak_working_set")
		b.ReportMetric(float64(final), "final_series")
		b.ReportMetric(float64(after.HeapAlloc-before.HeapAlloc)/(1024*1024), "residual_heap_MiB")
	}
}

// -----------------------------------------------------------------------------
// Verification test (not a benchmark). Runs quickly and asserts the stability
// property directly, so CI can catch regressions without needing to invoke
// the benchmark harness.
// -----------------------------------------------------------------------------

// TestChurnMemoryStable is a `go test` counterpart to
// BenchmarkProcessor_ConcurrentChurn that asserts memory stability with a
// small workload — safe to run on every CI build.
func TestChurnMemoryStable(t *testing.T) {
	if testing.Short() {
		t.Skip("skipping memory-stability test in short mode")
	}

	cfg := &Config{
		FlushInterval:     50 * time.Millisecond,
		TTL:               100 * time.Millisecond,
		EvictionInterval:  25 * time.Millisecond,
		AlignmentInterval: time.Second,
	}
	sink := newNullConsumer()
	p := newAggregatorProcessor(cfg, zap.NewNop(), sink)
	if err := p.Start(context.Background(), nil); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = p.Shutdown(context.Background()) })

	const (
		waves       = 5
		perWave     = 20_000
		perBatch    = 500
		maxWorkSize = 60_000 // 3x per-wave: allows two waves worth of overlap
	)

	start := time.Now()
	base := 0
	for wave := 0; wave < waves; wave++ {
		for produced := 0; produced < perWave; produced += perBatch {
			md := buildBatch("stab.metric", base+produced, perBatch, start)
			if err := p.ConsumeMetrics(context.Background(), md); err != nil {
				t.Fatal(err)
			}
		}
		base += perWave

		// Between waves, let eviction run.
		time.Sleep(3 * cfg.TTL)

		if l := p.state.len(); l > maxWorkSize {
			t.Fatalf("wave %d: working set %d exceeds %d — eviction not keeping up",
				wave, l, maxWorkSize)
		}
	}

	// After the final quiescent period the map should drain to essentially
	// zero.
	time.Sleep(5 * cfg.TTL)
	p.state.evictOlderThan(time.Now().Add(-cfg.TTL))
	if l := p.state.len(); l != 0 {
		t.Fatalf("post-drain residual: %d series remain", l)
	}
}

// -----------------------------------------------------------------------------
// Helpers used only by the benchmarks in this file.
// -----------------------------------------------------------------------------

// bareConsumer implements consumer.Metrics with zero downstream cost.
type bareConsumer struct{ points atomic.Int64 }

func (bc *bareConsumer) Capabilities() consumer.Capabilities {
	return consumer.Capabilities{MutatesData: false}
}

func (bc *bareConsumer) ConsumeMetrics(_ context.Context, md pmetric.Metrics) error {
	bc.points.Add(int64(md.DataPointCount()))
	return nil
}

func (bc *bareConsumer) consumed() int64 { return bc.points.Load() }

// Compile-time check.
var _ consumer.Metrics = (*bareConsumer)(nil)

// newBenchSeries constructs a minimal aggregatedSeries whose shape mirrors
// what the real ingest path produces.
func newBenchSeries(seed int) *aggregatedSeries {
	as := &aggregatedSeries{
		scopeName:    "bench.scope",
		scopeVersion: "v1",
		metricName:   "bench.metric",
		metricUnit:   "1",
		metricType:   pmetric.MetricTypeSum,
		isMonotonic:  true,
		temporality:  pmetric.AggregationTemporalityDelta,
		isInt:        true,
		startTime:    0,
		bucketTime:   0,
	}
	as.resourceAttrs = newBenchMap("service.name", "bench")
	as.scopeAttrs = newBenchMap()
	as.pointAttrs = newBenchMap("id", fmt.Sprintf("%d", seed))
	return as
}

// newBenchMap builds a pcommon.Map from alternating key/value string args.
func newBenchMap(kv ...string) pcommon.Map {
	m := pcommon.NewMap()
	for i := 0; i+1 < len(kv); i += 2 {
		m.PutStr(kv[i], kv[i+1])
	}
	return m
}

// buildBatchWithIDs constructs a pmetric.Metrics whose data points draw
// their "id" attribute from a caller-supplied pool of active ids. This is
// used by the churn load test, where the pool rotates every 10ms.
func buildBatchWithIDs(metricName string, activeIDs []int64, rng *rand.Rand, count int, ts time.Time) pmetric.Metrics {
	md := pmetric.NewMetrics()
	rm := md.ResourceMetrics().AppendEmpty()
	rm.Resource().Attributes().PutStr("service.name", "bench")

	sm := rm.ScopeMetrics().AppendEmpty()
	sm.Scope().SetName("bench.scope")
	sm.Scope().SetVersion("v1")

	m := sm.Metrics().AppendEmpty()
	m.SetName(metricName)
	m.SetUnit("1")
	s := m.SetEmptySum()
	s.SetIsMonotonic(true)
	s.SetAggregationTemporality(pmetric.AggregationTemporalityDelta)

	dps := s.DataPoints()
	nActive := len(activeIDs)
	if nActive == 0 {
		return md
	}
	for i := 0; i < count; i++ {
		dp := dps.AppendEmpty()
		dp.SetIntValue(1)
		id := activeIDs[rng.Intn(nActive)]
		dp.Attributes().PutStr("id", fmt.Sprintf("%d", id))
		dp.SetTimestamp(pcommon.NewTimestampFromTime(ts))
	}
	return md
}

// buildBatch constructs a pmetric.Metrics with `count` distinct series
// starting at the given offset. Each data point has a unique "id" attribute
// so it hashes to a distinct series key.
func buildBatch(metricName string, offset, count int, ts time.Time) pmetric.Metrics {
	md := pmetric.NewMetrics()
	rm := md.ResourceMetrics().AppendEmpty()
	rm.Resource().Attributes().PutStr("service.name", "bench")

	sm := rm.ScopeMetrics().AppendEmpty()
	sm.Scope().SetName("bench.scope")
	sm.Scope().SetVersion("v1")

	m := sm.Metrics().AppendEmpty()
	m.SetName(metricName)
	m.SetUnit("1")
	s := m.SetEmptySum()
	s.SetIsMonotonic(true)
	s.SetAggregationTemporality(pmetric.AggregationTemporalityDelta)

	dps := s.DataPoints()
	for i := 0; i < count; i++ {
		dp := dps.AppendEmpty()
		dp.SetIntValue(1)
		dp.Attributes().PutStr("id", fmt.Sprintf("%d", offset+i))
		// Timestamp is set to `now` so all points fall in the same alignment
		// bucket regardless of when they were emitted — this keeps the
		// series-count budget exactly equal to distinct attribute sets.
		dp.SetTimestamp(pcommon.NewTimestampFromTime(ts))
	}
	return md
}
