// Package aggregatorprocessor implements an OpenTelemetry Collector processor
// that performs stateful aggregation of metrics using a mutex-protected map
// keyed by a hash of the metric identity (resource attrs + scope + metric name
// + attribute set + timestamp bucket).
//
// The processor buffers samples in memory, aggregates them into running
// SUM / GAUGE / HISTOGRAM values, and periodically flushes aggregated
// pdata.Metrics to the next consumer. A background TTL eviction loop prevents
// memory bloat from unbounded cardinality.
package aggregatorprocessor

import (
	"errors"
	"time"

	"go.opentelemetry.io/collector/component"
)

// Config is the configuration for the aggregator processor.
type Config struct {
	// FlushInterval is how often the processor emits an aggregated batch of
	// metrics to the downstream consumer.
	FlushInterval time.Duration `mapstructure:"flush_interval"`

	// TTL is how long an aggregation series may live without being touched
	// before it is evicted. Prevents unbounded memory growth from
	// high-cardinality label churn.
	TTL time.Duration `mapstructure:"ttl"`

	// EvictionInterval is how often the background TTL scanner runs.
	EvictionInterval time.Duration `mapstructure:"eviction_interval"`

	// MaxSeries caps the number of distinct series held in the aggregation
	// map. When exceeded, incoming new series are dropped (and a debug log
	// is emitted) until eviction frees space. Zero disables the cap.
	MaxSeries int `mapstructure:"max_series"`

	// AlignmentInterval aligns sample timestamps to a fixed bucket before
	// hashing, so samples arriving within the same wall-clock window are
	// grouped into a single aggregate. Set to zero to disable alignment
	// (each unique timestamp becomes its own series).
	AlignmentInterval time.Duration `mapstructure:"alignment_interval"`
}

var _ component.Config = (*Config)(nil)

// Validate implements component.Config.
func (c *Config) Validate() error {
	if c.FlushInterval <= 0 {
		return errors.New("flush_interval must be positive")
	}
	if c.TTL <= 0 {
		return errors.New("ttl must be positive")
	}
	if c.EvictionInterval <= 0 {
		return errors.New("eviction_interval must be positive")
	}
	if c.MaxSeries < 0 {
		return errors.New("max_series must be non-negative")
	}
	if c.AlignmentInterval < 0 {
		return errors.New("alignment_interval must be non-negative")
	}
	return nil
}

// createDefaultConfig returns a sane default configuration.
func createDefaultConfig() component.Config {
	return &Config{
		FlushInterval:     10 * time.Second,
		TTL:               5 * time.Minute,
		EvictionInterval:  30 * time.Second,
		MaxSeries:         0, // unlimited
		AlignmentInterval: 10 * time.Second,
	}
}
