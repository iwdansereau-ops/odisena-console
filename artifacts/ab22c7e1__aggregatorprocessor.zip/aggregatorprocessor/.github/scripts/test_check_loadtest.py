#!/usr/bin/env python3
"""Unit tests for check_loadtest.py.

Run with: python3 -m unittest test_check_loadtest.py
Kept in the same directory so CI can invoke it before running the real
check against production data.
"""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))

from check_loadtest import (  # noqa: E402
    parse_duration_seconds,
    parse_summary,
    extract_max,
)


# Reference summary matching the exact format written by writeLoadtestSummary
# in loadtest_test.go. Update if that format changes.
GOOD_SUMMARY = textwrap.dedent(
    """\
    aggregator processor — continuous churn load test
    run duration:       5s
    working set:        100000
    rotate:             50000 every 10ms (50%)

    throughput:
      upsert ops:       2345400 (469080/s)
      evict ops:        229 (46/s)
      drain ops:        99 (20/s)
      downstream pts:   2151261

    state map:
      peak size:        36470 (target 100000)
      peak heap:        81.1 MiB

    mutex held (µs):
      evict:            p50=801.184µs p90=1.744445ms p99=4.564975ms max=4.965399ms
      drain:            p50=1.00883ms p90=3.248923ms p99=4.79059ms max=6.340524ms
      upsert>100µs:     p50=121.227µs p90=224.56µs p99=3.894415ms max=13.392896ms
      upsert wait:      p50=62ns p90=89ns p99=16.455617ms max=89.382297ms
      max held any op:  13.392896ms

    GC:
      pauses observed:  109
      pause:            p50=61.305µs p90=154.59µs p99=219.198µs max=481.624µs
      total gc pause:   8.729505ms (0.17% of run)

    ingest:
      max latency:      167.486636ms
      over-budget:      0 calls
    """
)


class TestParseDuration(unittest.TestCase):
    def test_nanoseconds(self) -> None:
        self.assertAlmostEqual(parse_duration_seconds("500ns"), 500e-9)

    def test_microseconds_unicode(self) -> None:
        self.assertAlmostEqual(parse_duration_seconds("482.61µs"), 482.61e-6)

    def test_microseconds_ascii(self) -> None:
        self.assertAlmostEqual(parse_duration_seconds("482.61us"), 482.61e-6)

    def test_milliseconds(self) -> None:
        self.assertAlmostEqual(parse_duration_seconds("52.024622ms"), 0.052024622)

    def test_seconds(self) -> None:
        self.assertAlmostEqual(parse_duration_seconds("1.5s"), 1.5)

    def test_compound(self) -> None:
        # 1m2.3s = 62.3s
        self.assertAlmostEqual(parse_duration_seconds("1m2.3s"), 62.3, places=4)

    def test_invalid(self) -> None:
        with self.assertRaises(ValueError):
            parse_duration_seconds("notaduration")


class TestExtractMax(unittest.TestCase):
    def test_basic(self) -> None:
        line = "pause: p50=61.305µs p90=154.59µs p99=219.198µs max=481.624µs"
        self.assertEqual(extract_max(line), "481.624µs")

    def test_no_max(self) -> None:
        with self.assertRaises(ValueError):
            extract_max("no max here")


class TestParseSummary(unittest.TestCase):
    def _write(self, content: str) -> Path:
        f = tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", suffix=".txt", delete=False
        )
        f.write(content)
        f.close()
        return Path(f.name)

    def test_good_summary(self) -> None:
        path = self._write(GOOD_SUMMARY)
        try:
            m = parse_summary(path)
        finally:
            path.unlink()
        self.assertAlmostEqual(m["max_ingest_s"], 0.167486636, places=6)
        self.assertAlmostEqual(m["max_gc_pause_s"], 481.624e-6, places=9)
        self.assertEqual(m["over_budget_calls"], 0)
        self.assertEqual(m["peak_state"], 36470)
        self.assertAlmostEqual(m["peak_heap_mib"], 81.1)


class TestCliBehavior(unittest.TestCase):
    """End-to-end tests that invoke the script as a subprocess."""

    SCRIPT = HERE / "check_loadtest.py"

    def _run(self, summary: str, *extra: str) -> tuple[int, str, str]:
        f = tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", suffix=".txt", delete=False
        )
        f.write(summary)
        f.close()
        try:
            proc = subprocess.run(
                [sys.executable, str(self.SCRIPT), "--summary", f.name, *extra],
                capture_output=True,
                text=True,
                check=False,
                env={**os.environ, "GITHUB_STEP_SUMMARY": ""},
            )
            return proc.returncode, proc.stdout, proc.stderr
        finally:
            os.unlink(f.name)

    def test_pass(self) -> None:
        rc, out, err = self._run(GOOD_SUMMARY)
        self.assertEqual(rc, 0, msg=out + err)
        self.assertIn("max ingest latency", out)

    def test_fail_ingest(self) -> None:
        rc, out, err = self._run(GOOD_SUMMARY, "--max-ingest-ms", "100")
        self.assertEqual(rc, 1)
        self.assertIn("Ingest latency budget exceeded", err)

    def test_fail_gc(self) -> None:
        # Real max GC pause in fixture is 481µs = 0.48ms; use 0.1ms budget.
        rc, out, err = self._run(GOOD_SUMMARY, "--max-gc-pause-ms", "0.1")
        self.assertEqual(rc, 1)
        self.assertIn("GC pause budget exceeded", err)

    def test_missing_file(self) -> None:
        proc = subprocess.run(
            [sys.executable, str(self.SCRIPT), "--summary", "/nonexistent"],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(proc.returncode, 2)


if __name__ == "__main__":
    unittest.main()
