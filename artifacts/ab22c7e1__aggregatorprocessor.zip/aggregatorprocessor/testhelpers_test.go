package aggregatorprocessor

import (
	"context"
	"sync"
	"time"

	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/pmetric"
)

// mockConsumer is a thread-safe consumer.Metrics that records every batch
// forwarded to it. It's used by tests to assert on flushed output.
type mockConsumer struct {
	mu      sync.Mutex
	batches []pmetric.Metrics
}

var _ consumer.Metrics = (*mockConsumer)(nil)

func (mc *mockConsumer) Capabilities() consumer.Capabilities {
	return consumer.Capabilities{MutatesData: false}
}

func (mc *mockConsumer) ConsumeMetrics(_ context.Context, md pmetric.Metrics) error {
	mc.mu.Lock()
	defer mc.mu.Unlock()
	// Clone so the processor can freely reuse buffers.
	cloned := pmetric.NewMetrics()
	md.CopyTo(cloned)
	mc.batches = append(mc.batches, cloned)
	return nil
}

func (mc *mockConsumer) received() []pmetric.Metrics {
	mc.mu.Lock()
	defer mc.mu.Unlock()
	out := make([]pmetric.Metrics, len(mc.batches))
	copy(out, mc.batches)
	return out
}

func (mc *mockConsumer) reset() {
	mc.mu.Lock()
	defer mc.mu.Unlock()
	mc.batches = nil
}

// buildSumMetric constructs a pmetric.Metrics containing a single monotonic
// sum with one data point. Attributes are passed as flat k/v pairs.
func buildSumMetric(
	metricName string,
	resAttrs map[string]string,
	pointAttrs map[string]string,
	value int64,
	ts time.Time,
) pmetric.Metrics {
	md := pmetric.NewMetrics()
	rm := md.ResourceMetrics().AppendEmpty()
	setStringAttrs(rm.Resource().Attributes(), resAttrs)

	sm := rm.ScopeMetrics().AppendEmpty()
	sm.Scope().SetName("test.scope")
	sm.Scope().SetVersion("v1")

	m := sm.Metrics().AppendEmpty()
	m.SetName(metricName)
	m.SetUnit("1")
	s := m.SetEmptySum()
	s.SetIsMonotonic(true)
	s.SetAggregationTemporality(pmetric.AggregationTemporalityDelta)

	dp := s.DataPoints().AppendEmpty()
	dp.SetTimestamp(pcommon.NewTimestampFromTime(ts))
	dp.SetStartTimestamp(pcommon.NewTimestampFromTime(ts.Add(-time.Second)))
	dp.SetIntValue(value)
	setStringAttrs(dp.Attributes(), pointAttrs)
	return md
}

// buildGaugeMetric constructs a pmetric.Metrics with a single gauge point.
func buildGaugeMetric(
	metricName string,
	resAttrs map[string]string,
	pointAttrs map[string]string,
	value float64,
	ts time.Time,
) pmetric.Metrics {
	md := pmetric.NewMetrics()
	rm := md.ResourceMetrics().AppendEmpty()
	setStringAttrs(rm.Resource().Attributes(), resAttrs)

	sm := rm.ScopeMetrics().AppendEmpty()
	sm.Scope().SetName("test.scope")
	sm.Scope().SetVersion("v1")

	m := sm.Metrics().AppendEmpty()
	m.SetName(metricName)
	g := m.SetEmptyGauge()
	dp := g.DataPoints().AppendEmpty()
	dp.SetTimestamp(pcommon.NewTimestampFromTime(ts))
	dp.SetDoubleValue(value)
	setStringAttrs(dp.Attributes(), pointAttrs)
	return md
}

// buildHistogramMetric constructs a pmetric.Metrics with a single histogram
// data point with the given bounds and counts.
func buildHistogramMetric(
	metricName string,
	pointAttrs map[string]string,
	bounds []float64,
	counts []uint64,
	sum float64,
	ts time.Time,
) pmetric.Metrics {
	md := pmetric.NewMetrics()
	rm := md.ResourceMetrics().AppendEmpty()
	sm := rm.ScopeMetrics().AppendEmpty()
	sm.Scope().SetName("test.scope")
	sm.Scope().SetVersion("v1")

	m := sm.Metrics().AppendEmpty()
	m.SetName(metricName)
	h := m.SetEmptyHistogram()
	h.SetAggregationTemporality(pmetric.AggregationTemporalityDelta)

	dp := h.DataPoints().AppendEmpty()
	dp.SetTimestamp(pcommon.NewTimestampFromTime(ts))
	dp.ExplicitBounds().FromRaw(append([]float64(nil), bounds...))
	dp.BucketCounts().FromRaw(append([]uint64(nil), counts...))
	dp.SetSum(sum)
	setStringAttrs(dp.Attributes(), pointAttrs)
	return md
}

func setStringAttrs(m pcommon.Map, kv map[string]string) {
	for k, v := range kv {
		m.PutStr(k, v)
	}
}

// findMetric walks a pmetric.Metrics tree and returns the first metric with
// the given name, or an empty pmetric.Metric if not found.
func findMetric(md pmetric.Metrics, name string) (pmetric.Metric, bool) {
	rms := md.ResourceMetrics()
	for i := 0; i < rms.Len(); i++ {
		sms := rms.At(i).ScopeMetrics()
		for j := 0; j < sms.Len(); j++ {
			ms := sms.At(j).Metrics()
			for k := 0; k < ms.Len(); k++ {
				if ms.At(k).Name() == name {
					return ms.At(k), true
				}
			}
		}
	}
	return pmetric.Metric{}, false
}

// sumSumMetricInts walks every int data point of the named Sum metric across
// all batches and returns the total. This is a coarse but useful oracle when
// verifying aggregation correctness.
func sumSumMetricInts(batches []pmetric.Metrics, name string) int64 {
	var total int64
	for _, b := range batches {
		if m, ok := findMetric(b, name); ok && m.Type() == pmetric.MetricTypeSum {
			dps := m.Sum().DataPoints()
			for i := 0; i < dps.Len(); i++ {
				total += dps.At(i).IntValue()
			}
		}
	}
	return total
}
