package aggregatorprocessor

import (
	"context"
	"fmt"
	"math/rand"
	"os"
	"runtime"
	"sort"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"go.uber.org/zap"
)

// -----------------------------------------------------------------------------
// Continuous load test with 50%-rotation churn
//
// Workload:
//   - Working set: 100,000 active series keys at any moment.
//   - Rotation: every 10ms, half of the working set is retired and replaced
//     with brand-new keys never seen before. Over a 5-second run this yields
//     500 rotations × 50,000 new keys = 25M *unique* series ingested against
//     a 100k steady-state working set. Old keys age out via the TTL loop.
//   - Multiple producer goroutines drive traffic in parallel.
//
// Instrumentation:
//   - A lockObserver captures wait/held durations for every stateMap
//     critical section, tagged by op (upsert / drain / evict).
//   - A dedicated goroutine samples runtime.MemStats every 5ms and diffs
//     PauseNs[] to isolate GC pauses that occurred during the run.
//   - Peak state size and heap are captured.
//
// Assertions:
//   - No single GC pause exceeds 200ms.
//   - The processor keeps up (no ConsumeMetrics call stalls > 200ms).
//   - Working-set size stays bounded (< 4× target).
//   - Eviction actually runs during the test (nonzero evict operations).
//
// After the run the test prints a percentile summary plus a memo-ready
// snapshot of mutex contention which the accompanying memo interprets.
//
// Run with:
//   go test -run TestContinuousChurn200msGCBudget -timeout 3m -v ./...
// -----------------------------------------------------------------------------

// lockSample is one instrumented critical section.
type lockSample struct {
	op     string
	waited time.Duration
	held   time.Duration
}

// lockObserver implements LockObserver. It appends samples to a
// per-goroutine buffer that gets flushed under a coarser lock — this keeps
// the hot-path cost to one channel send worth of work, avoiding a global
// contention hotspot inside the observer itself.
type lockObserver struct {
	mu      sync.Mutex
	samples []lockSample

	// evictSamples is broken out because eviction is the operation we care
	// about most for this workload, and separating it avoids O(N) filtering
	// later.
	evictSamples []lockSample
	upsertCount  atomic.Int64
	drainCount   atomic.Int64
	evictCount   atomic.Int64
	lenCount     atomic.Int64

	// Track the maximum critical-section-held duration ever observed;
	// atomic so producers can update it without contending on mu.
	maxHeldNs atomic.Int64
}

func (o *lockObserver) OnLock(op string, waited, held time.Duration) {
	// Track max held.
	for {
		cur := o.maxHeldNs.Load()
		if int64(held) <= cur || o.maxHeldNs.CompareAndSwap(cur, int64(held)) {
			break
		}
	}

	switch op {
	case "upsert":
		o.upsertCount.Add(1)
	case "drain":
		o.drainCount.Add(1)
	case "evict":
		o.evictCount.Add(1)
	case "len":
		o.lenCount.Add(1)
	}

	// Only sample expensive/rare ops in full detail — upsert would flood
	// the sample buffer at 100k+/sec.
	if op == "upsert" && held < 100*time.Microsecond {
		return
	}

	o.mu.Lock()
	s := lockSample{op: op, waited: waited, held: held}
	o.samples = append(o.samples, s)
	if op == "evict" {
		o.evictSamples = append(o.evictSamples, s)
	}
	o.mu.Unlock()
}

// snapshot returns copies of the collected samples, safe to sort.
func (o *lockObserver) snapshot() (all, evicts []lockSample) {
	o.mu.Lock()
	defer o.mu.Unlock()
	all = make([]lockSample, len(o.samples))
	copy(all, o.samples)
	evicts = make([]lockSample, len(o.evictSamples))
	copy(evicts, o.evictSamples)
	return
}

// -----------------------------------------------------------------------------
// GC monitoring
// -----------------------------------------------------------------------------

// gcMonitor samples runtime.MemStats and extracts individual GC pauses.
// Go's runtime keeps a circular buffer of the last 256 pauses in
// MemStats.PauseNs, indexed by (NumGC+255)%256. To capture *all* pauses
// during the run, we sample at ~200Hz (well below GC frequency at any
// realistic heap size) and diff NumGC each tick to walk the ring buffer.
type gcMonitor struct {
	pauses  []time.Duration // every pause seen during the run
	maxHeap uint64
}

func (g *gcMonitor) run(ctx context.Context) {
	var prev runtime.MemStats
	runtime.ReadMemStats(&prev)
	baseNumGC := prev.NumGC

	t := time.NewTicker(5 * time.Millisecond)
	defer t.Stop()

	var cur runtime.MemStats
	for {
		select {
		case <-ctx.Done():
			// Final read to catch trailing GCs.
			runtime.ReadMemStats(&cur)
			g.harvestPauses(baseNumGC, prev.NumGC, cur)
			if cur.HeapAlloc > g.maxHeap {
				g.maxHeap = cur.HeapAlloc
			}
			return
		case <-t.C:
			runtime.ReadMemStats(&cur)
			g.harvestPauses(baseNumGC, prev.NumGC, cur)
			if cur.HeapAlloc > g.maxHeap {
				g.maxHeap = cur.HeapAlloc
			}
			prev = cur
		}
	}
}

// harvestPauses walks PauseNs entries added since prevNumGC and records
// them in g.pauses. baseNumGC is the NumGC value at monitor start; it lets
// us reject any pause that happened before the workload began.
func (g *gcMonitor) harvestPauses(baseNumGC, prevNumGC uint32, cur runtime.MemStats) {
	for i := prevNumGC; i < cur.NumGC; i++ {
		if i < baseNumGC {
			continue
		}
		p := cur.PauseNs[(i+255)%256]
		g.pauses = append(g.pauses, time.Duration(p))
	}
}

// -----------------------------------------------------------------------------
// The actual load test
// -----------------------------------------------------------------------------

// TestContinuousChurn200msGCBudget is the load test proper. It is guarded
// by the AGGREGATOR_LOADTEST env var so it doesn't run in normal CI —
// it's a stress test, not a functional check.
func TestContinuousChurn200msGCBudget(t *testing.T) {
	if os.Getenv("AGGREGATOR_LOADTEST") == "" && !testing.Short() {
		// If AGGREGATOR_LOADTEST is unset AND not short-mode, run a
		// short version (2s). If AGGREGATOR_LOADTEST=1, run full 5s.
		t.Logf("running short (2s) load test; set AGGREGATOR_LOADTEST=1 for full 5s")
	}
	if testing.Short() {
		t.Skip("load test skipped in -short mode")
	}

	runDuration := 2 * time.Second
	if os.Getenv("AGGREGATOR_LOADTEST") == "1" {
		runDuration = 5 * time.Second
	}

	const (
		workingSet    = 100_000              // steady-state active series
		rotateFrac    = 0.5                  // 50% rotation
		rotateEvery   = 10 * time.Millisecond // every 10ms
		producers     = 8                    // parallel ingestion goroutines
		ttl           = 100 * time.Millisecond
		flushInterval = 50 * time.Millisecond
		evictionEvery = 20 * time.Millisecond
		gcBudget      = 200 * time.Millisecond
	)

	rotateN := int(workingSet * rotateFrac)

	// -------------------------------------------------------------------------
	// Wire up processor with the lock observer installed.
	// -------------------------------------------------------------------------
	cfg := &Config{
		FlushInterval:     flushInterval,
		TTL:               ttl,
		EvictionInterval:  evictionEvery,
		AlignmentInterval: time.Second,
	}
	sink := newNullConsumer()
	p := newAggregatorProcessor(cfg, zap.NewNop(), sink)

	obs := &lockObserver{}
	p.state.setObserver(obs)

	if err := p.Start(context.Background(), nil); err != nil {
		t.Fatalf("start: %v", err)
	}
	t.Cleanup(func() { _ = p.Shutdown(context.Background()) })

	// -------------------------------------------------------------------------
	// GC monitor + peak-state sampler
	// -------------------------------------------------------------------------
	monCtx, monCancel := context.WithCancel(context.Background())
	var mon gcMonitor
	monDone := make(chan struct{})
	go func() {
		defer close(monDone)
		mon.run(monCtx)
	}()

	var peakLen int64
	stateSamplerCtx, stateSamplerCancel := context.WithCancel(context.Background())
	stateSamplerDone := make(chan struct{})
	go func() {
		defer close(stateSamplerDone)
		t := time.NewTicker(10 * time.Millisecond)
		defer t.Stop()
		for {
			select {
			case <-stateSamplerCtx.Done():
				return
			case <-t.C:
				l := int64(p.state.len())
				if l > atomic.LoadInt64(&peakLen) {
					atomic.StoreInt64(&peakLen, l)
				}
			}
		}
	}()

	// -------------------------------------------------------------------------
	// Workload: the rotation controller owns the "active id ring". Every
	// rotateEvery it retires rotateN old ids and mints rotateN new ones.
	// Producer goroutines read the current active slice via an atomic
	// pointer and hammer the processor with samples referencing those ids.
	// -------------------------------------------------------------------------
	type activeSet struct {
		ids []int64 // len == workingSet
	}

	// Seed the initial working set: ids [0, workingSet).
	seed := &activeSet{ids: make([]int64, workingSet)}
	for i := range seed.ids {
		seed.ids[i] = int64(i)
	}
	activePtr := atomic.Pointer[activeSet]{}
	activePtr.Store(seed)

	var nextID atomic.Int64
	nextID.Store(int64(workingSet))

	// The "max ingest latency" tracker: any ConsumeMetrics call taking
	// > gcBudget is a red flag (either the mutex or GC has stalled us).
	var maxIngestLatencyNs atomic.Int64
	var overBudgetIngests atomic.Int64

	rotateCtx, rotateCancel := context.WithCancel(context.Background())
	rotateDone := make(chan struct{})
	go func() {
		defer close(rotateDone)
		t := time.NewTicker(rotateEvery)
		defer t.Stop()
		rng := rand.New(rand.NewSource(1))
		for {
			select {
			case <-rotateCtx.Done():
				return
			case <-t.C:
				cur := activePtr.Load()
				next := &activeSet{ids: make([]int64, workingSet)}
				copy(next.ids, cur.ids)
				// Pick rotateN random slots and replace them with fresh
				// ids drawn from a monotonically increasing counter.
				for i := 0; i < rotateN; i++ {
					slot := rng.Intn(workingSet)
					next.ids[slot] = nextID.Add(1)
				}
				activePtr.Store(next)
			}
		}
	}()

	produceCtx, produceCancel := context.WithCancel(context.Background())
	var wg sync.WaitGroup
	wg.Add(producers)
	for w := 0; w < producers; w++ {
		go func(worker int) {
			defer wg.Done()
			rng := rand.New(rand.NewSource(int64(worker) + 100))
			// batchSize is a knob. Small batches better simulate the
			// steady drip of a real Collector; large batches would let us
			// amortize the mutex.
			const batchSize = 200
			ts := time.Now()
			for {
				select {
				case <-produceCtx.Done():
					return
				default:
				}
				cur := activePtr.Load()
				md := buildBatchWithIDs("churn.metric", cur.ids, rng, batchSize, ts)
				start := time.Now()
				if err := p.ConsumeMetrics(context.Background(), md); err != nil {
					t.Errorf("consume: %v", err)
					return
				}
				lat := time.Since(start)
				if int64(lat) > maxIngestLatencyNs.Load() {
					// racy but harmless — we're tracking a rough max
					maxIngestLatencyNs.Store(int64(lat))
				}
				if lat > gcBudget {
					overBudgetIngests.Add(1)
				}
			}
		}(w)
	}

	// -------------------------------------------------------------------------
	// Let it cook.
	// -------------------------------------------------------------------------
	time.Sleep(runDuration)

	produceCancel()
	wg.Wait()
	rotateCancel()
	<-rotateDone
	stateSamplerCancel()
	<-stateSamplerDone
	monCancel()
	<-monDone

	// -------------------------------------------------------------------------
	// Report
	// -------------------------------------------------------------------------
	allSamples, evictSamples := obs.snapshot()

	evictHeld := extractHeld(evictSamples)
	drainHeld := extractHeldForOp(allSamples, "drain")
	upsertHeld := extractHeldForOp(allSamples, "upsert")
	upsertWait := extractWaitForOp(allSamples, "upsert")

	t.Logf("=== continuous churn load test ===")
	t.Logf("duration: %v  producers: %d  workingSet: %d  rotate: %d every %v",
		runDuration, producers, workingSet, rotateN, rotateEvery)
	t.Logf("")
	t.Logf("--- throughput ---")
	t.Logf("upsert ops:        %d  (%.0f/s)", obs.upsertCount.Load(),
		float64(obs.upsertCount.Load())/runDuration.Seconds())
	t.Logf("evict ops:         %d  (%.0f/s)", obs.evictCount.Load(),
		float64(obs.evictCount.Load())/runDuration.Seconds())
	t.Logf("drain ops:         %d  (%.0f/s)", obs.drainCount.Load(),
		float64(obs.drainCount.Load())/runDuration.Seconds())
	t.Logf("downstream points: %d", sink.consumed())
	t.Logf("")
	t.Logf("--- state map ---")
	t.Logf("peak state size:   %d  (target %d)", atomic.LoadInt64(&peakLen), workingSet)
	t.Logf("peak heap:         %.1f MiB", float64(mon.maxHeap)/(1024*1024))
	t.Logf("")
	t.Logf("--- mutex contention ---")
	logDist(t, "evict held  (µs)", evictHeld, time.Microsecond)
	logDist(t, "drain held  (µs)", drainHeld, time.Microsecond)
	logDist(t, "upsert>100µ (µs)", upsertHeld, time.Microsecond)
	logDist(t, "upsert wait (µs)", upsertWait, time.Microsecond)
	t.Logf("max critical section held (any op): %v",
		time.Duration(obs.maxHeldNs.Load()))
	t.Logf("")
	t.Logf("--- GC ---")
	t.Logf("gc pauses observed: %d", len(mon.pauses))
	logDist(t, "gc pause    (µs)", mon.pauses, time.Microsecond)
	var totalGC time.Duration
	var maxGC time.Duration
	for _, p := range mon.pauses {
		totalGC += p
		if p > maxGC {
			maxGC = p
		}
	}
	t.Logf("total gc pause:  %v  (%.2f%% of run)",
		totalGC, 100*float64(totalGC)/float64(runDuration))
	t.Logf("max gc pause:    %v  (budget %v)", maxGC, gcBudget)
	t.Logf("")
	t.Logf("--- ingest latency ---")
	t.Logf("max ConsumeMetrics latency: %v", time.Duration(maxIngestLatencyNs.Load()))
	t.Logf("ingest calls over budget:   %d", overBudgetIngests.Load())

	// -------------------------------------------------------------------------
	// Assertions — the actual pass/fail conditions.
	// -------------------------------------------------------------------------
	if maxGC > gcBudget {
		t.Errorf("GC pause %v exceeded %v budget", maxGC, gcBudget)
	}
	if lat := time.Duration(maxIngestLatencyNs.Load()); lat > gcBudget {
		t.Errorf("ingest latency %v exceeded %v budget", lat, gcBudget)
	}
	if obs.evictCount.Load() == 0 {
		t.Error("no eviction operations observed — TTL loop did not run")
	}
	if pl := atomic.LoadInt64(&peakLen); pl > int64(workingSet*4) {
		t.Errorf("working set unbounded: peak %d, expected ~%d", pl, workingSet)
	}

	// Persist a summary to disk so the load test writes a machine-readable
	// artifact the memo can quote from.
	writeLoadtestSummary(t, runDuration, workingSet, rotateN, rotateEvery,
		obs, atomic.LoadInt64(&peakLen), mon.maxHeap,
		evictHeld, drainHeld, upsertHeld, upsertWait, mon.pauses,
		time.Duration(maxIngestLatencyNs.Load()), overBudgetIngests.Load(),
		sink.consumed())
}

// -----------------------------------------------------------------------------
// Reporting helpers
// -----------------------------------------------------------------------------

func extractHeld(s []lockSample) []time.Duration {
	out := make([]time.Duration, len(s))
	for i, v := range s {
		out[i] = v.held
	}
	return out
}

func extractHeldForOp(s []lockSample, op string) []time.Duration {
	var out []time.Duration
	for _, v := range s {
		if v.op == op {
			out = append(out, v.held)
		}
	}
	return out
}

func extractWaitForOp(s []lockSample, op string) []time.Duration {
	var out []time.Duration
	for _, v := range s {
		if v.op == op {
			out = append(out, v.waited)
		}
	}
	return out
}

func percentile(sorted []time.Duration, p float64) time.Duration {
	if len(sorted) == 0 {
		return 0
	}
	idx := int(float64(len(sorted)-1) * p)
	return sorted[idx]
}

func logDist(t *testing.T, label string, d []time.Duration, unit time.Duration) {
	t.Helper()
	if len(d) == 0 {
		t.Logf("%-24s n=0", label)
		return
	}
	cp := make([]time.Duration, len(d))
	copy(cp, d)
	sort.Slice(cp, func(i, j int) bool { return cp[i] < cp[j] })
	p50 := percentile(cp, 0.50)
	p90 := percentile(cp, 0.90)
	p99 := percentile(cp, 0.99)
	pmx := cp[len(cp)-1]
	toUnit := func(x time.Duration) float64 { return float64(x) / float64(unit) }
	t.Logf("%-24s n=%-7d p50=%.1f p90=%.1f p99=%.1f max=%.1f",
		label, len(cp), toUnit(p50), toUnit(p90), toUnit(p99), toUnit(pmx))
}

// writeLoadtestSummary persists a plain-text report to
// /home/user/workspace/aggregatorprocessor/loadtest_summary.txt so the memo
// can quote real numbers.
func writeLoadtestSummary(
	t *testing.T,
	runDuration time.Duration,
	workingSet, rotateN int,
	rotateEvery time.Duration,
	obs *lockObserver,
	peakLen int64,
	peakHeap uint64,
	evictHeld, drainHeld, upsertHeld, upsertWait []time.Duration,
	gcPauses []time.Duration,
	maxIngest time.Duration,
	overBudget int64,
	downstreamPoints int64,
) {
	t.Helper()
	path := "loadtest_summary.txt"
	f, err := os.Create(path)
	if err != nil {
		t.Logf("could not write summary: %v", err)
		return
	}
	defer f.Close()

	pct := func(d []time.Duration) (p50, p90, p99, mx time.Duration) {
		if len(d) == 0 {
			return
		}
		cp := make([]time.Duration, len(d))
		copy(cp, d)
		sort.Slice(cp, func(i, j int) bool { return cp[i] < cp[j] })
		return percentile(cp, 0.50), percentile(cp, 0.90),
			percentile(cp, 0.99), cp[len(cp)-1]
	}

	ep50, ep90, ep99, emx := pct(evictHeld)
	dp50, dp90, dp99, dmx := pct(drainHeld)
	up50, up90, up99, umx := pct(upsertHeld)
	wp50, wp90, wp99, wmx := pct(upsertWait)
	gp50, gp90, gp99, gmx := pct(gcPauses)
	var totalGC time.Duration
	for _, p := range gcPauses {
		totalGC += p
	}

	fmt.Fprintf(f, "aggregator processor — continuous churn load test\n")
	fmt.Fprintf(f, "run duration:       %v\n", runDuration)
	fmt.Fprintf(f, "working set:        %d\n", workingSet)
	fmt.Fprintf(f, "rotate:             %d every %v (50%%)\n", rotateN, rotateEvery)
	fmt.Fprintf(f, "\n")
	fmt.Fprintf(f, "throughput:\n")
	fmt.Fprintf(f, "  upsert ops:       %d (%.0f/s)\n",
		obs.upsertCount.Load(), float64(obs.upsertCount.Load())/runDuration.Seconds())
	fmt.Fprintf(f, "  evict ops:        %d (%.0f/s)\n",
		obs.evictCount.Load(), float64(obs.evictCount.Load())/runDuration.Seconds())
	fmt.Fprintf(f, "  drain ops:        %d (%.0f/s)\n",
		obs.drainCount.Load(), float64(obs.drainCount.Load())/runDuration.Seconds())
	fmt.Fprintf(f, "  downstream pts:   %d\n", downstreamPoints)
	fmt.Fprintf(f, "\n")
	fmt.Fprintf(f, "state map:\n")
	fmt.Fprintf(f, "  peak size:        %d (target %d)\n", peakLen, workingSet)
	fmt.Fprintf(f, "  peak heap:        %.1f MiB\n", float64(peakHeap)/(1024*1024))
	fmt.Fprintf(f, "\n")
	fmt.Fprintf(f, "mutex held (µs):\n")
	fmt.Fprintf(f, "  evict:            p50=%v p90=%v p99=%v max=%v\n", ep50, ep90, ep99, emx)
	fmt.Fprintf(f, "  drain:            p50=%v p90=%v p99=%v max=%v\n", dp50, dp90, dp99, dmx)
	fmt.Fprintf(f, "  upsert>100µs:     p50=%v p90=%v p99=%v max=%v\n", up50, up90, up99, umx)
	fmt.Fprintf(f, "  upsert wait:      p50=%v p90=%v p99=%v max=%v\n", wp50, wp90, wp99, wmx)
	fmt.Fprintf(f, "  max held any op:  %v\n", time.Duration(obs.maxHeldNs.Load()))
	fmt.Fprintf(f, "\n")
	fmt.Fprintf(f, "GC:\n")
	fmt.Fprintf(f, "  pauses observed:  %d\n", len(gcPauses))
	fmt.Fprintf(f, "  pause:            p50=%v p90=%v p99=%v max=%v\n", gp50, gp90, gp99, gmx)
	fmt.Fprintf(f, "  total gc pause:   %v (%.2f%% of run)\n",
		totalGC, 100*float64(totalGC)/float64(runDuration))
	fmt.Fprintf(f, "\n")
	fmt.Fprintf(f, "ingest:\n")
	fmt.Fprintf(f, "  max latency:      %v\n", maxIngest)
	fmt.Fprintf(f, "  over-budget:      %d calls\n", overBudget)
	t.Logf("wrote %s", path)
}
