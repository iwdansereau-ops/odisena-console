package aggregatorprocessor

import (
	"testing"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/processor"
	"go.uber.org/zap/zaptest"
)

// processorSettingsForTest constructs a minimally-viable processor.Settings
// for exercising the factory in tests without pulling in the full collector
// test kit.
func processorSettingsForTest(t *testing.T) processor.Settings {
	t.Helper()
	return processor.Settings{
		ID: component.NewID(component.MustNewType(typeStr)),
		TelemetrySettings: component.TelemetrySettings{
			Logger: zaptest.NewLogger(t),
		},
		BuildInfo: component.NewDefaultBuildInfo(),
	}
}
