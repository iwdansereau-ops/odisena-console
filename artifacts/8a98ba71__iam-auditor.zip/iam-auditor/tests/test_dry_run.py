"""
Offline smoke test: no AWS credentials required.

Feeds sample events + sample policy into the analyzer and builder to verify
the refactored policy is generated correctly and reporting math works.
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from datetime import datetime

from iam_auditor.action_matcher import match_statements, summarize_usage
from iam_auditor.cloudtrail_collector import TrailEvent
from iam_auditor.policy_builder import build_refactored_policy
from iam_auditor.policy_loader import LoadedPolicy
from iam_auditor.reporter import build_summary
from iam_auditor.validator import ValidationReport


def load_sample_events():
    events = []
    with open(ROOT / "examples/sample_events.jsonl") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            events.append(TrailEvent(
                event_time=datetime.fromisoformat(rec["eventTime"].replace("Z", "+00:00")),
                event_source=rec["eventSource"],
                event_name=rec["eventName"],
                aws_region=rec["awsRegion"],
                resources=rec.get("resources", []),
                request_parameters={},
                error_code=None,
                read_only=rec.get("readOnly"),
            ))
    return events


def main():
    events = load_sample_events()

    current = json.loads((ROOT / "examples/sample_current_policy.json").read_text())
    loaded = LoadedPolicy(role_name="SampleRole")
    loaded.inline_policies["combined"] = current

    usage = summarize_usage(events)
    stmt_usages = match_statements(loaded, usage)
    refactored = build_refactored_policy(stmt_usages, usage)
    summary = build_summary(
        role_name="SampleRole",
        lookback_days=90,
        events=events,
        usage=usage,
        statement_usages=stmt_usages,
        refactored_policy=refactored,
        validation=ValidationReport(),
    )

    print("--- Refactored policy ---")
    print(json.dumps(refactored, indent=2))
    print("\n--- Summary ---")
    print(summary.to_text())

    # Assertions
    assert "s3:GetObject" in summary.retained_actions
    assert "s3:ListBucket" in summary.retained_actions
    assert "dynamodb:Query" in summary.retained_actions
    assert "sts:GetCallerIdentity" in summary.retained_actions
    assert "ec2:DescribeInstances" in summary.retained_actions

    # Removed permissions we care about
    assert "s3:PutObject" in summary.removed_actions
    assert "dynamodb:*" in summary.removed_actions
    assert "ec2:TerminateInstances" in summary.removed_actions
    assert "lambda:InvokeFunction" in summary.removed_actions

    # Deny preserved
    deny_stmts = [s for s in refactored["Statement"] if s.get("Effect") == "Deny"]
    assert deny_stmts and "iam:DeleteRole" in (deny_stmts[0]["Action"])

    print("\nAll assertions passed.")


if __name__ == "__main__":
    main()
