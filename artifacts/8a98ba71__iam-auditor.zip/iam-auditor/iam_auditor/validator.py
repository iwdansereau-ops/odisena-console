"""
Validate a proposed policy with AWS IAM Access Analyzer.

Uses ``accessanalyzer:ValidatePolicy`` to surface:

  * SECURITY_WARNING findings (e.g. overly broad resource, PassRole misuse)
  * ERROR / WARNING grammar findings
  * SUGGESTION findings

We also run ``CheckNoNewAccess`` when the caller passes an existing baseline
policy so reviewers can see any *net-new* permissions granted by the refactor.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import List, Optional

import boto3
from botocore.exceptions import ClientError

log = logging.getLogger(__name__)


@dataclass
class ValidationFinding:
    finding_type: str
    issue_code: str
    message: str
    locations: list = field(default_factory=list)


@dataclass
class ValidationReport:
    findings: List[ValidationFinding] = field(default_factory=list)
    check_no_new_access: Optional[str] = None  # "PASS" | "FAIL" | None

    @property
    def has_errors(self) -> bool:
        return any(f.finding_type in {"ERROR", "SECURITY_WARNING"} for f in self.findings)

    def by_type(self):
        buckets = {}
        for f in self.findings:
            buckets.setdefault(f.finding_type, []).append(f)
        return buckets


def validate_policy(
    policy_document: dict,
    baseline_document: Optional[dict] = None,
    policy_type: str = "IDENTITY_POLICY",
    session: Optional[boto3.session.Session] = None,
    region: str = "us-east-1",
) -> ValidationReport:
    session = session or boto3.session.Session()
    client = session.client("accessanalyzer", region_name=region)
    report = ValidationReport()

    body = json.dumps(policy_document)

    try:
        paginator = client.get_paginator("validate_policy")
        for page in paginator.paginate(policyDocument=body, policyType=policy_type):
            for f in page.get("findings", []):
                report.findings.append(
                    ValidationFinding(
                        finding_type=f.get("findingType", ""),
                        issue_code=f.get("issueCode", ""),
                        message=f.get("findingDetails", ""),
                        locations=f.get("locations", []),
                    )
                )
    except ClientError as exc:
        log.error("ValidatePolicy failed: %s", exc)
        raise

    if baseline_document is not None:
        try:
            resp = client.check_no_new_access(
                newPolicyDocument=body,
                existingPolicyDocument=json.dumps(baseline_document),
                policyType=policy_type,
            )
            report.check_no_new_access = resp.get("result")
        except ClientError as exc:
            log.warning("CheckNoNewAccess failed: %s", exc)

    return report
