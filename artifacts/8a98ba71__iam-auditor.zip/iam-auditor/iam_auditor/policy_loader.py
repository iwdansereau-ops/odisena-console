"""
Load the current policy document(s) attached to an IAM role.

Combines inline policies and all attached managed policies (customer + AWS
managed) into a single "effective allow set" that we can diff against
CloudTrail activity. Deny statements are preserved verbatim in the refactored
policy — we never strip a Deny.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import boto3

log = logging.getLogger(__name__)


@dataclass
class LoadedPolicy:
    role_name: str
    inline_policies: Dict[str, dict] = field(default_factory=dict)   # name -> doc
    attached_policies: Dict[str, dict] = field(default_factory=dict) # arn  -> doc

    def iter_statements(self):
        for name, doc in self.inline_policies.items():
            for stmt in _as_list(doc.get("Statement", [])):
                yield ("inline", name, stmt)
        for arn, doc in self.attached_policies.items():
            for stmt in _as_list(doc.get("Statement", [])):
                yield ("managed", arn, stmt)


def _as_list(x):
    return x if isinstance(x, list) else [x]


def load_role_policies(
    role_name: str, session: Optional[boto3.session.Session] = None
) -> LoadedPolicy:
    session = session or boto3.session.Session()
    iam = session.client("iam")

    loaded = LoadedPolicy(role_name=role_name)

    # Inline policies
    for name in iam.list_role_policies(RoleName=role_name).get("PolicyNames", []):
        resp = iam.get_role_policy(RoleName=role_name, PolicyName=name)
        loaded.inline_policies[name] = resp["PolicyDocument"]

    # Attached (managed) policies
    for att in iam.list_attached_role_policies(RoleName=role_name).get("AttachedPolicies", []):
        arn = att["PolicyArn"]
        pol = iam.get_policy(PolicyArn=arn)["Policy"]
        ver = iam.get_policy_version(PolicyArn=arn, VersionId=pol["DefaultVersionId"])
        loaded.attached_policies[arn] = ver["PolicyVersion"]["Document"]

    log.info(
        "Loaded %d inline + %d managed policies for role=%s",
        len(loaded.inline_policies), len(loaded.attached_policies), role_name,
    )
    return loaded
