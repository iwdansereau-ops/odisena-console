"""IAM Least-Privilege Auditor package."""

__version__ = "1.0.0"
