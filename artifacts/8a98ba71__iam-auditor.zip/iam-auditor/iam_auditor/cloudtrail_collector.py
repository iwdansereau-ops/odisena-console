"""
CloudTrail activity collector.

Pulls all API calls made *by* a specific IAM role principal over a lookback
window (default 90 days) using CloudTrail LookupEvents. Falls back to
paginated multi-region collection when a caller supplies a region list.

CloudTrail LookupEvents only returns management events from the last 90 days,
which happens to be exactly the window we need for a least-privilege audit.
For deployments that stream events to S3 or CloudWatch Logs Insights, callers
can override `iter_events` and feed pre-loaded records into the analyzer.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Iterable, Iterator, List, Optional, Sequence

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

log = logging.getLogger(__name__)


@dataclass
class TrailEvent:
    """Normalized subset of a CloudTrail event that the analyzer consumes."""

    event_time: datetime
    event_source: str            # e.g. "s3.amazonaws.com"
    event_name: str              # e.g. "GetObject"
    aws_region: str
    resources: List[dict] = field(default_factory=list)  # [{"ARN":..,"type":..}]
    request_parameters: dict = field(default_factory=dict)
    error_code: Optional[str] = None
    read_only: Optional[bool] = None

    @property
    def iam_action(self) -> str:
        """Return the canonical IAM action string, e.g. ``s3:GetObject``."""
        service = self.event_source.split(".")[0]
        # A handful of services report a different prefix in eventSource than
        # the IAM action namespace. Extend this map as needed.
        service = _SERVICE_PREFIX_OVERRIDES.get(service, service)
        return f"{service}:{self.event_name}"


# eventSource host -> IAM service prefix (only where they diverge)
_SERVICE_PREFIX_OVERRIDES = {
    "monitoring": "cloudwatch",
    "tagging": "tag",
    "email": "ses",
}


class CloudTrailCollector:
    """Collect CloudTrail events for a given IAM role principal."""

    def __init__(
        self,
        role_name: str,
        session: Optional[boto3.session.Session] = None,
        regions: Optional[Sequence[str]] = None,
        lookback_days: int = 90,
    ):
        self.role_name = role_name
        self.session = session or boto3.session.Session()
        self.lookback_days = lookback_days
        # If regions is None we ask STS/EC2 for the enabled regions.
        self.regions = list(regions) if regions else self._discover_regions()
        self._botocfg = Config(retries={"max_attempts": 10, "mode": "adaptive"})

    # ------------------------------------------------------------------ utils
    def _discover_regions(self) -> List[str]:
        ec2 = self.session.client("ec2", config=Config(retries={"max_attempts": 5}))
        try:
            resp = ec2.describe_regions(AllRegions=False)
            return [r["RegionName"] for r in resp["Regions"]]
        except ClientError as exc:
            log.warning("describe_regions failed (%s); falling back to us-east-1", exc)
            return ["us-east-1"]

    # -------------------------------------------------------------- iteration
    def iter_events(self) -> Iterator[TrailEvent]:
        """Yield TrailEvent objects for every management event by the role."""
        end = datetime.now(tz=timezone.utc)
        start = end - timedelta(days=self.lookback_days)
        log.info(
            "Collecting CloudTrail events for role=%s from %s to %s across %d regions",
            self.role_name, start.isoformat(), end.isoformat(), len(self.regions),
        )
        for region in self.regions:
            yield from self._iter_region(region, start, end)

    def _iter_region(
        self, region: str, start: datetime, end: datetime
    ) -> Iterator[TrailEvent]:
        client = self.session.client("cloudtrail", region_name=region, config=self._botocfg)
        paginator = client.get_paginator("lookup_events")
        try:
            pages = paginator.paginate(
                LookupAttributes=[
                    {"AttributeKey": "Username", "AttributeValue": self.role_name},
                ],
                StartTime=start,
                EndTime=end,
                PaginationConfig={"PageSize": 50},
            )
            for page in pages:
                for record in page.get("Events", []):
                    ev = _parse_event(record, region)
                    if ev is not None:
                        yield ev
        except ClientError as exc:
            log.warning("lookup_events failed in %s: %s", region, exc)


def _parse_event(record: dict, region: str) -> Optional[TrailEvent]:
    """Convert a raw lookup_events record to a TrailEvent."""
    import json

    raw = record.get("CloudTrailEvent")
    if not raw:
        return None
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        log.debug("Skipping unparseable CloudTrail record")
        return None

    return TrailEvent(
        event_time=payload.get("eventTime"),
        event_source=payload.get("eventSource", ""),
        event_name=payload.get("eventName", ""),
        aws_region=payload.get("awsRegion", region),
        resources=payload.get("resources") or record.get("Resources") or [],
        request_parameters=payload.get("requestParameters") or {},
        error_code=payload.get("errorCode"),
        read_only=payload.get("readOnly"),
    )


def collect_events(
    role_name: str,
    session: Optional[boto3.session.Session] = None,
    regions: Optional[Iterable[str]] = None,
    lookback_days: int = 90,
) -> List[TrailEvent]:
    """Convenience wrapper that materializes all events into a list."""
    collector = CloudTrailCollector(
        role_name=role_name,
        session=session,
        regions=list(regions) if regions else None,
        lookback_days=lookback_days,
    )
    return list(collector.iter_events())
