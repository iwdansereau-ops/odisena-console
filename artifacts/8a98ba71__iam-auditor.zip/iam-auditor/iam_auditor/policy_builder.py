"""
Build a refactored, least-privilege policy document from observed usage.

Strategy:
  1. Preserve every Deny statement verbatim.
  2. Replace Allow statements with one consolidated Allow per service.
  3. For each service, list only the actions that were actually called.
  4. For each action, scope the Resource list to the observed ARNs
     (falling back to ``*`` when the original policy already used ``*``
     AND the service does not support resource-level permissions).
"""

from __future__ import annotations

import json
from collections import defaultdict
from typing import Dict, List, Set

from .action_matcher import StatementUsage, UsedAction


def build_refactored_policy(
    statement_usages: List[StatementUsage],
    usage: Dict[str, UsedAction],
) -> dict:
    """Return a new policy document (Version 2012-10-17)."""
    allow_actions_by_service: Dict[str, Set[str]] = defaultdict(set)
    resources_by_action: Dict[str, Set[str]] = defaultdict(set)
    deny_statements: List[dict] = []

    for su in statement_usages:
        if su.statement.get("Effect", "Allow") != "Allow":
            deny_statements.append(su.statement)
            continue
        for act in su.matched_actions:
            service = act.split(":", 1)[0]
            allow_actions_by_service[service].add(act)
            observed = usage[act].resources
            resources_by_action[act].update(observed)

    statements: List[dict] = []

    for service in sorted(allow_actions_by_service):
        service_actions = sorted(allow_actions_by_service[service])

        # Group actions that share the same resource set so we emit compact
        # statements instead of one Sid per action.
        by_resource_set: Dict[str, List[str]] = defaultdict(list)
        for act in service_actions:
            res = tuple(sorted(resources_by_action[act])) or ("*",)
            by_resource_set[json.dumps(res)].append(act)

        for res_key, acts in by_resource_set.items():
            resources = json.loads(res_key)
            statements.append({
                "Sid": _mk_sid(service, acts),
                "Effect": "Allow",
                "Action": acts if len(acts) > 1 else acts[0],
                "Resource": list(resources) if len(resources) > 1 else resources[0],
            })

    # Append preserved denies at the end so they take precedence semantically
    # (Deny always wins in IAM, but appending is a common convention).
    statements.extend(deny_statements)

    return {
        "Version": "2012-10-17",
        "Statement": statements,
    }


def _mk_sid(service: str, actions: List[str]) -> str:
    # Sids must be alphanumeric. Use service + a short hash of the action list.
    import hashlib
    h = hashlib.sha1(",".join(actions).encode()).hexdigest()[:8]
    return f"{service.capitalize()}LeastPriv{h}"
