"""
Match observed IAM actions against policy statements.

Handles wildcard expansion for both Action strings (``s3:Get*``) and Resource
ARNs (``arn:aws:s3:::my-bucket/*``). We do NOT try to enumerate every AWS
action universe — we only need to answer:

  "For each Allow statement in the current policy, is there at least one
   observed CloudTrail call that matches both its Action and Resource?"

Statements that go unmatched are candidates for removal.
"""

from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Set, Tuple


def _wildcard_match(pattern: str, value: str) -> bool:
    # IAM uses * and ? as wildcards. fnmatch handles both, but IAM matching is
    # case-insensitive for actions and case-sensitive for ARNs. We normalize
    # actions to lowercase before matching.
    return fnmatch.fnmatchcase(value, pattern)


def action_matches(pattern: str, action: str) -> bool:
    return _wildcard_match(pattern.lower(), action.lower())


def resource_matches(pattern: str, resource: str) -> bool:
    if pattern == "*" or resource == "*":
        return True
    return _wildcard_match(pattern, resource)


@dataclass
class UsedAction:
    """One (action, resource) pair we observed in CloudTrail."""
    action: str
    resources: Set[str] = field(default_factory=set)
    call_count: int = 0
    last_seen: str = ""


def summarize_usage(events) -> Dict[str, UsedAction]:
    """Group TrailEvent records into (action -> UsedAction) buckets."""
    usage: Dict[str, UsedAction] = {}
    for ev in events:
        # Skip failed access-denied calls — they don't prove the policy allows it.
        if ev.error_code in {"AccessDenied", "UnauthorizedOperation"}:
            continue
        act = ev.iam_action
        bucket = usage.setdefault(act, UsedAction(action=act))
        bucket.call_count += 1
        if ev.event_time and str(ev.event_time) > bucket.last_seen:
            bucket.last_seen = str(ev.event_time)
        arns = [r.get("ARN") or r.get("arn") for r in (ev.resources or [])]
        arns = [a for a in arns if a]
        if arns:
            bucket.resources.update(arns)
        else:
            # Some services don't populate the resources block (e.g. sts, iam
            # metadata calls). Fall back to "*" so wildcard resources still
            # match. We record this fact so the report can flag it.
            bucket.resources.add("*")
    return usage


@dataclass
class StatementUsage:
    source: str                       # "inline:<name>" or "managed:<arn>"
    statement: dict
    matched_actions: Set[str] = field(default_factory=set)
    matched_resources: Set[str] = field(default_factory=set)

    @property
    def used(self) -> bool:
        return bool(self.matched_actions)


def _stmt_actions(stmt: dict) -> List[str]:
    a = stmt.get("Action") or stmt.get("NotAction") or []
    return a if isinstance(a, list) else [a]


def _stmt_resources(stmt: dict) -> List[str]:
    r = stmt.get("Resource") or stmt.get("NotResource") or ["*"]
    return r if isinstance(r, list) else [r]


def match_statements(
    loaded_policy, usage: Dict[str, UsedAction]
) -> List[StatementUsage]:
    """For each Allow statement in the loaded policy, record which observed
    actions/resources it covers."""
    results: List[StatementUsage] = []
    for kind, origin, stmt in loaded_policy.iter_statements():
        if stmt.get("Effect", "Allow") != "Allow":
            # Preserve denies as-is; we never remove them.
            results.append(StatementUsage(f"{kind}:{origin}", stmt))
            continue

        actions = _stmt_actions(stmt)
        resources = _stmt_resources(stmt)
        record = StatementUsage(f"{kind}:{origin}", stmt)

        for observed_action, used in usage.items():
            if not any(action_matches(p, observed_action) for p in actions):
                continue
            # Then check resources
            for res in used.resources:
                if any(resource_matches(rp, res) for rp in resources):
                    record.matched_actions.add(observed_action)
                    record.matched_resources.add(res)

        results.append(record)
    return results
