"""
Human-readable summary reports for the audit run.

Produces both a plain-text console report and a machine-readable JSON blob so
the auditor can be dropped into a CI pipeline.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Dict, List

from .action_matcher import StatementUsage, UsedAction
from .validator import ValidationReport


@dataclass
class AuditSummary:
    role_name: str
    lookback_days: int
    total_events: int
    unique_actions_used: int
    original_action_count: int
    refactored_action_count: int
    removed_actions: List[str] = field(default_factory=list)
    retained_actions: List[str] = field(default_factory=list)
    unmatched_statements: List[dict] = field(default_factory=list)
    validation_findings: Dict[str, int] = field(default_factory=dict)
    check_no_new_access: str = ""

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, default=str)

    def to_text(self) -> str:
        lines = [
            "=" * 72,
            f"IAM Least-Privilege Audit — role: {self.role_name}",
            "=" * 72,
            f"Lookback window        : {self.lookback_days} days",
            f"CloudTrail events read : {self.total_events}",
            f"Distinct actions used  : {self.unique_actions_used}",
            "",
            f"Original policy allows : {self.original_action_count} action patterns",
            f"Refactored policy      : {self.refactored_action_count} action patterns",
            f"Reduction              : "
            f"{_pct(self.original_action_count, self.refactored_action_count)}",
            "",
            "--- Removed permissions ---",
        ]
        lines.extend(f"  - {a}" for a in self.removed_actions[:50])
        if len(self.removed_actions) > 50:
            lines.append(f"  … (+{len(self.removed_actions) - 50} more)")

        lines += ["", "--- Retained permissions ---"]
        lines.extend(f"  + {a}" for a in self.retained_actions)

        if self.unmatched_statements:
            lines += ["", "--- Statements with no observed usage ---"]
            for s in self.unmatched_statements:
                lines.append(f"  · {s['source']}: {s['actions']}")

        lines += ["", "--- Access Analyzer validation ---"]
        if not self.validation_findings:
            lines.append("  No findings.")
        else:
            for ftype, count in self.validation_findings.items():
                lines.append(f"  {ftype:20s}: {count}")
        if self.check_no_new_access:
            lines.append(f"  CheckNoNewAccess     : {self.check_no_new_access}")

        lines.append("=" * 72)
        return "\n".join(lines)


def _pct(before: int, after: int) -> str:
    if before == 0:
        return "n/a"
    return f"{(before - after) / before * 100:.1f}% fewer actions"


def build_summary(
    role_name: str,
    lookback_days: int,
    events: list,
    usage: Dict[str, UsedAction],
    statement_usages: List[StatementUsage],
    refactored_policy: dict,
    validation: ValidationReport,
) -> AuditSummary:
    original_actions = _flatten_actions(statement_usages)
    retained = sorted({a for su in statement_usages for a in su.matched_actions})
    removed = sorted(original_actions - set(retained))

    refactored_action_count = 0
    for stmt in refactored_policy.get("Statement", []):
        if stmt.get("Effect") != "Allow":
            continue
        acts = stmt.get("Action", [])
        refactored_action_count += len(acts) if isinstance(acts, list) else 1

    unmatched = []
    for su in statement_usages:
        if su.statement.get("Effect", "Allow") == "Allow" and not su.used:
            actions = su.statement.get("Action", [])
            unmatched.append({
                "source": su.source,
                "actions": actions if isinstance(actions, list) else [actions],
            })

    findings_counts = {k: len(v) for k, v in validation.by_type().items()}

    return AuditSummary(
        role_name=role_name,
        lookback_days=lookback_days,
        total_events=len(events),
        unique_actions_used=len(usage),
        original_action_count=len(original_actions),
        refactored_action_count=refactored_action_count,
        removed_actions=removed,
        retained_actions=retained,
        unmatched_statements=unmatched,
        validation_findings=findings_counts,
        check_no_new_access=validation.check_no_new_access or "",
    )


def _flatten_actions(statement_usages: List[StatementUsage]) -> set:
    out = set()
    for su in statement_usages:
        if su.statement.get("Effect", "Allow") != "Allow":
            continue
        acts = su.statement.get("Action", [])
        if isinstance(acts, str):
            acts = [acts]
        out.update(acts)
    return out
