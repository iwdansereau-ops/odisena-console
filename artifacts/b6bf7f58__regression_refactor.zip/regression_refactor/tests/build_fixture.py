#!/usr/bin/env python3
"""
Split the aggregate bench_history.json into per-run files matching the
`benchmarks/history/<YYYY-MM-DD>_<sha>.json` layout used by the CI workflow.
Each per-run file is a valid "summary" doc with `runs: [<single run>]`.
"""
import json, os, pathlib

HERE = pathlib.Path(__file__).parent
SRC  = HERE / "full_bench_history.json"
DST  = HERE / "fixture_history"
DST.mkdir(exist_ok=True)

# Clear stale files so re-runs are hermetic.
for f in DST.glob("*.json"):
    f.unlink()

doc = json.loads(SRC.read_text())
for run in doc["runs"]:
    date  = run["timestamp"][:10]
    sha   = run["commit"][:7]
    out   = DST / f"{date}_{sha}.json"
    # Wrap each single run in the {"runs": [...]} envelope so the loader
    # treats it identically to a full history file.
    out.write_text(json.dumps({"runs": [run]}, indent=2))

    # Preserve the timestamp ordering via mtime as a belt-and-braces measure.
    import datetime as _dt
    epoch = _dt.datetime.fromisoformat(
        run["timestamp"].replace("Z", "+00:00")).timestamp()
    os.utime(out, (epoch, epoch))

print(f"Wrote {len(doc['runs'])} per-run fixture files to {DST}")
