###############################################################################
# Example: provision GitHub OIDC roles in both staging and production accounts.
#
# Trust surface:
#   - staging     -> any push to `main` or `release/*` branches
#   - production  -> ONLY the `production` GitHub Environment (which typically
#                    has manual approval + protected reviewers configured on
#                    the GitHub side). No branch trust, no PR trust.
###############################################################################

module "gha_oidc_staging" {
  source = "../../modules/github-oidc-role"
  providers = {
    aws = aws.staging
  }

  role_name   = "gha-otel-pipeline-staging"
  environment = "staging"

  github_org           = var.github_org
  allowed_repositories = [var.otel_repo]
  allowed_branches     = ["main", "release/*"]

  max_session_duration = 3600 # 1h

  otel_policy_config = {
    otlp_traces_log_group_arn  = var.staging_otel_resources.otlp_traces_log_group_arn
    otlp_metrics_log_group_arn = var.staging_otel_resources.otlp_metrics_log_group_arn
    telemetry_bucket_arn       = var.staging_otel_resources.telemetry_bucket_arn
    xray_enabled               = true
    amp_workspace_arn          = var.staging_otel_resources.amp_workspace_arn
  }

  tags = {
    CostCenter = "observability"
    Owner      = "platform-team"
  }
}

module "gha_oidc_production" {
  source = "../../modules/github-oidc-role"
  providers = {
    aws = aws.production
  }

  role_name   = "gha-otel-pipeline-production"
  environment = "production"

  github_org           = var.github_org
  allowed_repositories = [var.otel_repo]

  # No branch or PR trust in prod. Only the GitHub `production` environment,
  # which should have required reviewers + a deployment protection rule.
  allowed_environments = ["production"]

  # Shorter session — CI deploys should be quick.
  max_session_duration = 1800 # 30m

  otel_policy_config = {
    otlp_traces_log_group_arn  = var.production_otel_resources.otlp_traces_log_group_arn
    otlp_metrics_log_group_arn = var.production_otel_resources.otlp_metrics_log_group_arn
    telemetry_bucket_arn       = var.production_otel_resources.telemetry_bucket_arn
    xray_enabled               = true
    amp_workspace_arn          = var.production_otel_resources.amp_workspace_arn
  }

  tags = {
    CostCenter = "observability"
    Owner      = "platform-team"
    Compliance = "prod"
  }
}
