variable "region" {
  type    = string
  default = "us-east-1"
}

variable "github_org" {
  type        = string
  description = "GitHub org that owns the OTel pipeline repo."
}

variable "otel_repo" {
  type        = string
  description = "Name of the OTel pipeline repository (without org prefix)."
  default     = "otel-pipeline"
}

variable "staging_deploy_role_arn" {
  type        = string
  description = "Deployment role Terraform assumes in the staging account."
}

variable "production_deploy_role_arn" {
  type        = string
  description = "Deployment role Terraform assumes in the production account."
}

# Pre-existing infra the OTel role is scoped to. In a real setup these come
# from other modules; hard-coding ARNs here keeps the example self-contained.
variable "staging_otel_resources" {
  type = object({
    otlp_traces_log_group_arn  = string
    otlp_metrics_log_group_arn = string
    telemetry_bucket_arn       = string
    amp_workspace_arn          = optional(string, "")
  })
}

variable "production_otel_resources" {
  type = object({
    otlp_traces_log_group_arn  = string
    otlp_metrics_log_group_arn = string
    telemetry_bucket_arn       = string
    amp_workspace_arn          = optional(string, "")
  })
}
