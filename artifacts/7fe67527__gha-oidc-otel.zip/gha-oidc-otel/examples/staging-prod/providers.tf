###############################################################################
# Two AWS providers, one per target account. The role_arn values should point
# to an org-provisioned deployment role (e.g. from AWS Control Tower / OU
# baseline) that Terraform assumes at plan/apply time.
###############################################################################

provider "aws" {
  alias  = "staging"
  region = var.region

  assume_role {
    role_arn     = var.staging_deploy_role_arn
    session_name = "terraform-gha-oidc-staging"
  }
}

provider "aws" {
  alias  = "production"
  region = var.region

  assume_role {
    role_arn     = var.production_deploy_role_arn
    session_name = "terraform-gha-oidc-production"
  }
}
