output "staging_role_arn" {
  value = module.gha_oidc_staging.role_arn
}

output "production_role_arn" {
  value = module.gha_oidc_production.role_arn
}

output "staging_allowed_subs" {
  value = module.gha_oidc_staging.allowed_subs
}

output "production_allowed_subs" {
  value = module.gha_oidc_production.allowed_subs
}
