###############################################################################
# github-oidc-role
#
# Provisions:
#   1. (Optional) IAM OIDC identity provider for token.actions.githubusercontent.com
#   2. An IAM role with a restrictive trust policy scoped to:
#        - the GitHub OIDC provider (Federated principal)
#        - specific `sub` claims (repo + branch/tag/environment)
#        - the expected `aud` claim
#   3. A least-privilege inline policy for a sample OTel telemetry pipeline
#      (CloudWatch Logs, X-Ray, S3 archive, optional AMP remote-write).
#
# Design rules:
#   - Never trust `repo:*` or `sub:*` — every allowed identity is enumerated.
#   - Trust policy uses ForAllValues + StringEquals for `aud` so no other
#     audience is accepted, even if GitHub issues multiple.
#   - Sub-claim matches use StringLike only when the caller opts in via
#     wildcarded branch/tag patterns; exact matches use StringEquals.
###############################################################################

locals {
  # Canonical OIDC provider URL for GitHub Actions (no scheme in the resource,
  # but we use the fully qualified form for the trust-policy principal ARN).
  github_oidc_url  = "token.actions.githubusercontent.com"
  github_oidc_host = "https://${local.github_oidc_url}"

  # ARN of the OIDC provider we will federate against, whether we create it
  # here or the caller passed one in.
  oidc_provider_arn = var.create_oidc_provider ? aws_iam_openid_connect_provider.github[0].arn : var.existing_oidc_provider_arn

  # -----------------------------------------------------------------------
  # Build the concrete list of allowed `sub` claims. Each repo is combined
  # with every allowed branch / tag / environment. Exact strings go into
  # StringEquals; wildcard patterns (containing '*' or '?') go into StringLike.
  # -----------------------------------------------------------------------
  repo_prefixes = [for r in var.allowed_repositories : "repo:${var.github_org}/${r}"]

  branch_subs = flatten([
    for prefix in local.repo_prefixes : [
      for b in var.allowed_branches : "${prefix}:ref:refs/heads/${b}"
    ]
  ])

  tag_subs = flatten([
    for prefix in local.repo_prefixes : [
      for t in var.allowed_tags : "${prefix}:ref:refs/tags/${t}"
    ]
  ])

  env_subs = flatten([
    for prefix in local.repo_prefixes : [
      for e in var.allowed_environments : "${prefix}:environment:${e}"
    ]
  ])

  pr_subs = var.allowed_pull_request ? [for prefix in local.repo_prefixes : "${prefix}:pull_request"] : []

  all_subs = concat(local.branch_subs, local.tag_subs, local.env_subs, local.pr_subs)

  # Split into exact vs. wildcard so we can emit two Condition blocks and
  # avoid accidentally widening a StringEquals into a glob.
  exact_subs    = [for s in local.all_subs : s if !can(regex("[*?]", s))]
  wildcard_subs = [for s in local.all_subs : s if can(regex("[*?]", s))]

  common_tags = merge(
    {
      "ManagedBy"   = "terraform"
      "Module"      = "github-oidc-role"
      "Environment" = var.environment
    },
    var.tags,
  )
}

###############################################################################
# Preconditions
###############################################################################

# Fail fast if the caller misconfigured the trust surface.
resource "terraform_data" "trust_preconditions" {
  lifecycle {
    precondition {
      condition     = length(local.all_subs) > 0
      error_message = "You must specify at least one of allowed_branches, allowed_tags, allowed_environments, or allowed_pull_request=true. An empty trust surface would trust every workflow in the repo."
    }
    precondition {
      condition     = var.create_oidc_provider || length(var.existing_oidc_provider_arn) > 0
      error_message = "When create_oidc_provider = false, existing_oidc_provider_arn must be set."
    }
    precondition {
      condition     = !var.attach_otel_policy || var.otel_policy_config != null
      error_message = "attach_otel_policy = true requires otel_policy_config to be set."
    }
  }
}

###############################################################################
# OIDC provider (optional)
###############################################################################

resource "aws_iam_openid_connect_provider" "github" {
  count = var.create_oidc_provider ? 1 : 0

  url             = local.github_oidc_host
  client_id_list  = [var.audience]
  thumbprint_list = var.oidc_thumbprints

  tags = merge(local.common_tags, {
    Name = "github-actions-oidc"
  })
}

###############################################################################
# Trust policy
###############################################################################

data "aws_iam_policy_document" "trust" {
  # Exact-match statement — emitted only when there is at least one exact sub.
  # If we always emitted it and there were no exact subs, the statement would
  # have only an `aud` condition, effectively trusting every sub. Guard hard.
  dynamic "statement" {
    for_each = length(local.exact_subs) > 0 ? [1] : []
    content {
      sid     = "GitHubActionsOIDC"
      effect  = "Allow"
      actions = ["sts:AssumeRoleWithWebIdentity"]

      principals {
        type        = "Federated"
        identifiers = [local.oidc_provider_arn]
      }

      # Enforce the audience claim. ForAllValues ensures every value in the
      # token's aud array is in our allow-list — no extra audiences accepted.
      condition {
        test     = "ForAllValues:StringEquals"
        variable = "${local.github_oidc_url}:aud"
        values   = [var.audience]
      }

      condition {
        test     = "StringEquals"
        variable = "${local.github_oidc_url}:sub"
        values   = local.exact_subs
      }
    }
  }

  # A wildcard-sub statement is emitted only when we have wildcard subs, because a
  # single statement can't mix StringEquals and StringLike on the same key
  # without one overriding the intent. Each statement is independently
  # sufficient; both still require the Federated principal + audience.
  dynamic "statement" {
    for_each = length(local.wildcard_subs) > 0 ? [1] : []
    content {
      sid     = "GitHubActionsOIDCWildcard"
      effect  = "Allow"
      actions = ["sts:AssumeRoleWithWebIdentity"]

      principals {
        type        = "Federated"
        identifiers = [local.oidc_provider_arn]
      }

      condition {
        test     = "ForAllValues:StringEquals"
        variable = "${local.github_oidc_url}:aud"
        values   = [var.audience]
      }

      condition {
        test     = "StringLike"
        variable = "${local.github_oidc_url}:sub"
        values   = local.wildcard_subs
      }
    }
  }
}

###############################################################################
# IAM role
###############################################################################

resource "aws_iam_role" "this" {
  name                 = var.role_name
  description          = "GitHub Actions OIDC role for ${var.environment} (${var.github_org})."
  assume_role_policy   = data.aws_iam_policy_document.trust.json
  max_session_duration = var.max_session_duration
  permissions_boundary = var.permissions_boundary_arn

  tags = merge(local.common_tags, {
    Name = var.role_name
  })

  depends_on = [terraform_data.trust_preconditions]
}

###############################################################################
# OTel telemetry pipeline permissions (least privilege)
###############################################################################

data "aws_iam_policy_document" "otel" {
  count = var.attach_otel_policy ? 1 : 0

  # --- CloudWatch Logs: only the two named log groups + their streams ------
  statement {
    sid    = "OTelLogsWrite"
    effect = "Allow"
    actions = [
      "logs:CreateLogStream",
      "logs:PutLogEvents",
      "logs:DescribeLogStreams",
    ]
    resources = [
      var.otel_policy_config.otlp_traces_log_group_arn,
      "${var.otel_policy_config.otlp_traces_log_group_arn}:log-stream:*",
      var.otel_policy_config.otlp_metrics_log_group_arn,
      "${var.otel_policy_config.otlp_metrics_log_group_arn}:log-stream:*",
    ]
  }

  # --- S3 archive bucket: writes and lifecycle-friendly listing only -------
  statement {
    sid    = "OTelArchiveWrite"
    effect = "Allow"
    actions = [
      "s3:PutObject",
      "s3:AbortMultipartUpload",
    ]
    resources = ["${var.otel_policy_config.telemetry_bucket_arn}/*"]
  }

  statement {
    sid       = "OTelArchiveListPrefix"
    effect    = "Allow"
    actions   = ["s3:ListBucket"]
    resources = [var.otel_policy_config.telemetry_bucket_arn]

    condition {
      test     = "StringLike"
      variable = "s3:prefix"
      values   = ["otel/*"]
    }
  }

  # --- X-Ray: only if enabled (still requires "*" per AWS docs) ------------
  dynamic "statement" {
    for_each = var.otel_policy_config.xray_enabled ? [1] : []
    content {
      sid    = "OTelXRayWrite"
      effect = "Allow"
      actions = [
        "xray:PutTraceSegments",
        "xray:PutTelemetryRecords",
      ]
      # X-Ray does not currently support resource-level permissions for these
      # actions. Wildcard is unavoidable — but the role itself is bounded by
      # OIDC trust, so blast radius stays narrow.
      resources = ["*"]
    }
  }

  # --- Amazon Managed Prometheus remote-write (optional) -------------------
  dynamic "statement" {
    for_each = length(var.otel_policy_config.amp_workspace_arn) > 0 ? [1] : []
    content {
      sid       = "OTelAMPRemoteWrite"
      effect    = "Allow"
      actions   = ["aps:RemoteWrite"]
      resources = [var.otel_policy_config.amp_workspace_arn]
    }
  }
}

resource "aws_iam_policy" "otel" {
  count       = var.attach_otel_policy ? 1 : 0
  name        = "${var.role_name}-otel"
  description = "Least-privilege OTel telemetry pipeline permissions for ${var.role_name}."
  policy      = data.aws_iam_policy_document.otel[0].json
  tags        = local.common_tags
}

resource "aws_iam_role_policy_attachment" "otel" {
  count      = var.attach_otel_policy ? 1 : 0
  role       = aws_iam_role.this.name
  policy_arn = aws_iam_policy.otel[0].arn
}

resource "aws_iam_role_policy_attachment" "additional" {
  for_each   = toset(var.additional_policy_arns)
  role       = aws_iam_role.this.name
  policy_arn = each.value
}
