###############################################################################
# Inputs
###############################################################################

variable "role_name" {
  description = "Name of the IAM role that GitHub Actions will assume."
  type        = string

  validation {
    condition     = can(regex("^[A-Za-z0-9+=,.@_-]{1,64}$", var.role_name))
    error_message = "role_name must be 1-64 chars matching IAM role naming rules."
  }
}

variable "environment" {
  description = "Deployment environment (e.g. staging, production). Used for tagging and naming only."
  type        = string
}

variable "github_org" {
  description = "GitHub organization or user that owns the repository (case-sensitive)."
  type        = string

  validation {
    condition     = length(var.github_org) > 0 && !can(regex("[/\\s]", var.github_org))
    error_message = "github_org must be a single org/user name without slashes or whitespace."
  }
}

variable "allowed_repositories" {
  description = <<-EOT
    List of repositories (without the org prefix) that are allowed to assume the role.
    Each entry combined with `github_org` produces the `sub` claim prefix
    `repo:<github_org>/<repo>:...`. At least one repo is required to prevent an
    unbounded trust policy.
  EOT
  type        = list(string)

  validation {
    condition     = length(var.allowed_repositories) > 0
    error_message = "You must specify at least one repository. Wildcards across all repos are refused."
  }

  validation {
    condition     = alltrue([for r in var.allowed_repositories : can(regex("^[A-Za-z0-9._-]+$", r))])
    error_message = "Repository names must contain only [A-Za-z0-9._-] (no wildcards, no slashes)."
  }
}

variable "allowed_branches" {
  description = <<-EOT
    Branch names allowed to assume the role via the `ref:refs/heads/<branch>` sub-claim.
    Used only when `allowed_environments` is empty. Wildcards are supported via
    StringLike (e.g. "release/*"). Leave empty to disallow branch-based trust.
  EOT
  type        = list(string)
  default     = []
}

variable "allowed_tags" {
  description = "Git tag patterns allowed via the `ref:refs/tags/<tag>` sub-claim. Supports StringLike wildcards."
  type        = list(string)
  default     = []
}

variable "allowed_environments" {
  description = <<-EOT
    GitHub deployment environments allowed to assume the role via the
    `environment:<env>` sub-claim. When set, this is the preferred, most
    restrictive binding (recommended for production).
  EOT
  type        = list(string)
  default     = []
}

variable "allowed_pull_request" {
  description = "If true, allow the `pull_request` sub-claim. Strongly discouraged for prod."
  type        = bool
  default     = false
}

variable "audience" {
  description = "Expected OIDC audience. `sts.amazonaws.com` matches aws-actions/configure-aws-credentials."
  type        = string
  default     = "sts.amazonaws.com"
}

variable "create_oidc_provider" {
  description = <<-EOT
    Whether to create the token.actions.githubusercontent.com OIDC provider in
    this account. Set to false in accounts where the provider already exists
    and pass its ARN via `existing_oidc_provider_arn`.
  EOT
  type        = bool
  default     = true
}

variable "existing_oidc_provider_arn" {
  description = "ARN of an existing GitHub OIDC provider to reuse when create_oidc_provider = false."
  type        = string
  default     = ""
}

variable "oidc_thumbprints" {
  description = <<-EOT
    Optional list of certificate thumbprints. AWS now validates GitHub's OIDC
    tokens against its trusted CA store, so this is effectively cosmetic, but
    Terraform still requires the argument. Leave default unless you have a
    compliance reason to pin thumbprints.
  EOT
  type        = list(string)
  default = [
    # GitHub's historically published thumbprints. AWS no longer relies on
    # these for verification, but Terraform requires a non-empty list.
    "6938fd4d98bab03faadb97b34396831e3780aea1",
    "1c58a3a8518e8759bf075b76b750d4f2df264fcd",
  ]
}

variable "max_session_duration" {
  description = "Max session duration (seconds) for the role. Keep short for CI."
  type        = number
  default     = 3600

  validation {
    condition     = var.max_session_duration >= 900 && var.max_session_duration <= 43200
    error_message = "max_session_duration must be between 900 (15m) and 43200 (12h) seconds."
  }
}

variable "permissions_boundary_arn" {
  description = "Optional IAM permissions boundary ARN to attach to the role."
  type        = string
  default     = null
}

variable "attach_otel_policy" {
  description = "Attach the built-in least-privilege OTel telemetry pipeline policy."
  type        = bool
  default     = true
}

variable "otel_policy_config" {
  description = <<-EOT
    Configuration for the built-in OTel policy. All ARNs are required so
    the policy stays scoped to specific resources rather than "*".
  EOT
  type = object({
    otlp_traces_log_group_arn  = string # CloudWatch Logs group ARN for OTel traces
    otlp_metrics_log_group_arn = string # CloudWatch Logs group ARN for OTel metrics
    telemetry_bucket_arn       = string # S3 bucket ARN for raw span/metric archive
    xray_enabled               = bool
    amp_workspace_arn          = optional(string, "") # Optional AMP (Managed Prometheus) workspace ARN
  })
  default = null
}

variable "additional_policy_arns" {
  description = "Extra managed policy ARNs to attach to the role."
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Tags applied to all created resources."
  type        = map(string)
  default     = {}
}
