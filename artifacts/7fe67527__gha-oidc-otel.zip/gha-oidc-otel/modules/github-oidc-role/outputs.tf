output "role_arn" {
  description = "ARN of the IAM role that GitHub Actions will assume via OIDC."
  value       = aws_iam_role.this.arn
}

output "role_name" {
  description = "Name of the IAM role."
  value       = aws_iam_role.this.name
}

output "oidc_provider_arn" {
  description = "ARN of the GitHub OIDC provider used by the trust policy."
  value       = local.oidc_provider_arn
}

output "trust_policy_json" {
  description = "Rendered trust policy JSON (useful for audit / diffing)."
  value       = data.aws_iam_policy_document.trust.json
}

output "otel_policy_arn" {
  description = "ARN of the attached OTel permissions policy, if created."
  value       = try(aws_iam_policy.otel[0].arn, null)
}

output "allowed_subs" {
  description = "Concrete list of OIDC `sub` claims allowed by the trust policy (audit aid)."
  value       = local.all_subs
}
