# gha-oidc-otel

Reusable Terraform module that provisions:

1. An **IAM OIDC identity provider** for `token.actions.githubusercontent.com` (optional — reusable across accounts).
2. An **IAM role** with a restrictive trust policy scoped by repo, branch/tag/environment, and audience.
3. A **least-privilege inline policy** for a sample OpenTelemetry (OTel) telemetry pipeline.
4. A **validation script** (`scripts/validate_oidc_trust.sh`) that proves only GitHub-signed OIDC tokens can assume the role.

Directory layout:

```
gha-oidc-otel/
├── modules/github-oidc-role/          # the reusable module
├── examples/staging-prod/             # multi-account example (staging + production)
├── scripts/
│   ├── validate_oidc_trust.sh         # static + live trust-policy validator
│   ├── otel_probe/                    # least-privilege smoke test (S3/X-Ray/AMP/Logs)
│   └── otel_loadtest/                 # 1x→10x load ramp + sensitivity report + GH issue draft
└── .github/workflows/
    ├── validate-oidc.yml              # weekly trust-policy drift check
    ├── otel-probe.yml                 # on-demand permission smoke test
    └── otel-loadtest.yml              # on-demand load ramp
```

## Module inputs (summary)

| Input | Required | Purpose |
| --- | --- | --- |
| `role_name` | ✅ | IAM role name. |
| `environment` | ✅ | Tag + naming aid (`staging`, `production`, …). |
| `github_org` | ✅ | GitHub org/user — case sensitive. |
| `allowed_repositories` | ✅ | List of repo names (no wildcards, no slashes). |
| `allowed_branches` | – | Branch names / patterns (StringLike when a `*` or `?` is present). |
| `allowed_tags` | – | Tag names / patterns. |
| `allowed_environments` | – | GitHub deployment environments (preferred for prod). |
| `allowed_pull_request` | – | Trust the `pull_request` sub-claim (default `false`). |
| `audience` | – | Defaults to `sts.amazonaws.com`. |
| `create_oidc_provider` | – | Set `false` and pass `existing_oidc_provider_arn` to reuse. |
| `attach_otel_policy` + `otel_policy_config` | – | Attach the built-in OTel policy. |
| `max_session_duration` | – | Seconds, 900–43200. |
| `permissions_boundary_arn` | – | Optional boundary. |
| `additional_policy_arns` | – | Extra managed policies. |

## Trust-policy security model

The generated trust policy enforces **all four** of the following, in every statement:

1. `Principal.Federated` = the GitHub OIDC provider ARN (nothing else).
2. `Action` = `sts:AssumeRoleWithWebIdentity` only. `sts:AssumeRole` is never granted.
3. `token.actions.githubusercontent.com:aud` pinned via `ForAllValues:StringEquals` (rejects tokens with extra audiences).
4. `token.actions.githubusercontent.com:sub` pinned to an **enumerated list** built from `github_org` × `allowed_repositories` × (`branches` ∪ `tags` ∪ `environments` ∪ optional `pull_request`).

Cross-repo protection works because the `sub` claim is always prefixed with `repo:<org>/<repo>:` and the module refuses `*` or `/` in repo names (input validation) and refuses an empty trust surface (precondition). A workflow in any other repo — even inside the same org — produces a different `sub` and STS denies the assume.

Exact strings and wildcard patterns are emitted as **separate** statements so a `StringEquals` block is never accidentally widened by a `StringLike` glob.

## Least-privilege OTel policy

The attached policy grants only:

- `logs:CreateLogStream` / `logs:PutLogEvents` / `logs:DescribeLogStreams` — **only** on the two named log groups you pass in (traces + metrics).
- `s3:PutObject` / `s3:AbortMultipartUpload` on `arn:aws:s3:::<bucket>/*`.
- `s3:ListBucket` on the bucket, gated by `s3:prefix` = `otel/*`.
- `xray:PutTraceSegments` / `PutTelemetryRecords` (X-Ray requires `Resource: "*"` for these — unavoidable, but the role's OIDC trust bounds the blast radius).
- `aps:RemoteWrite` on a specific AMP workspace, only when `amp_workspace_arn` is provided.

No `iam:*`, no `sts:AssumeRole`, no wildcard resources (except where AWS forces it for X-Ray).

## Multi-account example (`examples/staging-prod`)

Uses provider aliases `aws.staging` and `aws.production`, each assuming a
per-account deployment role Terraform holds. Staging trusts pushes to
`main` and `release/*`; production trusts **only** the GitHub `production`
environment (which should be gated by required reviewers on the GitHub side).

```hcl
module "gha_oidc_production" {
  source = "../../modules/github-oidc-role"
  providers = { aws = aws.production }

  role_name             = "gha-otel-pipeline-production"
  environment           = "production"
  github_org            = "acme"
  allowed_repositories  = ["otel-pipeline"]
  allowed_environments  = ["production"]
  max_session_duration  = 1800

  otel_policy_config = {
    otlp_traces_log_group_arn  = "arn:aws:logs:us-east-1:222…:log-group:/otel/traces"
    otlp_metrics_log_group_arn = "arn:aws:logs:us-east-1:222…:log-group:/otel/metrics"
    telemetry_bucket_arn       = "arn:aws:s3:::acme-otel-prod-archive"
    xray_enabled               = true
    amp_workspace_arn          = "arn:aws:aps:us-east-1:222…:workspace/ws-abc"
  }
}
```

## Validation script

`scripts/validate_oidc_trust.sh` runs both static and live checks against a
provisioned role. Requires `aws` v2, `jq`, and `python3`.

```bash
./scripts/validate_oidc_trust.sh \
  --staging-role    arn:aws:iam::111111111111:role/gha-otel-pipeline-staging \
  --production-role arn:aws:iam::222222222222:role/gha-otel-pipeline-production
```

The script verifies, per role:

1. Federated principal points **only** at `token.actions.githubusercontent.com`.
2. `aud` is pinned to a single expected value.
3. `sub` is pinned to specific values (rejects bare `*` or missing sub).
4. Only `sts:AssumeRoleWithWebIdentity` is in the `Action` list.
5. **Negative test:** `sts:AssumeRole` with the caller's own credentials fails.
6. **Negative test:** a hand-crafted JWT (valid structure, no GitHub signature) is rejected by STS with `InvalidIdentityToken` — proving STS actually verifies GitHub's signing keys.
7. **Positive test (only when run inside GitHub Actions):** the real GitHub-issued OIDC token successfully assumes the role.

The included workflow `.github/workflows/validate-oidc.yml` runs the script
from CI on demand and on a weekly schedule, so drift in the trust policy is
caught early. Store the role ARNs as GitHub **Variables**
`STAGING_ROLE_ARN` and `PRODUCTION_ROLE_ARN`, and gate the `production`
matrix leg behind a protected environment.

## Assumptions

- AWS provider ≥ 5.30, Terraform ≥ 1.5.
- The caller-side Terraform runner assumes a per-account deployment role
  (`staging_deploy_role_arn`, `production_deploy_role_arn` in the example).
- Log groups / S3 buckets / AMP workspaces referenced by `otel_policy_config`
  are provisioned by other modules; this module never grants create/delete.
- AWS validates GitHub's OIDC signature against its trusted CA store, so the
  `thumbprint_list` is retained for Terraform compatibility only.
