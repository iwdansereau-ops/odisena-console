# OTel pipeline load-injection harness

`otel_loadtest.py` ramps traffic against your provisioned OTel role from
**1× through 10×** a stated baseline peak, records per-request outcomes
(2xx / 403 / 429 / 5xx / other), correlates against AWS-side CloudWatch
counters (`AWS/Usage` `ThrottleCount`, `AWS/Prometheus`
`IngestionRate` / `DiscardedSamples`), and writes a sensitivity report
plus a **pre-filled GitHub issue** that recommends the specific quota
increases and collector-side backoff changes needed before you enable
production ingest at target volume.

## What it does per stage

- Reads `--baseline-xray-tps` (X-Ray `PutTraceSegments` calls/sec) and
  `--baseline-amp-samples-per-sec` (AMP samples/sec).
- Multiplies by 1, 2, 3, … 10 to build 10 stages.
- Each stage runs for `--stage-duration-sec` (default 60 s), followed by
  a `--stage-cooldown-sec` idle gap (default 15 s). The cooldown gives
  AMP's 30-min rolling ingestion baseline room to breathe — AMP will
  throttle if you *double* your prior baseline in a burst.
- Every request records `(ts, service, stage, http_status, error_code,
  latency, retry_after)` into an in-memory ring.
- After the ramp, the script pulls CloudWatch metrics that overlap the
  run window and emits four files.

## Safety rails (all on by default)

| Rail | Default | Effect |
|------|---------|--------|
| `--max-total-requests` | 2,000,000 | Hard cap; ramp exits early on breach. |
| `--max-wallclock-sec` | 2,700 (45 min) | Hard wallclock cap. |
| `--kill-switch-file` | (unset) | Touch this path from any shell to abort cleanly at the next stage boundary. |
| `--dry-run` | off | Prints the ramp plan and exits without sending traffic. |
| Prod ambient-cred check | on | Refuses to run against `--env production` with ambient creds unless `--allow-ambient` is set. |
| Makefile `loadtest-prod` | requires `CONFIRM_PROD=I_UNDERSTAND` | Second belt against prod misfires. |

## Credentials

Identical resolution to `otel_probe.py`:

1. `AWS_WEB_IDENTITY_TOKEN_FILE` + `AWS_ROLE_ARN` (runner-native OIDC).
2. `--assume-role-arn <role>` for local dev with an admin session.
3. Ambient (env / `~/.aws` / instance role); refused for prod unless
   `--allow-ambient`.

The session duration is auto-sized so it lasts through the entire ramp +
cooldowns + a 5 min buffer.

## Local usage

```bash
cd scripts/otel_loadtest
cp .env.example .env.staging   # fill in real values
make dry-run                   # inspect the plan
make loadtest-staging
```

Reports land in `./reports/`:

- `otel-loadtest-<env>-<UTC>.md` — human-readable stage table + verdict.
- `otel-loadtest-<env>-<UTC>.csv` — chartable per-stage counters (feed
  into Grafana / Google Sheets / matplotlib).
- `otel-loadtest-<env>-<UTC>.json` — full structured record.
- `otel-loadtest-<env>-<UTC>-github-issue.md` — copy-paste-ready issue
  body with quota-increase asks and specific collector-config snippets.

## Verdict logic

The script computes an **error-budget verdict** per stage:

- **Knee** = the smallest multiplier at which per-stage error rate
  exceeds `--error-budget-pct` (default 1.0%).
- Overall verdict is PASS if neither X-Ray nor AMP has a knee inside the
  1× → 10× range.
- Exit code: `0` on PASS, `1` on FAIL, `2` on aborted / config error.

## Interpreting 403 vs 429

The report separates them because they mean very different things:

- **429** — AWS accepted the identity but the rate limit tripped. Fix
  with quota + backoff (the GitHub issue draft has the exact
  `queue_config` / `AWS_RETRY_MODE` values).
- **403** — the role lost permission mid-ramp. This is orthogonal to
  throttling: usually STS session expiry, a workspace-scoped resource
  ARN mismatch, or SigV4 clock skew. The GitHub issue draft calls out
  each root cause with a specific action.

If both trip, the issue draft splits them into separate work items so
you don't accidentally raise a quota when the actual problem is IAM.

## Running from a GitHub runner

Add a manual dispatch job that assumes the role via OIDC and runs the
harness; upload the reports as artifacts.

```yaml
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: ${{ vars.STAGING_ROLE_ARN }}
    aws-region: us-east-1
- run: |
    pip install -r scripts/otel_loadtest/requirements.txt
    python scripts/otel_loadtest/otel_loadtest.py \
      --region us-east-1 --env staging \
      --baseline-xray-tps ${{ vars.BASELINE_XRAY_TPS }} \
      --baseline-amp-samples-per-sec ${{ vars.BASELINE_AMP_SAMPLES_PER_SEC }} \
      --amp-endpoint ${{ vars.AMP_REMOTE_WRITE_URL }} \
      --amp-workspace-id ${{ vars.AMP_WORKSPACE_ID }} \
      --stage-duration-sec 60 --error-budget-pct 1.0
- uses: actions/upload-artifact@v4
  with: { name: otel-loadtest-report, path: reports/ }
```

## References

- [AWS X-Ray service quotas](https://docs.aws.amazon.com/general/latest/gr/xray.html) — 2,600 segments/sec/region default.
- [X-Ray `PutTraceSegments` API — ThrottledException](https://docs.aws.amazon.com/it_it/xray/latest/api/API_PutTraceSegments.html) — HTTP 429.
- [AMP service quotas](https://docs.aws.amazon.com/prometheus/latest/userguide/AMP_quotas.html) — 70k samples/sec default, token bucket.
- [AMP troubleshooting: 429 errors](https://docs.aws.amazon.com/prometheus/latest/userguide/AMP-troubleshooting.html) — RemoteWrite rate-limit responses.
