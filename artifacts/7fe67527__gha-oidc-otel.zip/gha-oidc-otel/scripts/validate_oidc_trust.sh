#!/usr/bin/env bash
# =============================================================================
# validate_oidc_trust.sh
#
# Verifies that a provisioned IAM role can ONLY be assumed via a GitHub-signed
# OIDC token, and rejects every other assumption path.
#
# Checks performed per role (staging + production):
#   1. The role's trust policy has exactly one Federated principal, and it
#      points at token.actions.githubusercontent.com.
#   2. The trust policy pins the `aud` condition to a single value.
#   3. The trust policy pins the `sub` condition to specific values (no bare
#      "*" or missing sub condition).
#   4. `sts:AssumeRole` (long-term creds) is NOT allowed — only
#      `sts:AssumeRoleWithWebIdentity`.
#   5. Negative test: attempting `aws sts assume-role` with the caller's
#      current credentials MUST fail with AccessDenied.
#   6. Negative test: attempting `sts:AssumeRoleWithWebIdentity` with a
#      hand-crafted (non-GitHub-signed) JWT MUST fail with
#      InvalidIdentityToken or Unauthorized.
#   7. Positive test (only when GITHUB_OIDC_TOKEN + GITHUB_SUB are provided,
#      i.e. run from inside GitHub Actions): assume the role with the real
#      GitHub-issued token and confirm success.
#
# Usage:
#   ./validate_oidc_trust.sh \
#       --staging-role    arn:aws:iam::111111111111:role/gha-otel-pipeline-staging \
#       --production-role arn:aws:iam::222222222222:role/gha-otel-pipeline-production
#
# Requires: aws CLI v2, jq, python3.
# Exit code: 0 on success, non-zero if any check fails.
# =============================================================================
set -euo pipefail

STAGING_ROLE=""
PRODUCTION_ROLE=""
EXPECTED_AUD="${EXPECTED_AUD:-sts.amazonaws.com}"
EXPECTED_ISSUER="token.actions.githubusercontent.com"

usage() {
  sed -n '2,32p' "$0"
  exit 1
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --staging-role)    STAGING_ROLE="$2"; shift 2 ;;
    --production-role) PRODUCTION_ROLE="$2"; shift 2 ;;
    -h|--help)         usage ;;
    *) echo "Unknown arg: $1" >&2; usage ;;
  esac
done

[[ -z "$STAGING_ROLE" || -z "$PRODUCTION_ROLE" ]] && usage

for bin in aws jq python3; do
  command -v "$bin" >/dev/null || { echo "Missing required tool: $bin" >&2; exit 2; }
done

FAILURES=0
pass() { printf '  \033[32m✓\033[0m %s\n' "$1"; }
fail() { printf '  \033[31m✗\033[0m %s\n' "$1"; FAILURES=$((FAILURES+1)); }

# ---------------------------------------------------------------------------
# Split an ARN into account id + role name.
# ---------------------------------------------------------------------------
parse_role_arn() {
  local arn="$1"
  # arn:aws:iam::<account>:role/<name>
  python3 - "$arn" <<'PY'
import sys
arn = sys.argv[1]
parts = arn.split(":")
if len(parts) != 6 or not parts[5].startswith("role/"):
    sys.exit(f"Not a role ARN: {arn}")
print(parts[4])           # account
print(parts[5][len("role/"):])  # role name
PY
}

# ---------------------------------------------------------------------------
# Static trust-policy checks (1–4)
# ---------------------------------------------------------------------------
check_trust_policy() {
  local label="$1" role_arn="$2"
  echo "== $label ($role_arn) =="

  mapfile -t parsed < <(parse_role_arn "$role_arn")
  local account="${parsed[0]}" role_name="${parsed[1]}"

  local policy_json
  if ! policy_json=$(aws iam get-role --role-name "$role_name" \
        --query 'Role.AssumeRolePolicyDocument' --output json 2>/dev/null); then
    fail "Unable to fetch trust policy (need iam:GetRole in account $account)."
    return
  fi

  # Trust policies come back URL-encoded when queried via some SDKs; the CLI
  # already decodes JSON, but guard anyway.
  echo "$policy_json" | jq . >/dev/null 2>&1 || {
    fail "Trust policy is not valid JSON."
    return
  }

  # 1. Federated principal points at GitHub OIDC provider.
  local principals
  principals=$(echo "$policy_json" | jq -r '
    [.Statement[]?.Principal.Federated] | flatten | map(select(. != null)) | .[]')
  if [[ -z "$principals" ]]; then
    fail "No Federated principal in trust policy."
  else
    local bad_principals=0
    while IFS= read -r p; do
      if [[ "$p" != *"oidc-provider/${EXPECTED_ISSUER}"* ]]; then
        fail "Unexpected Federated principal: $p"
        bad_principals=1
      fi
    done <<<"$principals"
    [[ $bad_principals -eq 0 ]] && pass "Federated principal = GitHub OIDC provider only."
  fi

  # 2. `aud` condition pinned.
  local aud_values
  aud_values=$(echo "$policy_json" | jq -r --arg iss "$EXPECTED_ISSUER" '
    [.Statement[]?.Condition // {} | to_entries[]?.value | to_entries[]?
     | select(.key == ($iss + ":aud")) | .value] | flatten | unique | .[]?')
  if [[ -z "$aud_values" ]]; then
    fail "Trust policy does not restrict the aud claim."
  else
    local bad_aud=0
    while IFS= read -r v; do
      [[ "$v" == "$EXPECTED_AUD" ]] || { fail "Unexpected aud value: $v"; bad_aud=1; }
    done <<<"$aud_values"
    [[ $bad_aud -eq 0 ]] && pass "aud claim pinned to '$EXPECTED_AUD'."
  fi

  # 3. `sub` condition present and not a bare wildcard.
  local sub_values
  sub_values=$(echo "$policy_json" | jq -r --arg iss "$EXPECTED_ISSUER" '
    [.Statement[]?.Condition // {} | to_entries[]?.value | to_entries[]?
     | select(.key == ($iss + ":sub")) | .value] | flatten | .[]?')
  if [[ -z "$sub_values" ]]; then
    fail "Trust policy does not restrict the sub claim — anyone in the org could assume the role."
  else
    local bad_sub=0
    while IFS= read -r v; do
      if [[ "$v" == "*" || "$v" == "repo:*" ]]; then
        fail "sub value is a bare wildcard: $v"
        bad_sub=1
      fi
    done <<<"$sub_values"
    [[ $bad_sub -eq 0 ]] && pass "sub claim pinned to $(echo "$sub_values" | wc -l | tr -d ' ') specific value(s)."
  fi

  # 4. Only AssumeRoleWithWebIdentity is allowed.
  local actions
  actions=$(echo "$policy_json" | jq -r '[.Statement[]?.Action] | flatten | unique | .[]')
  local bad_action=0
  while IFS= read -r a; do
    case "$a" in
      "sts:AssumeRoleWithWebIdentity") ;;
      *) fail "Unexpected action in trust policy: $a"; bad_action=1 ;;
    esac
  done <<<"$actions"
  [[ $bad_action -eq 0 ]] && pass "Trust policy allows only sts:AssumeRoleWithWebIdentity."

  # 5. Negative test: current credentials must NOT be able to assume the role.
  echo "  -- negative test: sts:AssumeRole with caller's creds --"
  if aws sts assume-role \
        --role-arn "$role_arn" \
        --role-session-name "validate-negative-$RANDOM" \
        --duration-seconds 900 >/dev/null 2>&1; then
    fail "SECURITY: current credentials were able to sts:AssumeRole this role — trust policy is too permissive."
  else
    pass "sts:AssumeRole denied for non-OIDC caller (expected)."
  fi

  # 6. Negative test: forged web-identity token must be rejected.
  echo "  -- negative test: forged OIDC token --"
  local fake_jwt
  fake_jwt=$(python3 - <<'PY'
import base64, json, time
def b64(x): return base64.urlsafe_b64encode(x).rstrip(b"=").decode()
header = {"alg": "RS256", "kid": "fake", "typ": "JWT"}
payload = {
    "iss": "https://token.actions.githubusercontent.com",
    "sub": "repo:attacker/evil:ref:refs/heads/main",
    "aud": "sts.amazonaws.com",
    "iat": int(time.time()),
    "exp": int(time.time()) + 600,
}
print(f"{b64(json.dumps(header).encode())}.{b64(json.dumps(payload).encode())}.AAAA")
PY
)
  set +e
  err=$(aws sts assume-role-with-web-identity \
          --role-arn "$role_arn" \
          --role-session-name "validate-forged-$RANDOM" \
          --web-identity-token "$fake_jwt" 2>&1 >/dev/null)
  rc=$?
  set -e
  if [[ $rc -eq 0 ]]; then
    fail "SECURITY: forged JWT was accepted. STS did not verify GitHub's signature."
  else
    if echo "$err" | grep -qiE "InvalidIdentityToken|Unauthorized|not authorized|signature"; then
      pass "Forged JWT correctly rejected by STS (signature check enforced)."
    else
      # Still rejected, but the reason wasn't signature — surface it.
      pass "Forged JWT rejected (reason: $(echo "$err" | tr '\n' ' ' | head -c 160))."
    fi
  fi

  # 7. Positive test — only inside GitHub Actions with a real token.
  if [[ -n "${GITHUB_OIDC_TOKEN:-}" && -n "${GITHUB_SUB_MATCHES:-}" && "$GITHUB_SUB_MATCHES" == "1" ]]; then
    echo "  -- positive test: real GitHub-issued token --"
    if aws sts assume-role-with-web-identity \
          --role-arn "$role_arn" \
          --role-session-name "validate-positive-$RANDOM" \
          --web-identity-token "$GITHUB_OIDC_TOKEN" >/dev/null 2>&1; then
      pass "Real GitHub OIDC token successfully assumed the role."
    else
      fail "Real GitHub OIDC token was rejected — check sub/aud/branch mapping."
    fi
  fi
}

check_trust_policy "STAGING"    "$STAGING_ROLE"
check_trust_policy "PRODUCTION" "$PRODUCTION_ROLE"

echo
if [[ $FAILURES -eq 0 ]]; then
  echo -e "\033[32mAll trust-policy checks passed.\033[0m"
  exit 0
else
  echo -e "\033[31m$FAILURES check(s) failed.\033[0m"
  exit 1
fi
