"""
Reporting: turn a refactored policy + analyzer findings + validation result
into a human-readable Markdown / text report and a machine-readable JSON blob.
"""
from __future__ import annotations

import json
from typing import Any

from .analyzer import Finding, worst_severity
from .actions import DESTRUCTIVE_ACTIONS, READ_ACTIONS
from .diff import diff_policies, render_diff_markdown
from .validator import ValidationResult


def _as_list(v: Any) -> list[Any]:
    if v is None:
        return []
    if isinstance(v, list):
        return v
    return [v]


def action_resource_matrix(policy: dict[str, Any]) -> list[dict[str, Any]]:
    """Flatten policy into (Sid, Effect, Action, Resource[], Access-Class) rows."""
    rows: list[dict[str, Any]] = []
    for stmt in _as_list(policy.get("Statement", [])):
        sid = stmt.get("Sid", "")
        effect = stmt.get("Effect", "")
        actions = _as_list(stmt.get("Action"))
        resources = _as_list(stmt.get("Resource"))
        cond = "yes" if "Condition" in stmt else "no"
        for a in actions:
            if a in DESTRUCTIVE_ACTIONS:
                cls = "destructive"
            elif a in READ_ACTIONS:
                cls = "read"
            elif isinstance(a, str) and a.startswith("dynamodb:"):
                cls = "write/admin"
            else:
                cls = "other"
            rows.append(
                {
                    "sid": sid,
                    "effect": effect,
                    "action": a,
                    "resources": resources,
                    "class": cls,
                    "conditioned": cond,
                }
            )
    return rows


def render_markdown(
    original: dict[str, Any],
    refactored: dict[str, Any],
    findings: list[Finding],
    validation: ValidationResult,
    include_diff: bool = True,
) -> str:
    lines: list[str] = []
    lines.append("# DynamoDB IAM Policy Refactor Report")
    lines.append("")
    lines.append(f"- Worst risk in original policy: **{worst_severity(findings).upper()}**")
    lines.append(f"- Validation backend used: **{validation.used}**")
    lines.append(f"- Overall validation OK: **{validation.ok}**")
    lines.append(f"- Statements: original={len(_as_list(original.get('Statement', [])))}, "
                 f"refactored={len(_as_list(refactored.get('Statement', [])))}")
    lines.append("")

    # 1. Security findings
    lines.append("## 1. Security findings on the ORIGINAL policy")
    lines.append("")
    if not findings:
        lines.append("_No findings._")
    else:
        lines.append("| Severity | Code | Stmt | Sid | Message |")
        lines.append("|----------|------|------|-----|---------|")
        for f in findings:
            msg = f.message.replace("|", "\\|")
            lines.append(
                f"| {f.severity.upper()} | `{f.code}` | {f.statement_index} | "
                f"{f.statement_sid or ''} | {msg} |"
            )
    lines.append("")

    # 2. Validation
    lines.append("## 2. Access Analyzer / structural validation on the REFACTORED policy")
    lines.append("")
    if not validation.findings:
        lines.append("_No validation findings._")
    else:
        lines.append("| Source | Severity | Code | Message |")
        lines.append("|--------|----------|------|---------|")
        for v in validation.findings:
            msg = v.message.replace("|", "\\|")
            lines.append(f"| {v.source} | {v.severity} | `{v.code}` | {msg} |")
    lines.append("")

    # 3. Action → Resource matrix
    lines.append("## 3. Action → Resource matrix for the REFACTORED policy")
    lines.append("")
    lines.append("Every allowed DynamoDB action and the exact ARNs it is limited to.")
    lines.append("")
    lines.append("| Sid | Effect | Class | Action | Conditioned | Resources |")
    lines.append("|-----|--------|-------|--------|-------------|-----------|")
    for row in action_resource_matrix(refactored):
        resources = row["resources"]
        if len(resources) == 1:
            res_txt = f"`{resources[0]}`"
        else:
            res_txt = "<br>".join(f"`{r}`" for r in resources)
        lines.append(
            f"| {row['sid']} | {row['effect']} | {row['class']} | "
            f"`{row['action']}` | {row['conditioned']} | {res_txt} |"
        )
    lines.append("")

    # 3b. Diff
    if include_diff:
        lines.append(render_diff_markdown(diff_policies(original, refactored)))
        lines.append("")

    # 4. Refactored policy
    lines.append("## 4. Refactored policy JSON")
    lines.append("")
    lines.append("```json")
    lines.append(json.dumps(refactored, indent=2))
    lines.append("```")
    lines.append("")

    # 5. Recommendations
    lines.append("## 5. Recommendations")
    lines.append("")
    lines.append("- Prefer explicit `Action` lists over `dynamodb:*` or verb-level wildcards.")
    lines.append("- Bind every table-scoped action to a specific `arn:aws:dynamodb:...:table/NAME` ARN.")
    lines.append("- Scope index, stream, and backup ARNs off the parent table.")
    lines.append("- Put service-level list/describe actions in their own statement with `Resource: \"*\"`.")
    lines.append("- Add `Condition` blocks (e.g. `aws:SourceIp`, `aws:MultiFactorAuthPresent`) on destructive actions.")
    lines.append("- Re-run Access Analyzer validation in CI on every policy change.")
    return "\n".join(lines)
