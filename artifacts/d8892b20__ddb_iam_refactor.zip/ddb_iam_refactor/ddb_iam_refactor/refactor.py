"""
Refactor a DynamoDB IAM policy into a least-privilege version.

Strategy:
  1. Walk every statement.
  2. Expand action wildcards (`dynamodb:*`, `dynamodb:Get*`, etc.) against the
     known action catalog.
  3. Split each statement into up to three sub-statements:
       a. actions that require Resource "*"        (list/describe endpoints)
       b. actions bound to concrete table ARNs
       c. actions bound to concrete index / stream / backup ARNs derived
          from the caller-supplied table list.
  4. Preserve Sid, Effect, and Condition.
  5. If Resource == "*" in the input, substitute the caller-supplied table
     ARNs.  If the input already lists concrete ARNs, keep them.
"""
from __future__ import annotations

import copy
import fnmatch
import re
from typing import Any

from .actions import (
    BACKUP_ACTIONS,
    EXPORT_ACTIONS,
    GLOBAL_TABLE_ACTIONS,
    INDEX_ACTIONS,
    STREAM_ACTIONS,
    TABLE_ACTIONS,
    WILDCARD_ONLY_ACTIONS,
    all_known_actions,
)

ARN_RE = re.compile(
    r"^arn:(?P<partition>aws|aws-us-gov|aws-cn):dynamodb:"
    r"(?P<region>[^:]*):(?P<account>[^:]*):table/(?P<table>[^/]+)(?P<suffix>/.*)?$"
)


def _as_list(v: Any) -> list[Any]:
    if v is None:
        return []
    if isinstance(v, list):
        return v
    return [v]


def _expand_actions(actions: list[str]) -> set[str]:
    """Expand any wildcard patterns against the known DynamoDB action catalog."""
    known = all_known_actions()
    out: set[str] = set()
    for a in actions:
        if not isinstance(a, str):
            continue
        if a == "*" or a == "dynamodb:*":
            out.update(known)
        elif "*" in a or "?" in a:
            out.update({k for k in known if fnmatch.fnmatchcase(k, a)})
        else:
            out.add(a)
    return out


def _table_arn(partition: str, region: str, account: str, table: str) -> str:
    return f"arn:{partition}:dynamodb:{region}:{account}:table/{table}"


def _derived_arn(table_arn: str, suffix: str) -> str:
    return f"{table_arn}{suffix}"


def _parse_input_tables(resources: list[str]) -> list[dict[str, str]]:
    """Return unique {partition,region,account,table} dicts pulled from ARNs in the input."""
    seen: set[tuple[str, str, str, str]] = set()
    out: list[dict[str, str]] = []
    for r in resources:
        if not isinstance(r, str):
            continue
        m = ARN_RE.match(r)
        if not m:
            continue
        key = (m["partition"], m["region"], m["account"], m["table"])
        if key in seen:
            continue
        seen.add(key)
        out.append(
            {
                "partition": m["partition"],
                "region": m["region"],
                "account": m["account"],
                "table": m["table"],
            }
        )
    return out


def _parse_target_tables(target_tables: list[str], default_region: str, default_account: str, default_partition: str = "aws") -> list[dict[str, str]]:
    """Accept either full ARNs or bare table names in the target list."""
    out: list[dict[str, str]] = []
    seen: set[tuple[str, str, str, str]] = set()
    for t in target_tables:
        m = ARN_RE.match(t)
        if m:
            key = (m["partition"], m["region"], m["account"], m["table"])
        else:
            key = (default_partition, default_region, default_account, t)
        if key in seen:
            continue
        seen.add(key)
        out.append(
            {
                "partition": key[0],
                "region": key[1],
                "account": key[2],
                "table": key[3],
            }
        )
    return out


def refactor_policy(
    policy: dict[str, Any],
    target_tables: list[str] | None = None,
    default_region: str = "*",
    default_account: str = "*",
    default_partition: str = "aws",
    index_names: list[str] | None = None,
) -> dict[str, Any]:
    """Return a new policy that is functionally scoped to the given tables."""
    new_policy: dict[str, Any] = {"Version": "2012-10-17", "Statement": []}

    for stmt in _as_list(policy.get("Statement", [])):
        new_statements = _refactor_statement(
            stmt,
            target_tables=target_tables or [],
            default_region=default_region,
            default_account=default_account,
            default_partition=default_partition,
            index_names=index_names or [],
        )
        new_policy["Statement"].extend(new_statements)

    return new_policy


def _refactor_statement(
    stmt: dict[str, Any],
    target_tables: list[str],
    default_region: str,
    default_account: str,
    default_partition: str,
    index_names: list[str],
) -> list[dict[str, Any]]:
    effect = stmt.get("Effect", "Allow")
    sid = stmt.get("Sid")
    condition = stmt.get("Condition")

    raw_actions = _as_list(stmt.get("Action"))
    raw_resources = _as_list(stmt.get("Resource"))

    # Determine which tables the new statements should target.
    input_tables = _parse_input_tables(raw_resources)
    if target_tables:
        tables = _parse_target_tables(target_tables, default_region, default_account, default_partition)
    elif input_tables:
        tables = input_tables
    else:
        # Nothing to bind to → keep the original resource list (may be "*") but flag downstream.
        tables = []

    expanded = sorted(_expand_actions([a for a in raw_actions if isinstance(a, str)]))

    # Bucket by resource-kind.
    buckets: dict[str, list[str]] = {
        "table": [],
        "index": [],
        "stream": [],
        "backup": [],
        "export": [],
        "global-table": [],
        "wildcard-only": [],
    }
    for a in expanded:
        if a in WILDCARD_ONLY_ACTIONS:
            buckets["wildcard-only"].append(a)
            continue
        placed = False
        if a in TABLE_ACTIONS:
            buckets["table"].append(a)
            placed = True
        if a in INDEX_ACTIONS and index_names:
            buckets["index"].append(a)
            placed = True
        if a in STREAM_ACTIONS:
            buckets["stream"].append(a)
            placed = True
        if a in BACKUP_ACTIONS:
            buckets["backup"].append(a)
            placed = True
        if a in EXPORT_ACTIONS:
            buckets["export"].append(a)
            placed = True
        if a in GLOBAL_TABLE_ACTIONS:
            buckets["global-table"].append(a)
            placed = True
        if not placed:
            # Unknown → fall back to table scope (safer than "*")
            buckets["table"].append(a)

    out: list[dict[str, Any]] = []

    def _emit(actions: list[str], resources: list[str], sid_suffix: str) -> None:
        if not actions or not resources:
            return
        new_stmt: dict[str, Any] = {"Effect": effect}
        if sid:
            new_stmt["Sid"] = f"{sid}{sid_suffix}"
        elif sid_suffix:
            new_stmt["Sid"] = sid_suffix.lstrip("_")
        new_stmt["Action"] = sorted(set(actions))
        new_stmt["Resource"] = resources if len(resources) > 1 else resources[0]
        if condition:
            new_stmt["Condition"] = copy.deepcopy(condition)
        out.append(new_stmt)

    if tables:
        table_arns = [_table_arn(t["partition"], t["region"], t["account"], t["table"]) for t in tables]

        _emit(buckets["table"], table_arns, "_Table")

        if buckets["index"]:
            index_arns = []
            for tarn in table_arns:
                for idx in index_names:
                    index_arns.append(_derived_arn(tarn, f"/index/{idx}"))
            _emit(buckets["index"], index_arns, "_Index")

        if buckets["stream"]:
            _emit(buckets["stream"], [_derived_arn(a, "/stream/*") for a in table_arns], "_Stream")
        if buckets["backup"]:
            _emit(buckets["backup"], [_derived_arn(a, "/backup/*") for a in table_arns], "_Backup")
        if buckets["export"]:
            _emit(buckets["export"], [_derived_arn(a, "/export/*") for a in table_arns], "_Export")
        if buckets["global-table"]:
            gt_arns = [
                f"arn:{t['partition']}:dynamodb::{t['account']}:global-table/{t['table']}"
                for t in tables
            ]
            _emit(buckets["global-table"], gt_arns, "_GlobalTable")
    else:
        # No table list — keep original resources for table-scoped buckets.
        original = [r for r in raw_resources if isinstance(r, str)]
        for bucket_name in ("table", "index", "stream", "backup", "export", "global-table"):
            _emit(buckets[bucket_name], original or ["*"], f"_{bucket_name.replace('-', '').title()}")

    if buckets["wildcard-only"]:
        _emit(buckets["wildcard-only"], ["*"], "_ServiceLevel")

    if not out:
        # Nothing matched — return the original statement unchanged so we never silently drop it.
        return [copy.deepcopy(stmt)]

    return out
