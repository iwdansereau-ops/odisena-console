"""
Diff two policies at the (action, resource) level.

Produces:
  - removed:   (action, resource) pairs the original allowed but the refactored does not
  - added:     pairs the refactored adds
  - retained:  pairs present in both
  - narrowed:  actions where the original had "*" resource and the refactored has specific ARNs
"""
from __future__ import annotations

import fnmatch
from typing import Any

from .actions import all_known_actions


def _as_list(v: Any) -> list[Any]:
    if v is None:
        return []
    if isinstance(v, list):
        return v
    return [v]


def _expand_actions(actions: list[str]) -> set[str]:
    known = all_known_actions()
    out: set[str] = set()
    for a in actions:
        if not isinstance(a, str):
            continue
        if a == "*" or a == "dynamodb:*":
            out.update(known)
        elif "*" in a or "?" in a:
            out.update({k for k in known if fnmatch.fnmatchcase(k, a)})
        else:
            out.add(a)
    return out


def _allow_pairs(policy: dict[str, Any]) -> dict[str, set[str]]:
    """action -> set(resources) across all Allow statements."""
    out: dict[str, set[str]] = {}
    for stmt in _as_list(policy.get("Statement", [])):
        if not isinstance(stmt, dict) or stmt.get("Effect") != "Allow":
            continue
        actions = _expand_actions(_as_list(stmt.get("Action")))
        resources = [r for r in _as_list(stmt.get("Resource")) if isinstance(r, str)]
        if not resources:
            resources = ["*"]
        for a in actions:
            out.setdefault(a, set()).update(resources)
    return out


def diff_policies(original: dict[str, Any], refactored: dict[str, Any]) -> dict[str, Any]:
    before = _allow_pairs(original)
    after = _allow_pairs(refactored)

    all_actions = sorted(set(before) | set(after))

    removed: list[tuple[str, str]] = []
    added: list[tuple[str, str]] = []
    retained: list[tuple[str, str]] = []
    narrowed: list[dict[str, Any]] = []

    for a in all_actions:
        b = before.get(a, set())
        f = after.get(a, set())
        for r in b - f:
            removed.append((a, r))
        for r in f - b:
            added.append((a, r))
        for r in b & f:
            retained.append((a, r))
        if "*" in b and f and "*" not in f:
            narrowed.append({"action": a, "from": "*", "to": sorted(f)})

    return {
        "removed": sorted(removed),
        "added": sorted(added),
        "retained": sorted(retained),
        "narrowed": narrowed,
        "summary": {
            "actions_before": len(before),
            "actions_after": len(after),
            "actions_narrowed_off_star": len(narrowed),
            "pairs_removed": len(removed),
            "pairs_added": len(added),
        },
    }


def render_diff_markdown(d: dict[str, Any]) -> str:
    lines: list[str] = ["## Diff: original vs refactored", ""]
    s = d["summary"]
    lines.append(
        f"- Actions in original: **{s['actions_before']}**, "
        f"in refactored: **{s['actions_after']}**"
    )
    lines.append(f"- Actions narrowed off `\"*\"`: **{s['actions_narrowed_off_star']}**")
    lines.append(f"- (action, resource) pairs removed: **{s['pairs_removed']}**")
    lines.append(f"- (action, resource) pairs added: **{s['pairs_added']}**")
    lines.append("")

    if d["narrowed"]:
        lines.append("### Narrowed off `\"*\"`")
        lines.append("")
        lines.append("| Action | From | To |")
        lines.append("|--------|------|-----|")
        for row in d["narrowed"]:
            to_txt = "<br>".join(f"`{r}`" for r in row["to"])
            lines.append(f"| `{row['action']}` | `*` | {to_txt} |")
        lines.append("")

    if d["removed"]:
        lines.append("### Removed (action, resource) pairs")
        lines.append("")
        lines.append("| Action | Resource |")
        lines.append("|--------|----------|")
        for a, r in d["removed"][:200]:
            lines.append(f"| `{a}` | `{r}` |")
        if len(d["removed"]) > 200:
            lines.append(f"| … | _{len(d['removed']) - 200} more rows omitted_ |")
        lines.append("")
    return "\n".join(lines)
