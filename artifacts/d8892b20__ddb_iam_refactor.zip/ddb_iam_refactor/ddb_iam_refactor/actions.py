"""
Catalog of DynamoDB IAM actions grouped by access level and resource type.

Sources:
- AWS Service Authorization Reference for Amazon DynamoDB
  https://docs.aws.amazon.com/service-authorization/latest/reference/list_amazondynamodb.html
"""
from __future__ import annotations

# Actions that target a specific TABLE resource (arn:aws:dynamodb:REGION:ACCT:table/NAME)
TABLE_ACTIONS = {
    # Read
    "dynamodb:BatchGetItem",
    "dynamodb:ConditionCheckItem",
    "dynamodb:DescribeContinuousBackups",
    "dynamodb:DescribeContributorInsights",
    "dynamodb:DescribeKinesisStreamingDestination",
    "dynamodb:DescribeTable",
    "dynamodb:DescribeTableReplicaAutoScaling",
    "dynamodb:DescribeTimeToLive",
    "dynamodb:GetItem",
    "dynamodb:GetRecords",
    "dynamodb:ListTagsOfResource",
    "dynamodb:PartiQLSelect",
    "dynamodb:Query",
    "dynamodb:Scan",
    # Write
    "dynamodb:BatchWriteItem",
    "dynamodb:DeleteItem",
    "dynamodb:DisableKinesisStreamingDestination",
    "dynamodb:EnableKinesisStreamingDestination",
    "dynamodb:PartiQLDelete",
    "dynamodb:PartiQLInsert",
    "dynamodb:PartiQLUpdate",
    "dynamodb:PutItem",
    "dynamodb:RestoreTableFromAwsBackup",
    "dynamodb:RestoreTableFromBackup",
    "dynamodb:UpdateContinuousBackups",
    "dynamodb:UpdateContributorInsights",
    "dynamodb:UpdateItem",
    "dynamodb:UpdateKinesisStreamingDestination",
    "dynamodb:UpdateTimeToLive",
    # Tagging / permissions management
    "dynamodb:TagResource",
    "dynamodb:UntagResource",
    "dynamodb:UpdateTable",
    "dynamodb:UpdateTableReplicaAutoScaling",
    "dynamodb:DeleteTable",
    "dynamodb:CreateTableReplica",
    "dynamodb:DeleteTableReplica",
    "dynamodb:ExportTableToPointInTime",
    "dynamodb:ImportTable",
}

# Actions that target an INDEX resource (arn:aws:dynamodb:...:table/NAME/index/INDEX)
INDEX_ACTIONS = {
    "dynamodb:Query",
    "dynamodb:Scan",
}

# Actions that target a STREAM (arn:aws:dynamodb:...:table/NAME/stream/LABEL)
STREAM_ACTIONS = {
    "dynamodb:DescribeStream",
    "dynamodb:GetRecords",
    "dynamodb:GetShardIterator",
    "dynamodb:ListStreams",
}

# Actions that target a BACKUP (arn:aws:dynamodb:...:table/NAME/backup/ID)
BACKUP_ACTIONS = {
    "dynamodb:DeleteBackup",
    "dynamodb:DescribeBackup",
    "dynamodb:CreateBackup",
    "dynamodb:RestoreTableFromBackup",
}

# Actions that target an EXPORT (arn:aws:dynamodb:...:table/NAME/export/ID)
EXPORT_ACTIONS = {
    "dynamodb:DescribeExport",
    "dynamodb:ExportTableToPointInTime",
}

# Actions that target a GLOBAL TABLE (arn:aws:dynamodb::ACCT:global-table/NAME)
GLOBAL_TABLE_ACTIONS = {
    "dynamodb:CreateGlobalTable",
    "dynamodb:DescribeGlobalTable",
    "dynamodb:DescribeGlobalTableSettings",
    "dynamodb:UpdateGlobalTable",
    "dynamodb:UpdateGlobalTableSettings",
}

# Actions that ONLY work with resource "*" (service-level; cannot be scoped to a table)
WILDCARD_ONLY_ACTIONS = {
    "dynamodb:ListBackups",
    "dynamodb:ListContributorInsights",
    "dynamodb:ListExports",
    "dynamodb:ListGlobalTables",
    "dynamodb:ListImports",
    "dynamodb:ListStreams",
    "dynamodb:ListTables",
    "dynamodb:DescribeEndpoints",
    "dynamodb:DescribeLimits",
    "dynamodb:DescribeReservedCapacity",
    "dynamodb:DescribeReservedCapacityOfferings",
    "dynamodb:PurchaseReservedCapacityOfferings",
    "dynamodb:CreateTable",  # cannot know ARN before creation
}

# High-risk write/destructive actions — flagged if paired with wildcard resources
DESTRUCTIVE_ACTIONS = {
    "dynamodb:DeleteTable",
    "dynamodb:DeleteBackup",
    "dynamodb:DeleteItem",
    "dynamodb:BatchWriteItem",
    "dynamodb:PartiQLDelete",
    "dynamodb:UpdateTable",
    "dynamodb:RestoreTableFromBackup",
    "dynamodb:RestoreTableFromAwsBackup",
    "dynamodb:PurchaseReservedCapacityOfferings",
}

READ_ACTIONS = {
    "dynamodb:BatchGetItem",
    "dynamodb:ConditionCheckItem",
    "dynamodb:DescribeBackup",
    "dynamodb:DescribeContinuousBackups",
    "dynamodb:DescribeContributorInsights",
    "dynamodb:DescribeExport",
    "dynamodb:DescribeGlobalTable",
    "dynamodb:DescribeGlobalTableSettings",
    "dynamodb:DescribeKinesisStreamingDestination",
    "dynamodb:DescribeLimits",
    "dynamodb:DescribeReservedCapacity",
    "dynamodb:DescribeReservedCapacityOfferings",
    "dynamodb:DescribeStream",
    "dynamodb:DescribeTable",
    "dynamodb:DescribeTableReplicaAutoScaling",
    "dynamodb:DescribeTimeToLive",
    "dynamodb:GetItem",
    "dynamodb:GetRecords",
    "dynamodb:GetShardIterator",
    "dynamodb:ListBackups",
    "dynamodb:ListContributorInsights",
    "dynamodb:ListExports",
    "dynamodb:ListGlobalTables",
    "dynamodb:ListImports",
    "dynamodb:ListStreams",
    "dynamodb:ListTables",
    "dynamodb:ListTagsOfResource",
    "dynamodb:PartiQLSelect",
    "dynamodb:Query",
    "dynamodb:Scan",
}


def all_known_actions() -> set[str]:
    return (
        TABLE_ACTIONS
        | INDEX_ACTIONS
        | STREAM_ACTIONS
        | BACKUP_ACTIONS
        | EXPORT_ACTIONS
        | GLOBAL_TABLE_ACTIONS
        | WILDCARD_ONLY_ACTIONS
    )


def resource_types_for_action(action: str) -> list[str]:
    """Return the resource-type kinds a given DynamoDB action supports."""
    kinds: list[str] = []
    if action in TABLE_ACTIONS:
        kinds.append("table")
    if action in INDEX_ACTIONS:
        kinds.append("index")
    if action in STREAM_ACTIONS:
        kinds.append("stream")
    if action in BACKUP_ACTIONS:
        kinds.append("backup")
    if action in EXPORT_ACTIONS:
        kinds.append("export")
    if action in GLOBAL_TABLE_ACTIONS:
        kinds.append("global-table")
    if action in WILDCARD_ONLY_ACTIONS:
        kinds.append("*")
    return kinds or ["unknown"]
