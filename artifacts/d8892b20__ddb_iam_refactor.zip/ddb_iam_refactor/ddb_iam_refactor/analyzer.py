"""
Static risk analyzer for DynamoDB IAM policies.

Detects excessive wildcards, dangerous action/resource combinations,
NotAction/NotResource pitfalls, missing Version, non-DynamoDB actions, etc.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from .actions import (
    DESTRUCTIVE_ACTIONS,
    WILDCARD_ONLY_ACTIONS,
    all_known_actions,
)

SEVERITY_ORDER = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


@dataclass
class Finding:
    severity: str  # info | low | medium | high | critical
    code: str
    message: str
    statement_index: int | None = None
    statement_sid: str | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "severity": self.severity,
            "code": self.code,
            "message": self.message,
            "statement_index": self.statement_index,
            "statement_sid": self.statement_sid,
            "details": self.details,
        }


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _is_dynamodb_action(action: str) -> bool:
    return action == "*" or action.lower().startswith("dynamodb:") or action.startswith("dynamodb:")


def analyze_policy(policy: dict[str, Any]) -> list[Finding]:
    findings: list[Finding] = []

    # Top-level checks
    if "Version" not in policy:
        findings.append(
            Finding(
                "low",
                "MISSING_VERSION",
                "Policy has no Version. AWS recommends \"Version\": \"2012-10-17\".",
            )
        )
    elif policy.get("Version") != "2012-10-17":
        findings.append(
            Finding(
                "low",
                "OLD_VERSION",
                f"Policy Version is {policy.get('Version')!r}; use \"2012-10-17\" for full IAM feature support.",
            )
        )

    if "Statement" not in policy:
        findings.append(
            Finding("critical", "NO_STATEMENT", "Policy has no Statement block.")
        )
        return findings

    statements = _as_list(policy["Statement"])
    for idx, stmt in enumerate(statements):
        findings.extend(_analyze_statement(stmt, idx))

    return findings


def _analyze_statement(stmt: dict[str, Any], idx: int) -> list[Finding]:
    out: list[Finding] = []
    sid = stmt.get("Sid")

    effect = stmt.get("Effect")
    if effect not in ("Allow", "Deny"):
        out.append(
            Finding(
                "high",
                "BAD_EFFECT",
                f"Statement has invalid Effect {effect!r}; must be 'Allow' or 'Deny'.",
                idx,
                sid,
            )
        )

    if "NotAction" in stmt:
        out.append(
            Finding(
                "high",
                "NOT_ACTION",
                "Uses NotAction. This is easy to get wrong and typically grants more than intended. Prefer explicit Action lists.",
                idx,
                sid,
            )
        )
    if "NotResource" in stmt:
        out.append(
            Finding(
                "high",
                "NOT_RESOURCE",
                "Uses NotResource. Prefer explicit Resource ARNs.",
                idx,
                sid,
            )
        )

    actions = _as_list(stmt.get("Action")) + _as_list(stmt.get("NotAction"))
    resources = _as_list(stmt.get("Resource")) + _as_list(stmt.get("NotResource"))

    if not actions:
        out.append(
            Finding("high", "NO_ACTION", "Statement has no Action.", idx, sid)
        )
    if not resources and effect == "Allow":
        out.append(
            Finding(
                "high",
                "NO_RESOURCE",
                "Allow statement has no Resource.",
                idx,
                sid,
            )
        )

    # Action-level checks
    has_star_action = "*" in actions
    has_ddb_wildcard = "dynamodb:*" in actions
    non_ddb_actions = [a for a in actions if isinstance(a, str) and not _is_dynamodb_action(a) and a != "*"]
    ddb_wildcard_verbs = [a for a in actions if isinstance(a, str) and a.startswith("dynamodb:") and "*" in a and a != "dynamodb:*"]

    if has_star_action and effect == "Allow":
        out.append(
            Finding(
                "critical",
                "ACTION_STAR",
                "Action \"*\" grants ALL AWS actions across ALL services. Never use this in an Allow statement.",
                idx,
                sid,
            )
        )
    if has_ddb_wildcard and effect == "Allow":
        out.append(
            Finding(
                "high",
                "ACTION_DDB_STAR",
                "Action \"dynamodb:*\" grants every DynamoDB permission including DeleteTable and DeleteBackup. Enumerate the specific actions the workload needs.",
                idx,
                sid,
            )
        )
    if non_ddb_actions:
        out.append(
            Finding(
                "medium",
                "NON_DDB_ACTIONS",
                f"Statement mixes non-DynamoDB actions: {non_ddb_actions}. Split into a separate statement or policy for clarity.",
                idx,
                sid,
                details={"non_ddb_actions": non_ddb_actions},
            )
        )
    for a in ddb_wildcard_verbs:
        out.append(
            Finding(
                "medium",
                "ACTION_VERB_WILDCARD",
                f"Wildcard verb {a!r} matches multiple actions. Prefer explicit action names.",
                idx,
                sid,
                details={"action": a},
            )
        )

    # Unknown DDB actions (typos)
    known = all_known_actions()
    for a in actions:
        if not isinstance(a, str):
            continue
        if a.startswith("dynamodb:") and "*" not in a and a not in known:
            out.append(
                Finding(
                    "medium",
                    "UNKNOWN_ACTION",
                    f"Action {a!r} is not a recognized DynamoDB action (possible typo).",
                    idx,
                    sid,
                    details={"action": a},
                )
            )

    # Resource-level checks
    has_star_resource = "*" in resources
    if has_star_resource and effect == "Allow":
        # If every action is wildcard-only, "*" is required and OK.
        concrete_actions = [
            a for a in actions
            if isinstance(a, str) and a not in ("*", "dynamodb:*") and "*" not in a
        ]
        needs_wildcard_only = concrete_actions and all(a in WILDCARD_ONLY_ACTIONS for a in concrete_actions)
        if needs_wildcard_only and not any(
            a in DESTRUCTIVE_ACTIONS for a in concrete_actions
        ):
            out.append(
                Finding(
                    "info",
                    "RESOURCE_STAR_REQUIRED",
                    "Resource \"*\" is required for these service-level list/describe actions and is acceptable here.",
                    idx,
                    sid,
                )
            )
        else:
            out.append(
                Finding(
                    "high",
                    "RESOURCE_STAR",
                    "Resource \"*\" grants the listed actions across every DynamoDB resource in the account. Replace with specific table/index/stream ARNs.",
                    idx,
                    sid,
                )
            )

    # Destructive + wildcard combo → critical
    destructive_in_stmt = [a for a in actions if a in DESTRUCTIVE_ACTIONS]
    if destructive_in_stmt and has_star_resource and effect == "Allow":
        out.append(
            Finding(
                "critical",
                "DESTRUCTIVE_ON_STAR",
                f"Destructive actions {destructive_in_stmt} allowed on Resource \"*\". This lets the principal delete or overwrite ANY table/backup in the account.",
                idx,
                sid,
                details={"destructive_actions": destructive_in_stmt},
            )
        )

    # Malformed ARNs
    for r in resources:
        if not isinstance(r, str) or r == "*":
            continue
        if not r.startswith("arn:"):
            out.append(
                Finding(
                    "high",
                    "BAD_ARN",
                    f"Resource {r!r} does not look like an ARN.",
                    idx,
                    sid,
                    details={"resource": r},
                )
            )
            continue
        if not re.match(
            r"^arn:(aws|aws-us-gov|aws-cn):dynamodb:[^:]*:[^:]*:(table/[^/]+.*|global-table/.+)$",
            r,
        ):
            out.append(
                Finding(
                    "medium",
                    "SUSPICIOUS_ARN",
                    f"Resource {r!r} is not a well-formed DynamoDB ARN.",
                    idx,
                    sid,
                    details={"resource": r},
                )
            )

    # Missing Condition on destructive operations
    if effect == "Allow" and destructive_in_stmt and "Condition" not in stmt:
        out.append(
            Finding(
                "low",
                "NO_CONDITION_ON_DESTRUCTIVE",
                "Destructive actions allowed without any Condition (e.g., aws:SourceIp, aws:MultiFactorAuthPresent). Consider hardening.",
                idx,
                sid,
                details={"destructive_actions": destructive_in_stmt},
            )
        )

    return out


def worst_severity(findings: list[Finding]) -> str:
    if not findings:
        return "info"
    return max(findings, key=lambda f: SEVERITY_ORDER[f.severity]).severity
