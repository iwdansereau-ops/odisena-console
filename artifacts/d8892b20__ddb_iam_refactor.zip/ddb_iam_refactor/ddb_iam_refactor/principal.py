"""
Principal-block analysis for resource-based policies (e.g., DynamoDB resource
policies, added by AWS in 2024). Identity policies must NOT contain Principal;
resource policies MUST. This module enforces both.
"""
from __future__ import annotations

from typing import Any

from .analyzer import Finding


def _as_list(v: Any) -> list[Any]:
    if v is None:
        return []
    if isinstance(v, list):
        return v
    return [v]


def analyze_principals(
    policy: dict[str, Any],
    policy_type: str,
) -> list[Finding]:
    """
    policy_type: "IDENTITY_POLICY" | "RESOURCE_POLICY"
    """
    out: list[Finding] = []
    for idx, stmt in enumerate(_as_list(policy.get("Statement", []))):
        if not isinstance(stmt, dict):
            continue
        sid = stmt.get("Sid")
        has_principal = "Principal" in stmt or "NotPrincipal" in stmt

        if policy_type == "IDENTITY_POLICY" and has_principal:
            out.append(
                Finding(
                    "high",
                    "PRINCIPAL_IN_IDENTITY_POLICY",
                    "Principal/NotPrincipal is not allowed in identity policies. Remove it, or set --policy-type RESOURCE_POLICY.",
                    idx,
                    sid,
                )
            )
            continue

        if policy_type == "RESOURCE_POLICY":
            if not has_principal:
                out.append(
                    Finding(
                        "high",
                        "MISSING_PRINCIPAL",
                        "Resource policy statement is missing Principal.",
                        idx,
                        sid,
                    )
                )
                continue

            principal = stmt.get("Principal")
            # "*" or {"AWS": "*"} → public
            is_star = principal == "*" or (
                isinstance(principal, dict)
                and any(
                    v == "*" or (isinstance(v, list) and "*" in v)
                    for v in principal.values()
                )
            )
            if is_star and stmt.get("Effect") == "Allow":
                # Public unless a Condition constrains the caller
                cond = stmt.get("Condition") or {}
                constrained = any(
                    k in cond
                    for k in (
                        "StringEquals",
                        "StringLike",
                        "ArnEquals",
                        "ArnLike",
                        "IpAddress",
                    )
                ) and any(
                    "aws:PrincipalOrgID" in vals
                    or "aws:PrincipalArn" in vals
                    or "aws:PrincipalAccount" in vals
                    or "aws:SourceArn" in vals
                    or "aws:SourceAccount" in vals
                    or "aws:SourceIp" in vals
                    for vals in cond.values()
                    if isinstance(vals, dict)
                )
                sev = "critical" if not constrained else "medium"
                msg = (
                    "Resource policy grants access to Principal \"*\" without any "
                    "aws:PrincipalOrgID / aws:PrincipalArn / aws:SourceAccount condition — "
                    "this is effectively public."
                    if not constrained
                    else "Resource policy uses Principal \"*\" but is constrained by a Condition. Verify the condition is correct."
                )
                out.append(
                    Finding(sev, "PUBLIC_PRINCIPAL", msg, idx, sid)
                )

            if "NotPrincipal" in stmt and stmt.get("Effect") == "Allow":
                out.append(
                    Finding(
                        "high",
                        "NOT_PRINCIPAL_ALLOW",
                        "NotPrincipal on Allow is extremely error-prone. Prefer an explicit Principal list.",
                        idx,
                        sid,
                    )
                )
    return out
