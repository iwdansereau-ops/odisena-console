"""
Policy validation.

Primary path: AWS IAM Access Analyzer ValidatePolicy API (via boto3) or the
`aws accessanalyzer validate-policy` CLI when the SDK is unavailable.

Fallback path: offline structural / JSON / IAM-grammar checks so the tool is
usable without AWS credentials.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Any

from .analyzer import analyze_policy


@dataclass
class ValidationFinding:
    source: str  # "access-analyzer" | "offline"
    severity: str  # ERROR | SECURITY_WARNING | SUGGESTION | WARNING | INFO
    code: str
    message: str
    location: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__


@dataclass
class ValidationResult:
    ok: bool
    used: str  # "boto3" | "aws-cli" | "offline"
    findings: list[ValidationFinding] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "used": self.used,
            "findings": [f.to_dict() for f in self.findings],
        }


def _validate_offline(policy: dict[str, Any]) -> ValidationResult:
    """Structural + syntactic checks that don't need AWS."""
    findings: list[ValidationFinding] = []
    ok = True

    # JSON round-trip
    try:
        json.dumps(policy)
    except (TypeError, ValueError) as e:
        ok = False
        findings.append(
            ValidationFinding("offline", "ERROR", "INVALID_JSON", f"Policy is not JSON-serializable: {e}")
        )
        return ValidationResult(ok, "offline", findings)

    if not isinstance(policy, dict):
        return ValidationResult(
            False,
            "offline",
            [ValidationFinding("offline", "ERROR", "NOT_OBJECT", "Policy must be a JSON object.")],
        )

    if policy.get("Version") not in (None, "2012-10-17", "2008-10-17"):
        findings.append(
            ValidationFinding(
                "offline",
                "WARNING",
                "BAD_VERSION",
                f"Version {policy.get('Version')!r} is not a recognized IAM policy version.",
            )
        )

    statements = policy.get("Statement")
    if statements is None:
        return ValidationResult(
            False,
            "offline",
            [ValidationFinding("offline", "ERROR", "MISSING_STATEMENT", "Policy has no Statement.")],
        )
    if not isinstance(statements, list):
        statements = [statements]

    for i, stmt in enumerate(statements):
        if not isinstance(stmt, dict):
            ok = False
            findings.append(
                ValidationFinding(
                    "offline",
                    "ERROR",
                    "BAD_STATEMENT",
                    f"Statement[{i}] is not an object.",
                    {"index": i},
                )
            )
            continue
        if stmt.get("Effect") not in ("Allow", "Deny"):
            ok = False
            findings.append(
                ValidationFinding(
                    "offline",
                    "ERROR",
                    "BAD_EFFECT",
                    f"Statement[{i}] Effect must be 'Allow' or 'Deny'.",
                    {"index": i},
                )
            )
        if "Action" not in stmt and "NotAction" not in stmt:
            ok = False
            findings.append(
                ValidationFinding(
                    "offline",
                    "ERROR",
                    "NO_ACTION",
                    f"Statement[{i}] must contain Action or NotAction.",
                    {"index": i},
                )
            )
        if "Resource" not in stmt and "NotResource" not in stmt and stmt.get("Effect") == "Allow":
            ok = False
            findings.append(
                ValidationFinding(
                    "offline",
                    "ERROR",
                    "NO_RESOURCE",
                    f"Statement[{i}] must contain Resource or NotResource.",
                    {"index": i},
                )
            )

    # Layer in security findings from the analyzer, mapped to Access Analyzer severities.
    sev_map = {
        "critical": "SECURITY_WARNING",
        "high": "SECURITY_WARNING",
        "medium": "SUGGESTION",
        "low": "SUGGESTION",
        "info": "INFO",
    }
    for f in analyze_policy(policy):
        findings.append(
            ValidationFinding(
                "offline",
                sev_map.get(f.severity, "INFO"),
                f.code,
                f.message,
                {"statement_index": f.statement_index, "sid": f.statement_sid, **f.details},
            )
        )

    return ValidationResult(ok, "offline", findings)


def _validate_boto3(policy: dict[str, Any], region: str | None, policy_type: str = "IDENTITY_POLICY") -> ValidationResult | None:
    try:
        import boto3  # type: ignore
        from botocore.exceptions import BotoCoreError, ClientError  # type: ignore
    except ImportError:
        return None
    try:
        client = boto3.client("accessanalyzer", region_name=region) if region else boto3.client("accessanalyzer")
        resp = client.validate_policy(
            policyDocument=json.dumps(policy),
            policyType=policy_type,
        )
    except (BotoCoreError, ClientError) as e:
        return ValidationResult(
            False,
            "boto3",
            [ValidationFinding("access-analyzer", "ERROR", "AWS_CALL_FAILED", str(e))],
        )

    findings: list[ValidationFinding] = []
    for r in resp.get("findings", []):
        findings.append(
            ValidationFinding(
                "access-analyzer",
                r.get("findingType", "INFO"),
                r.get("issueCode", ""),
                r.get("findingDetails", ""),
                {"locations": r.get("locations", []), "learnMoreLink": r.get("learnMoreLink")},
            )
        )
    ok = not any(f.severity == "ERROR" for f in findings)
    return ValidationResult(ok, "boto3", findings)


def _validate_cli(policy: dict[str, Any], region: str | None, policy_type: str = "IDENTITY_POLICY") -> ValidationResult | None:
    if not shutil.which("aws"):
        return None
    cmd = [
        "aws", "accessanalyzer", "validate-policy",
        "--policy-type", policy_type,
        "--policy-document", json.dumps(policy),
        "--output", "json",
    ]
    if region:
        cmd.extend(["--region", region])
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except (subprocess.SubprocessError, OSError) as e:
        return ValidationResult(
            False,
            "aws-cli",
            [ValidationFinding("access-analyzer", "ERROR", "AWS_CLI_FAILED", str(e))],
        )
    if proc.returncode != 0:
        return ValidationResult(
            False,
            "aws-cli",
            [ValidationFinding("access-analyzer", "ERROR", "AWS_CLI_ERROR", proc.stderr.strip() or proc.stdout.strip())],
        )
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError as e:
        return ValidationResult(
            False,
            "aws-cli",
            [ValidationFinding("access-analyzer", "ERROR", "AWS_CLI_BAD_JSON", str(e))],
        )
    findings = []
    for r in data.get("findings", []):
        findings.append(
            ValidationFinding(
                "access-analyzer",
                r.get("findingType", "INFO"),
                r.get("issueCode", ""),
                r.get("findingDetails", ""),
                {"locations": r.get("locations", []), "learnMoreLink": r.get("learnMoreLink")},
            )
        )
    ok = not any(f.severity == "ERROR" for f in findings)
    return ValidationResult(ok, "aws-cli", findings)


def validate_policy(
    policy: dict[str, Any],
    prefer: str = "auto",
    region: str | None = None,
    policy_type: str = "IDENTITY_POLICY",
) -> ValidationResult:
    """
    Run offline + (optionally) AWS Access Analyzer validation.

    prefer:      "auto" | "boto3" | "cli" | "offline"
    policy_type: "IDENTITY_POLICY" | "RESOURCE_POLICY"
    """
    offline = _validate_offline(policy)

    if prefer == "offline":
        return offline

    aws: ValidationResult | None = None
    if prefer in ("auto", "boto3"):
        aws = _validate_boto3(policy, region, policy_type)
    if aws is None and prefer in ("auto", "cli"):
        aws = _validate_cli(policy, region, policy_type)

    if aws is None:
        return offline

    # Merge: keep offline findings that AA doesn't emit (e.g., our own security codes).
    merged_findings = list(aws.findings)
    existing_codes = {(f.source, f.code) for f in merged_findings}
    for f in offline.findings:
        if f.source == "offline" and (f.source, f.code) not in existing_codes:
            merged_findings.append(f)

    return ValidationResult(aws.ok and offline.ok, aws.used, merged_findings)
