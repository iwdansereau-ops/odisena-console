"""
Emit findings as SARIF 2.1.0 for GitHub code scanning / CI dashboards.
Spec: https://docs.oasis-open.org/sarif/sarif/v2.1.0/os/sarif-v2.1.0-os.html
"""
from __future__ import annotations

from typing import Any

from .analyzer import Finding
from . import __version__


_SEV_TO_SARIF = {
    "critical": "error",
    "high": "error",
    "medium": "warning",
    "low": "note",
    "info": "note",
}

_RULES = {
    "ACTION_STAR": ("Action wildcard \"*\"", "Grants all AWS actions."),
    "ACTION_DDB_STAR": ("dynamodb:* wildcard", "Grants every DynamoDB permission."),
    "ACTION_VERB_WILDCARD": ("Verb-level action wildcard", "Matches multiple actions."),
    "RESOURCE_STAR": ("Resource wildcard \"*\"", "Grants actions on every DynamoDB resource."),
    "RESOURCE_STAR_REQUIRED": ("Resource \"*\" is required", "Service-level actions require Resource \"*\"."),
    "DESTRUCTIVE_ON_STAR": ("Destructive on \"*\"", "Destructive DynamoDB action on Resource \"*\"."),
    "NON_DDB_ACTIONS": ("Non-DynamoDB action in DDB policy", "Split into a separate policy or statement."),
    "UNKNOWN_ACTION": ("Unknown DynamoDB action", "Likely a typo — not in service authorization reference."),
    "NOT_ACTION": ("Uses NotAction", "Grants more than intended in practice."),
    "NOT_RESOURCE": ("Uses NotResource", "Prefer explicit Resource ARNs."),
    "NO_ACTION": ("Missing Action", "Statement has no Action."),
    "NO_RESOURCE": ("Missing Resource", "Allow statement has no Resource."),
    "MISSING_VERSION": ("Missing Version", "Use \"2012-10-17\"."),
    "OLD_VERSION": ("Old Version", "Use \"2012-10-17\"."),
    "BAD_EFFECT": ("Invalid Effect", "Must be Allow or Deny."),
    "BAD_ARN": ("Malformed ARN", "Resource is not an ARN."),
    "SUSPICIOUS_ARN": ("Suspicious ARN", "Not a well-formed DynamoDB ARN."),
    "NO_CONDITION_ON_DESTRUCTIVE": ("No Condition on destructive action", "Consider adding a Condition."),
    "PRINCIPAL_IN_IDENTITY_POLICY": ("Principal in identity policy", "Move to a resource policy."),
    "MISSING_PRINCIPAL": ("Resource policy missing Principal", "Add Principal."),
    "PUBLIC_PRINCIPAL": ("Public Principal", "Principal \"*\" without a Condition is effectively public."),
    "NOT_PRINCIPAL_ALLOW": ("NotPrincipal on Allow", "Prefer an explicit Principal list."),
    "NO_STATEMENT": ("Missing Statement", "Policy has no Statement."),
}


def to_sarif(findings: list[Finding], source_path: str) -> dict[str, Any]:
    rules_used: dict[str, dict[str, Any]] = {}
    results: list[dict[str, Any]] = []

    for f in findings:
        rule_id = f.code
        if rule_id not in rules_used:
            name, desc = _RULES.get(rule_id, (rule_id, f.message))
            rules_used[rule_id] = {
                "id": rule_id,
                "name": name,
                "shortDescription": {"text": name},
                "fullDescription": {"text": desc},
                "defaultConfiguration": {"level": _SEV_TO_SARIF.get(f.severity, "note")},
            }
        results.append(
            {
                "ruleId": rule_id,
                "level": _SEV_TO_SARIF.get(f.severity, "note"),
                "message": {"text": f.message},
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {"uri": source_path},
                            "region": {
                                "startLine": 1,
                                "properties": {
                                    "statementIndex": f.statement_index,
                                    "sid": f.statement_sid,
                                },
                            },
                        }
                    }
                ],
                "properties": {"severity": f.severity, **f.details},
            }
        )

    return {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "ddb-iam-refactor",
                        "version": __version__,
                        "informationUri": "https://docs.aws.amazon.com/service-authorization/latest/reference/list_amazondynamodb.html",
                        "rules": list(rules_used.values()),
                    }
                },
                "results": results,
            }
        ],
    }
