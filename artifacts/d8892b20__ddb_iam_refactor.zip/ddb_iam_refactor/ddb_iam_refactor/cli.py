"""Command-line entry point."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .analyzer import analyze_policy
from .diff import diff_policies
from .principal import analyze_principals
from .refactor import refactor_policy
from .report import render_markdown
from .sarif import to_sarif
from .validator import validate_policy


def _read_policy(path: str) -> dict[str, Any]:
    text = sys.stdin.read() if path == "-" else Path(path).read_text(encoding="utf-8")
    return json.loads(text)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ddb-iam-refactor",
        description="Analyze, refactor, and validate DynamoDB IAM policies.",
    )
    p.add_argument("policy", help="Path to input policy JSON, a directory (with --batch), or '-' for stdin")
    p.add_argument(
        "--policy-type",
        choices=["IDENTITY_POLICY", "RESOURCE_POLICY"],
        default="IDENTITY_POLICY",
        help="How to treat the policy. RESOURCE_POLICY enables Principal checks (default: IDENTITY_POLICY)",
    )
    p.add_argument("--table", action="append", default=[], help="Target table (name or ARN). Repeatable.")
    p.add_argument("--index", action="append", default=[], help="Index name to include. Repeatable.")
    p.add_argument("--region", default="*", help="Region for synthesized ARNs (default: '*')")
    p.add_argument("--account", default="*", help="Account for synthesized ARNs (default: '*')")
    p.add_argument("--partition", default="aws", help="Partition for synthesized ARNs (default: aws)")
    p.add_argument(
        "--validate",
        choices=["auto", "boto3", "cli", "offline"],
        default="auto",
        help="Validation backend (default: auto)",
    )
    p.add_argument("--aws-region", default=None, help="Region for Access Analyzer calls")
    p.add_argument(
        "--output",
        choices=["report", "policy", "json", "sarif"],
        default="report",
        help="report=Markdown; policy=refactored JSON; json=combined; sarif=SARIF 2.1.0 for CI",
    )
    p.add_argument("--out", default="-", help="Output file (default: stdout)")
    p.add_argument("--no-diff", action="store_true", help="Skip the diff section in the Markdown report")
    p.add_argument(
        "--fail-on",
        choices=["never", "medium", "high", "critical"],
        default="never",
        help="Exit non-zero if any original-policy finding meets/exceeds this severity",
    )
    p.add_argument(
        "--batch",
        action="store_true",
        help="Treat 'policy' as a directory. Every *.json is analyzed and written to --out (a directory).",
    )
    return p


def _analyze_one(policy: dict[str, Any], policy_type: str) -> list:
    return analyze_policy(policy) + analyze_principals(policy, policy_type)


def _run_single(args, policy: dict[str, Any], source_uri: str) -> tuple[str, list]:
    findings = _analyze_one(policy, args.policy_type)
    refactored = refactor_policy(
        policy,
        target_tables=args.table,
        default_region=args.region,
        default_account=args.account,
        default_partition=args.partition,
        index_names=args.index,
    )
    validation = validate_policy(
        refactored,
        prefer=args.validate,
        region=args.aws_region,
        policy_type=args.policy_type,
    )

    if args.output == "policy":
        return json.dumps(refactored, indent=2), findings
    if args.output == "json":
        return (
            json.dumps(
                {
                    "source": source_uri,
                    "policy_type": args.policy_type,
                    "original_findings": [f.to_dict() for f in findings],
                    "refactored_policy": refactored,
                    "validation": validation.to_dict(),
                    "diff": diff_policies(policy, refactored),
                },
                indent=2,
            ),
            findings,
        )
    if args.output == "sarif":
        return json.dumps(to_sarif(findings, source_uri), indent=2), findings
    return (
        render_markdown(policy, refactored, findings, validation, include_diff=not args.no_diff),
        findings,
    )


def _exit_code_for(findings: list, fail_on: str) -> int:
    if fail_on == "never":
        return 0
    threshold = {"medium": 2, "high": 3, "critical": 4}[fail_on]
    order = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
    return 1 if any(order[f.severity] >= threshold for f in findings) else 0


def _run_batch(args) -> int:
    src = Path(args.policy)
    if not src.is_dir():
        print(f"error: --batch requires a directory, got {src}", file=sys.stderr)
        return 2
    if args.out == "-":
        print("error: --batch requires --out DIR", file=sys.stderr)
        return 2
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    ext_map = {"report": ".md", "policy": ".json", "json": ".json", "sarif": ".sarif.json"}
    ext = ext_map[args.output]

    worst = 0
    summary_rows = []
    for p in sorted(src.glob("*.json")):
        try:
            policy = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as e:
            print(f"[skip] {p.name}: {e}", file=sys.stderr)
            continue
        rendered, findings = _run_single(args, policy, p.name)
        (out_dir / (p.stem + ext)).write_text(rendered, encoding="utf-8")
        rc = _exit_code_for(findings, args.fail_on)
        worst = max(worst, rc)
        summary_rows.append((p.name, len(findings), rc))

    print(f"processed {len(summary_rows)} policies → {out_dir}", file=sys.stderr)
    for name, n, rc in summary_rows:
        print(f"  {name}: {n} findings, exit={rc}", file=sys.stderr)
    return worst


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if args.batch:
        return _run_batch(args)

    try:
        policy = _read_policy(args.policy)
    except (OSError, json.JSONDecodeError) as e:
        print(f"error: failed to read policy: {e}", file=sys.stderr)
        return 2

    source = "<stdin>" if args.policy == "-" else args.policy
    rendered, findings = _run_single(args, policy, source)

    if args.out == "-":
        sys.stdout.write(rendered + ("\n" if not rendered.endswith("\n") else ""))
    else:
        Path(args.out).write_text(rendered, encoding="utf-8")
        print(f"wrote {args.out}", file=sys.stderr)

    return _exit_code_for(findings, args.fail_on)


if __name__ == "__main__":
    raise SystemExit(main())
