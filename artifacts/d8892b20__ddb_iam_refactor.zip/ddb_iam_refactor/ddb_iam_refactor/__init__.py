"""DynamoDB IAM Policy Refactor Tool."""
__version__ = "0.1.0"
