import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from ddb_iam_refactor.analyzer import analyze_policy, worst_severity
from ddb_iam_refactor.diff import diff_policies
from ddb_iam_refactor.principal import analyze_principals
from ddb_iam_refactor.refactor import refactor_policy
from ddb_iam_refactor.sarif import to_sarif
from ddb_iam_refactor.validator import validate_policy


INSECURE = json.loads((ROOT / "examples" / "insecure_policy.json").read_text())


def test_analyzer_flags_wildcards():
    findings = analyze_policy(INSECURE)
    codes = {f.code for f in findings}
    assert "ACTION_DDB_STAR" in codes
    assert "RESOURCE_STAR" in codes or "DESTRUCTIVE_ON_STAR" in codes
    assert "NON_DDB_ACTIONS" in codes
    assert "UNKNOWN_ACTION" in codes
    assert worst_severity(findings) in ("high", "critical")


def test_refactor_binds_to_specific_tables():
    refactored = refactor_policy(
        INSECURE,
        target_tables=["Orders", "Customers"],
        default_region="us-east-1",
        default_account="111122223333",
        index_names=["by_email"],
    )
    dumped = json.dumps(refactored)
    assert "arn:aws:dynamodb:us-east-1:111122223333:table/Orders" in dumped
    assert "arn:aws:dynamodb:us-east-1:111122223333:table/Customers" in dumped
    # dynamodb:GetItem should end up bound to concrete table ARNs, not "*"
    getitem_stmts = [
        s for s in refactored["Statement"]
        if "dynamodb:GetItem" in (s.get("Action") if isinstance(s.get("Action"), list) else [s.get("Action")])
    ]
    assert getitem_stmts, "expected a statement containing dynamodb:GetItem"
    for s in getitem_stmts:
        res = s["Resource"] if isinstance(s["Resource"], list) else [s["Resource"]]
        assert all(r.startswith("arn:aws:dynamodb:") for r in res), res
    # dynamodb:ListTables must remain on "*"
    list_stmts = [
        s for s in refactored["Statement"]
        if "dynamodb:ListTables" in (s.get("Action") if isinstance(s.get("Action"), list) else [s.get("Action")])
    ]
    assert list_stmts
    for s in list_stmts:
        assert s["Resource"] == "*"


def test_offline_validation_runs():
    refactored = refactor_policy(
        INSECURE,
        target_tables=["Orders"],
        default_region="us-east-1",
        default_account="111122223333",
    )
    result = validate_policy(refactored, prefer="offline")
    assert result.used == "offline"
    assert result.ok is True


def test_cli_produces_report(tmp_path):
    policy_path = ROOT / "examples" / "insecure_policy.json"
    out_path = tmp_path / "report.md"
    proc = subprocess.run(
        [
            sys.executable,
            "-m",
            "ddb_iam_refactor.cli",
            str(policy_path),
            "--table", "Orders",
            "--table", "Customers",
            "--region", "us-east-1",
            "--account", "111122223333",
            "--validate", "offline",
            "--output", "report",
            "--out", str(out_path),
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    assert proc.returncode == 0, proc.stderr
    text = out_path.read_text()
    assert "Action → Resource matrix" in text
    assert "arn:aws:dynamodb:us-east-1:111122223333:table/Orders" in text


def test_diff_shows_narrowing():
    refactored = refactor_policy(
        INSECURE,
        target_tables=["Orders"],
        default_region="us-east-1",
        default_account="111122223333",
    )
    d = diff_policies(INSECURE, refactored)
    assert d["summary"]["actions_narrowed_off_star"] > 0
    narrowed_actions = {row["action"] for row in d["narrowed"]}
    assert "dynamodb:GetItem" in narrowed_actions


def test_public_principal_flagged():
    rpol = json.loads((ROOT / "examples" / "resource_policy.json").read_text())
    findings = analyze_principals(rpol, "RESOURCE_POLICY")
    codes = {f.code for f in findings}
    assert "PUBLIC_PRINCIPAL" in codes
    # Identity-policy mode on the same doc must flag the Principal blocks
    findings2 = analyze_principals(rpol, "IDENTITY_POLICY")
    assert any(f.code == "PRINCIPAL_IN_IDENTITY_POLICY" for f in findings2)


def test_sarif_shape():
    findings = analyze_policy(INSECURE)
    doc = to_sarif(findings, "insecure_policy.json")
    assert doc["version"] == "2.1.0"
    assert doc["runs"][0]["tool"]["driver"]["name"] == "ddb-iam-refactor"
    assert len(doc["runs"][0]["results"]) == len(findings)


def test_batch_mode(tmp_path):
    src = tmp_path / "in"; src.mkdir()
    dst = tmp_path / "out"
    (src / "a.json").write_text((ROOT / "examples" / "insecure_policy.json").read_text())
    (src / "b.json").write_text((ROOT / "examples" / "resource_policy.json").read_text())
    proc = subprocess.run(
        [
            sys.executable, "-m", "ddb_iam_refactor.cli", str(src),
            "--batch", "--out", str(dst),
            "--table", "Orders", "--region", "us-east-1", "--account", "111122223333",
            "--validate", "offline", "--output", "sarif",
        ],
        cwd=ROOT, capture_output=True, text=True,
    )
    assert proc.returncode == 0, proc.stderr
    assert (dst / "a.sarif.json").exists()
    assert (dst / "b.sarif.json").exists()
    doc = json.loads((dst / "a.sarif.json").read_text())
    assert doc["version"] == "2.1.0"


if __name__ == "__main__":
    import tempfile
    test_analyzer_flags_wildcards()
    test_refactor_binds_to_specific_tables()
    test_offline_validation_runs()
    test_diff_shows_narrowing()
    test_public_principal_flagged()
    test_sarif_shape()
    with tempfile.TemporaryDirectory() as td:
        test_cli_produces_report(Path(td))
        test_batch_mode(Path(td) if False else Path(tempfile.mkdtemp()))
    print("ALL TESTS PASSED")
