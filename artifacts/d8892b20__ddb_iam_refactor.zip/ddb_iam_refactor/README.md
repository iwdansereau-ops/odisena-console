# ddb-iam-refactor

A CLI tool that takes a raw JSON IAM policy for Amazon DynamoDB, analyzes it
for security risks (wildcards, mixed services, destructive-on-`*` combos,
typos, missing `Version`, `NotAction`/`NotResource` pitfalls, unconditioned
destructive actions), rewrites it into a **least-privilege** version bound
to specific table ARNs, and validates the result against **AWS IAM Access
Analyzer** (`ValidatePolicy`) — with an offline fallback so it runs without
AWS creds.

## Install

```bash
cd ddb_iam_refactor
python -m pip install -e .          # optional
# or run directly:
python -m ddb_iam_refactor.cli --help
```

Requires Python 3.10+. `boto3` is optional and only needed for the live AWS
Access Analyzer path.

## Usage

```bash
python -m ddb_iam_refactor.cli examples/insecure_policy.json \
    --table Orders --table Customers \
    --index by_email \
    --region us-east-1 --account 111122223333 \
    --validate auto \
    --output report --out report.md
```

Flags:

| Flag | Purpose |
|------|---------|
| `--policy-type {IDENTITY_POLICY,RESOURCE_POLICY}` | How to treat the input. `RESOURCE_POLICY` enables `Principal`/`NotPrincipal` and public-access checks. |
| `--table NAME_OR_ARN` | Target table to bind the refactored policy to. Repeatable. |
| `--index NAME` | GSI/LSI names to scope index actions to. Repeatable. |
| `--region` / `--account` / `--partition` | Used when a bare table name is provided. |
| `--validate {auto,boto3,cli,offline}` | Which validation backend to use. `auto` tries boto3 → aws CLI → offline. |
| `--aws-region` | AWS region to call Access Analyzer in. |
| `--output {report,policy,json,sarif}` | `report`=Markdown, `policy`=refactored JSON, `json`=combined, `sarif`=SARIF 2.1.0 for GitHub code scanning. |
| `--out PATH` | Write to file (default stdout). With `--batch`, this is a directory. |
| `--no-diff` | Skip the diff section in the Markdown report. |
| `--batch` | Treat the input as a directory; every `*.json` inside is processed and written to `--out DIR`. |
| `--fail-on {never,medium,high,critical}` | Exit non-zero on findings in the ORIGINAL policy at/above this severity — useful in CI. |

## What it does

1. **Analyzer** — flags `dynamodb:*`, `Resource: "*"`, destructive-action + `*`
   combos, non-DynamoDB actions mixed in, unknown/typo action names,
   `NotAction`/`NotResource`, missing `Version`, and destructive actions
   without any `Condition`.
2. **Principal analyzer** — for `--policy-type RESOURCE_POLICY`, catches
   `Principal: "*"` without a `Condition` (effectively public), `NotPrincipal`
   on `Allow`, and missing `Principal`. For identity policies, flags any
   `Principal` block (which AWS will reject).
3. **Refactorer** — expands action wildcards against a catalog of DynamoDB
   actions, then splits each statement into up to six sub-statements bound
   to the correct resource kind (table, index, stream, backup, export,
   global-table). Service-level actions (`ListTables`, `DescribeLimits`,
   `DescribeEndpoints`, etc.) are kept in their own statement on `"*"`
   because AWS requires it.
4. **Validator** — calls AWS Access Analyzer `ValidatePolicy` (via boto3 or
   the `aws` CLI) with the correct `policyType`. Falls back to a built-in
   structural + IAM-grammar checker when AWS is unavailable, so the tool
   always produces a validation report.
5. **Diff** — shows, at the (action, resource) level, exactly which pairs
   were removed, added, retained, and which actions got **narrowed off `"*"`**
   onto specific ARNs — so you can prove the refactor removed blast radius
   without silently taking away needed access.
6. **SARIF emitter** — outputs SARIF 2.1.0 that GitHub code scanning / CI
   dashboards understand out of the box.
7. **Batch mode** — point the CLI at a directory of policies and it will
   analyze, refactor, validate, and emit reports (or SARIF) for each one.
8. **Reporter** — renders a Markdown report with:
   - a severity-ranked findings table on the original policy,
   - the Access-Analyzer validation results on the refactored policy,
   - a full **action → resource matrix** (every allowed action and the
     exact ARNs it maps to), classified as read / write-admin / destructive,
   - the diff summary, and the final refactored JSON.

## CI recipe (GitHub Actions)

```yaml
- name: DynamoDB IAM policy scan
  run: |
    python -m ddb_iam_refactor.cli policies/ \
      --batch --out sarif-out --output sarif \
      --validate offline --fail-on high
- uses: github/codeql-action/upload-sarif@v3
  with:
    sarif_file: sarif-out
```

## Example

`examples/insecure_policy.json` intentionally contains `dynamodb:*` on `*`,
a mixed S3 action, service-level actions, and a typo. Running the CLI on it
with `--table Orders --table Customers` produces a refactored policy whose
`GetItem`/`Query`/etc. are bound to
`arn:aws:dynamodb:us-east-1:111122223333:table/Orders` and
`.../table/Customers`, whose `ListTables`/`DescribeLimits` stay on `"*"`,
whose stream/backup/export/index actions get their own ARN patterns, and
whose typo action is called out as `UNKNOWN_ACTION` in the findings table.

## Tests

```bash
cd ddb_iam_refactor
python tests/test_end_to_end.py
```
