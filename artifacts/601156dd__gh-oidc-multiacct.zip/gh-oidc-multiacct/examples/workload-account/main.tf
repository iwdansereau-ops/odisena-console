###############################################################################
# Example root: deploy in EACH workload account (dev, staging, prod).
#
# Creates the spoke role trusted by the hub role in the Security account.
# The spoke role holds the actual deployment permissions.
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
  }
}

provider "aws" {
  region = var.aws_region
  # Run with credentials for the workload account.
}

variable "aws_region"          { type = string, default = "us-east-1" }
variable "hub_role_arn"        { type = string }
variable "external_id"         { type = string, sensitive = true }
variable "spoke_role_name"     { type = string, default = "GitHubActionsSpokeRole" }
variable "artifact_bucket_arn" { type = string }
variable "allowed_source_identities" { type = list(string), default = [] }
variable "security_account_id"       { type = string }
variable "alert_topic_arn"           { type = string }

data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}
data "aws_region" "current" {}

###############################################################################
# Deployment permissions for this workload account.
# Customize per environment; example below covers OTel Collector on ECS.
###############################################################################
data "aws_iam_policy_document" "deploy" {
  statement {
    sid     = "ReadArtifactsFromSecurity"
    effect  = "Allow"
    actions = ["s3:GetObject", "s3:ListBucket"]
    resources = [
      var.artifact_bucket_arn,
      "${var.artifact_bucket_arn}/*",
    ]
  }

  statement {
    sid       = "ECRAuth"
    effect    = "Allow"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid    = "ECRPull"
    effect = "Allow"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:GetDownloadUrlForLayer",
      "ecr:BatchGetImage",
    ]
    resources = [
      "arn:${data.aws_partition.current.partition}:ecr:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:repository/otel/*",
    ]
  }

  statement {
    sid    = "ECSDeploy"
    effect = "Allow"
    actions = [
      "ecs:RegisterTaskDefinition",
      "ecs:DescribeTaskDefinition",
      "ecs:UpdateService",
      "ecs:DescribeServices",
      "ecs:DescribeClusters",
    ]
    resources = ["*"]
  }

  statement {
    sid       = "PassOTelTaskRoles"
    effect    = "Allow"
    actions   = ["iam:PassRole"]
    resources = ["arn:${data.aws_partition.current.partition}:iam::${data.aws_caller_identity.current.account_id}:role/otel-*"]
    condition {
      test     = "StringEquals"
      variable = "iam:PassedToService"
      values   = ["ecs-tasks.amazonaws.com"]
    }
  }
}

module "spoke" {
  source                    = "../../modules/spoke-role"
  role_name                 = var.spoke_role_name
  hub_role_arn              = var.hub_role_arn
  external_id               = var.external_id
  allowed_source_identities = var.allowed_source_identities
  policy_json               = data.aws_iam_policy_document.deploy.json
}

###############################################################################
# Drift detection on the spoke trust policy — publishes to the central topic
###############################################################################
module "drift_check" {
  source                  = "../../modules/spoke-drift-check"
  spoke_role_arn          = module.spoke.spoke_role_arn
  expected_hub_account_id = var.security_account_id
  alert_target_arn        = var.alert_topic_arn
}

output "spoke_role_arn" { value = module.spoke.spoke_role_arn }
output "analyzer_arn"   { value = module.drift_check.analyzer_arn }
