###############################################################################
# Example root: deploy in the Security / CI account.
#
# This creates:
#   - The single organization-wide GitHub OIDC provider
#   - One hub role trusted by GitHub, allowed to assume spoke roles listed here
#   - A hardened S3 artifact bucket shared across accounts (for build outputs,
#     rendered task definitions, OTel configs, etc.) with a cross-account
#     bucket policy scoped to the workload spoke roles
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
  }
}

provider "aws" {
  region = var.aws_region
  # Assumes you're running with credentials for the Security account.
}

variable "aws_region" { type = string, default = "us-east-1" }
variable "github_org" { type = string }

variable "allowed_subjects" {
  type = list(string)
  # Tight defaults: main branch + prod environment + version tags only.
}

variable "workload_accounts" {
  description = "Map of workload account names to account IDs."
  type        = map(string)
  # Example: { dev = "111111111111", staging = "222222222222", prod = "333333333333" }
}

variable "spoke_role_name" {
  type    = string
  default = "GitHubActionsSpokeRole"
}

variable "artifact_bucket_name" { type = string }

variable "alert_email_addresses" {
  type        = list(string)
  default     = []
  description = "Emails to subscribe to the org-wide OIDC alert topic."
}

locals {
  spoke_role_arns = [
    for id in values(var.workload_accounts) :
    "arn:aws:iam::${id}:role/${var.spoke_role_name}"
  ]
}

###############################################################################
# 1) OIDC provider  (one per org, lives here)
###############################################################################
module "oidc" {
  source = "../../modules/oidc-provider"
}

###############################################################################
# 2) Hub role  (GitHub -> Security account)
###############################################################################
module "hub" {
  source            = "../../modules/hub-role"
  oidc_provider_arn = module.oidc.provider_arn
  github_org        = var.github_org
  allowed_subjects  = var.allowed_subjects
  spoke_role_arns   = local.spoke_role_arns
}

###############################################################################
# 3) Shared artifact bucket  (cross-account read for the workload spoke roles)
###############################################################################
resource "aws_s3_bucket" "artifacts" {
  bucket = var.artifact_bucket_name
}

resource "aws_s3_bucket_ownership_controls" "artifacts" {
  bucket = aws_s3_bucket.artifacts.id
  rule { object_ownership = "BucketOwnerEnforced" }
}

resource "aws_s3_bucket_public_access_block" "artifacts" {
  bucket                  = aws_s3_bucket.artifacts.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "artifacts" {
  bucket = aws_s3_bucket.artifacts.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "artifacts" {
  bucket = aws_s3_bucket.artifacts.id
  rule {
    apply_server_side_encryption_by_default { sse_algorithm = "AES256" }
    bucket_key_enabled = true
  }
}

data "aws_iam_policy_document" "artifacts" {
  # Deny anything not using TLS.
  statement {
    sid     = "DenyInsecureTransport"
    effect  = "Deny"
    actions = ["s3:*"]
    resources = [
      aws_s3_bucket.artifacts.arn,
      "${aws_s3_bucket.artifacts.arn}/*",
    ]
    principals {
      type        = "*"
      identifiers = ["*"]
    }
    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }

  # Hub role can put artifacts.
  statement {
    sid     = "HubWrite"
    effect  = "Allow"
    actions = ["s3:PutObject", "s3:GetObject", "s3:ListBucket"]
    resources = [
      aws_s3_bucket.artifacts.arn,
      "${aws_s3_bucket.artifacts.arn}/*",
    ]
    principals {
      type        = "AWS"
      identifiers = [module.hub.hub_role_arn]
    }
  }

  # Every workload spoke role can read artifacts under its account prefix.
  dynamic "statement" {
    for_each = var.workload_accounts
    content {
      sid    = "SpokeRead${title(statement.key)}"
      effect = "Allow"
      actions = ["s3:GetObject", "s3:ListBucket"]
      resources = [
        aws_s3_bucket.artifacts.arn,
        "${aws_s3_bucket.artifacts.arn}/${statement.key}/*",
      ]
      principals {
        type        = "AWS"
        identifiers = ["arn:aws:iam::${statement.value}:role/${var.spoke_role_name}"]
      }
      # Scope ListBucket to the account's prefix.
      condition {
        test     = "StringLike"
        variable = "s3:prefix"
        values   = ["${statement.key}/*", "${statement.key}"]
      }
    }
  }
}

resource "aws_s3_bucket_policy" "artifacts" {
  bucket = aws_s3_bucket.artifacts.id
  policy = data.aws_iam_policy_document.artifacts.json
}

###############################################################################
# 4) Detective control: alert on out-of-policy AssumeRoleWithWebIdentity
###############################################################################
module "oidc_alerting" {
  source                = "../../modules/oidc-alerting"
  hub_role_arn          = module.hub.hub_role_arn
  github_org            = var.github_org
  allowed_subjects      = var.allowed_subjects
  alert_email_addresses = var.alert_email_addresses
}

###############################################################################
# 5) Allow workload accounts to publish drift findings to the alert topic
###############################################################################
data "aws_iam_policy_document" "alert_topic" {
  statement {
    sid     = "AllowWorkloadEventBridgePublish"
    effect  = "Allow"
    actions = ["sns:Publish"]
    resources = [module.oidc_alerting.sns_topic_arn]

    principals {
      type        = "Service"
      identifiers = ["events.amazonaws.com"]
    }

    condition {
      test     = "StringEquals"
      variable = "aws:SourceAccount"
      values   = values(var.workload_accounts)
    }
  }
}

resource "aws_sns_topic_policy" "alerts" {
  arn    = module.oidc_alerting.sns_topic_arn
  policy = data.aws_iam_policy_document.alert_topic.json
}

output "hub_role_arn"      { value = module.hub.hub_role_arn }
output "oidc_provider_arn" { value = module.oidc.provider_arn }
output "artifact_bucket"   { value = aws_s3_bucket.artifacts.bucket }
output "alert_topic_arn"   { value = module.oidc_alerting.sns_topic_arn }
