###############################################################################
# Module: spoke-role  (deploys into each workload account: dev / staging / prod)
#
# Creates a workload-scoped IAM role that:
#   1) Trusts ONLY the hub role in the Security account (no GitHub trust here).
#   2) Requires an ExternalId AND source identity match, and pins the source
#      GitHub subject via aws:RequestTag / sts:SourceIdentity when passed
#      through by the hub session.
#   3) Carries the actual deployment permissions (S3, ECS, ECR, etc.).
#
# Why trust only the hub role?
#   - Single chokepoint for auditing GitHub -> AWS auth.
#   - Rotate/revoke access org-wide by editing one hub role.
#   - Workload accounts don't need their own OIDC provider or GitHub knowledge.
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
  }
}

variable "role_name" {
  type    = string
  default = "GitHubActionsSpokeRole"
}

variable "hub_role_arn" {
  type        = string
  description = "ARN of the hub role in the Security/CI account."
}

variable "external_id" {
  type        = string
  description = "ExternalId the hub must present when assuming this role. Rotate periodically."
  sensitive   = true
}

variable "allowed_source_identities" {
  type        = list(string)
  description = <<-EOT
    Values allowed for sts:SourceIdentity when the hub assumes this role.
    The hub workflow passes GitHub subject as SourceIdentity for full audit trail.
    Example: ["repo:my-org/otel-collector:environment:production"]
  EOT
  default     = []
}

variable "policy_json" {
  type        = string
  description = "Inline JSON of the deployment permissions this workload role grants."
}

variable "permissions_boundary_arn" {
  type        = string
  description = "Optional permissions boundary limiting what this role can ever do."
  default     = null
}

variable "tags" {
  type    = map(string)
  default = {}
}

###############################################################################
# Trust policy: only the hub role can assume, with ExternalId + SourceIdentity
###############################################################################

data "aws_iam_policy_document" "trust" {
  statement {
    sid     = "TrustHubRole"
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type        = "AWS"
      identifiers = [var.hub_role_arn]
    }

    condition {
      test     = "StringEquals"
      variable = "sts:ExternalId"
      values   = [var.external_id]
    }
  }

  # Optional second statement adds SetSourceIdentity permission.
  # The hub session MUST call AssumeRole with --source-identity so CloudTrail
  # records the originating GitHub repo/ref for every downstream API call.
  statement {
    sid     = "AllowSetSourceIdentity"
    effect  = "Allow"
    actions = ["sts:SetSourceIdentity"]

    principals {
      type        = "AWS"
      identifiers = [var.hub_role_arn]
    }

    dynamic "condition" {
      for_each = length(var.allowed_source_identities) > 0 ? [1] : []
      content {
        test     = "StringLike"
        variable = "sts:SourceIdentity"
        values   = var.allowed_source_identities
      }
    }
  }
}

resource "aws_iam_role" "spoke" {
  name                 = var.role_name
  description          = "Workload-account role assumed by the GitHub Actions hub role in Security."
  assume_role_policy   = data.aws_iam_policy_document.trust.json
  max_session_duration = 3600
  permissions_boundary = var.permissions_boundary_arn
  tags                 = var.tags
}

resource "aws_iam_role_policy" "deploy" {
  name   = "${var.role_name}-deploy"
  role   = aws_iam_role.spoke.id
  policy = var.policy_json
}

output "spoke_role_arn" {
  value = aws_iam_role.spoke.arn
}
