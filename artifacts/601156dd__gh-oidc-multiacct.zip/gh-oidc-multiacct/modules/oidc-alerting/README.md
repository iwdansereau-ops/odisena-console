# oidc-alerting

Deploys the detective control that complements the preventive controls in the
hub trust policy.

## What it does

1. **EventBridge rule** matches every `sts:AssumeRoleWithWebIdentity` CloudTrail
   event targeting the hub role.
2. **Filter Lambda** parses the `sub` and `repository_owner` claims and
   publishes to SNS only when the call is **out of policy** — meaning the
   `sub` claim doesn't match any pattern in `allowed_subjects`, or the
   `repository_owner` doesn't match `github_org`, or the claim can't be
   parsed at all (fail-open to alert).
3. **SNS topic** fans out to email subscribers. Add Slack / PagerDuty via
   the AWS Chatbot or a custom subscription.
4. **CloudWatch alarm** trips on any alerted event in a 5-minute window so
   you get a second surface (dashboards, ChatOps) in addition to the direct
   SNS message.

## Why not filter in EventBridge alone?

EventBridge content filtering does not support negative regex / "does-not-match"
predicates. Doing the allow-list check in ~30 lines of Python is simpler,
auditable, and lets us apply the same patterns you passed to the hub trust
policy — reducing the chance of drift between preventive and detective rules.

## Prerequisites

- **CloudTrail** must be logging management events in the Security account.
  An org-trail from the management account works equally well and is
  recommended for org-wide governance.
- Email subscribers must confirm the SNS subscription email AWS sends.

## Tuning

- To silence expected noise (e.g. a chaos-drill run), add an `archive_rule`
  to CloudTrail Lake or extend the Lambda with an ignore-list env var.
- To dashboard trends, chart `Security/GitHubOIDC / OutOfPolicyAssumeRoleCount`
  over 24h alongside successful GitHub deploys.
