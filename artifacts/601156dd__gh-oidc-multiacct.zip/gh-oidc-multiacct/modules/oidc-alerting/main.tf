###############################################################################
# Module: oidc-alerting  (deploys into the Security account)
#
# Fires an alert whenever GitHub Actions successfully or unsuccessfully calls
# sts:AssumeRoleWithWebIdentity against the hub role with a `sub` claim
# that is NOT in the allow-list. This is the org-wide detective control that
# complements the preventive controls in the hub trust policy.
#
# Pipeline:
#   CloudTrail management events (org trail recommended)
#     -> EventBridge rule with a content-filter on the userIdentity/requestParameters
#     -> SNS topic (email/Slack/PagerDuty subscribers)
#     -> Optional CloudWatch metric + alarm for rate-based dashboards
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
  }
}

variable "hub_role_arn" {
  type        = string
  description = "ARN of the hub role. Only events targeting this role are alerted on."
}

variable "github_org" {
  type = string
}

variable "allowed_subjects" {
  type        = list(string)
  description = <<-EOT
    The SAME list you passed to the hub-role module. Alerts fire when a
    federated call is made whose `sub` claim does NOT match any of these
    patterns. Wildcards are treated as prefix/suffix matches.
  EOT
}

variable "alert_email_addresses" {
  type        = list(string)
  default     = []
  description = "Emails to subscribe to the alert SNS topic (confirmation email required)."
}

variable "tags" {
  type    = map(string)
  default = {}
}

###############################################################################
# SNS topic (destinations)
###############################################################################
resource "aws_sns_topic" "alerts" {
  name = "github-oidc-out-of-policy-alerts"
  tags = var.tags
}

resource "aws_sns_topic_subscription" "email" {
  for_each  = toset(var.alert_email_addresses)
  topic_arn = aws_sns_topic.alerts.arn
  protocol  = "email"
  endpoint  = each.value
}

###############################################################################
# EventBridge rule — CloudTrail "AWS API Call via CloudTrail" events
#
# We match on:
#   - eventSource = sts.amazonaws.com
#   - eventName  = AssumeRoleWithWebIdentity
#   - requestParameters.roleArn = <hub role ARN>
#
# Content filtering in EventBridge does NOT support negative regex, so we
# match ALL such events here and defer the "is-sub-allowed?" check to a
# tiny Lambda target. This keeps the rule simple and auditable.
###############################################################################
resource "aws_cloudwatch_event_rule" "assume_role_with_web_identity" {
  name        = "github-oidc-assume-role-web-identity"
  description = "Every sts:AssumeRoleWithWebIdentity call targeting the hub role."

  event_pattern = jsonencode({
    source        = ["aws.sts"]
    "detail-type" = ["AWS API Call via CloudTrail"]
    detail = {
      eventSource = ["sts.amazonaws.com"]
      eventName   = ["AssumeRoleWithWebIdentity"]
      requestParameters = {
        roleArn = [var.hub_role_arn]
      }
    }
  })

  tags = var.tags
}

###############################################################################
# Lambda filter — publishes to SNS only when `sub` is out of policy
###############################################################################
data "archive_file" "filter" {
  type        = "zip"
  output_path = "${path.module}/filter.zip"

  source {
    filename = "index.py"
    content  = <<-PYTHON
      import json, os, re, boto3

      SNS_ARN         = os.environ["SNS_ARN"]
      GITHUB_ORG      = os.environ["GITHUB_ORG"]
      ALLOWED_SUBJECTS = [s.strip() for s in os.environ["ALLOWED_SUBJECTS"].split(",") if s.strip()]

      def _to_regex(pattern: str) -> re.Pattern:
          # Convert AWS "StringLike" style wildcards to regex.
          # Escape everything, then turn escaped \* back into .*
          escaped = re.escape(pattern).replace(r"\*", ".*")
          return re.compile(f"^{escaped}$")

      ALLOW_RES = [_to_regex(p) for p in ALLOWED_SUBJECTS]
      sns = boto3.client("sns")

      def _extract_sub(detail):
          # CloudTrail records the raw JWT claims under
          # requestParameters.tokenPayload / additionalContext depending on
          # the record version. We probe both locations.
          rp = detail.get("requestParameters") or {}
          for k in ("tokenPayload", "webIdentityToken"):
              blob = rp.get(k)
              if isinstance(blob, dict) and "sub" in blob:
                  return blob["sub"], blob.get("repository_owner")
          # Fallback: userIdentity has parsed claims in some record versions.
          ui = detail.get("userIdentity") or {}
          claims = (ui.get("webIdFederationData") or {}).get("attributes") or {}
          return claims.get("sub"), claims.get("repository_owner")

      def handler(event, _ctx):
          detail = event.get("detail") or {}
          sub, owner = _extract_sub(detail)
          # If we can't parse the sub, err on the side of alerting.
          out_of_policy_reason = None
          if not sub:
              out_of_policy_reason = "unparseable sub claim"
          elif owner and owner != GITHUB_ORG:
              out_of_policy_reason = f"repository_owner={owner} not {GITHUB_ORG}"
          elif not any(rgx.match(sub) for rgx in ALLOW_RES):
              out_of_policy_reason = f"sub={sub} not in allow-list"

          if not out_of_policy_reason:
              return {"ok": True, "filtered": True}

          msg = {
              "alert":  "GitHub OIDC out-of-policy AssumeRoleWithWebIdentity",
              "reason": out_of_policy_reason,
              "sub":    sub,
              "eventTime":    detail.get("eventTime"),
              "sourceIP":     detail.get("sourceIPAddress"),
              "eventID":      detail.get("eventID"),
              "responseCode": (detail.get("errorCode") or "Success"),
          }
          sns.publish(
              TopicArn=SNS_ARN,
              Subject="[SECURITY] GitHub OIDC out-of-policy assume-role",
              Message=json.dumps(msg, indent=2, default=str),
          )
          return {"ok": True, "alerted": True, "reason": out_of_policy_reason}
    PYTHON
  }
}

resource "aws_iam_role" "filter" {
  name = "github-oidc-filter-lambda"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
  tags = var.tags
}

resource "aws_iam_role_policy_attachment" "logs" {
  role       = aws_iam_role.filter.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "publish" {
  role = aws_iam_role.filter.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "sns:Publish"
      Resource = aws_sns_topic.alerts.arn
    }]
  })
}

resource "aws_lambda_function" "filter" {
  function_name    = "github-oidc-out-of-policy-filter"
  role             = aws_iam_role.filter.arn
  handler          = "index.handler"
  runtime          = "python3.12"
  filename         = data.archive_file.filter.output_path
  source_code_hash = data.archive_file.filter.output_base64sha256
  timeout          = 10

  environment {
    variables = {
      SNS_ARN          = aws_sns_topic.alerts.arn
      GITHUB_ORG       = var.github_org
      ALLOWED_SUBJECTS = join(",", var.allowed_subjects)
    }
  }

  tags = var.tags
}

resource "aws_lambda_permission" "eventbridge" {
  statement_id  = "AllowEventBridgeInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.filter.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.assume_role_with_web_identity.arn
}

resource "aws_cloudwatch_event_target" "to_lambda" {
  rule      = aws_cloudwatch_event_rule.assume_role_with_web_identity.name
  target_id = "filter-lambda"
  arn       = aws_lambda_function.filter.arn
}

###############################################################################
# Rate alarm — any out-of-policy alert in a 5-minute window is one too many
###############################################################################
resource "aws_cloudwatch_log_metric_filter" "alerted" {
  name           = "github-oidc-out-of-policy-count"
  log_group_name = "/aws/lambda/${aws_lambda_function.filter.function_name}"
  pattern        = "{ $.alerted = true }"

  metric_transformation {
    name      = "OutOfPolicyAssumeRoleCount"
    namespace = "Security/GitHubOIDC"
    value     = "1"
  }
}

resource "aws_cloudwatch_metric_alarm" "any_out_of_policy" {
  alarm_name          = "github-oidc-out-of-policy"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  threshold           = 1
  evaluation_periods  = 1
  period              = 300
  namespace           = "Security/GitHubOIDC"
  metric_name         = "OutOfPolicyAssumeRoleCount"
  statistic           = "Sum"
  treat_missing_data  = "notBreaching"
  alarm_actions       = [aws_sns_topic.alerts.arn]
  tags                = var.tags
}

output "sns_topic_arn" { value = aws_sns_topic.alerts.arn }
output "rule_name"     { value = aws_cloudwatch_event_rule.assume_role_with_web_identity.name }
output "lambda_name"   { value = aws_lambda_function.filter.function_name }
