# spoke-drift-check

Detects when a workload account's spoke role trust policy is modified to
grant access outside the expected hub role.

## What it does

1. Creates an **IAM Access Analyzer** (account-scoped) in the workload
   account.
2. Adds an **archive rule** that auto-suppresses the one expected finding
   — the hub role in the Security account, gated by an `sts:ExternalId`
   condition. Any finding that lacks the ExternalId condition, references
   a different account, or points at a different resource stays ACTIVE.
3. Adds an **EventBridge rule** that fires on ACTIVE Access Analyzer
   findings targeting the spoke role and forwards a reshaped payload to
   the central SNS topic in the Security account.

## What it catches

- Someone edits the spoke trust policy to add a second principal.
- Someone removes the `sts:ExternalId` condition.
- A CloudFormation drift adds a wildcard principal.
- A future Terraform apply against stale state changes the trust boundary.

## Cross-account SNS

The workload account's EventBridge publishes directly to an SNS topic in
the Security account. The Security account example wires up the required
topic policy so `events.amazonaws.com` from allow-listed workload accounts
can publish. If you'd rather keep alerts local per account, swap
`alert_target_arn` for a topic in the workload account itself.

## Cost

Access Analyzer is free at account scope. EventBridge is billed per
event; drift findings are rare — expect near-zero cost.
