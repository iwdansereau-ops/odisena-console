###############################################################################
# Module: spoke-drift-check  (deploys into each workload account)
#
# Uses IAM Access Analyzer to detect when a spoke role's trust policy grants
# access to any principal OTHER than the expected hub role in the Security
# account. Findings are surfaced via EventBridge -> SNS (cross-account to
# the Security account's alert topic, or a local topic per account).
#
# What this catches:
#   - Someone edits the spoke trust policy to trust an extra principal
#   - Someone removes the sts:ExternalId condition
#   - A CloudFormation drift adds a wildcard principal
#   - Any "external access" surface change on the role
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
  }
}

variable "analyzer_name" {
  type    = string
  default = "workload-external-access"
}

variable "spoke_role_arn" {
  type        = string
  description = "The spoke role this account exposes to the hub."
}

variable "expected_hub_account_id" {
  type        = string
  description = "The Security account ID. Findings that reference any other account are alerted on."
}

variable "alert_target_arn" {
  type        = string
  description = <<-EOT
    ARN to publish drift alerts to. Typically the SNS topic in the Security
    account (aws_sns_topic.alerts). Cross-account SNS requires the topic
    policy to allow this account's EventBridge to publish.
  EOT
}

variable "tags" {
  type    = map(string)
  default = {}
}

data "aws_caller_identity" "current" {}

###############################################################################
# 1) Analyzer — account-scoped, evaluates trust policies + resource policies
###############################################################################
resource "aws_accessanalyzer_analyzer" "this" {
  analyzer_name = var.analyzer_name
  type          = "ACCOUNT"
  tags          = var.tags
}

###############################################################################
# 2) Archive rule — auto-archive findings that only reference the expected hub
#
# Access Analyzer surfaces every principal outside the account as a "finding".
# We EXPECT one finding on the spoke role (the hub). This archive rule filters
# that expected finding out so any NEW finding on the spoke role is real drift.
###############################################################################
resource "aws_accessanalyzer_archive_rule" "expected_hub" {
  analyzer_name = aws_accessanalyzer_analyzer.this.analyzer_name
  rule_name     = "expected-hub-access"

  filter {
    criteria = "resource"
    eq       = [var.spoke_role_arn]
  }

  filter {
    criteria = "principal.AWS"
    contains = [var.expected_hub_account_id]
  }

  filter {
    criteria = "condition.sts:ExternalId"
    exists   = true
  }
}

###############################################################################
# 3) EventBridge rule — any non-archived active finding on the spoke role
###############################################################################
resource "aws_cloudwatch_event_rule" "drift" {
  name        = "spoke-role-trust-drift"
  description = "Active Access Analyzer finding on the spoke role."

  event_pattern = jsonencode({
    source        = ["aws.access-analyzer"]
    "detail-type" = ["Access Analyzer Finding"]
    detail = {
      status   = ["ACTIVE"]
      resource = [var.spoke_role_arn]
    }
  })

  tags = var.tags
}

resource "aws_cloudwatch_event_target" "to_sns" {
  rule      = aws_cloudwatch_event_rule.drift.name
  target_id = "drift-alert"
  arn       = var.alert_target_arn

  # Reshape the finding into a readable message.
  input_transformer {
    input_paths = {
      resource   = "$.detail.resource"
      principal  = "$.detail.principal"
      conditions = "$.detail.conditionKeyMap"
      account    = "$.account"
      time       = "$.time"
      findingId  = "$.detail.id"
    }
    input_template = <<-EOT
      {
        "alert":     "Spoke role trust policy drift detected",
        "account":   <account>,
        "resource":  <resource>,
        "principal": <principal>,
        "conditions": <conditions>,
        "time":      <time>,
        "findingId": <findingId>
      }
    EOT
  }
}

output "analyzer_arn" { value = aws_accessanalyzer_analyzer.this.arn }
output "rule_name"    { value = aws_cloudwatch_event_rule.drift.name }
