###############################################################################
# Module: oidc-provider
# Purpose: Create the GitHub OIDC identity provider ONCE in the Security account.
# Consumers: The hub-role module (same account) references its ARN.
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
  }
}

variable "tags" {
  type    = map(string)
  default = {}
}

resource "aws_iam_openid_connect_provider" "github" {
  url            = "https://token.actions.githubusercontent.com"
  client_id_list = ["sts.amazonaws.com"]

  # AWS validates GitHub's TLS chain against a trusted root CA (June 2023+);
  # the thumbprint is no longer used for verification but the field is required.
  thumbprint_list = ["ffffffffffffffffffffffffffffffffffffffff"]

  tags = merge(var.tags, {
    Name      = "github-actions-oidc"
    ManagedBy = "terraform"
    Purpose   = "org-wide-ci-cd"
  })
}

output "provider_arn" {
  value       = aws_iam_openid_connect_provider.github.arn
  description = "ARN of the GitHub OIDC provider (Security account)."
}
