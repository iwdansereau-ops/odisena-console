###############################################################################
# Module: hub-role  (deploys into the Security / CI account)
#
# Creates a "hub" IAM role that:
#   1) Is assumed by GitHub Actions via OIDC (federated principal).
#   2) Has ONE permission: sts:AssumeRole into a set of allow-listed spoke
#      roles across workload accounts (role chaining).
#
# Design rationale:
#   - Only the Security account trusts GitHub. Workload accounts trust the
#     Security account, not GitHub directly. This gives you a single audit
#     chokepoint for all CI/CD identity.
#   - The hub role has NO deployment permissions of its own. All real work
#     happens after chaining into a spoke role scoped to one workload account.
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
  }
}

variable "role_name" {
  type    = string
  default = "GitHubActionsHubRole"
}

variable "oidc_provider_arn" {
  type        = string
  description = "ARN of the GitHub OIDC provider (from the oidc-provider module)."
}

variable "github_org" {
  type = string
}

variable "allowed_subjects" {
  type        = list(string)
  description = <<-EOT
    GitHub OIDC `sub` claim patterns permitted to assume the hub role.
    Use the tightest patterns possible. Examples:
      repo:my-org/repo-a:ref:refs/heads/main
      repo:my-org/repo-b:environment:production
      repo:my-org/*:ref:refs/tags/v*
    Avoid `repo:my-org/*:*` — that includes PR-triggered workflows.
  EOT
}

variable "spoke_role_arns" {
  type        = list(string)
  description = "ARNs of spoke roles in workload accounts the hub is allowed to assume."
}

variable "tags" {
  type    = map(string)
  default = {}
}

###############################################################################
# Trust policy: only GitHub OIDC with matching org/repo/ref/env can assume
###############################################################################

data "aws_iam_policy_document" "trust" {
  statement {
    sid     = "GitHubOIDCFederated"
    effect  = "Allow"
    actions = ["sts:AssumeRoleWithWebIdentity"]

    principals {
      type        = "Federated"
      identifiers = [var.oidc_provider_arn]
    }

    # Audience pinning — token must be minted for AWS STS.
    condition {
      test     = "StringEquals"
      variable = "token.actions.githubusercontent.com:aud"
      values   = ["sts.amazonaws.com"]
    }

    # Belt-and-suspenders: enforce the GitHub org even if `sub` is misconfigured.
    # `repository_owner` is a first-class claim on GitHub OIDC tokens.
    condition {
      test     = "StringEquals"
      variable = "token.actions.githubusercontent.com:repository_owner"
      values   = [var.github_org]
    }

    # Repo/branch/tag/environment allow-list.
    condition {
      test     = "StringLike"
      variable = "token.actions.githubusercontent.com:sub"
      values   = var.allowed_subjects
    }
  }
}

resource "aws_iam_role" "hub" {
  name                 = var.role_name
  description          = "Hub role assumed by GitHub Actions via OIDC; chains into workload spoke roles."
  assume_role_policy   = data.aws_iam_policy_document.trust.json
  max_session_duration = 3600
  tags                 = var.tags
}

###############################################################################
# Only permission granted: assume the specific spoke roles.
###############################################################################

data "aws_iam_policy_document" "chain" {
  statement {
    sid       = "AssumeSpokeRoles"
    effect    = "Allow"
    actions   = ["sts:AssumeRole", "sts:TagSession"]
    resources = var.spoke_role_arns
  }
}

resource "aws_iam_role_policy" "chain" {
  name   = "${var.role_name}-chain"
  role   = aws_iam_role.hub.id
  policy = data.aws_iam_policy_document.chain.json
}

output "hub_role_arn" {
  value = aws_iam_role.hub.arn
}
