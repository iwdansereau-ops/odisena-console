# Example Terraform IAM to exercise the governance pipeline.
#
# The `good_read_role` policy is least-privileged and should PASS.
# The `bad_admin` policy is deliberately over-privileged and should FAIL
# with CRITICAL findings from both Checkov and IAM Access Analyzer.

terraform {
  required_providers {
    aws = { source = "hashicorp/aws", version = ">= 5.0" }
  }
}

# ------------------------------------------------------------
# GOOD
# ------------------------------------------------------------
resource "aws_iam_role" "good_read_role" {
  name = "app-read-role-tf"
  assume_role_policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {"Service": "lambda.amazonaws.com"},
    "Action": "sts:AssumeRole"
  }]
}
EOT
}

resource "aws_iam_role_policy" "good_read_policy" {
  name = "read-only-bucket-tf"
  role = aws_iam_role.good_read_role.id
  policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "ReadDataBucket",
    "Effect": "Allow",
    "Action": ["s3:GetObject", "s3:ListBucket"],
    "Resource": [
      "arn:aws:s3:::my-app-data-bucket",
      "arn:aws:s3:::my-app-data-bucket/*"
    ],
    "Condition": {"StringEquals": {"aws:SecureTransport": "true"}}
  }]
}
EOT
}

# ------------------------------------------------------------
# BAD — should be caught
# ------------------------------------------------------------
resource "aws_iam_policy" "bad_admin" {
  name = "everything-goes-tf"
  policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "*",
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": ["iam:PassRole", "iam:CreateAccessKey"],
      "Resource": "*"
    }
  ]
}
EOT
}
