# Bootstrap: GitHub OIDC → AWS IAM role

Deploy this stack **once per AWS account** where you want the governance pipeline to run.

```bash
aws cloudformation deploy \
  --template-file setup/github-oidc-role.yaml \
  --stack-name github-iam-governance-oidc \
  --parameter-overrides \
      GitHubOrg=your-org \
      GitHubRepo=your-repo \
      GitHubRefPattern='*' \
  --capabilities CAPABILITY_NAMED_IAM

aws cloudformation describe-stacks \
  --stack-name github-iam-governance-oidc \
  --query 'Stacks[0].Outputs'
```

## Wiring into GitHub

Copy the `RoleArn` output value, then in the target repository:

**Settings → Secrets and variables → Actions → Variables** (repository or environment scope):
- `AWS_ROLE_ARN` → the outputted role ARN
- `AWS_REGION` → e.g. `us-east-1`
- `IAC_DIR` → path to your Terraform/CloudFormation directory (default: `iac`)
- `SOFT_FAIL` → `true` to warn-only during initial rollout, `false` (default) to enforce

## Restricting further

The default `GitHubRefPattern='*'` allows any workflow in the repo to assume the role. Tighten it to a specific event:

| Purpose | Pattern |
|---|---|
| Only PR events | `pull_request` |
| Only `main` branch | `ref:refs/heads/main` |
| Only a specific environment | `environment:production` |

Redeploy the stack with the new parameter value to update the trust policy.

## Permissions granted

Read-only IAM plus the specific Access Analyzer actions the pipeline invokes:

- `access-analyzer:ValidatePolicy`
- `access-analyzer:CheckAccessNotGranted`
- `access-analyzer:CheckNoNewAccess`
- `iam:ListPolicies`, `iam:GetPolicy`, `iam:GetPolicyVersion`
- `iam:ListRoles`, `iam:GetRole`, `iam:GetRolePolicy`
- `iam:ListRolePolicies`, `iam:ListAttachedRolePolicies`
- `sts:GetCallerIdentity`

The role has **no write permissions** on any AWS resource, and sessions last at most 1 hour.

## Already have a GitHub OIDC provider?

An AWS account can only have one OIDC provider per URL. If `token.actions.githubusercontent.com` already exists (from a prior CDK/Terraform stack), remove the `GitHubOidcProvider` resource from `github-oidc-role.yaml` and change the role's `Principal.Federated` to the existing provider ARN before deploying.
