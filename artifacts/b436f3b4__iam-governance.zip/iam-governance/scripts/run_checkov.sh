#!/usr/bin/env bash
# Run Checkov against an IaC directory and normalize the exit code so the
# workflow can decide gating in a single place (merge_findings.py).
#
# Usage: run_checkov.sh <iac-dir> <output-json>
set -euo pipefail

IAC_DIR="${1:-iac}"
OUTPUT="${2:-checkov-output.json}"

if [[ ! -d "$IAC_DIR" ]]; then
  echo "::warning::IaC directory '$IAC_DIR' not found; emitting empty result"
  echo '{"results":{"failed_checks":[],"passed_checks":[]},"summary":{"passed":0,"failed":0,"skipped":0}}' > "$OUTPUT"
  exit 0
fi

# --soft-fail so Checkov always exits 0; we make blocking decisions later.
# --config-file picks up frameworks + check filters from .checkov.yaml.
set +e
checkov \
  --directory "$IAC_DIR" \
  --config-file .checkov.yaml \
  --soft-fail \
  --output json \
  --output-file-path "$(dirname "$OUTPUT")","$(dirname "$OUTPUT")" \
  > /tmp/checkov.raw.json 2>/tmp/checkov.err || true
rc=$?
set -e

# Newer Checkov versions write to <dir>/results_json.json when --output-file-path
# is used; older versions print to stdout. Handle both.
if [[ -f "$(dirname "$OUTPUT")/results_json.json" ]]; then
  mv "$(dirname "$OUTPUT")/results_json.json" "$OUTPUT"
elif [[ -s /tmp/checkov.raw.json ]]; then
  cp /tmp/checkov.raw.json "$OUTPUT"
else
  echo "::warning::Checkov produced no output; falling back to empty result"
  echo '{"results":{"failed_checks":[],"passed_checks":[]},"summary":{"passed":0,"failed":0,"skipped":0}}' > "$OUTPUT"
fi

# Show a short summary in the job log
if command -v jq >/dev/null; then
  echo "----- Checkov summary -----"
  jq '{passed: (.summary.passed // 0), failed: (.summary.failed // 0), skipped: (.summary.skipped // 0)}' "$OUTPUT" || true
fi

exit 0
