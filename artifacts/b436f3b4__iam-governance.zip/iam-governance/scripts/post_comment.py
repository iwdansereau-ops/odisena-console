#!/usr/bin/env python3
"""
Post (or update) a sticky PR comment summarizing IAM governance findings.

The full HTML report is uploaded as a workflow artifact. This comment renders
a compact Markdown summary + a table of the top findings.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

import requests


MARKER = "<!-- iam-governance-report -->"


def render_markdown(findings: list[dict[str, Any]], counts: dict[str, int], gate: str,
                    repo: str, run_id: str) -> str:
    gate_emoji = {"pass": "✅", "warn": "⚠️", "block": "🛑"}[gate]
    lines: list[str] = []
    lines.append(f"{MARKER}")
    lines.append(f"## {gate_emoji} IAM Policy Governance — `{gate.upper()}`")
    lines.append("")
    lines.append(
        f"| Critical | High | Medium | Low | Total |\n"
        f"|---:|---:|---:|---:|---:|\n"
        f"| **{counts['critical']}** | **{counts['high']}** | {counts['medium']} | {counts['low']} | {counts['total']} |"
    )
    lines.append("")
    if gate == "block":
        lines.append("> This PR **cannot be merged** until critical/high findings are resolved.")
    elif gate == "warn":
        lines.append("> Merge allowed. Informational findings noted below.")
    else:
        lines.append("> No findings. Safe to merge.")
    lines.append("")

    top = [f for f in findings if f["severity"] in ("CRITICAL", "HIGH")][:15]
    if top:
        lines.append("### Top findings")
        lines.append("")
        lines.append("| Severity | Check | Source | File | Resource | Detail |")
        lines.append("|---|---|---|---|---|---|")
        for f in top:
            detail = (f.get("description") or "").replace("|", "\\|").replace("\n", " ")
            if len(detail) > 160:
                detail = detail[:157] + "…"
            lines.append(
                f"| `{f['severity']}` "
                f"| `{f.get('id','')}` "
                f"| {f.get('source','')} "
                f"| `{f.get('file','') or ''}` "
                f"| `{f.get('resource','') or ''}` "
                f"| {detail} |"
            )
        lines.append("")

    lines.append(
        f"[📄 Full HTML audit report](https://github.com/{repo}/actions/runs/{run_id}) "
        f"(download `iam-governance-report-{run_id}` artifact)"
    )
    lines.append("")
    lines.append(
        "_Static: Checkov · AWS-native: IAM Access Analyzer (ValidatePolicy + "
        "CheckAccessNotGranted + deployed-policy drift). Auth: GitHub OIDC._"
    )
    return "\n".join(lines)


def find_existing_comment(session: requests.Session, repo: str, pr_number: int) -> int | None:
    url = f"https://api.github.com/repos/{repo}/issues/{pr_number}/comments"
    page = 1
    while True:
        r = session.get(url, params={"per_page": 100, "page": page}, timeout=30)
        r.raise_for_status()
        items = r.json()
        if not items:
            return None
        for c in items:
            if MARKER in (c.get("body") or ""):
                return c["id"]
        if len(items) < 100:
            return None
        page += 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--findings", required=True)
    parser.add_argument("--summary", required=True)
    parser.add_argument("--pr-number", required=True, type=int)
    parser.add_argument("--repo", required=True)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()

    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        print("[post-comment] GITHUB_TOKEN not set — skipping comment")
        return 0

    findings_doc = json.loads(Path(args.findings).read_text())
    summary_doc = json.loads(Path(args.summary).read_text())

    body = render_markdown(
        findings=findings_doc.get("findings", []),
        counts=summary_doc["counts"],
        gate=summary_doc["gate"],
        repo=args.repo,
        run_id=args.run_id,
    )

    session = requests.Session()
    session.headers.update({
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    })

    existing = find_existing_comment(session, args.repo, args.pr_number)
    if existing:
        url = f"https://api.github.com/repos/{args.repo}/issues/comments/{existing}"
        r = session.patch(url, json={"body": body}, timeout=30)
    else:
        url = f"https://api.github.com/repos/{args.repo}/issues/{args.pr_number}/comments"
        r = session.post(url, json={"body": body}, timeout=30)
    r.raise_for_status()
    print(f"[post-comment] {'updated' if existing else 'created'} comment {r.json().get('id')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
