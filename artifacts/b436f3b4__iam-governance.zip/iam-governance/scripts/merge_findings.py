#!/usr/bin/env python3
"""
Merge Checkov and Access Analyzer outputs into a single normalized findings
JSON, compute counts by severity, and decide the merge gate (pass|warn|block).

Severity model
--------------
CRITICAL — never merge:
  - Checkov IAM checks tagged as privilege-escalation / admin (see PRIV_ESC_CHECKS)
  - Access Analyzer ValidatePolicy findingType == ERROR or SECURITY_WARNING
  - Any CheckAccessNotGranted FAIL result (policy grants a critical action)
  - Drift with newly_grants_privileges == true

HIGH    — never merge unless SOFT_FAIL=true:
  - All remaining Checkov failures for enabled IAM checks
  - Access Analyzer ValidatePolicy findingType == WARNING

MEDIUM  — informational, does not block:
  - Access Analyzer ValidatePolicy findingType == SUGGESTION

LOW     — informational, does not block:
  - Checkov skipped/soft findings (rare, since gate lives here)
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


# Checkov IDs that must always be treated as CRITICAL (privilege escalation,
# admin, credential exposure, data exfiltration, wildcard permissions).
PRIV_ESC_CHECKS = {
    "CKV_AWS_1", "CKV_AWS_39", "CKV_AWS_44", "CKV_AWS_45", "CKV_AWS_49",
    "CKV_AWS_60", "CKV_AWS_61", "CKV_AWS_62", "CKV_AWS_63",
    "CKV_AWS_107", "CKV_AWS_108", "CKV_AWS_109", "CKV_AWS_110",
    "CKV_AWS_286", "CKV_AWS_287", "CKV_AWS_288", "CKV_AWS_289",
    "CKV_AWS_355", "CKV2_AWS_40", "CKV2_AWS_41",
    "CKV_SECRET_2", "CKV_SECRET_10",
}


def _load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except Exception:
        return {}


def _normalize_checkov(raw: Any) -> list[dict[str, Any]]:
    """
    Checkov's JSON output shape differs by version and framework. It can be:
      - a dict with keys {results: {failed_checks: [...]}, summary: {...}}
      - a list of the above (one per framework)
    """
    findings: list[dict[str, Any]] = []
    items = raw if isinstance(raw, list) else [raw]
    for item in items:
        if not isinstance(item, dict):
            continue
        results = (item.get("results") or {}).get("failed_checks", []) or []
        for f in results:
            check_id = f.get("check_id") or f.get("bc_check_id") or "UNKNOWN"
            severity = (f.get("severity") or "").upper() or None
            if check_id in PRIV_ESC_CHECKS:
                sev = "CRITICAL"
            elif severity in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
                sev = severity
            else:
                sev = "HIGH"
            findings.append({
                "source": "checkov",
                "id": check_id,
                "severity": sev,
                "title": f.get("check_name") or check_id,
                "resource": f.get("resource"),
                "file": f.get("file_path") or f.get("repo_file_path"),
                "line_range": f.get("file_line_range"),
                "guideline": f.get("guideline"),
                "description": f.get("description") or f.get("check_name"),
            })
    return findings


def _normalize_access_analyzer(raw: dict[str, Any]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []

    # ValidatePolicy
    for f in raw.get("validate_policy", []) or []:
        ftype = (f.get("finding_type") or "").upper()
        if ftype == "ERROR":
            sev = "CRITICAL"
        elif ftype == "SECURITY_WARNING":
            sev = "CRITICAL"
        elif ftype == "WARNING":
            sev = "HIGH"
        elif ftype == "SUGGESTION":
            sev = "MEDIUM"
        else:
            sev = "MEDIUM"
        findings.append({
            "source": "access-analyzer/validate-policy",
            "id": f.get("issue_code") or "AA_VALIDATE",
            "severity": sev,
            "title": f.get("issue_code") or "Access Analyzer finding",
            "resource": f.get("resource"),
            "file": f.get("file"),
            "policy_name": f.get("policy_name"),
            "description": f.get("finding_details"),
            "learn_more_link": f.get("learn_more_link"),
            "locations": f.get("locations"),
        })

    # CheckAccessNotGranted
    for f in raw.get("check_access_not_granted", []) or []:
        findings.append({
            "source": "access-analyzer/check-access-not-granted",
            "id": "AA_CANG_FAIL",
            "severity": "CRITICAL",
            "title": "Policy grants a restricted action",
            "resource": f.get("resource"),
            "file": f.get("file"),
            "policy_name": f.get("policy_name"),
            "description": f.get("description") or "Policy grants an action that is on the restricted list.",
            "statement_index": f.get("statement_index"),
            "statement_id": f.get("statement_id"),
        })

    # Drift
    for f in raw.get("drift", []) or []:
        sev = "CRITICAL" if f.get("newly_grants_privileges") else "MEDIUM"
        findings.append({
            "source": "access-analyzer/drift",
            "id": "AA_DRIFT",
            "severity": sev,
            "title": "Policy drift vs. deployed IAM policy",
            "resource": f.get("resource"),
            "file": f.get("file"),
            "policy_name": f.get("policy_name"),
            "policy_arn": f.get("policy_arn"),
            "added_actions": f.get("added_actions"),
            "removed_actions": f.get("removed_actions"),
            "description": (
                f"Drift detected. Newly granted: {len(f.get('added_actions') or [])} action(s); "
                f"removed: {len(f.get('removed_actions') or [])} action(s)."
            ),
        })

    # Errors — surface as LOW so they show up in the report but never block.
    for e in raw.get("errors", []) or []:
        findings.append({
            "source": "access-analyzer/error",
            "id": "AA_ERROR",
            "severity": "LOW",
            "title": f"Access Analyzer error ({e.get('phase')})",
            "resource": e.get("resource"),
            "file": e.get("file"),
            "description": e.get("error"),
        })

    return findings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkov", required=True)
    parser.add_argument("--access-analyzer", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--summary", required=True)
    args = parser.parse_args()

    ck = _load_json(Path(args.checkov))
    aa = _load_json(Path(args.access_analyzer))

    findings = _normalize_checkov(ck) + _normalize_access_analyzer(aa)

    # Stable sort: severity (crit→low), then source, then resource
    sev_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    findings.sort(key=lambda f: (
        sev_order.get(f.get("severity", "LOW"), 9),
        f.get("source", ""),
        f.get("file") or "",
        f.get("resource") or "",
    ))

    counts = {
        "critical": sum(1 for f in findings if f["severity"] == "CRITICAL"),
        "high":     sum(1 for f in findings if f["severity"] == "HIGH"),
        "medium":   sum(1 for f in findings if f["severity"] == "MEDIUM"),
        "low":      sum(1 for f in findings if f["severity"] == "LOW"),
        "total":    len(findings),
    }

    if counts["critical"] > 0:
        gate = "block"
    elif counts["high"] > 0:
        gate = "block"
    elif counts["medium"] > 0:
        gate = "warn"
    else:
        gate = "pass"

    Path(args.output).write_text(json.dumps({
        "counts": counts,
        "gate": gate,
        "findings": findings,
    }, indent=2))
    Path(args.summary).write_text(json.dumps({"counts": counts, "gate": gate}, indent=2))
    print(f"[merge] counts={counts} gate={gate}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
