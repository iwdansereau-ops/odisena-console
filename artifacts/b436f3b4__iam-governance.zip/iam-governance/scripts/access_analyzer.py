#!/usr/bin/env python3
"""
Run AWS IAM Access Analyzer against every IAM policy discovered in the IaC
directory, plus a drift check that compares the proposed policy against the
policy currently deployed on the same role/user in the target AWS account.

Emits a normalized JSON document:

{
  "validate_policy": [ {file, policy_name, finding_type, issue_code, ...} ],
  "check_access_not_granted": [ {file, policy_name, action, ...} ],
  "drift": [ {resource, added_actions, removed_actions, ...} ],
  "errors": [ ... ]
}

Docs:
- ValidatePolicy: https://docs.aws.amazon.com/access-analyzer/latest/APIReference/API_ValidatePolicy.html
- CheckAccessNotGranted: https://docs.aws.amazon.com/access-analyzer/latest/APIReference/API_CheckAccessNotGranted.html
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Iterable

import boto3
import botocore
import yaml
from botocore.exceptions import BotoCoreError, ClientError


# --------------------------------------------------------------------------- #
# Data model
# --------------------------------------------------------------------------- #

@dataclass
class DiscoveredPolicy:
    file: str
    resource_name: str          # e.g. terraform resource address or CFN LogicalId
    policy_name: str | None     # AWS PolicyName if known
    policy_type: str            # IDENTITY_POLICY | RESOURCE_POLICY | SERVICE_CONTROL_POLICY
    document: dict[str, Any]

    def document_json(self) -> str:
        return json.dumps(self.document, sort_keys=True)


@dataclass
class Result:
    validate_policy: list[dict[str, Any]] = field(default_factory=list)
    check_access_not_granted: list[dict[str, Any]] = field(default_factory=list)
    drift: list[dict[str, Any]] = field(default_factory=list)
    errors: list[dict[str, Any]] = field(default_factory=list)
    discovered: int = 0


# --------------------------------------------------------------------------- #
# IaC discovery
# --------------------------------------------------------------------------- #

# Terraform HCL policy literal — captured as a JSON string via jsonencode(...) OR
# via the aws_iam_policy_document data source. We only handle the JSON literal
# case here (the common one). For jsonencode/data sources, users typically run
# `terraform plan -out` and Checkov consumes that plan — Access Analyzer here
# focuses on statically-embedded JSON policies which is where humans hide bugs.
TF_POLICY_JSON_RE = re.compile(
    r"policy\s*=\s*<<(?:EOT|EOF|POLICY)\s*(?P<body>.*?)\s*(?:EOT|EOF|POLICY)",
    re.DOTALL,
)
TF_POLICY_INLINE_RE = re.compile(
    r"policy\s*=\s*jsonencode\((?P<body>\{.*?\})\s*\)",
    re.DOTALL,
)


def _looks_like_iam_policy(obj: Any) -> bool:
    if not isinstance(obj, dict):
        return False
    stmt = obj.get("Statement") or obj.get("statement")
    if not stmt:
        return False
    # Normalize single-statement policies
    if isinstance(stmt, dict):
        stmt = [stmt]
    for s in stmt:
        if not isinstance(s, dict):
            return False
        if "Effect" not in s and "effect" not in s:
            return False
    return True


def _walk(obj: Any, path: list[str]) -> Iterable[tuple[list[str], Any]]:
    if isinstance(obj, dict):
        yield path, obj
        for k, v in obj.items():
            yield from _walk(v, path + [str(k)])
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _walk(v, path + [str(i)])


def discover_cloudformation(path: Path) -> list[DiscoveredPolicy]:
    """Find embedded IAM policy documents inside a CloudFormation template."""
    found: list[DiscoveredPolicy] = []
    try:
        # CFN allows YAML shortforms (!Ref etc.). We only need the structure,
        # not fidelity — replace shortforms with plain strings.
        text = path.read_text()
        text = re.sub(r"!\w+\s+", "", text)
        doc = yaml.safe_load(text)
    except Exception as e:
        return []
    if not isinstance(doc, dict):
        return []
    resources = doc.get("Resources", {}) or {}
    for logical_id, resource in resources.items():
        if not isinstance(resource, dict):
            continue
        rtype = resource.get("Type", "")
        props = resource.get("Properties", {}) or {}
        # AWS::IAM::ManagedPolicy / AWS::IAM::Policy
        if rtype in ("AWS::IAM::ManagedPolicy", "AWS::IAM::Policy"):
            pd = props.get("PolicyDocument")
            if _looks_like_iam_policy(pd):
                found.append(DiscoveredPolicy(
                    file=str(path),
                    resource_name=logical_id,
                    policy_name=props.get("ManagedPolicyName") or props.get("PolicyName"),
                    policy_type="IDENTITY_POLICY",
                    document=pd,
                ))
        # AWS::IAM::Role — inline Policies[] and AssumeRolePolicyDocument (trust)
        if rtype == "AWS::IAM::Role":
            trust = props.get("AssumeRolePolicyDocument")
            if _looks_like_iam_policy(trust):
                found.append(DiscoveredPolicy(
                    file=str(path),
                    resource_name=f"{logical_id}.AssumeRolePolicy",
                    policy_name=None,
                    policy_type="RESOURCE_POLICY",
                    document=trust,
                ))
            for inline in props.get("Policies", []) or []:
                pd = inline.get("PolicyDocument") if isinstance(inline, dict) else None
                if _looks_like_iam_policy(pd):
                    found.append(DiscoveredPolicy(
                        file=str(path),
                        resource_name=f"{logical_id}.{inline.get('PolicyName','inline')}",
                        policy_name=inline.get("PolicyName"),
                        policy_type="IDENTITY_POLICY",
                        document=pd,
                    ))
    return found


def discover_json(path: Path) -> list[DiscoveredPolicy]:
    try:
        doc = json.loads(path.read_text())
    except Exception:
        return []
    found: list[DiscoveredPolicy] = []
    # A raw policy file
    if _looks_like_iam_policy(doc):
        found.append(DiscoveredPolicy(
            file=str(path),
            resource_name=path.stem,
            policy_name=path.stem,
            policy_type="IDENTITY_POLICY",
            document=doc,
        ))
        return found
    # Search nested (e.g. a Terraform plan.json)
    for p, node in _walk(doc, []):
        if _looks_like_iam_policy(node) and node is not doc:
            found.append(DiscoveredPolicy(
                file=str(path),
                resource_name=".".join(p) or path.stem,
                policy_name=None,
                policy_type="IDENTITY_POLICY",
                document=node,
            ))
    return found


# Best-effort extractor for the enclosing resource's `name = "..."` attribute.
# We look backwards from each policy match to the nearest preceding `resource
# "aws_iam_policy" "..."` (or aws_iam_role_policy, aws_iam_user_policy, etc.)
# block and pull its `name` argument. Used to populate DiscoveredPolicy.policy_name
# so the drift check can look up the corresponding deployed AWS policy.
TF_RESOURCE_BLOCK_RE = re.compile(
    r'resource\s+"(aws_iam_[a-z_]*policy)"\s+"([^"]+)"\s*\{',
)
TF_NAME_ATTR_RE = re.compile(r'^\s*name\s*=\s*"([^"]+)"', re.MULTILINE)


def _terraform_policy_name_for_offset(text: str, offset: int) -> str | None:
    """Given the offset of a `policy = <<EOT` block, find the enclosing resource's name."""
    # Find the last `resource ... {` before this offset
    last_block = None
    for m in TF_RESOURCE_BLOCK_RE.finditer(text, 0, offset):
        last_block = m
    if not last_block:
        return None
    # Slice from the resource block opening to the policy offset and look for a
    # top-level `name = "..."` attribute inside that window.
    window = text[last_block.end():offset]
    name_match = TF_NAME_ATTR_RE.search(window)
    return name_match.group(1) if name_match else None


def discover_terraform(path: Path) -> list[DiscoveredPolicy]:
    """Extract JSON policy literals from .tf files."""
    found: list[DiscoveredPolicy] = []
    try:
        text = path.read_text()
    except Exception:
        return []
    for i, m in enumerate(TF_POLICY_JSON_RE.finditer(text)):
        body = m.group("body").strip()
        try:
            doc = json.loads(body)
        except Exception:
            continue
        if _looks_like_iam_policy(doc):
            tf_name = _terraform_policy_name_for_offset(text, m.start())
            found.append(DiscoveredPolicy(
                file=str(path),
                resource_name=f"{path.stem}.policy[{i}]",
                policy_name=tf_name,
                policy_type="IDENTITY_POLICY",
                document=doc,
            ))
    return found


def discover_all(root: Path) -> list[DiscoveredPolicy]:
    policies: list[DiscoveredPolicy] = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        suf = p.suffix.lower()
        if suf in (".yaml", ".yml"):
            policies.extend(discover_cloudformation(p))
        elif suf == ".json":
            policies.extend(discover_json(p))
        elif suf == ".tf":
            policies.extend(discover_terraform(p))
    # Deduplicate by (file, resource_name, document)
    seen = set()
    unique: list[DiscoveredPolicy] = []
    for pol in policies:
        key = (pol.file, pol.resource_name, pol.document_json())
        if key in seen:
            continue
        seen.add(key)
        unique.append(pol)
    return unique


# --------------------------------------------------------------------------- #
# Access Analyzer calls
# --------------------------------------------------------------------------- #

def run_validate_policy(client, pol: DiscoveredPolicy, result: Result) -> None:
    """Call ValidatePolicy and record every finding."""
    try:
        paginator = client.get_paginator("validate_policy")
        pages = paginator.paginate(
            policyDocument=json.dumps(pol.document),
            policyType=pol.policy_type,
        )
        for page in pages:
            for f in page.get("findings", []):
                result.validate_policy.append({
                    "file": pol.file,
                    "resource": pol.resource_name,
                    "policy_name": pol.policy_name,
                    "finding_type": f.get("findingType"),
                    "issue_code": f.get("issueCode"),
                    "finding_details": f.get("findingDetails"),
                    "learn_more_link": f.get("learnMoreLink"),
                    "locations": [
                        {
                            "path": [
                                seg.get("value") if isinstance(seg, dict) else seg
                                for seg in loc.get("path", [])
                            ],
                            "span": loc.get("span"),
                        }
                        for loc in f.get("locations", [])
                    ],
                })
    except (ClientError, BotoCoreError) as e:
        result.errors.append({
            "phase": "validate_policy",
            "file": pol.file,
            "resource": pol.resource_name,
            "error": str(e),
        })


def run_check_access_not_granted(
    client, pol: DiscoveredPolicy, critical_actions: list[dict[str, Any]], result: Result
) -> None:
    """
    CheckAccessNotGranted returns PASS if the policy does NOT grant the given
    accesses. FAIL means the policy WOULD grant one of them → block.
    """
    if not critical_actions:
        return
    try:
        resp = client.check_access_not_granted(
            policyDocument=json.dumps(pol.document),
            access=critical_actions,
            policyType=pol.policy_type,
        )
    except ClientError as e:
        # Trust policies aren't supported by this API — skip quietly.
        code = e.response.get("Error", {}).get("Code", "")
        if code in ("ValidationException", "InvalidParameterException") and pol.policy_type == "RESOURCE_POLICY":
            return
        result.errors.append({
            "phase": "check_access_not_granted",
            "file": pol.file,
            "resource": pol.resource_name,
            "error": str(e),
        })
        return
    except BotoCoreError as e:
        result.errors.append({
            "phase": "check_access_not_granted",
            "file": pol.file,
            "resource": pol.resource_name,
            "error": str(e),
        })
        return

    if resp.get("result") == "FAIL":
        for reason in resp.get("reasons", []) or [{"description": resp.get("message", "policy grants a restricted action")}]:
            result.check_access_not_granted.append({
                "file": pol.file,
                "resource": pol.resource_name,
                "policy_name": pol.policy_name,
                "description": reason.get("description"),
                "statement_index": reason.get("statementIndex"),
                "statement_id": reason.get("statementId"),
            })


# --------------------------------------------------------------------------- #
# Drift check
# --------------------------------------------------------------------------- #

def _collect_actions(document: dict[str, Any]) -> set[str]:
    """Flatten every Action/NotAction from every Allow statement."""
    actions: set[str] = set()
    stmts = document.get("Statement") or []
    if isinstance(stmts, dict):
        stmts = [stmts]
    for s in stmts:
        if not isinstance(s, dict):
            continue
        if str(s.get("Effect", "")).lower() != "allow":
            continue
        for key in ("Action", "action", "NotAction", "notAction"):
            v = s.get(key)
            if v is None:
                continue
            if isinstance(v, str):
                actions.add(v)
            elif isinstance(v, list):
                actions.update(x for x in v if isinstance(x, str))
    return actions


def run_drift_check(pol: DiscoveredPolicy, iam_client, result: Result) -> None:
    """
    If a policy_name matches a currently deployed IAM managed policy, diff the
    proposed permissions against the live version. Any newly granted action
    triggers a finding. Silent no-op if the policy isn't currently deployed.
    """
    if not pol.policy_name:
        return
    try:
        # Look up the policy by name across account-managed policies
        paginator = iam_client.get_paginator("list_policies")
        arn = None
        for page in paginator.paginate(Scope="Local", OnlyAttached=False):
            for p in page.get("Policies", []):
                if p["PolicyName"] == pol.policy_name:
                    arn = p["Arn"]
                    default_ver = p["DefaultVersionId"]
                    break
            if arn:
                break
        if not arn:
            return
        v = iam_client.get_policy_version(PolicyArn=arn, VersionId=default_ver)
        live_doc = v["PolicyVersion"]["Document"]
        # boto returns a URL-encoded string sometimes; PolicyVersion.Document is a dict
        if isinstance(live_doc, str):
            live_doc = json.loads(live_doc)
        live_actions = _collect_actions(live_doc)
        proposed_actions = _collect_actions(pol.document)
        added = sorted(proposed_actions - live_actions)
        removed = sorted(live_actions - proposed_actions)
        if added or removed:
            result.drift.append({
                "file": pol.file,
                "resource": pol.resource_name,
                "policy_name": pol.policy_name,
                "policy_arn": arn,
                "added_actions": added,
                "removed_actions": removed,
                "newly_grants_privileges": bool(added),
            })
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")
        if code in ("NoSuchEntity", "AccessDenied"):
            return
        result.errors.append({
            "phase": "drift",
            "file": pol.file,
            "resource": pol.resource_name,
            "error": str(e),
        })


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--iac-dir", required=True, help="Directory containing IaC")
    parser.add_argument("--output", required=True, help="Path to write result JSON")
    parser.add_argument(
        "--critical-actions",
        default="templates/critical_actions.json",
        help="JSON file listing actions that must never be granted",
    )
    parser.add_argument("--region", default=os.environ.get("AWS_REGION", "us-east-1"))
    parser.add_argument("--base-ref", default=None, help="Base commit SHA (unused — reserved for future diff-only mode)")
    parser.add_argument("--skip-aws", action="store_true", help="Skip AWS API calls (offline dry-run)")
    args = parser.parse_args()

    result = Result()
    root = Path(args.iac_dir)
    if not root.exists():
        result.errors.append({"phase": "discover", "error": f"IaC dir '{root}' not found"})
        Path(args.output).write_text(json.dumps(asdict(result), indent=2))
        return 0

    policies = discover_all(root)
    result.discovered = len(policies)
    print(f"[access-analyzer] discovered {len(policies)} IAM policy documents in {root}")

    # Load critical actions list
    critical_actions: list[dict[str, Any]] = []
    ca_path = Path(args.critical_actions)
    if ca_path.exists():
        try:
            critical_actions = json.loads(ca_path.read_text())
        except Exception as e:
            result.errors.append({"phase": "load_critical_actions", "error": str(e)})

    if args.skip_aws or not policies:
        Path(args.output).write_text(json.dumps(asdict(result), indent=2))
        print(f"[access-analyzer] wrote {args.output} (skip-aws={args.skip_aws})")
        return 0

    try:
        session = boto3.session.Session(region_name=args.region)
        aa_client = session.client("accessanalyzer")
        iam_client = session.client("iam")
    except (BotoCoreError, ClientError) as e:
        result.errors.append({"phase": "session", "error": str(e)})
        Path(args.output).write_text(json.dumps(asdict(result), indent=2))
        return 0

    for pol in policies:
        run_validate_policy(aa_client, pol, result)
        run_check_access_not_granted(aa_client, pol, critical_actions, result)
        run_drift_check(pol, iam_client, result)

    Path(args.output).write_text(json.dumps(asdict(result), indent=2))
    print(
        f"[access-analyzer] validate={len(result.validate_policy)} "
        f"cang={len(result.check_access_not_granted)} "
        f"drift={len(result.drift)} errors={len(result.errors)}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
