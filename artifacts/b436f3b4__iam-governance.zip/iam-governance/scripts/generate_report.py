#!/usr/bin/env python3
"""Render the merged findings JSON into an HTML audit report via Jinja2."""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--findings", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--pr-number", default=None)
    parser.add_argument("--commit", default=None)
    parser.add_argument("--repo", default="local")
    parser.add_argument("--template-dir", default="templates")
    parser.add_argument("--template", default="report.html.j2")
    args = parser.parse_args()

    data = json.loads(Path(args.findings).read_text())
    env = Environment(
        loader=FileSystemLoader(args.template_dir),
        autoescape=select_autoescape(["html", "xml"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    tmpl = env.get_template(args.template)
    html = tmpl.render(
        counts=data.get("counts", {"critical": 0, "high": 0, "medium": 0, "low": 0, "total": 0}),
        gate=data.get("gate", "pass"),
        findings=data.get("findings", []),
        pr_number=args.pr_number,
        commit=args.commit,
        repo=args.repo,
        generated_at=dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
    )
    Path(args.output).write_text(html)
    print(f"[report] wrote {args.output} ({len(html):,} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
