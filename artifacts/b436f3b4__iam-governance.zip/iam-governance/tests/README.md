# Test suites

Two independent suites live under `tests/`:

| Suite | File | What it covers | Runs on |
|---|---|---|---|
| Severity/gate mapping | `test_merge_findings.py` | Every path through `scripts/merge_findings.py`: severity mapping (Checkov priv-esc → CRITICAL, Access Analyzer ERROR → CRITICAL, SUGGESTION → MEDIUM, etc.), gate decision (`pass` / `warn` / `block`), and the guarantee that internal errors never block a merge. | Every PR (via `iam-governance.yml`) |
| Drift-detection regression | `run_drift_regression.py` + `drift_fixtures/` | Every path through the drift-check in `scripts/access_analyzer.py`: known privilege-escalation drifts (PassRole, DeleteBucket, KMS deletion, wildcard, StopLogging), removal-only diffs, no-drift refactors, and never-deployed policies. Uses a mock IAM client — zero AWS calls. | Every push to `main` and every PR touching the analyzer, its tests, or fixtures (via `drift-regression.yml`) |

## Running locally

```bash
# Drift regression (fast, hermetic, no AWS)
python tests/run_drift_regression.py --verbose

# With JUnit output for CI dashboards
python tests/run_drift_regression.py --junit drift.xml

# Severity/gate unit tests
python -c "import sys, importlib.util, inspect, tempfile, pathlib
spec = importlib.util.spec_from_file_location('t', 'tests/test_merge_findings.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
for name, fn in inspect.getmembers(m, inspect.isfunction):
    if name.startswith('test_'):
        with tempfile.TemporaryDirectory() as d: fn(pathlib.Path(d))
        print('PASS', name)"
```

## Drift fixture layout

Each fixture directory contains **exactly three files**:

| File | Purpose |
|---|---|
| `baseline.json` | The IAM policy document simulated as currently deployed in AWS. The mock IAM client returns this when queried by `policy_name`. A body of `null` means "not deployed" (exercises the drift check's early-return path). |
| `proposed.tf` **or** `proposed.yaml` | The IaC file the PR would introduce. This is what `discover_all()` in `access_analyzer.py` scans. |
| `expected.json` | Assertion contract. Fields: `policy_name`, `expected_drift_count`, `expected_added_actions`, `expected_removed_actions`, `expected_newly_grants_privileges`, plus a human-readable `description`. |

## Adding a new fixture

1. `mkdir tests/drift_fixtures/11_your_scenario/`
2. Write `baseline.json` — the current deployed policy.
3. Write `proposed.tf` or `proposed.yaml` — the PR's change. The `name` (Terraform) or `ManagedPolicyName` (CloudFormation) must match `expected.policy_name`.
4. Write `expected.json` — the exact drift shape the runner should see.
5. `python tests/run_drift_regression.py -v` — confirm it passes.

The runner discovers fixtures by directory listing; no registration step required.

## Why not just use real AWS in CI?

- **Speed** — the full 10-fixture suite runs in ~10 ms. A round trip to `iam:GetPolicyVersion` alone is 50–200 ms per call.
- **Determinism** — real deployed IAM policies drift on their own (people edit them). Regression tests must be immune to that.
- **Safety** — no OIDC federation, no credentials, nothing to leak or misconfigure. Contributors can fork the repo and run the suite immediately.
- **Coverage** — mocks let us test the "policy not deployed" path (fixture 10) without actually undeploying a policy.

The **live** drift check still runs on real AWS in the main `iam-governance.yml` workflow. This suite guarantees the *logic* stays correct; the live workflow proves the *integration* stays wired.
