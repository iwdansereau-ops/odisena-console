# Fixture 06: proposal REMOVES s3:DeleteObject but adds nothing. Drift should
# report the removal (for visibility) but newly_grants_privileges must be FALSE
# — tightening scope should never block a merge.
resource "aws_iam_policy" "regression_06_removal_only" {
  name = "regression-06-removal-only"
  policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:PutObject"],
      "Resource": "arn:aws:s3:::app-data/*"
    }
  ]
}
EOT
}
