# Fixture 09: adds several unrelated actions at once — verifies the analyzer
# reports the FULL added set, not just the first one it sees.
resource "aws_iam_policy" "regression_09_multi_added" {
  name = "regression-09-multi-added"
  policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem",
        "dynamodb:Query",
        "dynamodb:PutItem",
        "dynamodb:UpdateItem",
        "dynamodb:DeleteItem",
        "iam:CreateAccessKey"
      ],
      "Resource": "*"
    }
  ]
}
EOT
}
