# Fixture 04: widens ec2:Describe* into a bare "*" wildcard. Every previously
# scoped Describe call is now a totally different superset — the drift check
# must report "*" as newly added and the two Describe actions as removed.
resource "aws_iam_policy" "regression_04_add_wildcard" {
  name = "regression-04-add-wildcard"
  policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "*",
      "Resource": "*"
    }
  ]
}
EOT
}
