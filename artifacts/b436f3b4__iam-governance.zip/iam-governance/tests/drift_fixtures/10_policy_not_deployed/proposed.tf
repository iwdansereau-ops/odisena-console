# Fixture 10: a brand-new policy that is NOT yet deployed. The drift check
# should silently skip it (no baseline to diff against). This guards against
# the analyzer incorrectly reporting every action of a fresh policy as "added".
resource "aws_iam_policy" "regression_10_policy_not_deployed" {
  name = "regression-10-policy-not-deployed"
  policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["sqs:SendMessage", "sqs:ReceiveMessage"],
      "Resource": "arn:aws:sqs:*:*:jobs"
    }
  ]
}
EOT
}
