# Fixture 08: adds cloudtrail:StopLogging and cloudtrail:DeleteTrail — a
# classic "cover your tracks" escalation. Both are on the critical actions list.
resource "aws_iam_policy" "regression_08_tf_add_stop_cloudtrail" {
  name = "regression-08-tf-add-stop-cloudtrail"
  policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "cloudtrail:LookupEvents",
        "cloudtrail:GetTrail",
        "cloudtrail:StopLogging",
        "cloudtrail:DeleteTrail"
      ],
      "Resource": "*"
    }
  ]
}
EOT
}
