# Fixture 05: identical action set — only a comment/formatting change in the
# proposed policy. The drift check MUST NOT fire; a false positive here would
# spam every innocuous IaC refactor.
resource "aws_iam_policy" "regression_05_no_drift" {
  name = "regression-05-no-drift"
  policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "SameActionsDifferentSid",
      "Effect": "Allow",
      "Action": ["s3:ListBucket", "s3:GetObject"],
      "Resource": "arn:aws:s3:::app-data/*"
    }
  ]
}
EOT
}
