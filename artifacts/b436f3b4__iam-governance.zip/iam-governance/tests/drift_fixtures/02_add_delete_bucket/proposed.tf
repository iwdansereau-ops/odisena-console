# Fixture 02: adds s3:DeleteBucket — irreversible data loss surface.
resource "aws_iam_policy" "regression_02_add_delete_bucket" {
  name = "regression-02-add-delete-bucket"
  policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:PutObject", "s3:ListBucket", "s3:DeleteBucket"],
      "Resource": "arn:aws:s3:::app-data/*"
    }
  ]
}
EOT
}
