# Fixture 01: adds iam:PassRole on * — a classic privilege-escalation vector.
# The baseline only grants s3 read; the drift check must flag PassRole as newly added.
resource "aws_iam_policy" "regression_01_add_passrole" {
  name = "regression-01-add-passrole"
  policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ReadBucket",
      "Effect": "Allow",
      "Action": ["s3:GetObject", "s3:ListBucket"],
      "Resource": "arn:aws:s3:::app-data/*"
    },
    {
      "Sid": "AddedPassRole",
      "Effect": "Allow",
      "Action": "iam:PassRole",
      "Resource": "*"
    }
  ]
}
EOT
}
