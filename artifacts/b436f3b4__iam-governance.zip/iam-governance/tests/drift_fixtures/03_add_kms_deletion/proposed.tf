# Fixture 03: adds both kms:ScheduleKeyDeletion and kms:DisableKey. Both are
# on the critical actions list and would allow an attacker to render encrypted
# data unrecoverable.
resource "aws_iam_policy" "regression_03_add_kms_deletion" {
  name = "regression-03-add-kms-deletion"
  policy = <<EOT
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "kms:Encrypt",
        "kms:Decrypt",
        "kms:GenerateDataKey",
        "kms:ScheduleKeyDeletion",
        "kms:DisableKey"
      ],
      "Resource": "arn:aws:kms:us-east-1:111122223333:key/abc"
    }
  ]
}
EOT
}
