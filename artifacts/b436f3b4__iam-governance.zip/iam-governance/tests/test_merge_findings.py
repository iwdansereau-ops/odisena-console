"""Unit tests for scripts/merge_findings.py — focused on gate logic and severity mapping."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "merge_findings.py"


def _run(tmp_path: Path, checkov: dict, access_analyzer: dict) -> dict:
    ck = tmp_path / "ck.json"
    aa = tmp_path / "aa.json"
    out = tmp_path / "out.json"
    summ = tmp_path / "summ.json"
    ck.write_text(json.dumps(checkov))
    aa.write_text(json.dumps(access_analyzer))
    subprocess.run(
        [sys.executable, str(SCRIPT),
         "--checkov", str(ck),
         "--access-analyzer", str(aa),
         "--output", str(out),
         "--summary", str(summ)],
        check=True,
    )
    return json.loads(out.read_text())


def test_clean_input_passes(tmp_path):
    doc = _run(tmp_path,
               {"results": {"failed_checks": []}},
               {"validate_policy": [], "check_access_not_granted": [], "drift": [], "errors": []})
    assert doc["counts"]["total"] == 0
    assert doc["gate"] == "pass"


def test_priv_esc_check_is_critical(tmp_path):
    doc = _run(tmp_path,
               {"results": {"failed_checks": [
                   {"check_id": "CKV_AWS_49", "check_name": "Admin wildcard",
                    "resource": "aws_iam_policy.bad", "file_path": "iac/example.tf"}
               ]}},
               {"validate_policy": [], "check_access_not_granted": [], "drift": [], "errors": []})
    assert doc["counts"]["critical"] == 1
    assert doc["gate"] == "block"


def test_access_analyzer_error_finding_is_critical(tmp_path):
    doc = _run(tmp_path,
               {"results": {"failed_checks": []}},
               {"validate_policy": [{
                   "file": "iac/x.yaml", "resource": "Role1", "policy_name": None,
                   "finding_type": "ERROR", "issue_code": "INVALID_SERVICE_PRINCIPAL",
                   "finding_details": "boom", "locations": []
               }], "check_access_not_granted": [], "drift": [], "errors": []})
    assert doc["counts"]["critical"] == 1
    assert doc["gate"] == "block"


def test_check_access_not_granted_fail_is_critical(tmp_path):
    doc = _run(tmp_path,
               {"results": {"failed_checks": []}},
               {"validate_policy": [], "check_access_not_granted": [{
                   "file": "iac/x.tf", "resource": "policy1", "policy_name": "p",
                   "description": "grants iam:PassRole on *"
               }], "drift": [], "errors": []})
    assert doc["counts"]["critical"] == 1
    assert doc["gate"] == "block"


def test_drift_new_privilege_is_critical(tmp_path):
    doc = _run(tmp_path,
               {"results": {"failed_checks": []}},
               {"validate_policy": [], "check_access_not_granted": [], "drift": [{
                   "file": "iac/x.tf", "resource": "policy1", "policy_name": "p",
                   "policy_arn": "arn:aws:iam::123:policy/p",
                   "added_actions": ["ec2:TerminateInstances"], "removed_actions": [],
                   "newly_grants_privileges": True
               }], "errors": []})
    assert doc["counts"]["critical"] == 1
    assert doc["gate"] == "block"


def test_suggestion_is_medium_and_warns(tmp_path):
    doc = _run(tmp_path,
               {"results": {"failed_checks": []}},
               {"validate_policy": [{
                   "file": "iac/x.yaml", "resource": "Role1", "policy_name": None,
                   "finding_type": "SUGGESTION", "issue_code": "REDUNDANT_ACTION",
                   "finding_details": "s3:Get* already covers this", "locations": []
               }], "check_access_not_granted": [], "drift": [], "errors": []})
    assert doc["counts"]["medium"] == 1
    assert doc["gate"] == "warn"


def test_errors_are_low_and_never_block(tmp_path):
    doc = _run(tmp_path,
               {"results": {"failed_checks": []}},
               {"validate_policy": [], "check_access_not_granted": [], "drift": [],
                "errors": [{"phase": "validate_policy", "file": "x", "resource": "y", "error": "timeout"}]})
    assert doc["counts"]["low"] == 1
    assert doc["gate"] == "pass"
