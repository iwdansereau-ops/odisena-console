#!/usr/bin/env python3
"""
Regression test runner for IAM policy drift detection.

Reads every fixture in tests/drift_fixtures/, invokes the drift-check function
from scripts/access_analyzer.py against each proposed IaC file with a mocked
IAM client (fed by the fixture's baseline.json), and asserts the drift result
matches the fixture's expected.json.

Zero AWS calls. Deterministic. Runs in a few seconds.

Exit code is 0 on full-pass, 1 if any fixture fails.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
FIXTURES_DIR = ROOT / "tests" / "drift_fixtures"
sys.path.insert(0, str(ROOT / "scripts"))

# Import the real functions under test — never re-implement them here, or the
# regression suite would only be testing itself.
from access_analyzer import (  # noqa: E402
    Result,
    discover_all,
    run_drift_check,
)


# --------------------------------------------------------------------------- #
# Mock IAM client
# --------------------------------------------------------------------------- #

class MockIamPaginator:
    """Emulates the boto3 iam.get_paginator('list_policies') interface."""

    def __init__(self, policies: list[dict[str, str]]):
        self._policies = policies

    def paginate(self, **_kwargs) -> list[dict[str, Any]]:
        # Single page is sufficient for the test volume
        return [{"Policies": self._policies}]


class MockIamClient:
    """
    Minimal boto3-shaped IAM client with just the surface `run_drift_check`
    calls: `get_paginator('list_policies')` and `get_policy_version(...)`.

    Backing data comes from the union of every fixture's baseline.json. A
    baseline with body `null` (fixture 10) is treated as "not deployed" — the
    policy name is omitted from the list, exercising the drift-check's
    early-return path.
    """

    def __init__(self, baselines: dict[str, dict[str, Any]], account_id: str = "111122223333"):
        self._baselines = baselines
        self._account_id = account_id
        self._arn_by_name = {
            name: f"arn:aws:iam::{account_id}:policy/{name}"
            for name in baselines
        }

    # ---- paginator (list_policies) ----
    def get_paginator(self, op_name: str):
        assert op_name == "list_policies", f"unexpected paginator: {op_name}"
        return MockIamPaginator([
            {
                "PolicyName": name,
                "Arn": self._arn_by_name[name],
                "DefaultVersionId": "v1",
            }
            for name in self._baselines
        ])

    # ---- direct call (get_policy_version) ----
    def get_policy_version(self, PolicyArn: str, VersionId: str) -> dict[str, Any]:  # noqa: N803
        for name, arn in self._arn_by_name.items():
            if arn == PolicyArn:
                return {"PolicyVersion": {
                    "Document": self._baselines[name],
                    "VersionId": VersionId,
                    "IsDefaultVersion": True,
                }}
        # Mirror the real client's behavior
        from botocore.exceptions import ClientError
        raise ClientError(
            {"Error": {"Code": "NoSuchEntity", "Message": "policy not found"}},
            "GetPolicyVersion",
        )


# --------------------------------------------------------------------------- #
# Fixture loader
# --------------------------------------------------------------------------- #

@dataclass
class Fixture:
    name: str
    dir: Path
    proposed_file: Path
    expected: dict[str, Any]
    baseline: dict[str, Any] | None   # None = "not deployed"


def load_fixtures(root: Path) -> list[Fixture]:
    fixtures: list[Fixture] = []
    for d in sorted(p for p in root.iterdir() if p.is_dir()):
        expected_path = d / "expected.json"
        baseline_path = d / "baseline.json"
        # Find the single proposed IaC file (either .tf or .yaml/.yml)
        proposed_candidates = [
            *(d.glob("proposed.tf")),
            *(d.glob("proposed.yaml")),
            *(d.glob("proposed.yml")),
        ]
        if not (expected_path.exists() and baseline_path.exists() and proposed_candidates):
            print(f"[skip] {d.name} — missing baseline/proposed/expected")
            continue
        baseline = json.loads(baseline_path.read_text())
        expected = json.loads(expected_path.read_text())
        fixtures.append(Fixture(
            name=d.name,
            dir=d,
            proposed_file=proposed_candidates[0],
            expected=expected,
            baseline=baseline,  # may be None (fixture 10)
        ))
    return fixtures


# --------------------------------------------------------------------------- #
# Assertion helpers
# --------------------------------------------------------------------------- #

def _lists_equal_as_sets(actual: list[str] | None, expected: list[str] | None) -> bool:
    return sorted(actual or []) == sorted(expected or [])


def assert_fixture(fx: Fixture, actual_drift: list[dict[str, Any]]) -> tuple[bool, list[str]]:
    """Compare actual drift findings for a fixture against its expected.json."""
    errors: list[str] = []
    exp_count = fx.expected["expected_drift_count"]

    if len(actual_drift) != exp_count:
        errors.append(
            f"expected {exp_count} drift finding(s), got {len(actual_drift)}: "
            f"{json.dumps(actual_drift)[:400]}"
        )
        return False, errors

    if exp_count == 0:
        # No further shape to check
        return True, errors

    # Match by policy_name — a fixture may produce multiple findings if the
    # proposed file contains several policies, but our fixtures each hold one.
    matched = [f for f in actual_drift if f.get("policy_name") == fx.expected["policy_name"]]
    if not matched:
        errors.append(
            f"no drift finding for policy_name={fx.expected['policy_name']!r} "
            f"in {[f.get('policy_name') for f in actual_drift]}"
        )
        return False, errors

    finding = matched[0]

    if not _lists_equal_as_sets(finding.get("added_actions"), fx.expected["expected_added_actions"]):
        errors.append(
            f"added_actions mismatch: expected {fx.expected['expected_added_actions']}, "
            f"got {finding.get('added_actions')}"
        )
    if not _lists_equal_as_sets(finding.get("removed_actions"), fx.expected["expected_removed_actions"]):
        errors.append(
            f"removed_actions mismatch: expected {fx.expected['expected_removed_actions']}, "
            f"got {finding.get('removed_actions')}"
        )
    if bool(finding.get("newly_grants_privileges")) != bool(fx.expected["expected_newly_grants_privileges"]):
        errors.append(
            f"newly_grants_privileges mismatch: expected "
            f"{fx.expected['expected_newly_grants_privileges']}, "
            f"got {finding.get('newly_grants_privileges')}"
        )
    return not errors, errors


# --------------------------------------------------------------------------- #
# Runner
# --------------------------------------------------------------------------- #

def run(fixtures_dir: Path, verbose: bool, junit_path: Path | None) -> int:
    fixtures = load_fixtures(fixtures_dir)
    if not fixtures:
        print(f"[fail] no fixtures discovered under {fixtures_dir}")
        return 1

    # Build ONE shared mock client seeded with every baseline that has a
    # non-null body. This mirrors reality: the analyzer scans everything and
    # only finds matches for the subset of policies actually deployed.
    baselines_map = {
        fx.expected["policy_name"]: fx.baseline
        for fx in fixtures
        if fx.baseline is not None
    }
    iam_client = MockIamClient(baselines_map)

    print(f"Running {len(fixtures)} drift regression fixture(s) from {fixtures_dir}\n")
    passed: list[str] = []
    failed: list[tuple[str, list[str], float]] = []
    junit_cases: list[dict[str, Any]] = []

    for fx in fixtures:
        t0 = time.perf_counter()
        # Discover IAM policies in ONLY this fixture's proposed IaC. The
        # discover_all() function walks a directory, so pass the fixture dir
        # (baseline.json is a raw IAM policy — discover_json will pick it up
        # too, but its resource name won't match the expected policy_name so
        # it can't produce a false-positive drift finding).
        policies = discover_all(fx.dir)
        # Filter down to policies matching the fixture's proposed file; this
        # avoids the baseline.json being mistaken for a proposed policy.
        proposed_policies = [
            p for p in policies
            if Path(p.file).name == fx.proposed_file.name
        ]

        result = Result()
        for pol in proposed_policies:
            run_drift_check(pol, iam_client, result)

        ok, errors = assert_fixture(fx, result.drift)
        dt = time.perf_counter() - t0

        if ok:
            passed.append(fx.name)
            print(f"  ✓ {fx.name}  ({dt*1000:.0f} ms) — {fx.expected['description']}")
            junit_cases.append({"name": fx.name, "time": dt, "failure": None})
        else:
            failed.append((fx.name, errors, dt))
            print(f"  ✗ {fx.name}  ({dt*1000:.0f} ms)")
            for e in errors:
                print(f"      - {e}")
            junit_cases.append({"name": fx.name, "time": dt, "failure": "; ".join(errors)})

        if verbose:
            print(f"      discovered={len(policies)}  proposed={len(proposed_policies)}  drift={len(result.drift)}")

    total = len(fixtures)
    print(f"\n{'='*72}")
    print(f"Passed: {len(passed)}/{total}  Failed: {len(failed)}/{total}")
    if failed:
        print("\nFailed fixtures:")
        for name, errs, _ in failed:
            print(f"  - {name}")
            for e in errs:
                print(f"      {e}")

    if junit_path:
        _write_junit(junit_path, junit_cases)
        print(f"\nJUnit report written to {junit_path}")

    return 0 if not failed else 1


def _write_junit(path: Path, cases: list[dict[str, Any]]) -> None:
    """Emit a minimal JUnit XML so GitHub Actions can render results natively."""
    from xml.sax.saxutils import escape
    failures = sum(1 for c in cases if c["failure"])
    total_time = sum(c["time"] for c in cases)
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        f'<testsuite name="drift-regression" tests="{len(cases)}" failures="{failures}" time="{total_time:.3f}">',
    ]
    for c in cases:
        lines.append(f'  <testcase classname="drift" name="{escape(c["name"])}" time="{c["time"]:.3f}">')
        if c["failure"]:
            lines.append(f'    <failure message="assertion failed">{escape(c["failure"])}</failure>')
        lines.append("  </testcase>")
    lines.append("</testsuite>")
    path.write_text("\n".join(lines))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixtures-dir", default=str(FIXTURES_DIR))
    parser.add_argument("--verbose", "-v", action="store_true")
    parser.add_argument("--junit", default=None, help="Optional JUnit XML output path")
    args = parser.parse_args()

    return run(
        fixtures_dir=Path(args.fixtures_dir),
        verbose=args.verbose,
        junit_path=Path(args.junit) if args.junit else None,
    )


if __name__ == "__main__":
    raise SystemExit(main())
