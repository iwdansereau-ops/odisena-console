# IAM Policy Governance CI/CD

Automated IAM policy governance for CloudFormation and Terraform via GitHub Actions. Every pull request is scanned for privilege-escalation risks, IAM misconfigurations, and drift against deployed AWS infrastructure using **Checkov** and **AWS IAM Access Analyzer**. Findings are posted as an HTML audit report in a PR comment and critical violations block the merge. Authentication uses **AWS OIDC** — no long-lived credentials.

---

## Architecture

```
┌───────────────────┐    OIDC     ┌──────────────────────┐
│  GitHub Actions   │────────────▶│  AWS STS AssumeRole  │
│  (Pull Request)   │             │  (short-lived creds) │
└─────────┬─────────┘             └──────────┬───────────┘
          │                                  │
          ▼                                  ▼
┌───────────────────┐             ┌──────────────────────┐
│  Checkov scan     │             │  IAM Access Analyzer │
│  (static, IaC)    │             │  ValidatePolicy +    │
│                   │             │  CheckAccessNotGranted│
└─────────┬─────────┘             └──────────┬───────────┘
          │                                  │
          └──────────────┬───────────────────┘
                         ▼
              ┌────────────────────┐
              │  Merge findings    │
              │  HTML report       │
              │  PR comment        │
              │  Exit non-zero on  │
              │  CRITICAL findings │
              └────────────────────┘
```

### Two-layer defense

| Layer | Tool | What it catches |
|-------|------|-----------------|
| **Static** | Checkov | Wildcards (`Action: "*"`, `Resource: "*"`), overly permissive assume-role trust, missing conditions, known privilege-escalation patterns (CKV_AWS_* / CKV2_AWS_*) |
| **AWS-native** | Access Analyzer `ValidatePolicy` | Syntax and best-practice findings validated by AWS's own service (ERROR / SECURITY_WARNING / SUGGESTION / WARNING) |
| **AWS-native** | Access Analyzer `CheckAccessNotGranted` | Verifies the policy does **not** grant a set of critical actions (e.g. `iam:PassRole` on `*`, `s3:DeleteBucket`, `kms:ScheduleKeyDeletion`) — drift/blast-radius guard |
| **Drift** | Compare against live IAM | Diffs the proposed policy against the currently deployed policy on the same role/user, flags newly granted permissions |

---

## Repository layout

```
.
├── .github/workflows/iam-governance.yml   # PR pipeline
├── scripts/
│   ├── run_checkov.sh                     # Checkov invocation
│   ├── access_analyzer.py                 # ValidatePolicy + CheckAccessNotGranted + drift
│   ├── merge_findings.py                  # Combine Checkov + Access Analyzer results
│   ├── generate_report.py                 # HTML audit report
│   └── post_comment.py                    # Post/update PR comment
├── templates/
│   ├── report.html.j2                     # Jinja2 report template
│   └── critical_actions.json              # Actions that must never be granted
├── iac/
│   ├── terraform/example.tf               # Sample Terraform IAM
│   └── cloudformation/example.yaml        # Sample CloudFormation IAM
├── setup/
│   ├── github-oidc-role.yaml              # One-shot CloudFormation to bootstrap OIDC + IAM role
│   └── README.md                          # Deployment instructions
├── tests/
│   ├── test_merge_findings.py             # Unit tests for merger + gate logic
│   ├── run_drift_regression.py            # Regression suite for drift detection
│   ├── drift_fixtures/                    # Baseline + proposed + expected trios
│   └── README.md                          # Test docs and fixture format
├── .checkov.yaml                          # Checkov config (frameworks, skips, severity)
└── requirements.txt
```

---

## Quick start

### 1. Bootstrap AWS OIDC + IAM role (one time)

```bash
aws cloudformation deploy \
  --template-file setup/github-oidc-role.yaml \
  --stack-name github-iam-governance-oidc \
  --parameter-overrides \
      GitHubOrg=<your-org> \
      GitHubRepo=<your-repo> \
  --capabilities CAPABILITY_NAMED_IAM
```

Copy the `RoleArn` output into your GitHub repo:

**Settings → Secrets and variables → Actions → New repository variable**
- `AWS_ROLE_ARN` = `arn:aws:iam::<account>:role/github-iam-governance`
- `AWS_REGION` = `us-east-1`

### 2. Drop the workflow into any repo containing IaC

Copy `.github/workflows/iam-governance.yml` to the target repo. The workflow runs automatically on every PR that touches `.tf`, `.yaml`, `.yml`, or `.json` files.

### 3. Merge protection

**Settings → Branches → Branch protection rules → Require status checks**
- Require `iam-governance / scan` to pass before merging.

---

## How merges get blocked

The pipeline exits with a non-zero code — and therefore fails the required check — when any of the following occur:

1. Checkov reports a finding at severity **HIGH** or **CRITICAL** that is not explicitly skipped in `.checkov.yaml`.
2. Access Analyzer `ValidatePolicy` returns an `ERROR` or `SECURITY_WARNING` finding.
3. `CheckAccessNotGranted` reports that the policy **would** grant any action listed in `templates/critical_actions.json`.
4. Drift check detects that the PR grants a new permission not present on the currently deployed role.

Non-blocking findings (LOW / MEDIUM / SUGGESTION) still appear in the report for visibility.

---

## Local dry-run

```bash
pip install -r requirements.txt
export AWS_REGION=us-east-1
bash scripts/run_checkov.sh iac/ .checkov-output.json
python scripts/access_analyzer.py --iac-dir iac/ --output .aa-output.json
python scripts/merge_findings.py \
    --checkov .checkov-output.json \
    --access-analyzer .aa-output.json \
    --output findings.json
python scripts/generate_report.py --findings findings.json --output report.html
open report.html
```

---

## References

- [AWS IAM Access Analyzer — ValidatePolicy](https://docs.aws.amazon.com/access-analyzer/latest/APIReference/API_ValidatePolicy.html)
- [AWS IAM Access Analyzer — CheckAccessNotGranted](https://docs.aws.amazon.com/access-analyzer/latest/APIReference/API_CheckAccessNotGranted.html)
- [Checkov IAM policies](https://www.checkov.io/5.Policy%20Index/all.html)
- [Configuring OpenID Connect in AWS from GitHub](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services)

---

## Regression testing

A hermetic drift-detection regression suite lives in `tests/drift_fixtures/` and is executed by `tests/run_drift_regression.py`. Each fixture is a triple of `baseline.json` (simulated-deployed policy), `proposed.tf`/`proposed.yaml` (what the PR would introduce), and `expected.json` (assertion contract). A mock IAM client feeds the baseline into `run_drift_check()`, so tests run in milliseconds with zero AWS calls.

The workflow at `.github/workflows/drift-regression.yml` runs the suite on every push to `main` (and on PRs that touch the analyzer, its tests, or fixtures) across Python 3.11 and 3.12, publishing JUnit results as a check and commenting on failures. See `tests/README.md` for how to add a new fixture.
