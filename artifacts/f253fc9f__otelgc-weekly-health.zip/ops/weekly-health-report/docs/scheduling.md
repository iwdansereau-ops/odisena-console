# How the weekly task is scheduled

## Cadence

Every Monday at 09:00 America/New_York (= 13:00 UTC in EDT, 14:00 UTC in EST).
The schedule is defined in UTC so daylight-savings transitions will shift the
local delivery by one hour twice a year. If you need a strict "9am ET
regardless of DST" schedule, split into two seasonal schedules or run the
job on the ET-aware wrapper.

## What the task does

Each run:

1. Executes `weekly_health_report.py` against the configured Prometheus.
2. Reads the resulting `report.html` and `report.json`.
3. Sends an email to `i.w.dansereau@gmail.com` with the HTML as the body and
   a subject line derived from the fleet-wide health summary
   (e.g. `[GC-profile cleanup] 2 nodes stale, 1 alert firing`).
4. If Prometheus was unreachable, the task sends an in-app alert instead of a
   misleadingly-empty email.

## What the task does NOT do

- It does **not** run `simulate-cleanup-failure.sh`. That script is only ever
  executed by a human as an on-demand drill; running it weekly would generate
  a real page every week.
- It does not modify any collector, timer, or textfile.
- It does not depend on SSH access to the collector fleet — the report is
  entirely Prometheus-side.

## Adjusting

To change the cadence or delivery, update the scheduled task from
`https://www.perplexity.ai/computer/tasks/<session>` and re-issue with the new
cron expression. To change what "unhealthy" means, tune `MISSED_WINDOWS` or
`CLEANUP_CADENCE_MIN` in the task environment.
