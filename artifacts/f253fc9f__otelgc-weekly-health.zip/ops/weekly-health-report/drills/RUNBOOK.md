# Alert-plumbing drill — GC-profile cleanup

Purpose: prove that `GCProfileCleanupStale`, `GCProfileCleanupFailing`,
`GCProfileVolumeGrowing`, and `GCProfileRetentionMiss` fire when they should.

Scope: **one-time / on-demand**, not the weekly recurring job. Running this
weekly would generate a real page every week — the recurring health report
only *observes* alert state, it does not induce it.

## Preconditions

1. Pick a canary node with a low-traffic collector — e.g. `collector-canary-01`.
2. Silence pager rotations for the drill window in the alerting UI (Alertmanager
   silence matching `instance="<canary>"` for ~4 hours).
3. Announce the drill in `#observability-ops` so on-call knows the alert is real.
4. Confirm you have sudo NOPASSWD for `systemctl`, `touch`, `tee` on the node.

## Execution

```bash
NODE=collector-canary-01 ./simulate-cleanup-failure.sh all
```

The script injects four independent failure modes and then waits for you to
observe them before it restores state. Because the four rules have different
`for:` windows, plan on ~90 minutes for full coverage:

| Rule | `for:` window | Expected time to fire after injection |
| ---- | ------------- | ------------------------------------- |
| `GCProfileCleanupStale`    | 5m  | ~65 min (60 min threshold + 5 min for) |
| `GCProfileCleanupFailing`  | 15m | ~15 min after the forced-fail run     |
| `GCProfileVolumeGrowing`   | 30m | ~30-40 min after synthetic samples    |
| `GCProfileRetentionMiss`   | 30m | ~30 min after next cleanup run        |

## Verification checklist

For each rule, capture a screenshot or Prom query result:

```promql
ALERTS{alertname="GCProfileCleanupStale",   alertstate="firing", instance="<canary>"}
ALERTS{alertname="GCProfileCleanupFailing", alertstate="firing", instance="<canary>"}
ALERTS{alertname="GCProfileVolumeGrowing",  alertstate="firing", instance="<canary>"}
ALERTS{alertname="GCProfileRetentionMiss",  alertstate="firing", instance="<canary>"}
```

Each of those queries should return exactly one series during the drill window.

## Rollback

The script installs an `EXIT` trap that calls `phase_cleanup`, so Ctrl-C on the
`read` prompt restores state automatically. If you kill it uncleanly, run:

```bash
NODE=collector-canary-01 ./simulate-cleanup-failure.sh cleanup
```

`cleanup` is idempotent — it can be run repeatedly, it only removes drill
artifacts (unmask timer, remove drop-in, delete drill textfile and backdated
triplet).

## Post-drill

- Confirm all four alerts return to `OK` within one evaluation interval after
  cleanup.
- Remove the Alertmanager silence.
- Attach the four `ALERTS{...firing}` screenshots to the drill ticket.

## Why this is not weekly

Every drill invocation:

- pages on-call (unless silenced),
- publishes a synthetic gauge that shows up in Grafana history, and
- leaves the canary in a degraded state for the drill window.

Once you have observed the four rules fire successfully, the weekly recurring
report is sufficient — it inspects the *live* alert state and per-node cleanup
metrics without perturbing the fleet.
