#!/usr/bin/env bash
#
# One-time drill: simulate a failing cleanup timer on a canary node and
# verify that all four GCProfile* alert rules exercise their expected paths.
#
# This script is intentionally NOT executed by the weekly recurring job -
# doing so would guarantee a real page every week. Run it manually when you
# want to prove the alert plumbing end-to-end (typically after any change to
# alerts.yml, the cleanup timer, or the textfile collector wiring).
#
# Usage:
#   NODE=collector-canary-01 ./simulate-cleanup-failure.sh [phase]
#
# Phases (default: all):
#   stale       Stop the timer so last_run_timestamp goes stale
#   failing     Force the next run to exit non-zero
#   retention   Backdate a kept file so oldest_kept_hours > 60h
#   volume      Fabricate a growing bytes_in_use gauge
#   cleanup     Undo every phase (idempotent)
#
# Requirements on target node:
#   - systemd, gcprofile-cleanup.{service,timer} installed
#   - node_exporter textfile collector reading /var/lib/node_exporter/textfile_collector
#   - SSH key access, sudo NOPASSWD for systemctl/touch/tee on the target
#
# Safety:
#   - Only touches the node named in $NODE - never fans out across the fleet.
#   - Every mutation is reversed by the `cleanup` phase, which also runs on
#     EXIT via a trap so an interrupted drill self-heals.

set -euo pipefail

: "${NODE:?Set NODE=<hostname> (canary node only)}"
PHASE="${1:-all}"
SSH_OPTS="${SSH_OPTS:--o StrictHostKeyChecking=accept-new -o ConnectTimeout=10}"

TEXTFILE_DIR="/var/lib/node_exporter/textfile_collector"
DRILL_TEXTFILE="${TEXTFILE_DIR}/gcprofile_drill.prom"
PROFILE_DIR="${PROFILE_DIR:-/var/lib/otelcol/gcprofiles}"
DRILL_MARKER="${PROFILE_DIR}/.drill_backdated_marker"

log() { printf '[drill %s] %s\n' "$(date -u +%FT%TZ)" "$*"; }

run_remote() {
  # shellcheck disable=SC2029
  ssh $SSH_OPTS "$NODE" "sudo bash -s" <<REMOTE
set -euo pipefail
$1
REMOTE
}

phase_stale() {
  log "STALE: masking gcprofile-cleanup.timer on $NODE"
  run_remote '
    systemctl stop gcprofile-cleanup.timer || true
    systemctl mask gcprofile-cleanup.timer
  '
  log "Wait ~65 minutes, then confirm ALERTS{alertname=\"GCProfileCleanupStale\",alertstate=\"firing\"} is non-empty."
}

phase_failing() {
  log "FAILING: injecting a poison drop-in that forces exit 1"
  run_remote "
    mkdir -p /etc/systemd/system/gcprofile-cleanup.service.d
    cat >/etc/systemd/system/gcprofile-cleanup.service.d/99-drill.conf <<'CONF'
[Service]
# Drill override: force the next execution to exit non-zero so
# gcprofile_cleanup_last_run_exit_code publishes 1.
ExecStart=
ExecStart=/bin/bash -c 'echo drill-forced-failure >&2; /usr/local/bin/gcprofile-cleanup.sh --force-fail || exit 1'
CONF
    systemctl daemon-reload
    systemctl unmask gcprofile-cleanup.timer || true
    systemctl start gcprofile-cleanup.service || true
  "
  log "Confirm gcprofile_cleanup_last_run_exit_code == 1 in Prom, then GCProfileCleanupFailing fires after 15m."
}

phase_retention() {
  log "RETENTION: backdating a kept triplet to 72h old (past 60h threshold)"
  run_remote "
    mkdir -p '$PROFILE_DIR'
    ts=\$(date -d '72 hours ago' +%Y%m%dT%H%M%SZ)
    for ext in heap.pb.gz stack.txt meta.json; do
      f=\"$PROFILE_DIR/drill-\${ts}.\${ext}\"
      : > \"\$f\"
      touch -d '72 hours ago' \"\$f\"
    done
    touch '$DRILL_MARKER'
  "
  log "Trigger a cleanup run; oldest_kept_hours should publish ~72 and GCProfileRetentionMiss fires after 30m."
}

phase_volume() {
  log "VOLUME: publishing a synthetic growing bytes_in_use gauge"
  # Write two samples 10s apart so deriv() sees a positive slope in the
  # 2h window used by GCProfileVolumeGrowing.
  run_remote "
    mkdir -p '$TEXTFILE_DIR'
    v=\$(( 12 * 1024 * 1024 * 1024 ))
    cat > '$DRILL_TEXTFILE' <<PROM
# HELP gcprofile_cleanup_bytes_in_use Drill-injected value
# TYPE gcprofile_cleanup_bytes_in_use gauge
gcprofile_cleanup_bytes_in_use{drill=\"1\"} \$v
PROM
    sync
    sleep 15
    v=\$(( v + 512*1024*1024 ))
    cat > '$DRILL_TEXTFILE' <<PROM
# HELP gcprofile_cleanup_bytes_in_use Drill-injected value
# TYPE gcprofile_cleanup_bytes_in_use gauge
gcprofile_cleanup_bytes_in_use{drill=\"1\"} \$v
PROM
  "
  log "GCProfileVolumeGrowing should fire after ~30m of sustained positive deriv() above 10 GiB."
}

phase_cleanup() {
  log "CLEANUP: reversing all drill mutations on $NODE"
  run_remote "
    systemctl unmask gcprofile-cleanup.timer || true
    rm -f /etc/systemd/system/gcprofile-cleanup.service.d/99-drill.conf
    rmdir /etc/systemd/system/gcprofile-cleanup.service.d 2>/dev/null || true
    systemctl daemon-reload
    systemctl start gcprofile-cleanup.timer
    rm -f '$DRILL_TEXTFILE'
    if [ -f '$DRILL_MARKER' ]; then
      find '$PROFILE_DIR' -maxdepth 1 -name 'drill-*.heap.pb.gz' -delete
      find '$PROFILE_DIR' -maxdepth 1 -name 'drill-*.stack.txt'  -delete
      find '$PROFILE_DIR' -maxdepth 1 -name 'drill-*.meta.json'  -delete
      rm -f '$DRILL_MARKER'
    fi
    systemctl start gcprofile-cleanup.service || true
  "
  log "Drill cleanup complete. Watch alerts return to OK on their normal 'for:' windows."
}

trap 'phase_cleanup || true' EXIT

case "$PHASE" in
  stale)     phase_stale ;;
  failing)   phase_failing ;;
  retention) phase_retention ;;
  volume)    phase_volume ;;
  cleanup)   trap - EXIT; phase_cleanup ;;
  all)
    phase_stale
    phase_failing
    phase_retention
    phase_volume
    log "All injection phases done. Trap will restore state on script exit."
    log "Sleep here until you have observed the alerts firing, then press Ctrl-C."
    read -r -p "Press ENTER once alerts have been observed to restore state: " _
    ;;
  *) echo "Unknown phase: $PHASE" >&2; exit 2 ;;
esac
