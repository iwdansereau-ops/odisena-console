# Weekly cleanup-health report

This package delivers a weekly HTML email that answers three questions about
the GC-profile cleanup job across every OTel Collector node:

1. Are the four `GCProfile*` alert rules currently firing / pending / OK?
2. Which nodes have missed their last 3 cleanup windows (90+ min stale at the
   default 30-minute cadence)?
3. What is the current state of every node's cleanup metrics (last run age,
   exit code, retention age, volume in use)?

The recurring task **does not** induce failure conditions — it only observes
Prometheus. Verifying that the alerts *fire correctly* is done via the
on-demand drill under [`drills/`](drills/), which is intentionally not
scheduled.

## Layout

```
bin/weekly_health_report.py       - Prom query + HTML/JSON report generator
drills/simulate-cleanup-failure.sh - On-demand alert-plumbing drill
drills/RUNBOOK.md                  - How to run the drill safely
docs/scheduling.md                 - How the weekly task is scheduled
```

## Configuration

Environment variables consumed by `weekly_health_report.py`:

| Var                    | Default                                            | Purpose |
| ---------------------- | -------------------------------------------------- | ------- |
| `PROM_URL`             | `http://prometheus.observability.svc:9090`         | Base URL |
| `PROM_BEARER`          | (empty)                                            | Optional bearer token |
| `CLEANUP_CADENCE_MIN`  | `30`                                               | Expected cleanup cadence |
| `MISSED_WINDOWS`       | `3`                                                | Windows before a node is unhealthy |
| `ALERT_NAME_REGEX`     | `GCProfile.*`                                      | Alert selector |
| `MAX_NODES_IN_TABLE`   | `200`                                              | HTML detail-table cap |
| `REPORT_OUT_DIR`       | `.`                                                | Where `report.json`/`report.html` land |

## Output

```
report.json   Machine-readable summary + full stale/failing node list
report.html   Email-ready HTML body
```

The script prints a one-line JSON summary to stdout, which is what the
scheduled task uses to decide notification content.

## Design notes

- **Stateless.** No local state, no persistence. Everything is derived from
  Prometheus at query time. Missed-windows detection uses
  `time() - gcprofile_cleanup_last_run_timestamp_seconds`, matching the same
  metric that `GCProfileCleanupStale` fires on — so the report and the alert
  can never drift out of sync.
- **Explicit alert allowlist.** The 4 rule names are hardcoded so a rename in
  `alerts.yml` shows up as a blank row in the report instead of silently
  disappearing.
- **Unhealthy-first ordering.** The detail table sorts problem nodes to the
  top, so a screenshot of the first screen always tells you the worst news.
- **Failure isolation.** If Prometheus is unreachable the script exits non-zero
  and the wrapping task escalates instead of sending a misleadingly-empty
  report.
