// Package pdatainstr provides consumer wrappers that count pdata objects
// per pipeline stage and annotate OTel spans with allocation deltas so a
// side-by-side correlator can join memory spikes to specific stages.
//
// Usage sketch (inside a processor factory or an extension that patches
// pipelines):
//
//	next = pdatainstr.WrapTraces(next, "processor:batch", monitor, tracer)
//	next = pdatainstr.WrapLogs(next, "processor:batch", monitor, tracer)
//	next = pdatainstr.WrapMetrics(next, "processor:batch", monitor, tracer)
package pdatainstr

import (
	"context"
	"runtime"

	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/plog"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/trace"

	"github.com/example/otelgc/internal/gcpressure"
)

// ObjectRecorder is the small interface the wrappers need. gcpressure.Monitor
// satisfies it.
type ObjectRecorder interface {
	RecordPdataObjects(signal, stage string, n int)
}

var _ ObjectRecorder = (*gcpressure.Monitor)(nil)

// AttrKey* are the OTel span attribute keys the correlator looks for.
const (
	AttrKeyStage          = attribute.Key("otelcol.pdata.stage")
	AttrKeySignal         = attribute.Key("otelcol.pdata.signal")
	AttrKeyObjects        = attribute.Key("otelcol.pdata.objects")
	AttrKeyDataPoints     = attribute.Key("otelcol.pdata.data_points")
	AttrKeyAllocDeltaByte = attribute.Key("otelcol.pdata.alloc_delta_bytes")
	AttrKeyHeapBeforeByte = attribute.Key("otelcol.pdata.heap_before_bytes")
	AttrKeyHeapAfterByte  = attribute.Key("otelcol.pdata.heap_after_bytes")
	AttrKeyNumGCDelta     = attribute.Key("otelcol.pdata.numgc_delta")
)

// stageSpanName is the span name we emit per pipeline hop.
const stageSpanName = "otelcol.pdata.stage"

// --- Traces ---------------------------------------------------------------

type tracesWrapper struct {
	next   consumer.Traces
	stage  string
	rec    ObjectRecorder
	tracer trace.Tracer
}

// WrapTraces returns a consumer.Traces that records object counts + allocation
// deltas and forwards to next.
func WrapTraces(next consumer.Traces, stage string, rec ObjectRecorder, tr trace.Tracer) consumer.Traces {
	if next == nil {
		return next
	}
	if tr == nil {
		tr = trace.NewNoopTracerProvider().Tracer("noop")
	}
	return &tracesWrapper{next: next, stage: stage, rec: rec, tracer: tr}
}

func (w *tracesWrapper) Capabilities() consumer.Capabilities {
	return w.next.Capabilities()
}

func (w *tracesWrapper) ConsumeTraces(ctx context.Context, td ptrace.Traces) error {
	objects := td.SpanCount()
	if w.rec != nil {
		w.rec.RecordPdataObjects("traces", w.stage, objects)
	}
	ctx, span := w.tracer.Start(ctx, stageSpanName)
	defer span.End()

	before := readAlloc()
	beforeGC := numGC()
	err := w.next.ConsumeTraces(ctx, td)
	after := readAlloc()
	afterGC := numGC()

	annotate(span, "traces", w.stage, objects, 0, before, after, afterGC-beforeGC)
	return err
}

// --- Logs -----------------------------------------------------------------

type logsWrapper struct {
	next   consumer.Logs
	stage  string
	rec    ObjectRecorder
	tracer trace.Tracer
}

// WrapLogs mirrors WrapTraces for logs.
func WrapLogs(next consumer.Logs, stage string, rec ObjectRecorder, tr trace.Tracer) consumer.Logs {
	if next == nil {
		return next
	}
	if tr == nil {
		tr = trace.NewNoopTracerProvider().Tracer("noop")
	}
	return &logsWrapper{next: next, stage: stage, rec: rec, tracer: tr}
}

func (w *logsWrapper) Capabilities() consumer.Capabilities {
	return w.next.Capabilities()
}

func (w *logsWrapper) ConsumeLogs(ctx context.Context, ld plog.Logs) error {
	objects := ld.LogRecordCount()
	if w.rec != nil {
		w.rec.RecordPdataObjects("logs", w.stage, objects)
	}
	ctx, span := w.tracer.Start(ctx, stageSpanName)
	defer span.End()

	before := readAlloc()
	beforeGC := numGC()
	err := w.next.ConsumeLogs(ctx, ld)
	after := readAlloc()
	afterGC := numGC()

	annotate(span, "logs", w.stage, objects, 0, before, after, afterGC-beforeGC)
	return err
}

// --- Metrics --------------------------------------------------------------

type metricsWrapper struct {
	next   consumer.Metrics
	stage  string
	rec    ObjectRecorder
	tracer trace.Tracer
}

// WrapMetrics mirrors WrapTraces for metrics.
func WrapMetrics(next consumer.Metrics, stage string, rec ObjectRecorder, tr trace.Tracer) consumer.Metrics {
	if next == nil {
		return next
	}
	if tr == nil {
		tr = trace.NewNoopTracerProvider().Tracer("noop")
	}
	return &metricsWrapper{next: next, stage: stage, rec: rec, tracer: tr}
}

func (w *metricsWrapper) Capabilities() consumer.Capabilities {
	return w.next.Capabilities()
}

func (w *metricsWrapper) ConsumeMetrics(ctx context.Context, md pmetric.Metrics) error {
	objects := md.MetricCount()
	dps := md.DataPointCount()
	if w.rec != nil {
		w.rec.RecordPdataObjects("metrics", w.stage, objects)
		if dps > objects {
			w.rec.RecordPdataObjects("metrics", w.stage+":dp", dps-objects)
		}
	}
	ctx, span := w.tracer.Start(ctx, stageSpanName)
	defer span.End()

	before := readAlloc()
	beforeGC := numGC()
	err := w.next.ConsumeMetrics(ctx, md)
	after := readAlloc()
	afterGC := numGC()

	annotate(span, "metrics", w.stage, objects, dps, before, after, afterGC-beforeGC)
	return err
}

// --- helpers --------------------------------------------------------------

// readAlloc returns runtime.MemStats.TotalAlloc without forcing a STW GC.
// It uses ReadMemStats which is cheap enough at pipeline-stage cardinality.
func readAlloc() uint64 {
	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)
	return ms.TotalAlloc
}

func numGC() uint32 {
	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)
	return ms.NumGC
}

func annotate(span trace.Span, signal, stage string, objects, dps int, before, after uint64, gcDelta uint32) {
	if !span.IsRecording() {
		return
	}
	var delta int64
	if after >= before {
		delta = int64(after - before)
	} else {
		// TotalAlloc is monotonic; a lower value means overflow which is
		// not realistically achievable during a single call.
		delta = 0
	}
	attrs := []attribute.KeyValue{
		AttrKeySignal.String(signal),
		AttrKeyStage.String(stage),
		AttrKeyObjects.Int(objects),
		AttrKeyAllocDeltaByte.Int64(delta),
		AttrKeyHeapBeforeByte.Int64(int64(before)),
		AttrKeyHeapAfterByte.Int64(int64(after)),
		AttrKeyNumGCDelta.Int(int(gcDelta)),
	}
	if dps > 0 {
		attrs = append(attrs, AttrKeyDataPoints.Int(dps))
	}
	span.SetAttributes(attrs...)
}
