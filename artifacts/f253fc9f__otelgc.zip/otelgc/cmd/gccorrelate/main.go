// gccorrelate correlates pprof captures written by the gcpressure monitor
// with pdata pipeline spans emitted by the pdatainstr wrappers, plus
// Prometheus allocation-rate samples. It produces a side-by-side textual
// report intended for on-call debugging.
//
// Inputs
//
//   --profile-dir     Directory containing gc-*.meta.txt / .heap.pprof files
//                     (the same path configured on the extension).
//   --spans           A newline-delimited JSON file where each line is one
//                     span in the shape:
//                       {
//                         "traceId":"...", "spanId":"...",
//                         "name":"otelcol.pdata.stage",
//                         "startTimeUnixNano":"...", "endTimeUnixNano":"...",
//                         "attributes":[{"key":"otelcol.pdata.stage",
//                                        "value":{"stringValue":"processor:batch"}},
//                                       ...]
//                       }
//                     This is exactly what OTLP-JSON file exporters produce
//                     when configured with one-span-per-line.
//   --prom-url        Optional Prometheus base URL. When set, allocation-rate
//                     samples are pulled directly for a ±window around each
//                     capture and printed alongside the span timeline.
//   --window          Correlation window (default 30s each side).
//   --top             How many top-allocating stages to print (default 10).
package main

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

// -----------------------------------------------------------------------------
// Capture metadata
// -----------------------------------------------------------------------------

type capture struct {
	metaPath   string
	heapPath   string
	stacksPath string
	reason     string
	at         time.Time
	kv         map[string]string
}

func loadCaptures(dir string) ([]capture, error) {
	entries, err := filepath.Glob(filepath.Join(dir, "gc-*.meta.txt"))
	if err != nil {
		return nil, err
	}
	sort.Strings(entries)
	out := make([]capture, 0, len(entries))
	for _, p := range entries {
		c, err := parseMeta(p)
		if err != nil {
			fmt.Fprintf(os.Stderr, "warning: skip %s: %v\n", p, err)
			continue
		}
		out = append(out, c)
	}
	return out, nil
}

func parseMeta(path string) (capture, error) {
	f, err := os.Open(path)
	if err != nil {
		return capture{}, err
	}
	defer f.Close()

	c := capture{metaPath: path, kv: map[string]string{}}
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := sc.Text()
		i := strings.IndexByte(line, '=')
		if i <= 0 {
			continue
		}
		k, v := line[:i], line[i+1:]
		c.kv[k] = v
		switch k {
		case "reason":
			c.reason = v
		case "captured_at":
			if t, err := time.Parse(time.RFC3339Nano, v); err == nil {
				c.at = t
			}
		}
	}
	// Companion files share the base name.
	base := strings.TrimSuffix(path, ".meta.txt")
	c.heapPath = base + ".heap.pprof"
	c.stacksPath = base + ".stacks.txt"
	if c.at.IsZero() {
		return c, errors.New("capture missing captured_at timestamp")
	}
	return c, nil
}

// -----------------------------------------------------------------------------
// OTLP-JSON span loader
// -----------------------------------------------------------------------------

type spanRecord struct {
	TraceID   string      `json:"traceId"`
	SpanID    string      `json:"spanId"`
	Name      string      `json:"name"`
	StartNano json.Number `json:"startTimeUnixNano"`
	EndNano   json.Number `json:"endTimeUnixNano"`
	Attrs     []struct {
		Key   string `json:"key"`
		Value struct {
			StringValue *string      `json:"stringValue,omitempty"`
			IntValue    *json.Number `json:"intValue,omitempty"`
			BoolValue   *bool        `json:"boolValue,omitempty"`
			DoubleValue *float64     `json:"doubleValue,omitempty"`
		} `json:"value"`
	} `json:"attributes"`

	// Derived.
	start      time.Time
	end        time.Time
	signal     string
	stage      string
	objects    int64
	dataPoints int64
	allocDelta int64
	numGCDelta int64
}

func (s *spanRecord) hydrate() {
	if v, err := s.StartNano.Int64(); err == nil {
		s.start = time.Unix(0, v)
	}
	if v, err := s.EndNano.Int64(); err == nil {
		s.end = time.Unix(0, v)
	}
	for _, a := range s.Attrs {
		switch a.Key {
		case "otelcol.pdata.signal":
			if a.Value.StringValue != nil {
				s.signal = *a.Value.StringValue
			}
		case "otelcol.pdata.stage":
			if a.Value.StringValue != nil {
				s.stage = *a.Value.StringValue
			}
		case "otelcol.pdata.objects":
			if a.Value.IntValue != nil {
				if v, err := a.Value.IntValue.Int64(); err == nil {
					s.objects = v
				}
			}
		case "otelcol.pdata.data_points":
			if a.Value.IntValue != nil {
				if v, err := a.Value.IntValue.Int64(); err == nil {
					s.dataPoints = v
				}
			}
		case "otelcol.pdata.alloc_delta_bytes":
			if a.Value.IntValue != nil {
				if v, err := a.Value.IntValue.Int64(); err == nil {
					s.allocDelta = v
				}
			}
		case "otelcol.pdata.numgc_delta":
			if a.Value.IntValue != nil {
				if v, err := a.Value.IntValue.Int64(); err == nil {
					s.numGCDelta = v
				}
			}
		}
	}
}

func loadSpans(path string) ([]spanRecord, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()

	var out []spanRecord
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<16), 8<<20)
	for sc.Scan() {
		line := bytes(sc.Text())
		if len(line) == 0 {
			continue
		}
		var s spanRecord
		if err := json.Unmarshal(line, &s); err != nil {
			continue
		}
		s.hydrate()
		if s.stage == "" || s.start.IsZero() {
			continue
		}
		out = append(out, s)
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	return out, nil
}

func bytes(s string) []byte { return []byte(s) }

// -----------------------------------------------------------------------------
// Prometheus range query (kept dependency-free)
// -----------------------------------------------------------------------------

type promSample struct {
	at  time.Time
	val float64
}

type promRangeResp struct {
	Status string `json:"status"`
	Data   struct {
		ResultType string `json:"resultType"`
		Result     []struct {
			Metric map[string]string `json:"metric"`
			Values [][2]json.RawMessage `json:"values"`
		} `json:"result"`
	} `json:"data"`
}

func promRange(ctx context.Context, base, expr string, from, to time.Time, step time.Duration) ([]promSample, error) {
	u, err := url.Parse(strings.TrimRight(base, "/") + "/api/v1/query_range")
	if err != nil {
		return nil, err
	}
	q := u.Query()
	q.Set("query", expr)
	q.Set("start", strconv.FormatFloat(float64(from.UnixNano())/1e9, 'f', 3, 64))
	q.Set("end", strconv.FormatFloat(float64(to.UnixNano())/1e9, 'f', 3, 64))
	q.Set("step", strconv.FormatFloat(step.Seconds(), 'f', 3, 64))
	u.RawQuery = q.Encode()

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return nil, err
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("prometheus http %d", resp.StatusCode)
	}
	var pr promRangeResp
	if err := json.NewDecoder(resp.Body).Decode(&pr); err != nil {
		return nil, err
	}
	if pr.Status != "success" || len(pr.Data.Result) == 0 {
		return nil, nil
	}
	var out []promSample
	for _, v := range pr.Data.Result[0].Values {
		var tsF float64
		if err := json.Unmarshal(v[0], &tsF); err != nil {
			continue
		}
		var valStr string
		if err := json.Unmarshal(v[1], &valStr); err != nil {
			continue
		}
		f, err := strconv.ParseFloat(valStr, 64)
		if err != nil {
			continue
		}
		out = append(out, promSample{
			at:  time.Unix(0, int64(tsF*1e9)),
			val: f,
		})
	}
	return out, nil
}

// -----------------------------------------------------------------------------
// Rendering
// -----------------------------------------------------------------------------

func humanBytes(n int64) string {
	f := float64(n)
	units := []string{"B", "KiB", "MiB", "GiB", "TiB"}
	i := 0
	for f >= 1024 && i < len(units)-1 {
		f /= 1024
		i++
	}
	return fmt.Sprintf("%.1f %s", f, units[i])
}

func renderReport(c capture, spans []spanRecord, samples []promSample, window time.Duration, top int) {
	lo, hi := c.at.Add(-window), c.at.Add(window)
	fmt.Printf("═══════════════════════════════════════════════════════════════════════════════\n")
	fmt.Printf(" pprof capture: %s\n", filepath.Base(c.metaPath))
	fmt.Printf("   reason         : %s\n", c.reason)
	fmt.Printf("   captured_at    : %s\n", c.at.UTC().Format(time.RFC3339Nano))
	fmt.Printf("   heap profile   : %s\n", c.heapPath)
	fmt.Printf("   stacks dump    : %s\n", c.stacksPath)
	for _, k := range []string{"pause_ns", "churn_bytes_per_min", "threshold"} {
		if v, ok := c.kv[k]; ok {
			fmt.Printf("   %-14s : %s\n", k, v)
		}
	}
	fmt.Printf("   window         : ±%s\n", window)
	fmt.Println()

	// Side-by-side header.
	fmt.Printf(" %-30s │ %-44s\n", "alloc rate (bytes/sec)", "concurrent pdata pipeline stages")
	fmt.Printf(" %-30s │ %-44s\n", "──────────────────────────────", "────────────────────────────────────────────")

	// Left column: prom samples. Right column: overlapping spans by start time.
	overlapping := filterOverlapping(spans, lo, hi)
	sort.Slice(overlapping, func(i, j int) bool {
		return overlapping[i].start.Before(overlapping[j].start)
	})

	// Merge streams by time so lines interleave chronologically.
	type row struct {
		t    time.Time
		left string
		right string
	}
	var rows []row
	for _, s := range samples {
		rows = append(rows, row{t: s.at, left: fmt.Sprintf("%s  %10s/s", s.at.UTC().Format("15:04:05.000"), humanBytes(int64(s.val)))})
	}
	for _, sp := range overlapping {
		dur := sp.end.Sub(sp.start)
		right := fmt.Sprintf("%s  %-24s obj=%-6d Δalloc=%s",
			sp.start.UTC().Format("15:04:05.000"),
			truncate(sp.signal+":"+sp.stage, 24),
			sp.objects,
			humanBytes(sp.allocDelta),
		)
		if dur > 0 {
			right += fmt.Sprintf(" dur=%s", dur.Round(time.Millisecond))
		}
		if sp.numGCDelta > 0 {
			right += fmt.Sprintf(" gc+%d", sp.numGCDelta)
		}
		rows = append(rows, row{t: sp.start, right: right})
	}
	sort.Slice(rows, func(i, j int) bool { return rows[i].t.Before(rows[j].t) })

	for _, r := range rows {
		fmt.Printf(" %-30s │ %-44s\n", r.left, r.right)
	}

	fmt.Println()
	fmt.Printf(" ── top %d allocating stages (spans overlapping capture window) ──\n", top)
	agg := aggregateByStage(overlapping)
	sort.Slice(agg, func(i, j int) bool { return agg[i].allocDelta > agg[j].allocDelta })
	if len(agg) > top {
		agg = agg[:top]
	}
	fmt.Printf(" %-30s %10s %14s %10s %10s\n", "signal:stage", "spans", "Δalloc", "obj/span", "gc/span")
	for _, a := range agg {
		fmt.Printf(" %-30s %10d %14s %10.1f %10.2f\n",
			truncate(a.signal+":"+a.stage, 30),
			a.spans,
			humanBytes(a.allocDelta),
			float64(a.objects)/float64(a.spans),
			float64(a.gc)/float64(a.spans),
		)
	}
	fmt.Println()
	fmt.Printf(" tip: `go tool pprof -http :0 %s`\n", c.heapPath)
	fmt.Println()
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	if n <= 1 {
		return s[:n]
	}
	return s[:n-1] + "…"
}

func filterOverlapping(spans []spanRecord, lo, hi time.Time) []spanRecord {
	var out []spanRecord
	for _, s := range spans {
		if s.end.Before(lo) || s.start.After(hi) {
			continue
		}
		out = append(out, s)
	}
	return out
}

type stageAgg struct {
	signal, stage string
	spans         int
	objects       int64
	allocDelta    int64
	gc            int64
}

func aggregateByStage(spans []spanRecord) []stageAgg {
	m := map[string]*stageAgg{}
	for _, s := range spans {
		k := s.signal + "|" + s.stage
		a := m[k]
		if a == nil {
			a = &stageAgg{signal: s.signal, stage: s.stage}
			m[k] = a
		}
		a.spans++
		a.objects += s.objects
		a.allocDelta += s.allocDelta
		a.gc += s.numGCDelta
	}
	out := make([]stageAgg, 0, len(m))
	for _, a := range m {
		out = append(out, *a)
	}
	return out
}

// -----------------------------------------------------------------------------

func main() {
	var (
		profileDir = flag.String("profile-dir", "/var/lib/otelcol/gcprofiles", "directory of gc-* capture files")
		spansPath  = flag.String("spans", "", "path to OTLP-JSON file of pipeline spans (one span per line)")
		promURL    = flag.String("prom-url", "", "optional Prometheus base URL (e.g. http://prometheus:9090)")
		window     = flag.Duration("window", 30*time.Second, "correlation window around each capture")
		top        = flag.Int("top", 10, "top-N allocating stages to print")
		since      = flag.Duration("since", 0, "only report captures newer than this (0 = all)")
	)
	flag.Parse()

	captures, err := loadCaptures(*profileDir)
	if err != nil {
		fmt.Fprintln(os.Stderr, "load captures:", err)
		os.Exit(1)
	}
	if len(captures) == 0 {
		fmt.Fprintln(os.Stderr, "no captures found in", *profileDir)
		return
	}
	if *since > 0 {
		cutoff := time.Now().Add(-*since)
		filtered := captures[:0]
		for _, c := range captures {
			if c.at.After(cutoff) {
				filtered = append(filtered, c)
			}
		}
		captures = filtered
	}

	var spans []spanRecord
	if *spansPath != "" {
		spans, err = loadSpans(*spansPath)
		if err != nil {
			fmt.Fprintln(os.Stderr, "load spans:", err)
			os.Exit(1)
		}
	}

	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	for _, c := range captures {
		var samples []promSample
		if *promURL != "" {
			samples, err = promRange(ctx, *promURL,
				"otelcol_gc_alloc_rate_bytes_per_second",
				c.at.Add(-*window), c.at.Add(*window), time.Second,
			)
			if err != nil {
				fmt.Fprintln(os.Stderr, "prom query:", err)
			}
		}
		renderReport(c, spans, samples, *window, *top)
	}
}
