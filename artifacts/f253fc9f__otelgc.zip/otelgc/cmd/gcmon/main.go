// gcmon runs the pprof-based GC pressure monitor as a standalone process.
// It is primarily useful for embedding in the same binary as the OTel
// Collector (import _ "github.com/example/otelgc/cmd/gcmon") or for local
// development. For production, prefer the gcpressureextension.
package main

import (
	"context"
	"errors"
	"flag"
	"net"
	"net/http"
	_ "net/http/pprof" // expose the standard /debug/pprof endpoints too.
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"go.uber.org/zap"

	"github.com/example/otelgc/internal/gcpressure"
)

func main() {
	var (
		addr       = flag.String("listen", "0.0.0.0:9317", "listen address for /metrics")
		sample     = flag.Duration("sample-interval", time.Second, "MemStats sample interval")
		pause      = flag.Duration("pause-threshold", 100*time.Millisecond, "GC pause capture threshold")
		churn      = flag.Uint64("churn-bytes-per-min", 2*1024*1024*1024, "heap churn capture threshold (bytes/min)")
		profileDir = flag.String("profile-dir", "/tmp/otelcol-gcprofiles", "directory for heap profiles + stack dumps")
		minCap     = flag.Duration("min-capture-interval", 30*time.Second, "minimum interval between pprof captures")
	)
	flag.Parse()

	log, _ := zap.NewProduction()
	defer func() { _ = log.Sync() }()

	mon := gcpressure.NewMonitor(gcpressure.Config{
		SampleInterval:               *sample,
		PauseThreshold:               *pause,
		ChurnBytesPerMinuteThreshold: *churn,
		ProfileDir:                   *profileDir,
		MinCaptureInterval:           *minCap,
		Logger:                       log,
	})
	reg := prometheus.NewRegistry()
	if err := mon.Register(reg); err != nil {
		log.Fatal("register", zap.Error(err))
	}

	ctx, cancel := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer cancel()

	if err := mon.Start(ctx); err != nil {
		log.Fatal("start monitor", zap.Error(err))
	}
	defer mon.Stop()

	mux := http.NewServeMux()
	mux.Handle("/metrics", promhttp.HandlerFor(reg, promhttp.HandlerOpts{EnableOpenMetrics: true}))
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	// Also mount the default /debug/pprof handlers from net/http/pprof.
	mux.Handle("/debug/", http.DefaultServeMux)

	ln, err := net.Listen("tcp", *addr)
	if err != nil {
		log.Fatal("listen", zap.Error(err))
	}
	srv := &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	go func() {
		if err := srv.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Error("serve", zap.Error(err))
		}
	}()
	log.Info("gcmon listening",
		zap.String("addr", *addr),
		zap.Duration("pause_threshold", *pause),
		zap.Uint64("churn_bytes_per_min", *churn),
		zap.String("profile_dir", *profileDir),
	)

	<-ctx.Done()
	shutdown, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_ = srv.Shutdown(shutdown)
	_ = os.Stdout.Sync()
}
