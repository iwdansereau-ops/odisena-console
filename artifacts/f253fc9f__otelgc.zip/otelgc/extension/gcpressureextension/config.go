package gcpressureextension

import (
	"errors"
	"time"

	"go.opentelemetry.io/collector/component"
)

// Config controls the gcpressure extension.
type Config struct {
	// ListenAddr is the host:port on which /metrics is exposed.
	ListenAddr string `mapstructure:"listen_addr"`
	// SampleInterval controls how often MemStats is polled.
	SampleInterval time.Duration `mapstructure:"sample_interval"`
	// PauseThreshold triggers pprof capture on GC pauses >= this.
	PauseThreshold time.Duration `mapstructure:"pause_threshold"`
	// ChurnBytesPerMinute triggers alert + capture when heap allocation
	// rate exceeds this many bytes/minute (default 2 GiB).
	ChurnBytesPerMinute uint64 `mapstructure:"churn_bytes_per_minute"`
	// ProfileDir is where captured heap profiles and stack traces land.
	ProfileDir string `mapstructure:"profile_dir"`
	// MinCaptureInterval rate-limits pprof captures.
	MinCaptureInterval time.Duration `mapstructure:"min_capture_interval"`
}

var _ component.Config = (*Config)(nil)

// Validate implements component.ConfigValidator.
func (c *Config) Validate() error {
	if c.ListenAddr == "" {
		return errors.New("listen_addr must be set")
	}
	if c.SampleInterval < 100*time.Millisecond {
		return errors.New("sample_interval must be >= 100ms")
	}
	if c.PauseThreshold <= 0 {
		return errors.New("pause_threshold must be > 0")
	}
	if c.ChurnBytesPerMinute == 0 {
		return errors.New("churn_bytes_per_minute must be > 0")
	}
	if c.ProfileDir == "" {
		return errors.New("profile_dir must be set")
	}
	return nil
}

func createDefaultConfig() component.Config {
	return &Config{
		ListenAddr:          "0.0.0.0:9317",
		SampleInterval:      time.Second,
		PauseThreshold:      100 * time.Millisecond,
		ChurnBytesPerMinute: 2 * 1024 * 1024 * 1024,
		ProfileDir:          "/var/lib/otelcol/gcprofiles",
		MinCaptureInterval:  30 * time.Second,
	}
}
