package gcpressureextension

import (
	"context"
	"errors"
	"net"
	"net/http"
	"sync"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
	"go.opentelemetry.io/collector/component"
	"go.uber.org/zap"

	"github.com/example/otelgc/internal/gcpressure"
)

// registry allows other Collector components (e.g. a processor factory) to
// find the running monitor and record pdata-object counts against it.
var (
	registryMu sync.RWMutex
	registered *gcpressure.Monitor
)

// Lookup returns the currently registered monitor, or nil.
func Lookup() *gcpressure.Monitor {
	registryMu.RLock()
	defer registryMu.RUnlock()
	return registered
}

type gcExtension struct {
	cfg     *Config
	log     *zap.Logger
	monitor *gcpressure.Monitor
	server  *http.Server
	reg     *prometheus.Registry
}

func newExtension(cfg *Config, log *zap.Logger) (*gcExtension, error) {
	if cfg == nil {
		return nil, errors.New("nil config")
	}
	mon := gcpressure.NewMonitor(gcpressure.Config{
		SampleInterval:               cfg.SampleInterval,
		PauseThreshold:               cfg.PauseThreshold,
		ChurnBytesPerMinuteThreshold: cfg.ChurnBytesPerMinute,
		ProfileDir:                   cfg.ProfileDir,
		MinCaptureInterval:           cfg.MinCaptureInterval,
		Logger:                       log,
	})
	reg := prometheus.NewRegistry()
	if err := mon.Register(reg); err != nil {
		return nil, err
	}
	return &gcExtension{cfg: cfg, log: log, monitor: mon, reg: reg}, nil
}

// Start implements component.Component.
func (e *gcExtension) Start(ctx context.Context, _ component.Host) error {
	if err := e.monitor.Start(ctx); err != nil {
		return err
	}

	registryMu.Lock()
	registered = e.monitor
	registryMu.Unlock()

	mux := http.NewServeMux()
	mux.Handle("/metrics", promhttp.HandlerFor(e.reg, promhttp.HandlerOpts{
		EnableOpenMetrics: true,
		Registry:          e.reg,
	}))
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})

	ln, err := net.Listen("tcp", e.cfg.ListenAddr)
	if err != nil {
		return err
	}
	e.server = &http.Server{
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
	}
	go func() {
		if err := e.server.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
			e.log.Error("gcpressure metrics server exited", zap.Error(err))
		}
	}()
	e.log.Info("gcpressure extension started",
		zap.String("listen_addr", e.cfg.ListenAddr),
		zap.Duration("pause_threshold", e.cfg.PauseThreshold),
		zap.Uint64("churn_bytes_per_minute", e.cfg.ChurnBytesPerMinute),
		zap.String("profile_dir", e.cfg.ProfileDir),
	)
	return nil
}

// Shutdown implements component.Component.
func (e *gcExtension) Shutdown(ctx context.Context) error {
	registryMu.Lock()
	if registered == e.monitor {
		registered = nil
	}
	registryMu.Unlock()

	if e.server != nil {
		shutdownCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
		defer cancel()
		_ = e.server.Shutdown(shutdownCtx)
	}
	e.monitor.Stop()
	return nil
}
