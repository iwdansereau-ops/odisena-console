// Package gcpressureextension exposes the gcpressure.Monitor as a first-class
// OTel Collector extension. Adding it to a Collector config (see
// deploy/otelcol/config.yaml) will start the monitor, expose /metrics for
// Prometheus scraping, and register a singleton the pipeline instrumentation
// can look up.
package gcpressureextension

import (
	"context"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/extension"
)

// TypeStr is the component type string used in Collector configs.
const TypeStr = "gcpressure"

// NewFactory returns the extension factory.
func NewFactory() extension.Factory {
	return extension.NewFactory(
		component.MustNewType(TypeStr),
		createDefaultConfig,
		createExtension,
		component.StabilityLevelBeta,
	)
}

func createExtension(_ context.Context, set extension.CreateSettings, cfg component.Config) (extension.Extension, error) {
	return newExtension(cfg.(*Config), set.Logger)
}
