#!/usr/bin/env bash
#
# setup-self-hosted-64core.sh
# ---------------------------
# Provisions a 64-vCPU AWS c6i.16xlarge as an ephemeral self-hosted GitHub
# Actions runner labeled [self-hosted, linux, X64, '64-core'].
#
# Cost estimate (us-east-1, on-demand): $2.72/hr; a full matrix run (~15 min
# including cold-start) costs ~$0.70. Spot pricing drops that to ~$0.20.
#
# For a Team/Enterprise Cloud plan alternative, use GitHub's `linux_64_core`
# larger runner at $0.256/min ($15.36/hr) — no provisioning required.
#
# Requires: AWS CLI v2, jq. Assumes an existing IAM role with EC2 launch perms.
#
# Usage:
#   export GH_REPO="owner/repo"
#   export GH_RUNNER_TOKEN="$(gh api -X POST /repos/$GH_REPO/actions/runners/registration-token -q .token)"
#   ./setup-self-hosted-64core.sh
#
# The instance auto-terminates after the workflow completes.

set -euo pipefail

: "${GH_REPO:?must be set to owner/repo}"
: "${GH_RUNNER_TOKEN:?must be set (from POST /repos/OWNER/REPO/actions/runners/registration-token)}"

INSTANCE_TYPE="${INSTANCE_TYPE:-c6i.16xlarge}"
AWS_REGION="${AWS_REGION:-us-east-1}"
# Ubuntu 22.04 LTS x86_64 (Canonical) — refresh via:
#   aws ec2 describe-images --owners 099720109477 --filters \
#     "Name=name,Values=ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*"
AMI_ID="${AMI_ID:-ami-0c7217cdde317cfec}"
KEY_NAME="${KEY_NAME:?ec2 keypair name}"
SUBNET_ID="${SUBNET_ID:?vpc subnet id}"
SG_ID="${SG_ID:?security group id (needs outbound 443 to github.com)}"

RUNNER_VERSION="${RUNNER_VERSION:-2.319.1}"

read -r -d '' USER_DATA <<EOF || true
#!/bin/bash
set -eux
apt-get update -y
apt-get install -y jq curl ca-certificates tar
useradd -m -s /bin/bash gha
mkdir -p /home/gha/actions-runner && cd /home/gha/actions-runner
curl -o runner.tar.gz -L \
  https://github.com/actions/runner/releases/download/v${RUNNER_VERSION}/actions-runner-linux-x64-${RUNNER_VERSION}.tar.gz
tar xzf runner.tar.gz
chown -R gha:gha /home/gha/actions-runner
sudo -u gha ./config.sh \
  --url https://github.com/${GH_REPO} \
  --token ${GH_RUNNER_TOKEN} \
  --labels 64-core,linux,X64 \
  --unattended \
  --ephemeral
sudo -u gha ./run.sh
# Ephemeral runner exits after 1 job -> self-terminate.
shutdown -h now
EOF

echo "Launching ${INSTANCE_TYPE} in ${AWS_REGION}..."
INSTANCE_ID=$(aws ec2 run-instances \
  --region "${AWS_REGION}" \
  --image-id "${AMI_ID}" \
  --instance-type "${INSTANCE_TYPE}" \
  --key-name "${KEY_NAME}" \
  --subnet-id "${SUBNET_ID}" \
  --security-group-ids "${SG_ID}" \
  --instance-initiated-shutdown-behavior terminate \
  --user-data "${USER_DATA}" \
  --tag-specifications \
    "ResourceType=instance,Tags=[{Key=Name,Value=gha-64core-runner},{Key=purpose,Value=otel-loadtest}]" \
  --query 'Instances[0].InstanceId' \
  --output text)

echo "Instance: ${INSTANCE_ID}"
echo "Waiting for runner to register (~90s)..."
sleep 90
aws ec2 describe-instances --region "${AWS_REGION}" \
  --instance-ids "${INSTANCE_ID}" \
  --query 'Reservations[0].Instances[0].{ID:InstanceId,IP:PublicIpAddress,State:State.Name}'

echo "Done. The runner will pick up one job then self-terminate."
