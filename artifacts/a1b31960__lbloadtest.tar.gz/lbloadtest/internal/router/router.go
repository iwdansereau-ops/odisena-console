// Package router contains the two router implementations under test:
//
//   1. RWMutexRouter — mirrors the current contrib/loadbalancingexporter
//      pattern (sync.RWMutex guarding ring + exporter map).
//   2. AtomicRouter  — SOP §2.2 pattern (atomic.Pointer[snapshot]).
//
// Both expose the same interface so the load-test binary can swap them
// without any other changes.
package router

import (
	"fmt"
	"hash/fnv"
	"sort"
	"sync"
	"sync/atomic"
)

// WrappedExporter stands in for a real *wrappedExporter. Its only observed
// property is pointer identity — we do not actually export anything.
type WrappedExporter struct {
	Endpoint string
	_        [56]byte // pad to 64-byte cache line to prevent false sharing
}

// Router is the interface both implementations satisfy.
type Router interface {
	// ExporterAndEndpoint replicates loadbalancer.go's method exactly.
	ExporterAndEndpoint(traceID []byte) *WrappedExporter
	// OnBackendChanges swaps in a new backend set.
	OnBackendChanges(endpoints []string)
	// Name for reporting.
	Name() string
}

// -------- Consistent-hash ring (identical for both impls) --------

const virtualNodesPerEndpoint = 100

type HashRing struct {
	positions []uint32
	owner     map[uint32]string
}

func NewHashRing(endpoints []string) *HashRing {
	r := &HashRing{owner: make(map[uint32]string, len(endpoints)*virtualNodesPerEndpoint)}
	for _, ep := range endpoints {
		for v := 0; v < virtualNodesPerEndpoint; v++ {
			h := fnv.New32a()
			fmt.Fprintf(h, "%s#%d", ep, v)
			pos := h.Sum32()
			r.positions = append(r.positions, pos)
			r.owner[pos] = ep
		}
	}
	sort.Slice(r.positions, func(i, j int) bool { return r.positions[i] < r.positions[j] })
	return r
}

func (r *HashRing) EndpointFor(traceID []byte) string {
	h := fnv.New32a()
	h.Write(traceID)
	target := h.Sum32()
	idx := sort.Search(len(r.positions), func(i int) bool { return r.positions[i] >= target })
	if idx == len(r.positions) {
		idx = 0
	}
	return r.owner[r.positions[idx]]
}

// -------- Impl 1: sync.RWMutex (current loadbalancingexporter pattern) --------

type RWMutexRouter struct {
	mu        sync.RWMutex
	ring      *HashRing
	exporters map[string]*WrappedExporter
}

func NewRWMutexRouter(endpoints []string) *RWMutexRouter {
	exps := make(map[string]*WrappedExporter, len(endpoints))
	for _, ep := range endpoints {
		exps[ep] = &WrappedExporter{Endpoint: ep}
	}
	return &RWMutexRouter{ring: NewHashRing(endpoints), exporters: exps}
}

func (r *RWMutexRouter) ExporterAndEndpoint(traceID []byte) *WrappedExporter {
	r.mu.RLock()
	defer r.mu.RUnlock()
	ep := r.ring.EndpointFor(traceID)
	return r.exporters[ep]
}

func (r *RWMutexRouter) OnBackendChanges(endpoints []string) {
	newRing := NewHashRing(endpoints)
	newExps := make(map[string]*WrappedExporter, len(endpoints))
	for _, ep := range endpoints {
		newExps[ep] = &WrappedExporter{Endpoint: ep}
	}
	r.mu.Lock()
	r.ring = newRing
	r.exporters = newExps
	r.mu.Unlock()
}

func (r *RWMutexRouter) Name() string { return "rwmutex" }

// -------- Impl 2: atomic.Pointer[snapshot] (SOP §2.2) --------

type snapshot struct {
	ring      *HashRing
	exporters map[string]*WrappedExporter
	version   uint64
}

type AtomicRouter struct {
	snap    atomic.Pointer[snapshot]
	version atomic.Uint64
}

func NewAtomicRouter(endpoints []string) *AtomicRouter {
	r := &AtomicRouter{}
	r.OnBackendChanges(endpoints)
	return r
}

func (r *AtomicRouter) ExporterAndEndpoint(traceID []byte) *WrappedExporter {
	s := r.snap.Load()
	ep := s.ring.EndpointFor(traceID)
	return s.exporters[ep]
}

func (r *AtomicRouter) OnBackendChanges(endpoints []string) {
	exps := make(map[string]*WrappedExporter, len(endpoints))
	for _, ep := range endpoints {
		exps[ep] = &WrappedExporter{Endpoint: ep}
	}
	r.snap.Store(&snapshot{
		ring:      NewHashRing(endpoints),
		exporters: exps,
		version:   r.version.Add(1),
	})
}

func (r *AtomicRouter) Name() string { return "atomic" }
