// Command lbload runs a synthetic OTLP-shaped workload against one of two
// router implementations and records per-call latency into an HDR histogram.
//
// Design principles:
//
//   - Each worker goroutine simulates one num_consumers slot of an exporter.
//     Every worker calls ConsumeTraces(td) with td containing 10 spans across
//     1 resource / 1 scope. For each span, the worker resolves the routing
//     table exactly once — mirroring loadbalancer/trace_exporter.go's inner
//     loop (per-trace-ID lookup with per-batch cache).
//
//   - Latency is recorded per ConsumeTraces call, using the SCHEDULED time
//     as t0, not the send time. This prevents coordinated omission: if a
//     worker falls behind, the queued calls' latencies grow, exposing
//     RWMutex-induced backpressure instead of hiding it in the generator.
//
//   - Each worker owns a private HDR histogram; histograms are merged after
//     the run completes so the recording path itself has no contention.
//
//   - Warmup calls are recorded to a separate histogram and discarded, so
//     GC / PGO / cache-warming effects do not skew the reported percentiles.
//
// Output: a single JSON document on stdout with per-call latency percentiles,
// total ops served, actual achieved rate, and enough metadata to reconstruct
// the run parameters.
package main

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"runtime"
	"sync"
	"time"

	"github.com/HdrHistogram/hdrhistogram-go"
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/ptrace"

	"lbloadtest/internal/router"
)

// Flags
var (
	implFlag        = flag.String("impl", "rwmutex", "router implementation: rwmutex or atomic")
	targetRateFlag  = flag.Int("rate", 100_000, "target ConsumeTraces calls/sec (aggregate across workers)")
	spansPerCall    = flag.Int("spans-per-call", 10, "spans per ConsumeTraces payload")
	workersFlag     = flag.Int("workers", 0, "num_consumers; 0 = 2×GOMAXPROCS")
	warmupFlag      = flag.Duration("warmup", 5*time.Second, "warmup duration (excluded from stats)")
	durationFlag    = flag.Duration("duration", 30*time.Second, "measurement duration")
	backendsFlag    = flag.Int("backends", 32, "number of routing backends in the ring")
	churnFlag       = flag.Duration("churn", 0, "if >0, backend set is rebuilt at this cadence (writer scenario)")
	outFlag         = flag.String("out", "", "write JSON result to this path; empty = stdout")
	labelFlag       = flag.String("label", "", "free-form label included in result JSON (e.g., 'gha-64-core')")
)

func main() {
	flag.Parse()

	workers := *workersFlag
	if workers == 0 {
		workers = 2 * runtime.GOMAXPROCS(0)
	}
	if workers < 1 {
		workers = 1
	}

	// Build the router under test.
	endpoints := mkEndpoints(*backendsFlag)
	var r router.Router
	switch *implFlag {
	case "rwmutex":
		r = router.NewRWMutexRouter(endpoints)
	case "atomic":
		r = router.NewAtomicRouter(endpoints)
	default:
		fatalf("unknown -impl=%q; want rwmutex or atomic", *implFlag)
	}

	// Optional writer churning backends (models a DNS/K8s resolver).
	churnCtx, cancelChurn := context.WithCancel(context.Background())
	defer cancelChurn()
	var churnWG sync.WaitGroup
	if *churnFlag > 0 {
		churnWG.Add(1)
		go func() {
			defer churnWG.Done()
			tick := time.NewTicker(*churnFlag)
			defer tick.Stop()
			toggle := false
			for {
				select {
				case <-churnCtx.Done():
					return
				case <-tick.C:
					if toggle {
						r.OnBackendChanges(endpoints)
					} else {
						r.OnBackendChanges(endpoints[:len(endpoints)-1])
					}
					toggle = !toggle
				}
			}
		}()
	}

	// Per-worker histograms — merged after run.
	// Range: 100 ns .. 60 s, 3 significant figures.
	newHist := func() *hdrhistogram.Histogram {
		return hdrhistogram.New(100, int64(60*time.Second), 3)
	}
	hists := make([]*hdrhistogram.Histogram, workers)
	for i := range hists {
		hists[i] = newHist()
	}

	// Aggregate counters.
	var totalOps, totalDroppedOps, totalSpansResolved int64
	var mu sync.Mutex // for aggregating tail counters

	// Rate control: each worker gets rate/workers calls/sec.
	perWorkerRate := float64(*targetRateFlag) / float64(workers)
	interval := time.Duration(float64(time.Second) / perWorkerRate)

	// Start signal so all workers begin measuring at the same wall-clock time.
	measureStart := make(chan struct{})
	stop := make(chan struct{})

	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()

			// Pre-build the pdata payload once per worker; the router does
			// not mutate the payload (MutatesData=false), so reuse is safe.
			td := ptrace.NewTraces()
			rs := td.ResourceSpans().AppendEmpty()
			rs.Resource().Attributes().PutStr("service.name", fmt.Sprintf("worker-%d", id))
			ss := rs.ScopeSpans().AppendEmpty()
			for i := 0; i < *spansPerCall; i++ {
				s := ss.Spans().AppendEmpty()
				s.SetName("op")
			}

			gen := newRIDGen(uint64(id)*0x9E3779B97F4A7C15 + 1)
			hist := hists[id]

			// Warmup: run at target rate, discard results.
			warmupDeadline := time.Now().Add(*warmupFlag)
			nextTick := time.Now()
			for time.Now().Before(warmupDeadline) {
				consumeTraces(&td, r, gen)
				nextTick = nextTick.Add(interval)
				if d := time.Until(nextTick); d > 0 {
					time.Sleep(d)
				}
			}

			// Barrier: wait for all workers to finish warmup.
			<-measureStart

			// Measurement: scheduled-time latency, coordinated-omission-safe.
			var opsLocal, droppedLocal, spansLocal int64
			endAt := time.Now().Add(*durationFlag)
			scheduled := time.Now()
			for time.Now().Before(endAt) {
				// If we are behind schedule, do NOT skip — record the true
				// scheduled-to-completion latency, which is the honest signal.
				now := time.Now()
				if now.Before(scheduled) {
					time.Sleep(scheduled.Sub(now))
				}
				start := scheduled
				spansResolved := consumeTraces(&td, r, gen)
				elapsed := time.Since(start)
				if err := hist.RecordValue(int64(elapsed)); err != nil {
					droppedLocal++
				}
				opsLocal++
				spansLocal += int64(spansResolved)
				scheduled = scheduled.Add(interval)

				// Check for stop signal without blocking.
				select {
				case <-stop:
					goto done
				default:
				}
			}
		done:
			mu.Lock()
			totalOps += opsLocal
			totalDroppedOps += droppedLocal
			totalSpansResolved += spansLocal
			mu.Unlock()
		}(i)
	}

	// Warmup already ran per-worker; signal start of measurement.
	time.Sleep(*warmupFlag + 500*time.Millisecond) // small pad for slow workers
	measureStart2 := time.Now()
	close(measureStart)

	// Watchdog: force-stop 2s after duration expires to catch stuck workers.
	go func() {
		time.Sleep(*durationFlag + 2*time.Second)
		close(stop)
	}()

	wg.Wait()
	measureElapsed := time.Since(measureStart2)

	cancelChurn()
	churnWG.Wait()

	// Merge histograms.
	merged := newHist()
	for _, h := range hists {
		merged.Merge(h)
	}

	// Emit result.
	result := Result{
		Label:              *labelFlag,
		Impl:               r.Name(),
		Workers:            workers,
		GOMAXPROCS:         runtime.GOMAXPROCS(0),
		NumCPU:             runtime.NumCPU(),
		TargetRatePerSec:   *targetRateFlag,
		AchievedRatePerSec: float64(totalOps) / measureElapsed.Seconds(),
		SpansPerCall:       *spansPerCall,
		Backends:           *backendsFlag,
		ChurnInterval:      churnStr(*churnFlag),
		WarmupSec:          warmupFlag.Seconds(),
		DurationSec:        measureElapsed.Seconds(),
		TotalOps:           totalOps,
		TotalSpansResolved: totalSpansResolved,
		DroppedRecords:     totalDroppedOps,
		LatencyNs: LatencyStats{
			Min:   merged.Min(),
			P50:   merged.ValueAtQuantile(50),
			P75:   merged.ValueAtQuantile(75),
			P90:   merged.ValueAtQuantile(90),
			P99:   merged.ValueAtQuantile(99),
			P999:  merged.ValueAtQuantile(99.9),
			P9999: merged.ValueAtQuantile(99.99),
			Max:   merged.Max(),
			Mean:  merged.Mean(),
			Stdev: merged.StdDev(),
		},
	}

	buf, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		fatalf("marshal: %v", err)
	}
	if *outFlag == "" {
		os.Stdout.Write(buf)
		fmt.Println()
	} else {
		if err := os.WriteFile(*outFlag, buf, 0o644); err != nil {
			fatalf("write %s: %v", *outFlag, err)
		}
		fmt.Fprintf(os.Stderr, "wrote %s\n", *outFlag)
	}
}

// consumeTraces simulates the loadbalancingexporter's ConsumeTraces:
// resolve each span's trace ID through the router. Returns spans resolved.
func consumeTraces(td *ptrace.Traces, r router.Router, gen *ridGen) int {
	rss := td.ResourceSpans()
	resolved := 0
	buf := make([]byte, 16)
	for i := 0; i < rss.Len(); i++ {
		sss := rss.At(i).ScopeSpans()
		for j := 0; j < sss.Len(); j++ {
			spans := sss.At(j).Spans()
			for k := 0; k < spans.Len(); k++ {
				gen.next(buf)
				spans.At(k).SetTraceID(pcommon.TraceID(buf))
				_ = r.ExporterAndEndpoint(buf)
				resolved++
			}
		}
	}
	return resolved
}

// -------- Helpers --------

func mkEndpoints(n int) []string {
	out := make([]string, n)
	for i := range out {
		out[i] = fmt.Sprintf("backend-%02d.otel.svc.cluster.local:4317", i)
	}
	return out
}

func churnStr(d time.Duration) string {
	if d == 0 {
		return ""
	}
	return d.String()
}

// xorshift64* per-goroutine PRNG — no shared state, no lock.
type ridGen struct{ state uint64 }

func newRIDGen(seed uint64) *ridGen {
	if seed == 0 {
		var b [8]byte
		_, _ = rand.Read(b[:])
		for i, v := range b {
			seed |= uint64(v) << (8 * i)
		}
	}
	return &ridGen{state: seed | 1}
}

func (g *ridGen) next(buf []byte) {
	x := g.state
	x ^= x >> 12
	x ^= x << 25
	x ^= x >> 27
	g.state = x
	v := x * 2685821657736338717
	for i := 0; i < len(buf); i++ {
		buf[i] = byte(v >> uint((i%8)*8))
		if i == 7 {
			v = v*6364136223846793005 + 1442695040888963407
		}
	}
}

// Result is the JSON schema emitted at end of run.
type Result struct {
	Label              string       `json:"label"`
	Impl               string       `json:"impl"`
	Workers            int          `json:"workers"`
	GOMAXPROCS         int          `json:"gomaxprocs"`
	NumCPU             int          `json:"num_cpu"`
	TargetRatePerSec   int          `json:"target_rate_per_sec"`
	AchievedRatePerSec float64      `json:"achieved_rate_per_sec"`
	SpansPerCall       int          `json:"spans_per_call"`
	Backends           int          `json:"backends"`
	ChurnInterval      string       `json:"churn_interval"`
	WarmupSec          float64      `json:"warmup_sec"`
	DurationSec        float64      `json:"duration_sec"`
	TotalOps           int64        `json:"total_ops"`
	TotalSpansResolved int64        `json:"total_spans_resolved"`
	DroppedRecords     int64        `json:"dropped_records"`
	LatencyNs          LatencyStats `json:"latency_ns"`
}

type LatencyStats struct {
	Min   int64   `json:"min"`
	P50   int64   `json:"p50"`
	P75   int64   `json:"p75"`
	P90   int64   `json:"p90"`
	P99   int64   `json:"p99"`
	P999  int64   `json:"p99_9"`
	P9999 int64   `json:"p99_99"`
	Max   int64   `json:"max"`
	Mean  float64 `json:"mean"`
	Stdev float64 `json:"stdev"`
}

func fatalf(format string, a ...any) {
	fmt.Fprintf(os.Stderr, format+"\n", a...)
	os.Exit(1)
}
