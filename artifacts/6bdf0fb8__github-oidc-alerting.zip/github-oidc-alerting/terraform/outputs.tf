output "sns_topic_arn" {
  description = "Subscribe Slack/PagerDuty/Chatbot to this."
  value       = aws_sns_topic.alerts.arn
}

output "kms_key_arn" {
  description = "KMS CMK used to encrypt the SNS topic and log groups."
  value       = aws_kms_key.alerts.arn
}

output "enricher_lambda_arn" {
  description = "ARN of the enricher Lambda function."
  value       = aws_lambda_function.enricher.arn
}

output "eventbridge_rule_names" {
  description = "Names of the EventBridge rules deployed in the primary region."
  value = compact([
    aws_cloudwatch_event_rule.assume_role_with_web_identity.name,
    aws_cloudwatch_event_rule.arwi_denied_or_wrong_provider.name,
    aws_cloudwatch_event_rule.cloudtrail_insights.name,
  ])
}

output "us_east_1_forwarder_rule_name" {
  description = "Name of the cross-region forwarder rule in us-east-1, if enabled."
  value       = try(aws_cloudwatch_event_rule.arwi_forward_from_useast1[0].name, null)
}
