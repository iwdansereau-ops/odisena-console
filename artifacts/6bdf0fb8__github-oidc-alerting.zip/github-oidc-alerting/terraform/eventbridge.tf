########################################
# Rule 1 — Every AssumeRoleWithWebIdentity call targeting our role
# fires the enricher Lambda for detailed classification.
########################################

resource "aws_cloudwatch_event_rule" "assume_role_with_web_identity" {
  name        = "${var.sns_topic_name}-arwi-audit"
  description = "All AssumeRoleWithWebIdentity calls targeting the monitored GitHub OIDC role."
  event_bus_name = var.eventbridge_bus_name

  event_pattern = jsonencode({
    source        = ["aws.sts"]
    "detail-type" = ["AWS API Call via CloudTrail"]
    detail = {
      eventSource = ["sts.amazonaws.com"]
      eventName   = ["AssumeRoleWithWebIdentity"]
      requestParameters = {
        roleArn = [var.monitored_role_arn]
      }
    }
  })

  tags = var.tags
}

resource "aws_cloudwatch_event_target" "arwi_to_enricher" {
  rule      = aws_cloudwatch_event_rule.assume_role_with_web_identity.name
  event_bus_name = var.eventbridge_bus_name
  target_id = "enricher"
  arn       = aws_lambda_function.enricher.arn
}

########################################
# Rule 2 — Fast-path: obviously bad events (AccessDenied,
# wrong issuer, or wrong repo sub claim) that don't even
# need enrichment. Publishes directly to SNS with a
# structured alert via InputTransformer.
########################################

resource "aws_cloudwatch_event_rule" "arwi_denied_or_wrong_provider" {
  name        = "${var.sns_topic_name}-arwi-denied"
  description = "AssumeRoleWithWebIdentity failures or issuer mismatches for the monitored role."
  event_bus_name = var.eventbridge_bus_name

  event_pattern = jsonencode({
    source        = ["aws.sts"]
    "detail-type" = ["AWS API Call via CloudTrail"]
    detail = {
      eventSource = ["sts.amazonaws.com"]
      eventName   = ["AssumeRoleWithWebIdentity"]
      requestParameters = {
        roleArn = [var.monitored_role_arn]
      }
      "$or" = [
        { errorCode = [{ exists = true }] },
        { userIdentity = { identityProvider = [{ "anything-but" = [var.expected_oidc_provider_url] }] } },
      ]
    }
  })

  tags = var.tags
}

resource "aws_cloudwatch_event_target" "denied_to_sns" {
  rule      = aws_cloudwatch_event_rule.arwi_denied_or_wrong_provider.name
  event_bus_name = var.eventbridge_bus_name
  target_id = "sns"
  arn       = aws_sns_topic.alerts.arn

  input_transformer {
    input_paths = {
      time        = "$.time"
      account     = "$.account"
      region      = "$.region"
      ip          = "$.detail.sourceIPAddress"
      ua          = "$.detail.userAgent"
      provider    = "$.detail.userIdentity.identityProvider"
      role        = "$.detail.requestParameters.roleArn"
      session     = "$.detail.requestParameters.roleSessionName"
      errorCode   = "$.detail.errorCode"
      errorMsg    = "$.detail.errorMessage"
      eventId     = "$.detail.eventID"
    }

    input_template = <<EOT
"[HIGH] GitHub OIDC role misuse detected"
""
"time:       <time>"
"account:    <account>"
"region:     <region>"
"role:       <role>"
"session:    <session>"
"source IP:  <ip>"
"user agent: <ua>"
"issuer:     <provider>   (expected: ${var.expected_oidc_provider_url})"
"errorCode:  <errorCode>"
"errorMsg:   <errorMsg>"
"eventID:    <eventId>"
""
"Investigate immediately: this AssumeRoleWithWebIdentity attempt against ${var.monitored_role_arn} either failed or came from a non-GitHub OIDC issuer."
EOT
  }
}

########################################
# Rule 3 — CloudTrail Insights anomalies (rate + error spikes)
# on STS. These fire when Insights detects something unusual —
# e.g. sudden burst of AssumeRoleWithWebIdentity failures.
########################################

resource "aws_cloudwatch_event_rule" "cloudtrail_insights" {
  name        = "${var.sns_topic_name}-cloudtrail-insights"
  description = "CloudTrail Insights anomalies for STS AssumeRoleWithWebIdentity."
  event_bus_name = var.eventbridge_bus_name

  event_pattern = jsonencode({
    source        = ["aws.cloudtrail"]
    "detail-type" = ["AWS Insight via CloudTrail"]
    detail = {
      insightDetails = {
        eventSource = ["sts.amazonaws.com"]
        eventName   = ["AssumeRoleWithWebIdentity"]
        state       = ["Start"]
      }
    }
  })

  tags = var.tags
}

resource "aws_cloudwatch_event_target" "insights_to_sns" {
  rule      = aws_cloudwatch_event_rule.cloudtrail_insights.name
  event_bus_name = var.eventbridge_bus_name
  target_id = "sns"
  arn       = aws_sns_topic.alerts.arn

  input_transformer {
    input_paths = {
      time         = "$.time"
      account      = "$.account"
      region       = "$.region"
      insightType  = "$.detail.insightDetails.insightType"
      eventName    = "$.detail.insightDetails.eventName"
      eventSource  = "$.detail.insightDetails.eventSource"
      baseline     = "$.detail.insightDetails.insightContext.statistics.baseline.average"
      insight      = "$.detail.insightDetails.insightContext.statistics.insight.average"
    }

    input_template = <<EOT
"[MEDIUM] CloudTrail Insight anomaly on STS AssumeRoleWithWebIdentity"
""
"time:         <time>"
"account:      <account>"
"region:       <region>"
"insightType:  <insightType>   (ApiCallRateInsight or ApiErrorRateInsight)"
"eventSource:  <eventSource>"
"eventName:    <eventName>"
"baseline:     <baseline> calls/min"
"observed:     <insight> calls/min"
""
"Investigate whether this spike correlates with legitimate CI/CD activity for ${var.github_org}/${var.github_repo}."
EOT
  }
}

########################################
# Rule 4 — Forward matching STS events from us-east-1 to this region.
#
# STS is a global service; when the SDK uses the global endpoint, events
# are logged in us-east-1 regardless of where the workload runs. This
# rule (in us-east-1) puts matching events onto this region's default bus
# so a single alerting stack sees everything.
########################################

resource "aws_cloudwatch_event_rule" "arwi_forward_from_useast1" {
  count       = var.forward_from_us_east_1 && var.aws_region != "us-east-1" ? 1 : 0
  provider    = aws.us_east_1
  name        = "${var.sns_topic_name}-arwi-forward"
  description = "Forward AssumeRoleWithWebIdentity events for the monitored role from us-east-1 to ${var.aws_region}."

  event_pattern = jsonencode({
    source        = ["aws.sts"]
    "detail-type" = ["AWS API Call via CloudTrail"]
    detail = {
      eventSource = ["sts.amazonaws.com"]
      eventName   = ["AssumeRoleWithWebIdentity"]
      requestParameters = {
        roleArn = [var.monitored_role_arn]
      }
    }
  })

  tags = var.tags
}

resource "aws_iam_role" "forwarder" {
  count = var.forward_from_us_east_1 && var.aws_region != "us-east-1" ? 1 : 0
  name  = "${var.sns_topic_name}-eventbridge-forwarder"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "events.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = var.tags
}

resource "aws_iam_role_policy" "forwarder" {
  count = var.forward_from_us_east_1 && var.aws_region != "us-east-1" ? 1 : 0
  role  = aws_iam_role.forwarder[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "events:PutEvents"
      Resource = "arn:${local.partition}:events:${var.aws_region}:${local.account_id}:event-bus/${var.eventbridge_bus_name}"
    }]
  })
}

resource "aws_cloudwatch_event_target" "arwi_forward" {
  count     = var.forward_from_us_east_1 && var.aws_region != "us-east-1" ? 1 : 0
  provider  = aws.us_east_1
  rule      = aws_cloudwatch_event_rule.arwi_forward_from_useast1[0].name
  target_id = "cross-region-bus"
  arn       = "arn:${local.partition}:events:${var.aws_region}:${local.account_id}:event-bus/${var.eventbridge_bus_name}"
  role_arn  = aws_iam_role.forwarder[0].arn
}

########################################
# Optional: CloudTrail Insights on an existing trail
#
# We can't natively toggle insight_selectors on a trail we don't own
# without importing it. Use the AWS CLI via local-exec (idempotent).
# Skip this by setting enable_cloudtrail_insights = false and running
# the equivalent command manually.
########################################

resource "terraform_data" "enable_insights" {
  count = var.enable_cloudtrail_insights && var.cloudtrail_name != "" ? 1 : 0

  triggers_replace = {
    trail = var.cloudtrail_name
  }

  provisioner "local-exec" {
    command = <<-EOT
      aws cloudtrail put-insight-selectors \
        --region ${var.aws_region} \
        --trail-name ${var.cloudtrail_name} \
        --insight-selectors '[{"InsightType":"ApiCallRateInsight"},{"InsightType":"ApiErrorRateInsight"}]'
    EOT
  }
}
