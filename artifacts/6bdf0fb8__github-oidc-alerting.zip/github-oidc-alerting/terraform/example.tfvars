########################################
# Alerting stack — example inputs
########################################

aws_region = "us-east-1"

# The IAM role from the github-oidc-aws module.
monitored_role_arn = "arn:aws:iam::111122223333:role/github-actions-otel-collector-deploy"

# Legitimate caller identity.
github_org  = "odisena"
github_repo = "otel-collector-infra"

# Sessions from the hardened workflow start with gha-otel-...
expected_role_session_prefix = "gha-otel-"

# Leave empty to auto-fetch GitHub-hosted runner CIDRs from api.github.com/meta.
# If you use self-hosted runners in a VPC + NAT gateway, list those NAT EIPs
# here instead — much stronger allow-list than GitHub's broad ranges.
allowed_source_ip_cidrs = []

# CloudTrail Insights (optional but recommended).
enable_cloudtrail_insights = true
cloudtrail_name            = "odisena-org-trail"

# Alert delivery — add more email addresses or attach Slack via Chatbot to the SNS ARN.
alert_email_addresses = ["security-oncall@odisena.example"]

# Since aws_region = us-east-1, forwarding isn't needed. If you deployed
# this stack in us-west-2, set forward_from_us_east_1 = true (default) and
# add the aws.us_east_1 provider alias in your root module.
forward_from_us_east_1 = false

tags = {
  Owner       = "platform-security"
  Component   = "github-oidc-alerts"
  Environment = "prod"
}
