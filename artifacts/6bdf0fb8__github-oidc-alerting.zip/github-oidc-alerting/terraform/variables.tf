########################################
# What we're watching
########################################

variable "monitored_role_arn" {
  description = <<-EOT
    ARN of the IAM role that GitHub Actions assumes via OIDC
    (the one from the github-oidc-aws module).
  EOT
  type        = string
}

variable "github_org" {
  description = "GitHub org that legitimately assumes the role."
  type        = string
}

variable "github_repo" {
  description = "GitHub repo that legitimately assumes the role."
  type        = string
}

variable "expected_oidc_provider_url" {
  description = "OIDC issuer that must appear in the CloudTrail event. Change only for GHE."
  type        = string
  default     = "token.actions.githubusercontent.com"
}

variable "expected_audience" {
  description = "Expected aud claim."
  type        = string
  default     = "sts.amazonaws.com"
}

variable "expected_role_session_prefix" {
  description = <<-EOT
    Prefix that legitimate role sessions must start with. The reference
    workflow uses gha-otel-... — the enricher flags anything else.
  EOT
  type        = string
  default     = "gha-otel-"
}

variable "allowed_source_ip_cidrs" {
  description = <<-EOT
    Optional CIDR allow-list for sourceIPAddress. If empty, the enricher
    falls back to GitHub's published hosted-runner ranges via meta_api_url.
    Provide values here only if you use exclusively self-hosted runners
    inside a known VPC/NAT range.
  EOT
  type        = list(string)
  default     = []
}

variable "github_meta_api_url" {
  description = "GitHub Meta API endpoint the enricher queries for hosted-runner IP ranges."
  type        = string
  default     = "https://api.github.com/meta"
}

########################################
# Alerting infra
########################################

variable "alert_email_addresses" {
  description = "Email addresses subscribed to the SNS topic. Optional if you attach Slack/PagerDuty separately."
  type        = list(string)
  default     = []
}

variable "sns_topic_name" {
  description = "Name of the SNS topic that receives alerts."
  type        = string
  default     = "github-oidc-role-alerts"
}

variable "eventbridge_bus_name" {
  description = "Name of the EventBridge bus to attach rules to. Use \"default\" unless you have a custom bus."
  type        = string
  default     = "default"
}

variable "enable_cloudtrail_insights" {
  description = "Whether to enable ApiCallRate + ApiErrorRate Insights on the specified trail."
  type        = bool
  default     = true
}

variable "cloudtrail_name" {
  description = <<-EOT
    Name of the existing multi-region CloudTrail. Required when
    enable_cloudtrail_insights = true. Trail must include global service
    events (include_global_service_events = true) so STS calls are captured.
  EOT
  type        = string
  default     = ""
}

variable "forward_from_us_east_1" {
  description = <<-EOT
    STS is a global service — AssumeRoleWithWebIdentity events flow through
    us-east-1 when the global endpoint is used. When true, we deploy a
    forwarder rule in us-east-1 that ships matching events to this region's
    bus. Set false if your target region already IS us-east-1.
  EOT
  type        = bool
  default     = true
}

variable "aws_region" {
  description = "Primary region where the alerting stack lives."
  type        = string
}

variable "log_retention_days" {
  description = "CloudWatch Logs retention for the enricher Lambda."
  type        = number
  default     = 90
}

variable "tags" {
  description = "Tags applied to all resources."
  type        = map(string)
  default     = {}
}
