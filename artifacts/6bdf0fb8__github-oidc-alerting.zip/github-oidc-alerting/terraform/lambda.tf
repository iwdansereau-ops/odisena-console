########################################
# Enricher Lambda
#
# Receives every AssumeRoleWithWebIdentity CloudTrail event that targets
# the monitored role. Decides whether the call is legitimate by checking:
#
#   1. identityProvider matches token.actions.githubusercontent.com
#   2. userIdentity.identityProvider matches expected_oidc_provider_url
#   3. requestParameters.roleArn == monitored_role_arn
#   4. requestParameters.roleSessionName starts with expected prefix
#   5. errorCode is absent (the call succeeded)
#   6. sourceIPAddress falls inside allowed_source_ip_cidrs, OR (if empty)
#      inside the current GitHub-published `actions` IP ranges
#
# Anything that fails is published to SNS as a HIGH severity alert.
# Successful calls are logged as INFO for audit continuity.
########################################

data "archive_file" "enricher" {
  type        = "zip"
  source_dir  = "${path.module}/../lambda"
  output_path = "${path.module}/build/enricher.zip"
  excludes    = ["__pycache__", "*.pyc", ".pytest_cache"]
}

resource "aws_iam_role" "enricher" {
  name = "${var.sns_topic_name}-enricher"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = var.tags
}

resource "aws_iam_role_policy_attachment" "enricher_basic" {
  role       = aws_iam_role.enricher.name
  policy_arn = "arn:${local.partition}:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

data "aws_iam_policy_document" "enricher_inline" {
  statement {
    sid       = "PublishAlert"
    effect    = "Allow"
    actions   = ["sns:Publish"]
    resources = [aws_sns_topic.alerts.arn]
  }

  statement {
    sid       = "UseAlertKey"
    effect    = "Allow"
    actions   = ["kms:GenerateDataKey*", "kms:Decrypt"]
    resources = [aws_kms_key.alerts.arn]
  }

  # Cache GitHub Meta ranges in an SSM parameter so we don't hit the API on
  # every invocation.
  statement {
    sid    = "CacheGitHubRanges"
    effect = "Allow"
    actions = [
      "ssm:GetParameter",
      "ssm:PutParameter",
    ]
    resources = [
      "arn:${local.partition}:ssm:${var.aws_region}:${local.account_id}:parameter/github-oidc-alerts/*",
    ]
  }
}

resource "aws_iam_role_policy" "enricher_inline" {
  role   = aws_iam_role.enricher.id
  policy = data.aws_iam_policy_document.enricher_inline.json
}

resource "aws_cloudwatch_log_group" "enricher" {
  name              = "/aws/lambda/${var.sns_topic_name}-enricher"
  retention_in_days = var.log_retention_days
  kms_key_id        = aws_kms_key.alerts.arn
  tags              = var.tags
}

resource "aws_lambda_function" "enricher" {
  function_name = "${var.sns_topic_name}-enricher"
  role          = aws_iam_role.enricher.arn
  runtime       = "python3.12"
  handler       = "handler.handler"
  filename      = data.archive_file.enricher.output_path
  source_code_hash = data.archive_file.enricher.output_base64sha256
  timeout       = 15
  memory_size   = 256

  environment {
    variables = {
      MONITORED_ROLE_ARN         = var.monitored_role_arn
      EXPECTED_OIDC_PROVIDER     = var.expected_oidc_provider_url
      EXPECTED_AUDIENCE          = var.expected_audience
      EXPECTED_SESSION_PREFIX    = var.expected_role_session_prefix
      EXPECTED_REPO_SUB          = "repo:${var.github_org}/${var.github_repo}"
      ALLOWED_CIDR_LIST          = join(",", var.allowed_source_ip_cidrs)
      GITHUB_META_URL            = var.github_meta_api_url
      SNS_TOPIC_ARN              = aws_sns_topic.alerts.arn
      RANGES_CACHE_PARAM         = "/github-oidc-alerts/actions-cidrs"
      RANGES_CACHE_TTL_SECONDS   = "3600"
    }
  }

  depends_on = [aws_cloudwatch_log_group.enricher]

  tags = var.tags
}

resource "aws_lambda_permission" "allow_eventbridge" {
  statement_id  = "AllowInvokeFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.enricher.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.assume_role_with_web_identity.arn
}
