"""Local smoke test — no AWS calls. Run: python3 test_handler.py"""
import os
import sys
import types

# Stub boto3 before importing the handler.
class _Stub:
    def __init__(self, *a, **kw):
        pass
    def __getattr__(self, name):
        def _method(**kw):
            if name == "get_parameter":
                # Simulate parameter-not-found so we fall through to fetch.
                import botocore.exceptions as be
                raise be.ClientError({"Error": {"Code": "ParameterNotFound"}}, "GetParameter")
            if name == "put_parameter":
                return {}
            if name == "publish":
                print(f"[SNS.publish called] subject={kw.get('Subject')!r}")
                print(kw.get("Message"))
                return {"MessageId": "test"}
            return {}
        return _method

boto3_stub = types.ModuleType("boto3")
boto3_stub.client = lambda name, **kw: _Stub()
sys.modules["boto3"] = boto3_stub

import botocore.exceptions as _be
sys.modules["botocore"] = types.ModuleType("botocore")
sys.modules["botocore.exceptions"] = _be

# Stub urllib fetch of GitHub Meta.
import urllib.request as ur
_original_urlopen = ur.urlopen
class _FakeResp:
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def read(self):
        import json as j
        return j.dumps({"actions": ["4.148.0.0/16", "20.201.0.0/16"]}).encode()
ur.urlopen = lambda *a, **kw: _FakeResp()

# Configure env.
os.environ.update({
    "MONITORED_ROLE_ARN":      "arn:aws:iam::111122223333:role/github-actions-otel-collector-deploy",
    "EXPECTED_OIDC_PROVIDER":  "token.actions.githubusercontent.com",
    "EXPECTED_AUDIENCE":       "sts.amazonaws.com",
    "EXPECTED_SESSION_PREFIX": "gha-otel-",
    "EXPECTED_REPO_SUB":       "repo:odisena/otel-collector-infra",
    "SNS_TOPIC_ARN":           "arn:aws:sns:us-east-1:111122223333:github-oidc-role-alerts",
    "ALLOWED_CIDR_LIST":       "",
})

import importlib.util, pathlib
spec = importlib.util.spec_from_file_location(
    "handler", pathlib.Path(__file__).parent.parent / "lambda" / "handler.py"
)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)

# --- Case 1: legit call from a hosted runner IP -----------------
legit = {
    "time": "2026-07-02T08:15:00Z",
    "account": "111122223333",
    "region": "us-east-1",
    "detail": {
        "eventName": "AssumeRoleWithWebIdentity",
        "eventID": "abc-legit",
        "sourceIPAddress": "4.148.10.5",
        "userAgent": "aws-sdk-nodejs/2.1600.0",
        "userIdentity": {
            "type": "WebIdentityUser",
            "principalId": "arn:aws:iam::111122223333:oidc-provider/token.actions.githubusercontent.com:sts.amazonaws.com:repo:odisena/otel-collector-infra:environment:prod",
            "identityProvider": "token.actions.githubusercontent.com",
        },
        "requestParameters": {
            "roleArn": "arn:aws:iam::111122223333:role/github-actions-otel-collector-deploy",
            "roleSessionName": "gha-otel-deploy-9876543-1",
        },
    },
}
r = h.handler(legit, None)
print("case 1 (legit):", r)
assert r["severity"] == "INFO", r
assert r["published"] is False

# --- Case 2: attacker replay from unknown IP --------------------
import copy
bad_ip = copy.deepcopy(legit)
bad_ip["detail"]["eventID"] = "attacker-ip"
bad_ip["detail"]["sourceIPAddress"] = "203.0.113.42"
r = h.handler(bad_ip, None)
print("case 2 (bad ip):", r["severity"], r["findings"])
assert r["severity"] == "HIGH"

# --- Case 3: AccessDenied (trust policy rejected the token) -----
denied = copy.deepcopy(legit)
denied["detail"]["eventID"] = "denied"
denied["detail"]["errorCode"] = "AccessDenied"
denied["detail"]["errorMessage"] = "Not authorized to perform sts:AssumeRoleWithWebIdentity"
r = h.handler(denied, None)
print("case 3 (denied):", r["severity"], r["findings"])
assert r["severity"] == "HIGH"

# --- Case 4: wrong issuer (someone bolted on a different OIDC provider)
wrong_iss = copy.deepcopy(legit)
wrong_iss["detail"]["eventID"] = "wrong-iss"
wrong_iss["detail"]["userIdentity"]["identityProvider"] = "token.evil.example"
r = h.handler(wrong_iss, None)
print("case 4 (wrong issuer):", r["severity"], r["findings"])
assert r["severity"] == "HIGH"

# --- Case 5: weird session name (workflow drift, medium sev) ----
weird_sess = copy.deepcopy(legit)
weird_sess["detail"]["eventID"] = "weird-sess"
weird_sess["detail"]["requestParameters"]["roleSessionName"] = "GitHubActions"
r = h.handler(weird_sess, None)
print("case 5 (weird session):", r["severity"], r["findings"])
assert r["severity"] == "MEDIUM"

print("\nAll cases passed.")
