"""
GitHub OIDC AssumeRoleWithWebIdentity enricher.

Triggered by every CloudTrail-derived EventBridge event for
sts:AssumeRoleWithWebIdentity against the monitored role.

Applies a set of allow-list checks; anything that fails is published to SNS
as a HIGH-severity structured alert. Legitimate calls are logged at INFO
level so we have a full audit tail in CloudWatch Logs.

Checks (in order, first mismatch decides):
  1. eventName == "AssumeRoleWithWebIdentity"
  2. requestParameters.roleArn == MONITORED_ROLE_ARN
  3. userIdentity.identityProvider == EXPECTED_OIDC_PROVIDER
  4. requestParameters.roleSessionName starts with EXPECTED_SESSION_PREFIX
  5. errorCode is absent (success)
  6. sourceIPAddress falls inside the allow-list:
       - explicit ALLOWED_CIDR_LIST if set, else
       - the current GitHub Meta `actions` ranges (cached in SSM)
  7. userAgent looks like a GitHub Actions runner
     (starts with "aws-sdk-" — configure-aws-credentials uses aws-sdk-js/nodejs)

We can't validate the sub claim from the CloudTrail event itself
(AWS strips it); IAM already enforces the trust policy for us. Instead we
verify a set of *observable* properties that correlate with a legitimate run.
"""

from __future__ import annotations

import ipaddress
import json
import logging
import os
import time
import urllib.request
from typing import Any

import boto3
from botocore.exceptions import ClientError

log = logging.getLogger()
log.setLevel(logging.INFO)

MONITORED_ROLE_ARN      = os.environ["MONITORED_ROLE_ARN"]
EXPECTED_OIDC_PROVIDER  = os.environ["EXPECTED_OIDC_PROVIDER"]
EXPECTED_AUDIENCE       = os.environ.get("EXPECTED_AUDIENCE", "sts.amazonaws.com")
EXPECTED_SESSION_PREFIX = os.environ.get("EXPECTED_SESSION_PREFIX", "")
EXPECTED_REPO_SUB       = os.environ.get("EXPECTED_REPO_SUB", "")
SNS_TOPIC_ARN           = os.environ["SNS_TOPIC_ARN"]
GITHUB_META_URL         = os.environ.get("GITHUB_META_URL", "https://api.github.com/meta")
RANGES_CACHE_PARAM      = os.environ.get("RANGES_CACHE_PARAM", "/github-oidc-alerts/actions-cidrs")
RANGES_CACHE_TTL        = int(os.environ.get("RANGES_CACHE_TTL_SECONDS", "3600"))
_ALLOWED_CIDRS_ENV      = os.environ.get("ALLOWED_CIDR_LIST", "").strip()

sns = boto3.client("sns")
ssm = boto3.client("ssm")


# --------------------------------------------------------------------------- #
# IP allow-list resolution                                                    #
# --------------------------------------------------------------------------- #

def _static_cidrs() -> list[str] | None:
    if not _ALLOWED_CIDRS_ENV:
        return None
    return [c.strip() for c in _ALLOWED_CIDRS_ENV.split(",") if c.strip()]


def _fetch_github_actions_cidrs() -> list[str]:
    """
    Fetch the current GitHub-published IP ranges for the `actions` service.
    Cached in SSM for RANGES_CACHE_TTL seconds to avoid rate limits.
    """
    now = int(time.time())

    try:
        param = ssm.get_parameter(Name=RANGES_CACHE_PARAM)
        cached = json.loads(param["Parameter"]["Value"])
        if now - cached.get("fetched_at", 0) < RANGES_CACHE_TTL:
            return cached["cidrs"]
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "ParameterNotFound":
            log.warning("SSM cache lookup failed: %s", exc)

    log.info("Refreshing GitHub Meta ranges from %s", GITHUB_META_URL)
    with urllib.request.urlopen(GITHUB_META_URL, timeout=5) as resp:
        meta = json.loads(resp.read())

    cidrs = list(meta.get("actions", []))
    payload = {"fetched_at": now, "cidrs": cidrs}
    try:
        ssm.put_parameter(
            Name=RANGES_CACHE_PARAM,
            Value=json.dumps(payload),
            Type="String",
            Overwrite=True,
            Tier="Standard",
        )
    except ClientError as exc:
        log.warning("Could not cache GitHub ranges: %s", exc)

    return cidrs


def _ip_allowed(ip: str) -> tuple[bool, str]:
    """
    Returns (allowed, reason). `reason` is the matched CIDR or a diagnostic
    string when the IP is not allowed / not evaluable.
    """
    static = _static_cidrs()
    cidrs = static if static is not None else _fetch_github_actions_cidrs()
    source = "explicit allow-list" if static is not None else "GitHub Meta actions ranges"

    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False, f"unparseable source IP: {ip!r}"

    for cidr in cidrs:
        try:
            net = ipaddress.ip_network(cidr, strict=False)
        except ValueError:
            continue
        if addr in net:
            return True, f"matched {cidr} ({source})"

    return False, f"not in {source} ({len(cidrs)} ranges)"


# --------------------------------------------------------------------------- #
# Classification                                                              #
# --------------------------------------------------------------------------- #

def classify(detail: dict[str, Any]) -> tuple[str, list[str]]:
    """
    Returns (severity, findings). severity is one of INFO / MEDIUM / HIGH.
    findings is a list of human-readable strings.
    """
    findings: list[str] = []

    if detail.get("eventName") != "AssumeRoleWithWebIdentity":
        findings.append(f"unexpected eventName: {detail.get('eventName')}")

    role = (detail.get("requestParameters") or {}).get("roleArn")
    if role != MONITORED_ROLE_ARN:
        findings.append(f"roleArn mismatch: {role!r} != {MONITORED_ROLE_ARN!r}")

    provider = (detail.get("userIdentity") or {}).get("identityProvider")
    if provider != EXPECTED_OIDC_PROVIDER:
        findings.append(
            f"identityProvider mismatch: {provider!r} != {EXPECTED_OIDC_PROVIDER!r}"
        )

    session = (detail.get("requestParameters") or {}).get("roleSessionName", "")
    if EXPECTED_SESSION_PREFIX and not session.startswith(EXPECTED_SESSION_PREFIX):
        findings.append(
            f"roleSessionName {session!r} does not start with {EXPECTED_SESSION_PREFIX!r}"
        )

    err = detail.get("errorCode")
    if err:
        findings.append(f"AWS returned errorCode={err} — assumption failed")

    ua = detail.get("userAgent") or ""
    if not ua.startswith("aws-sdk-"):
        findings.append(
            f"userAgent {ua!r} does not look like a configure-aws-credentials run"
        )

    ip = detail.get("sourceIPAddress") or ""
    allowed, reason = _ip_allowed(ip)
    if not allowed:
        findings.append(f"sourceIPAddress {ip!r} rejected: {reason}")

    # HIGH: auth failed, wrong issuer, wrong role, or bad IP.
    high_markers = (
        "identityProvider mismatch",
        "roleArn mismatch",
        "errorCode=",
        "sourceIPAddress",
        "unexpected eventName",
    )
    if any(marker in f for f in findings for marker in high_markers):
        return "HIGH", findings

    # MEDIUM: session-name pattern off, weird UA — could be a legit workflow
    # change but worth flagging.
    if findings:
        return "MEDIUM", findings

    return "INFO", ["all checks passed"]


# --------------------------------------------------------------------------- #
# SNS publish                                                                 #
# --------------------------------------------------------------------------- #

def _format_message(severity: str, findings: list[str], event: dict[str, Any]) -> str:
    detail = event.get("detail", {})
    ui = detail.get("userIdentity", {}) or {}
    rp = detail.get("requestParameters", {}) or {}

    return "\n".join(
        [
            f"[{severity}] GitHub OIDC role usage alert",
            "",
            f"time:         {event.get('time')}",
            f"account:      {event.get('account')}",
            f"region:       {event.get('region')}",
            f"eventID:      {detail.get('eventID')}",
            f"eventName:    {detail.get('eventName')}",
            f"role:         {rp.get('roleArn')}",
            f"session:      {rp.get('roleSessionName')}",
            f"issuer:       {ui.get('identityProvider')}",
            f"principalId:  {ui.get('principalId')}",
            f"source IP:    {detail.get('sourceIPAddress')}",
            f"user agent:   {detail.get('userAgent')}",
            f"errorCode:    {detail.get('errorCode')}",
            f"errorMessage: {detail.get('errorMessage')}",
            "",
            "findings:",
            *(f"  - {f}" for f in findings),
            "",
            "expected caller: "
            f"{EXPECTED_REPO_SUB} via {EXPECTED_OIDC_PROVIDER}, "
            f"aud={EXPECTED_AUDIENCE}",
        ]
    )


def _publish(severity: str, findings: list[str], event: dict[str, Any]) -> None:
    subject = f"[{severity}] GitHub OIDC role usage — {event.get('account')}/{event.get('region')}"
    # SNS subjects are limited to 100 chars
    subject = subject[:100]

    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject=subject,
        Message=_format_message(severity, findings, event),
        MessageAttributes={
            "severity": {"DataType": "String", "StringValue": severity},
            "eventID":  {"DataType": "String", "StringValue": event.get("detail", {}).get("eventID", "")},
        },
    )


# --------------------------------------------------------------------------- #
# Handler                                                                     #
# --------------------------------------------------------------------------- #

def handler(event: dict[str, Any], _context) -> dict[str, Any]:
    log.info("received event: %s", json.dumps(event)[:2000])

    detail = event.get("detail", {}) or {}
    severity, findings = classify(detail)

    if severity == "INFO":
        log.info(
            "legitimate assumption eventID=%s session=%s ip=%s",
            detail.get("eventID"),
            (detail.get("requestParameters") or {}).get("roleSessionName"),
            detail.get("sourceIPAddress"),
        )
        return {"severity": severity, "findings": findings, "published": False}

    log.warning(
        "%s alert eventID=%s findings=%s",
        severity,
        detail.get("eventID"),
        findings,
    )
    _publish(severity, findings, event)
    return {"severity": severity, "findings": findings, "published": True}
