# GitHub OIDC role — usage alerting stack

An alerting stack that sits on top of the [`github-oidc-aws`](../github-oidc-aws) module. It watches every `sts:AssumeRoleWithWebIdentity` call against your GitHub-federated IAM role and pages you the moment anything doesn't look like a legitimate GitHub Actions run — **before** a stolen token can be used to actually change infrastructure.

## What gets deployed

```
                             CloudTrail (multi-region, global events on)
                                            │
                                            ▼
   ┌──────────────────────────────── us-east-1 ─────────────────────────────────┐
   │ Rule 4: cross-region forwarder ─▶ arn:aws:events:<your-region>:...:default │
   └────────────────────────────────────────────────────────────────────────────┘
                                            │
                                            ▼
                             EventBridge default bus (your region)
             ┌──────────────────────────────┼──────────────────────────────┐
             ▼                              ▼                              ▼
   Rule 1: all ARWI calls        Rule 2: AccessDenied           Rule 3: CloudTrail
   targeting the monitored       or wrong-issuer fast path      Insights anomaly on
   role                                                         sts:AssumeRoleWithWebIdentity
             │                              │                              │
             ▼                              ▼                              ▼
     enricher Lambda ─────────────▶  SNS topic (KMS-encrypted)  ◀──────────┘
     (Python 3.12, classifies                    │
      severity, publishes if                     ▼
      HIGH or MEDIUM)                    email / Slack / PagerDuty
```

### The three EventBridge rules

| Rule | Trigger | Action |
|---|---|---|
| **1. `-arwi-audit`** | Every `AssumeRoleWithWebIdentity` for `monitored_role_arn`, regardless of outcome. | Invoke the **enricher Lambda**, which runs the full allow-list and either logs INFO or publishes HIGH/MEDIUM to SNS. |
| **2. `-arwi-denied`** | Same, but only when `errorCode` is present OR `userIdentity.identityProvider` is *not* the expected GitHub issuer. Uses EventBridge's `$or` + `anything-but`. | Publish a formatted **HIGH** alert directly to SNS via `InputTransformer` — no Lambda cold-start needed for the obvious cases. |
| **3. `-cloudtrail-insights`** | `AWS Insight via CloudTrail` events where `insightDetails.eventSource == sts.amazonaws.com` and `eventName == AssumeRoleWithWebIdentity` — call-rate or error-rate anomalies detected by CloudTrail Insights. | Publish a **MEDIUM** alert with baseline vs. observed call rates. |

Rule 2 is intentional redundancy: even if the Lambda breaks, a wrong-issuer or `AccessDenied` still pages the on-call.

### The enricher Lambda

`lambda/handler.py`. Runs six checks against every `AssumeRoleWithWebIdentity` event:

| # | Check | HIGH if violated? |
|---|---|---|
| 1 | `eventName == "AssumeRoleWithWebIdentity"` | yes |
| 2 | `requestParameters.roleArn == MONITORED_ROLE_ARN` | yes |
| 3 | `userIdentity.identityProvider == token.actions.githubusercontent.com` | yes |
| 4 | `requestParameters.roleSessionName` starts with `gha-otel-` (from the hardened workflow) | MEDIUM |
| 5 | `errorCode` is absent (call succeeded) | yes |
| 6 | `sourceIPAddress` is inside `allowed_source_ip_cidrs` — or, if empty, inside the current `actions` ranges from `https://api.github.com/meta` (cached in SSM for 1h) | yes |
| 7 | `userAgent` starts with `aws-sdk-` | MEDIUM |

Successful, allow-listed calls are logged at INFO for the audit tail; only HIGH and MEDIUM cases publish to SNS. The published message includes every relevant CloudTrail field plus a `severity` message attribute so downstream subscribers can filter.

The classifier has been unit-tested against five representative events — see `tests/test_handler.py`. All five pass:

```
case 1 (legit):        INFO   — not published
case 2 (bad ip):       HIGH   — sourceIPAddress not in allow-list
case 3 (denied):       HIGH   — errorCode=AccessDenied
case 4 (wrong issuer): HIGH   — identityProvider mismatch
case 5 (weird session):MEDIUM — roleSessionName pattern drift
```

### CloudTrail Insights

`enable_cloudtrail_insights = true` runs an idempotent `aws cloudtrail put-insight-selectors` on your existing trail (specified by `cloudtrail_name`) enabling both `ApiCallRateInsight` and `ApiErrorRateInsight`. Insights need a baseline of ~7 days to become useful and cost roughly $0.35 per 100k analyzed events, but they'll catch things like *"suddenly 40× more `AccessDenied` on `AssumeRoleWithWebIdentity`"* automatically.

---

## Deploy

Prereqs:
- A multi-region CloudTrail with `include_global_service_events = true` (STS calls otherwise disappear).
- The role from the [`github-oidc-aws`](../github-oidc-aws) module already created.
- AWS CLI available on the Terraform host if you set `enable_cloudtrail_insights = true`.

```bash
cd terraform
terraform init
terraform apply -var-file=example.tfvars
```

If your alerting stack runs in a region other than `us-east-1`, add a second AWS provider alias for the forwarder rule:

```hcl
provider "aws" {
  region = "us-west-2"
}

provider "aws" {
  alias  = "us_east_1"
  region = "us-east-1"
}
```

and pass it to the module:

```hcl
module "oidc_alerts" {
  source    = "./terraform"
  providers = { aws = aws, aws.us_east_1 = aws.us_east_1 }
  # ...
}
```

Then confirm the email subscription that lands in your inbox.

---

## Verify end-to-end

1. **Legit path:** trigger the OTel Collector workflow. You should see nothing in SNS, and a matching `INFO` log line in `/aws/lambda/github-oidc-role-alerts-enricher`.

2. **AccessDenied path:** temporarily add a bogus condition to the trust policy (e.g. change the `sub` StringEquals to a different repo), re-run the workflow, and observe the `[HIGH]` SNS email from **Rule 2** (fast path) plus a duplicate from the enricher.

3. **Insights path:** in a sandbox, generate ~20 failed `AssumeRoleWithWebIdentity` calls with `aws sts assume-role-with-web-identity --role-arn <arn> --role-session-name t --web-identity-token badtoken` in a tight loop; Insights typically starts flagging within 15–20 minutes.

---

## File layout

```
github-oidc-alerting/
├── README.md
├── terraform/
│   ├── versions.tf
│   ├── variables.tf
│   ├── sns.tf              # KMS CMK, SNS topic + policy, email subs
│   ├── eventbridge.tf      # 4 rules (audit / fast-path / insights / forwarder)
│   ├── lambda.tf           # enricher Lambda + IAM + logs
│   ├── outputs.tf
│   └── example.tfvars
├── lambda/
│   └── handler.py          # the enricher (Python 3.12, stdlib + boto3 only)
└── tests/
    └── test_handler.py     # local smoke test with stubbed boto3
```

## Cost sketch

For a repo that deploys the collector a few dozen times a day:

- **Lambda enricher:** ~50 invocations/day × 400 ms × 256 MB = well under $0.10/month.
- **EventBridge rules + SNS:** negligible under 100k events/month.
- **CloudTrail Insights:** ~$0.35 per 100k management events analyzed. On a low-volume account this is $1–5/month; on a busy prod account expect $20–100/month. Turn off (`enable_cloudtrail_insights = false`) if you already have a SIEM doing anomaly detection.
- **KMS:** $1/month for the CMK.
