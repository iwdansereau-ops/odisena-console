########################################
# GitHub identity                       #
########################################

variable "github_org" {
  description = "GitHub organization or user that owns the repository (e.g. \"my-org\")."
  type        = string
  validation {
    condition     = length(var.github_org) > 0 && !can(regex("/", var.github_org))
    error_message = "github_org must be a non-empty string with no slashes."
  }
}

variable "github_repo" {
  description = "GitHub repository name that is allowed to assume the role (e.g. \"otel-collector-infra\")."
  type        = string
  validation {
    condition     = length(var.github_repo) > 0 && !can(regex("/", var.github_repo))
    error_message = "github_repo must be a non-empty string with no slashes."
  }
}

# Restrict which refs / environments / PRs may assume the role.
# Each entry becomes a `token.actions.githubusercontent.com:sub` value.
# Examples:
#   "ref:refs/heads/main"
#   "ref:refs/tags/v*"
#   "environment:production"
#   "pull_request"
variable "allowed_subjects" {
  description = <<-EOT
    List of GitHub OIDC `sub` claim patterns (without the leading
    `repo:<org>/<repo>:`) that are permitted to assume the role.
    Wildcards (`*`, `?`) are supported and evaluated via StringLike.
    Keep this list as narrow as possible — this is your primary
    security boundary.
  EOT
  type        = list(string)
  default     = ["environment:production"]
  validation {
    condition     = length(var.allowed_subjects) > 0
    error_message = "You must specify at least one allowed subject; an empty list would grant no access, and \"*\" would allow the entire repo (unsafe)."
  }
  validation {
    condition = alltrue([
      for s in var.allowed_subjects : s != "*" && s != ""
    ])
    error_message = "allowed_subjects may not contain \"*\" (would allow any workflow in the repo) or empty strings."
  }
}

########################################
# Naming & tagging                      #
########################################

variable "role_name" {
  description = "Name of the IAM role that GitHub Actions will assume."
  type        = string
  default     = "github-actions-otel-collector-deploy"
}

variable "role_path" {
  description = "IAM path for the role."
  type        = string
  default     = "/github-actions/"
}

variable "max_session_duration" {
  description = "Maximum session duration (seconds) for the assumed role. Keep short."
  type        = number
  default     = 3600
  validation {
    condition     = var.max_session_duration >= 900 && var.max_session_duration <= 43200
    error_message = "max_session_duration must be between 900 (15 min) and 43200 (12 h)."
  }
}

variable "permissions_boundary_arn" {
  description = "Optional IAM permissions boundary ARN applied to the deploy role."
  type        = string
  default     = null
}

variable "create_oidc_provider" {
  description = <<-EOT
    Whether to create the GitHub OIDC provider in this account.
    Set to false if the provider already exists (only one is allowed
    per AWS account) and pass its ARN via `existing_oidc_provider_arn`.
  EOT
  type        = bool
  default     = true
}

variable "existing_oidc_provider_arn" {
  description = "ARN of a pre-existing GitHub OIDC provider. Required when create_oidc_provider = false."
  type        = string
  default     = null
  validation {
    condition = (
      var.existing_oidc_provider_arn == null ||
      can(regex("^arn:aws[a-zA-Z-]*:iam::\\d{12}:oidc-provider/token\\.actions\\.githubusercontent\\.com$", var.existing_oidc_provider_arn))
    )
    error_message = "existing_oidc_provider_arn must be a valid GitHub OIDC provider ARN."
  }
}

########################################
# Deployment scope (least privilege)   #
########################################

variable "otel_ecs_cluster_arns" {
  description = "ECS cluster ARNs that the deploy role may update the OTel Collector service on."
  type        = list(string)
  default     = []
}

variable "otel_ecs_service_arns" {
  description = "ECS service ARNs corresponding to the OTel Collector."
  type        = list(string)
  default     = []
}

variable "otel_task_definition_family" {
  description = "ECS task definition family for the OTel Collector (used to scope RegisterTaskDefinition/DescribeTaskDefinition)."
  type        = string
  default     = "otel-collector"
}

variable "otel_ecr_repository_arns" {
  description = "ECR repository ARNs the deploy role may push OTel Collector images to."
  type        = list(string)
  default     = []
}

variable "otel_ssm_parameter_arns" {
  description = "SSM Parameter Store ARNs holding OTel Collector config that the role may read/write."
  type        = list(string)
  default     = []
}

variable "otel_task_role_arns" {
  description = "IAM roles the ECS task will assume (Task Role + Execution Role). Needed for iam:PassRole scoping."
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Tags applied to all resources."
  type        = map(string)
  default     = {}
}
