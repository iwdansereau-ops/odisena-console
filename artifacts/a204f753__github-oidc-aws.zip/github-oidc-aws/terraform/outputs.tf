output "oidc_provider_arn" {
  description = "ARN of the GitHub OIDC provider used by the role."
  value       = local.oidc_provider_arn
}

output "role_arn" {
  description = "ARN of the IAM role that GitHub Actions should assume. Pass this to `aws-actions/configure-aws-credentials` as `role-to-assume`."
  value       = aws_iam_role.deploy.arn
}

output "role_name" {
  description = "Name of the deploy role."
  value       = aws_iam_role.deploy.name
}

output "trust_policy_json" {
  description = "Rendered trust policy JSON (useful for audit / drift review)."
  value       = data.aws_iam_policy_document.trust.json
}
