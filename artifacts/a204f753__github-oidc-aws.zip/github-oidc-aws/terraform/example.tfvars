########################################
# Copy to terraform.tfvars and edit.    #
########################################

github_org  = "odisena"
github_repo = "otel-collector-infra"

# The security boundary. Prefer environments over branches: environments
# gate approvals in GitHub, so this is safer than allowing any push to main.
allowed_subjects = [
  "environment:production",
  "environment:staging",
  # "ref:refs/tags/v*",   # release tags
  # "ref:refs/heads/main" # main branch only (weaker than environments)
]

role_name            = "github-actions-otel-collector-deploy"
max_session_duration = 3600 # 1 hour

# --- Deployment scope (fill with your real ARNs) ---
otel_ecs_cluster_arns = [
  "arn:aws:ecs:us-east-1:123456789012:cluster/observability",
]

otel_ecs_service_arns = [
  "arn:aws:ecs:us-east-1:123456789012:service/observability/otel-collector",
]

otel_task_definition_family = "otel-collector"

otel_ecr_repository_arns = [
  "arn:aws:ecr:us-east-1:123456789012:repository/otel-collector",
]

otel_ssm_parameter_arns = [
  "arn:aws:ssm:us-east-1:123456789012:parameter/otel/collector/*",
]

otel_task_role_arns = [
  "arn:aws:iam::123456789012:role/otel-collector-task",
  "arn:aws:iam::123456789012:role/otel-collector-execution",
]

tags = {
  Environment = "shared"
  Owner       = "platform-observability"
  Component   = "otel-collector"
}
