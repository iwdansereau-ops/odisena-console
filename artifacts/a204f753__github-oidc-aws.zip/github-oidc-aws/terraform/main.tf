########################################
# GitHub OIDC provider (optional)       #
########################################
#
# AWS validates GitHub's OIDC token against its own library of trusted
# root CAs, so a `thumbprint_list` is no longer strictly required. We
# still set a placeholder value because the API accepts the field and
# some older tooling / drift-detection expects it; AWS ignores it for
# token validation of this specific issuer.
#
# Only ONE OIDC provider per AWS account may exist for a given URL.
# If you already have one, set create_oidc_provider = false and pass
# existing_oidc_provider_arn.

resource "aws_iam_openid_connect_provider" "github" {
  count = var.create_oidc_provider ? 1 : 0

  url             = "https://token.actions.githubusercontent.com"
  client_id_list  = ["sts.amazonaws.com"]
  thumbprint_list = ["ffffffffffffffffffffffffffffffffffffffff"] # Placeholder; AWS validates GitHub certs via its trusted CA store.

  tags = merge(var.tags, {
    Name      = "github-actions-oidc"
    ManagedBy = "terraform"
  })
}

locals {
  oidc_provider_arn = var.create_oidc_provider ? aws_iam_openid_connect_provider.github[0].arn : var.existing_oidc_provider_arn

  # Fully-qualified `sub` claim values, e.g. "repo:my-org/my-repo:environment:production"
  full_subjects = [
    for s in var.allowed_subjects : "repo:${var.github_org}/${var.github_repo}:${s}"
  ]
}

########################################
# Trust policy                          #
########################################
#
# Hardening notes:
#  * `aud` MUST be `sts.amazonaws.com` (StringEquals — exact match).
#  * `sub` is pinned to this specific repo AND to specific refs /
#    environments / PR contexts. Never leave `sub` unbounded or
#    wildcarded to `repo:org/repo:*` unless you fully trust every
#    workflow, branch, tag, PR, and fork-PR in the repo.
#  * We use StringLike for `sub` only so that patterns like
#    "ref:refs/tags/v*" work; if none of your subjects contain a
#    wildcard, this is equivalent to StringEquals.

data "aws_iam_policy_document" "trust" {
  statement {
    sid     = "GitHubActionsAssumeRoleWithOIDC"
    effect  = "Allow"
    actions = ["sts:AssumeRoleWithWebIdentity"]

    principals {
      type        = "Federated"
      identifiers = [local.oidc_provider_arn]
    }

    # Audience must be exactly the STS audience — prevents token reuse
    # against other relying parties.
    condition {
      test     = "StringEquals"
      variable = "token.actions.githubusercontent.com:aud"
      values   = ["sts.amazonaws.com"]
    }

    # Subject pins this role to a specific repo + specific
    # refs/environments/PR contexts.
    condition {
      test     = "StringLike"
      variable = "token.actions.githubusercontent.com:sub"
      values   = local.full_subjects
    }
  }
}

########################################
# Deploy role                           #
########################################

resource "aws_iam_role" "deploy" {
  name                 = var.role_name
  path                 = var.role_path
  description          = "Assumed by GitHub Actions via OIDC to deploy the OpenTelemetry Collector."
  assume_role_policy   = data.aws_iam_policy_document.trust.json
  max_session_duration = var.max_session_duration
  permissions_boundary = var.permissions_boundary_arn

  tags = merge(var.tags, {
    Name      = var.role_name
    ManagedBy = "terraform"
    Purpose   = "otel-collector-deploy"
  })
}

########################################
# Least-privilege deploy policy         #
########################################
#
# Tailored to a typical ECS-based OTel Collector deploy:
#   * push image to ECR
#   * register a new task definition revision
#   * update the ECS service
#   * read/write SSM parameters holding collector config
#   * pass the task/execution roles to ECS
#
# Trim or extend to match your actual deploy pipeline.

data "aws_iam_policy_document" "deploy" {
  # ECR: push images
  dynamic "statement" {
    for_each = length(var.otel_ecr_repository_arns) > 0 ? [1] : []
    content {
      sid    = "EcrAuthToken"
      effect = "Allow"
      actions = [
        "ecr:GetAuthorizationToken",
      ]
      resources = ["*"] # GetAuthorizationToken does not support resource-level perms.
    }
  }

  dynamic "statement" {
    for_each = length(var.otel_ecr_repository_arns) > 0 ? [1] : []
    content {
      sid    = "EcrPushOtelImage"
      effect = "Allow"
      actions = [
        "ecr:BatchCheckLayerAvailability",
        "ecr:BatchGetImage",
        "ecr:CompleteLayerUpload",
        "ecr:DescribeImages",
        "ecr:DescribeRepositories",
        "ecr:GetDownloadUrlForLayer",
        "ecr:InitiateLayerUpload",
        "ecr:PutImage",
        "ecr:UploadLayerPart",
      ]
      resources = var.otel_ecr_repository_arns
    }
  }

  # ECS: register task defs (must be *; RegisterTaskDefinition has no resource-level auth)
  # and update the specific service(s).
  statement {
    sid    = "EcsRegisterTaskDefinition"
    effect = "Allow"
    actions = [
      "ecs:RegisterTaskDefinition",
      "ecs:DescribeTaskDefinition",
      "ecs:ListTaskDefinitions",
    ]
    resources = ["*"]

    # Scope via tags / family so this role can't clobber unrelated services.
    condition {
      test     = "StringEqualsIfExists"
      variable = "ecs:family"
      values   = [var.otel_task_definition_family]
    }
  }

  dynamic "statement" {
    for_each = length(var.otel_ecs_service_arns) > 0 ? [1] : []
    content {
      sid    = "EcsUpdateOtelService"
      effect = "Allow"
      actions = [
        "ecs:UpdateService",
        "ecs:DescribeServices",
        "ecs:DescribeTasks",
        "ecs:ListTasks",
      ]
      resources = concat(var.otel_ecs_service_arns, var.otel_ecs_cluster_arns)
    }
  }

  # SSM: read/write collector config
  dynamic "statement" {
    for_each = length(var.otel_ssm_parameter_arns) > 0 ? [1] : []
    content {
      sid    = "SsmOtelConfig"
      effect = "Allow"
      actions = [
        "ssm:GetParameter",
        "ssm:GetParameters",
        "ssm:GetParametersByPath",
        "ssm:PutParameter",
      ]
      resources = var.otel_ssm_parameter_arns
    }
  }

  # iam:PassRole — required to point ECS at the task/execution roles.
  dynamic "statement" {
    for_each = length(var.otel_task_role_arns) > 0 ? [1] : []
    content {
      sid    = "PassOtelTaskRoles"
      effect = "Allow"
      actions = [
        "iam:PassRole",
      ]
      resources = var.otel_task_role_arns
      condition {
        test     = "StringEquals"
        variable = "iam:PassedToService"
        values   = ["ecs-tasks.amazonaws.com"]
      }
    }
  }
}

resource "aws_iam_policy" "deploy" {
  name        = "${var.role_name}-policy"
  path        = var.role_path
  description = "Least-privilege deploy permissions for the OpenTelemetry Collector."
  policy      = data.aws_iam_policy_document.deploy.json
  tags        = var.tags
}

resource "aws_iam_role_policy_attachment" "deploy" {
  role       = aws_iam_role.deploy.name
  policy_arn = aws_iam_policy.deploy.arn
}
