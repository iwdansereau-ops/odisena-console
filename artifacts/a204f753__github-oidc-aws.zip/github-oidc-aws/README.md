# GitHub OIDC → AWS for OTel Collector deploys

Zero-long-lived-credentials setup for deploying the OpenTelemetry Collector
from GitHub Actions into AWS ECS. Provided in two flavors — Terraform and
CloudFormation — plus a hardened workflow template.

```
github-oidc-aws/
├── terraform/
│   ├── versions.tf
│   ├── variables.tf
│   ├── main.tf
│   ├── outputs.tf
│   └── example.tfvars
├── cloudformation/
│   └── github-oidc.yaml
└── .github/workflows/
    └── deploy-otel-collector.yml
```

## What you get

| Piece | Purpose |
|---|---|
| `aws_iam_openid_connect_provider` for `token.actions.githubusercontent.com` | Lets AWS STS trust GitHub-minted JWTs. One per account. |
| IAM role with a **repo- and environment-pinned** trust policy | Only the specified repo + subjects (e.g. `environment:production`) can assume it. |
| Least-privilege inline policy | ECR push, ECS `RegisterTaskDefinition`/`UpdateService`, SSM parameter read/write, scoped `iam:PassRole`. |
| GitHub Actions workflow | `id-token: write`, environment-gated, SHA-pinned actions, no static keys. |

## Security model — read this before shipping

The **only** thing standing between the internet and your AWS account is the
trust-policy `sub` condition. Get it wrong and any workflow in your repo
(including PRs from forks, if enabled) can assume the role.

Rules:

1. **Never** use `repo:org/repo:*`. That allows every branch, tag, PR, and
   workflow in the repo.
2. Prefer `environment:<name>` over `ref:refs/heads/<branch>`. GitHub
   Environments add required-reviewer approval and wait timers that a raw
   branch cannot.
3. Pin the `aud` claim to `sts.amazonaws.com` with `StringEquals` (this
   module does).
4. Never mix `id-token: write` with `pull_request` from public forks unless
   you deeply understand the implications — a malicious PR could exfiltrate
   the OIDC token. Prefer `pull_request_target` + explicit checkout of the
   trusted ref, or restrict via `sub` to non-PR contexts.

## Terraform quickstart

```bash
cd terraform
cp example.tfvars terraform.tfvars   # edit values
terraform init
terraform plan
terraform apply
```

Grab `role_arn` from the outputs and set it as the `AWS_DEPLOY_ROLE_ARN`
repository secret (or, better, an **environment** secret on the `production`
environment).

## CloudFormation quickstart

```bash
aws cloudformation deploy \
  --stack-name github-oidc-otel \
  --template-file cloudformation/github-oidc.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --parameter-overrides \
      GitHubOrg=odisena \
      GitHubRepo=otel-collector-infra \
      AllowedSubjects="environment:production,environment:staging" \
      OtelEcsClusterArn=arn:aws:ecs:us-east-1:123456789012:cluster/observability \
      OtelEcsServiceArn=arn:aws:ecs:us-east-1:123456789012:service/observability/otel-collector \
      OtelEcrRepositoryArn=arn:aws:ecr:us-east-1:123456789012:repository/otel-collector \
      OtelTaskRoleArn=arn:aws:iam::123456789012:role/otel-collector-task \
      OtelTaskExecutionRoleArn=arn:aws:iam::123456789012:role/otel-collector-execution
```

Fetch the role ARN from stack outputs:

```bash
aws cloudformation describe-stacks \
  --stack-name github-oidc-otel \
  --query "Stacks[0].Outputs[?OutputKey=='RoleArn'].OutputValue" --output text
```

## Workflow prerequisites

1. Create a GitHub **Environment** named `production` (Settings → Environments).
   * Add required reviewers.
   * Add a wait timer if desired.
   * Add an environment secret `AWS_DEPLOY_ROLE_ARN` with the role ARN.
2. Ensure `collector/Dockerfile` and `collector/taskdef.json` exist in your
   repo (the workflow references them).
3. Commit `.github/workflows/deploy-otel-collector.yml`.

## Verifying the OIDC path end-to-end

After the first successful run, in CloudTrail look for an
`AssumeRoleWithWebIdentity` event where:

* `userIdentity.type = WebIdentityUser`
* `requestParameters.roleArn` matches your deploy role
* `requestParameters.roleSessionName` starts with `gha-otel-`
* `additionalEventData` contains a `sub` value like
  `repo:odisena/otel-collector-infra:environment:production`

If you see `sub` values you didn't authorize, tighten `allowed_subjects`
immediately.

## Notes on OIDC thumbprints

AWS previously required a thumbprint of GitHub's OIDC signing certificate.
Since 2023 AWS validates the certificate against its own trusted root CA
library, so the thumbprint is effectively cosmetic for
`token.actions.githubusercontent.com`. Both templates supply a placeholder
value for API compatibility. You do **not** need to rotate it when GitHub
rotates their intermediate cert.
