#!/usr/bin/env python3
"""
Federated-role discovery & cleanup scanner.

What it does
------------
1. Enumerates every IAM OpenID Connect provider and SAML provider in the
   account and classifies each by well-known issuer (GitHub Actions, GitLab,
   CircleCI, Terraform Cloud, AWS EKS clusters, Bitbucket, Google, Okta,
   Azure AD, custom).
2. Lists every IAM role and finds the ones whose trust policy allows
   `sts:AssumeRoleWithWebIdentity` (OIDC-federated) or
   `sts:AssumeRoleWithSAML` (SAML-federated).
3. For each federated role, evaluates trust-policy hardening:
     - Is the audience (aud) pinned with StringEquals?
     - Is a subject (sub / repo:*) condition present?
     - Does the sub use StringEquals (strict) or a wildcard StringLike?
     - Does it wildcard the whole repo (`repo:org/repo:*`)?
     - Is a permissions boundary attached?
     - Is max_session_duration <= 3600?
4. Pulls `role.RoleLastUsed` from IAM (Access Advisor-adjacent metadata)
   to flag roles unused for >= 90 days.
5. Optionally spot-checks CloudTrail for the past 90 days of
   AssumeRoleWithWebIdentity events per role for extra confidence.
6. Writes findings.json + prints a summary. The companion `report.py`
   turns findings.json into a multi-tab XLSX cleanup report.

Requires
--------
    pip install boto3
    AWS credentials with the read-only permissions in iam/audit-policy.json.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import logging
import re
import sys
from typing import Any

import boto3
from botocore.exceptions import ClientError

log = logging.getLogger("scan")

# --------------------------------------------------------------------------- #
# OIDC issuer taxonomy                                                        #
# --------------------------------------------------------------------------- #

# Ordered — first regex that matches wins.
ISSUER_TAXONOMY: list[tuple[str, str]] = [
    (r"^token\.actions\.githubusercontent\.com$",        "GitHub Actions (github.com)"),
    (r"\.ghe\.com$|github-enterprise",                   "GitHub Enterprise Server"),
    (r"^gitlab\.com$|^gitlab\.",                         "GitLab CI"),
    (r"^oidc\.circleci\.com",                            "CircleCI"),
    (r"^app\.terraform\.io$",                            "Terraform Cloud / HCP"),
    (r"^token\.actions\.bitbucket\.org|bitbucket\.org",  "Bitbucket Pipelines"),
    (r"^accounts\.google\.com$|^oauth2\.googleapis",     "Google / GCP Workload Identity"),
    (r"cognito-identity\.amazonaws\.com",                "Amazon Cognito"),
    (r"oidc\.eks\.[a-z0-9-]+\.amazonaws\.com/id/",       "Amazon EKS (IRSA)"),
    (r"^login\.microsoftonline\.com|sts\.windows\.net",  "Azure AD / Entra ID"),
    (r"^([a-z0-9-]+)\.okta\.com$",                       "Okta"),
    (r"^([a-z0-9-]+)\.auth0\.com$",                      "Auth0"),
    (r"^token\.actions\.buildkite\.com|buildkite\.com",  "Buildkite"),
    (r"vault\.",                                         "HashiCorp Vault"),
]

def classify_issuer(url: str) -> str:
    host = url.replace("https://", "").split("/", 1)[0].lower()
    for pattern, label in ISSUER_TAXONOMY:
        if re.search(pattern, host):
            return label
    return "Unknown / custom"


# --------------------------------------------------------------------------- #
# Provider enumeration                                                        #
# --------------------------------------------------------------------------- #

def list_oidc_providers(iam) -> list[dict[str, Any]]:
    out = []
    resp = iam.list_open_id_connect_providers()
    for p in resp.get("OpenIDConnectProviderList", []):
        arn = p["Arn"]
        detail = iam.get_open_id_connect_provider(OpenIDConnectProviderArn=arn)
        url = detail["Url"]
        out.append(
            {
                "arn": arn,
                "url": url,
                "issuer_class": classify_issuer(url),
                "client_ids": detail.get("ClientIDList", []),
                "thumbprints": detail.get("ThumbprintList", []),
                "create_date": detail.get("CreateDate").isoformat() if detail.get("CreateDate") else None,
                "tags": {t["Key"]: t["Value"] for t in detail.get("Tags", [])},
            }
        )
    return out


def list_saml_providers(iam) -> list[dict[str, Any]]:
    out = []
    for p in iam.list_saml_providers().get("SAMLProviderList", []):
        arn = p["Arn"]
        detail = iam.get_saml_provider(SAMLProviderArn=arn)
        out.append(
            {
                "arn": arn,
                "issuer_class": "SAML (generic)",
                "valid_until": detail.get("ValidUntil").isoformat() if detail.get("ValidUntil") else None,
                "create_date": detail.get("CreateDate").isoformat() if detail.get("CreateDate") else None,
                "tags": {t["Key"]: t["Value"] for t in detail.get("Tags", [])},
            }
        )
    return out


# --------------------------------------------------------------------------- #
# Role enumeration + trust-policy analysis                                    #
# --------------------------------------------------------------------------- #

def iter_all_roles(iam):
    paginator = iam.get_paginator("list_roles")
    for page in paginator.paginate():
        for role in page["Roles"]:
            yield role


def _as_list(v):
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def analyze_trust_policy(policy: dict[str, Any], provider_urls: dict[str, str]) -> dict[str, Any]:
    """
    Returns a structured view of the trust policy for a federated role.
    provider_urls maps OIDC provider ARN -> URL for classification.
    """
    findings: dict[str, Any] = {
        "is_web_identity":   False,
        "is_saml":           False,
        "provider_arns":     [],
        "provider_urls":     [],
        "provider_class":    [],
        "audiences":         [],
        "sub_values":        [],
        "sub_condition_op":  None,      # StringEquals / StringLike / None
        "aud_condition_op":  None,
        "has_sub_condition": False,
        "has_aud_condition": False,
        "sub_wildcards_repo": False,
        "sub_wildcard_all":  False,     # e.g. repo:org/repo:*
        "unconstrained":     False,     # federated but literally no aud/sub
        "hardening_issues":  [],
    }

    for stmt in _as_list(policy.get("Statement")):
        actions = [a.lower() for a in _as_list(stmt.get("Action"))]
        if not any(a in ("sts:assumerolewithwebidentity", "sts:assumerolewithsaml", "sts:*") for a in actions):
            continue

        principal = stmt.get("Principal") or {}
        federated = _as_list(principal.get("Federated"))

        for arn in federated:
            findings["provider_arns"].append(arn)
            url = provider_urls.get(arn, "")
            findings["provider_urls"].append(url)
            findings["provider_class"].append(classify_issuer(url) if url else ("SAML" if ":saml-provider/" in arn else "unknown"))
            if ":oidc-provider/" in arn:
                findings["is_web_identity"] = True
            if ":saml-provider/" in arn:
                findings["is_saml"] = True

        # Walk Condition
        cond = stmt.get("Condition") or {}
        for op, kvs in cond.items():
            for key, values in kvs.items():
                kl = key.lower()
                vs = _as_list(values)
                if kl.endswith(":aud"):
                    findings["has_aud_condition"] = True
                    findings["aud_condition_op"] = op
                    findings["audiences"].extend(vs)
                elif kl.endswith(":sub"):
                    findings["has_sub_condition"] = True
                    findings["sub_condition_op"] = op
                    findings["sub_values"].extend(vs)
                    for v in vs:
                        # Any wildcard character?
                        if "*" in v or "?" in v:
                            findings["sub_wildcards_repo"] = True
                        # `repo:org/repo:*` — wildcards everything under a repo
                        if re.fullmatch(r"repo:[^/:]+/[^/:]+:\*", v or ""):
                            findings["sub_wildcard_all"] = True

    if findings["is_web_identity"] or findings["is_saml"]:
        if not findings["has_aud_condition"] and not findings["has_sub_condition"]:
            findings["unconstrained"] = True

    # Populate hardening_issues
    issues = findings["hardening_issues"]
    if findings["is_web_identity"]:
        if not findings["has_aud_condition"]:
            issues.append("Missing aud condition")
        elif findings["aud_condition_op"] != "StringEquals":
            issues.append(f"aud uses {findings['aud_condition_op']} (should be StringEquals)")

        if not findings["has_sub_condition"]:
            issues.append("Missing sub condition (any repo/workflow can assume)")
        elif findings["sub_wildcard_all"]:
            issues.append("sub uses repo-wide wildcard (repo:org/repo:*)")
        elif findings["sub_condition_op"] == "StringLike" and not findings["sub_wildcards_repo"]:
            issues.append("sub uses StringLike without wildcard — should be StringEquals")

    return findings


def role_last_used_days(role: dict[str, Any]) -> int | None:
    last = (role.get("RoleLastUsed") or {}).get("LastUsedDate")
    if not last:
        return None
    now = dt.datetime.now(dt.timezone.utc)
    if last.tzinfo is None:
        last = last.replace(tzinfo=dt.timezone.utc)
    return (now - last).days


# --------------------------------------------------------------------------- #
# CloudTrail spot-check (optional)                                            #
# --------------------------------------------------------------------------- #

def cloudtrail_arwi_calls(session, role_arn: str, days: int = 90) -> dict[str, Any]:
    """
    Returns {count, last_seen, last_source_ip, last_error} for
    AssumeRoleWithWebIdentity events targeting role_arn in us-east-1
    (where global STS events land) over the last N days.
    """
    ct = session.client("cloudtrail", region_name="us-east-1")
    start = dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=days)

    result = {"count": 0, "last_seen": None, "last_source_ip": None, "last_error": None, "checked": True}
    try:
        paginator = ct.get_paginator("lookup_events")
        pages = paginator.paginate(
            LookupAttributes=[{"AttributeKey": "EventName", "AttributeValue": "AssumeRoleWithWebIdentity"}],
            StartTime=start,
            MaxResults=50,
        )
        for page in pages:
            for ev in page.get("Events", []):
                raw = json.loads(ev.get("CloudTrailEvent", "{}"))
                if (raw.get("requestParameters") or {}).get("roleArn") != role_arn:
                    continue
                result["count"] += 1
                if result["last_seen"] is None:
                    result["last_seen"] = raw.get("eventTime")
                    result["last_source_ip"] = raw.get("sourceIPAddress")
                    result["last_error"] = raw.get("errorCode")
    except ClientError as exc:
        log.warning("CloudTrail LookupEvents failed: %s", exc)
        result["checked"] = False
        result["error"] = str(exc)
    return result


# --------------------------------------------------------------------------- #
# Main                                                                       #
# --------------------------------------------------------------------------- #

def scan(
    profile: str | None,
    region: str | None,
    unused_days: int,
    cloudtrail_lookup: bool,
    expected_org_repos: list[str],
    out_path: str,
) -> dict[str, Any]:
    session = boto3.Session(profile_name=profile) if profile else boto3.Session()
    if region:
        session = boto3.Session(profile_name=profile, region_name=region) if profile else boto3.Session(region_name=region)

    sts = session.client("sts")
    ident = sts.get_caller_identity()
    log.info("Scanning account %s as %s", ident["Account"], ident["Arn"])

    iam = session.client("iam")

    log.info("Enumerating identity providers...")
    oidc_providers = list_oidc_providers(iam)
    saml_providers = list_saml_providers(iam)
    provider_url_by_arn = {p["arn"]: p["url"] for p in oidc_providers}
    log.info("Found %d OIDC + %d SAML providers", len(oidc_providers), len(saml_providers))

    log.info("Enumerating IAM roles...")
    all_roles = list(iter_all_roles(iam))
    log.info("Found %d total roles", len(all_roles))

    federated_roles: list[dict[str, Any]] = []
    for role in all_roles:
        trust = role.get("AssumeRolePolicyDocument") or {}
        # boto3 returns it as a URL-decoded dict already when using list_roles.
        if isinstance(trust, str):
            trust = json.loads(trust)

        analysis = analyze_trust_policy(trust, provider_url_by_arn)
        if not (analysis["is_web_identity"] or analysis["is_saml"]):
            continue

        last_days = role_last_used_days(role)
        arn = role["Arn"]

        entry: dict[str, Any] = {
            "role_name":                role["RoleName"],
            "role_arn":                 arn,
            "role_path":                role.get("Path"),
            "role_id":                  role.get("RoleId"),
            "create_date":              role["CreateDate"].isoformat(),
            "description":              role.get("Description"),
            "max_session_duration_s":   role.get("MaxSessionDuration"),
            "permissions_boundary_arn": (role.get("PermissionsBoundary") or {}).get("PermissionsBoundaryArn"),
            "last_used_date":           (role.get("RoleLastUsed") or {}).get("LastUsedDate").isoformat()
                                        if (role.get("RoleLastUsed") or {}).get("LastUsedDate") else None,
            "last_used_region":         (role.get("RoleLastUsed") or {}).get("Region"),
            "last_used_days_ago":       last_days,
            "unused_over_threshold":    (last_days is None or last_days >= unused_days),
            "trust_analysis":           analysis,
            "tags":                     {t["Key"]: t["Value"] for t in role.get("Tags", [])},
        }

        # Correlate the trust-policy sub claims against expected org/repos.
        entry["expected_repo_match"] = False
        if expected_org_repos:
            for s in analysis["sub_values"]:
                for expected in expected_org_repos:
                    if s.startswith(f"repo:{expected}"):
                        entry["expected_repo_match"] = True
                        break

        if cloudtrail_lookup and analysis["is_web_identity"]:
            entry["cloudtrail_90d"] = cloudtrail_arwi_calls(session, arn, days=unused_days)

        # Compute overall risk
        entry["risk_flags"] = compute_risk_flags(entry, unused_days)
        entry["risk_score"] = risk_score(entry["risk_flags"])
        entry["recommendation"] = recommend(entry)

        federated_roles.append(entry)

    findings = {
        "generated_at":     dt.datetime.now(dt.timezone.utc).isoformat(),
        "account_id":       ident["Account"],
        "scanner_identity": ident["Arn"],
        "unused_days":      unused_days,
        "cloudtrail_check": cloudtrail_lookup,
        "expected_org_repos": expected_org_repos,
        "oidc_providers":   oidc_providers,
        "saml_providers":   saml_providers,
        "federated_roles":  federated_roles,
        "summary":          summarize(federated_roles),
    }

    with open(out_path, "w") as f:
        json.dump(findings, f, indent=2, default=str)

    log.info("Wrote %s", out_path)
    return findings


# --------------------------------------------------------------------------- #
# Risk scoring + recommendation                                               #
# --------------------------------------------------------------------------- #

def compute_risk_flags(entry: dict[str, Any], unused_days: int) -> list[str]:
    flags = []
    a = entry["trust_analysis"]

    if a["unconstrained"]:
        flags.append("CRITICAL: no aud/sub conditions")
    for issue in a.get("hardening_issues", []):
        flags.append(f"HARDENING: {issue}")

    if a.get("sub_wildcard_all"):
        flags.append("HIGH: sub wildcards all workflows in repo")

    if entry["unused_over_threshold"]:
        if entry["last_used_days_ago"] is None:
            flags.append(f"UNUSED: never observed being assumed")
        else:
            flags.append(f"UNUSED: {entry['last_used_days_ago']} days since last use (threshold {unused_days}d)")

    if entry.get("permissions_boundary_arn") is None:
        flags.append("MISSING: no permissions boundary")

    if entry.get("max_session_duration_s", 3600) > 3600:
        flags.append(f"LONG_SESSION: max_session_duration={entry['max_session_duration_s']}s")

    if entry.get("expected_repo_match") is False and a.get("sub_values"):
        # We only surface this if we were given an expected list.
        if entry.get("_had_expected"):
            flags.append("UNKNOWN_REPO: sub does not match any expected org/repo")

    return flags


def risk_score(flags: list[str]) -> int:
    score = 0
    for f in flags:
        if f.startswith("CRITICAL"): score += 100
        elif f.startswith("HIGH"):    score += 50
        elif f.startswith("HARDENING"): score += 20
        elif f.startswith("UNUSED"):  score += 30
        elif f.startswith("LONG_SESSION"): score += 10
        elif f.startswith("MISSING"): score += 5
        else: score += 5
    return score


def recommend(entry: dict[str, Any]) -> str:
    flags = entry["risk_flags"]
    if any(f.startswith("CRITICAL") for f in flags):
        return "DELETE or fully re-scope trust policy immediately"
    if any(f.startswith("UNUSED") for f in flags) and any("wildcard" in f.lower() or "HARDENING" in f for f in flags):
        return "DELETE — unused and overly permissive"
    if any(f.startswith("UNUSED") for f in flags):
        return "DELETE if no owner claims it within 30 days"
    if any(f.startswith(("HIGH", "HARDENING")) for f in flags):
        return "TIGHTEN trust policy (add StringEquals sub, remove wildcards)"
    if any(f.startswith("MISSING") for f in flags):
        return "ADD permissions boundary"
    return "OK — review annually"


def summarize(roles: list[dict[str, Any]]) -> dict[str, Any]:
    total = len(roles)
    unused = sum(1 for r in roles if r["unused_over_threshold"])
    unconstrained = sum(1 for r in roles if r["trust_analysis"]["unconstrained"])
    wildcard = sum(1 for r in roles if r["trust_analysis"]["sub_wildcard_all"])
    delete = sum(1 for r in roles if r["recommendation"].startswith("DELETE"))
    tighten = sum(1 for r in roles if r["recommendation"].startswith("TIGHTEN"))
    by_issuer: dict[str, int] = {}
    for r in roles:
        for cls in r["trust_analysis"]["provider_class"] or ["(none)"]:
            by_issuer[cls] = by_issuer.get(cls, 0) + 1
    return {
        "total_federated_roles": total,
        "unused_over_threshold": unused,
        "unconstrained":         unconstrained,
        "wildcard_all_workflows": wildcard,
        "recommend_delete":      delete,
        "recommend_tighten":     tighten,
        "by_issuer_class":       by_issuer,
    }


# --------------------------------------------------------------------------- #
# CLI                                                                        #
# --------------------------------------------------------------------------- #

def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--profile", help="AWS profile name (default: env / instance)")
    p.add_argument("--region",  help="Primary region (default: from session)")
    p.add_argument("--unused-days", type=int, default=90,
                   help="Flag roles unused for >= N days (default 90)")
    p.add_argument("--cloudtrail", action="store_true",
                   help="Also look up AssumeRoleWithWebIdentity events in CloudTrail (slower)")
    p.add_argument("--expected-repo", action="append", default=[],
                   help="Repeatable. Expected github_org/github_repo — sub claims not "
                        "starting with `repo:<value>` get flagged UNKNOWN_REPO. "
                        "Example: --expected-repo odisena/otel-collector-infra")
    p.add_argument("--out", default="findings.json", help="Output JSON path")
    args = p.parse_args()

    findings = scan(
        profile=args.profile,
        region=args.region,
        unused_days=args.unused_days,
        cloudtrail_lookup=args.cloudtrail,
        expected_org_repos=args.expected_repo,
        out_path=args.out,
    )

    s = findings["summary"]
    print()
    print(f"Account:                    {findings['account_id']}")
    print(f"Federated roles:            {s['total_federated_roles']}")
    print(f"  unused >= {args.unused_days:>3}d:            {s['unused_over_threshold']}")
    print(f"  unconstrained trust:      {s['unconstrained']}")
    print(f"  wildcard-all-workflows:   {s['wildcard_all_workflows']}")
    print(f"  recommend DELETE:         {s['recommend_delete']}")
    print(f"  recommend TIGHTEN:        {s['recommend_tighten']}")
    print()
    print("By issuer class:")
    for cls, n in sorted(s["by_issuer_class"].items(), key=lambda kv: -kv[1]):
        print(f"  {cls:<40} {n}")
    print()
    print(f"Wrote raw findings to {args.out}. Now run: python3 report.py {args.out} report.xlsx")

    return 0


if __name__ == "__main__":
    sys.exit(main())
