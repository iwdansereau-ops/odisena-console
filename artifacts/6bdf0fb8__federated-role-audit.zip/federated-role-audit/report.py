#!/usr/bin/env python3
"""
Turn scan.py's findings.json into a multi-tab Excel cleanup report.

Sheets:
  1. Summary        — headline numbers + counts by issuer class + legend
  2. Federated Roles — one row per role, cleanup recommendation, risk flags
  3. Trust Policies — trust-policy hardening detail
  4. Identity Providers — every OIDC + SAML provider, classified
  5. CloudTrail 90d — if --cloudtrail was used during the scan
  6. Methodology    — how we scored things

Run:
    python3 report.py findings.json report.xlsx
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


# --------------------------------------------------------------------------- #
# Style palette (Nexus light — from design-foundations)                       #
# --------------------------------------------------------------------------- #

HEADER_FILL   = PatternFill("solid", fgColor="01696F")   # Primary
BAND_FILL     = PatternFill("solid", fgColor="F9F8F5")   # Surface
CRIT_FILL     = PatternFill("solid", fgColor="F4D5D9")   # tinted error
HIGH_FILL     = PatternFill("solid", fgColor="F7E4D6")   # tinted warning
UNUSED_FILL   = PatternFill("solid", fgColor="FFF2C6")   # tinted gold
OK_FILL       = PatternFill("solid", fgColor="E1EEDA")   # tinted success

HEADER_FONT   = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
BODY_FONT     = Font(name="Calibri", size=10)
BOLD_FONT     = Font(name="Calibri", bold=True, size=10)
TITLE_FONT    = Font(name="Calibri", bold=True, size=14, color="28251D")

THIN = Side(style="thin", color="D4D1CA")
BORDER = Border(top=THIN, bottom=THIN, left=THIN, right=THIN)

CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT   = Alignment(horizontal="left",   vertical="center", wrap_text=True)
RIGHT  = Alignment(horizontal="right",  vertical="center")


def _style_header_row(ws, row: int, cols: int) -> None:
    for c in range(1, cols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = CENTER
        cell.border = BORDER


def _autosize(ws, min_width: int = 10, max_width: int = 60) -> None:
    for col in ws.columns:
        letter = col[0].column_letter
        longest = 0
        for cell in col:
            v = cell.value
            if v is None:
                continue
            for line in str(v).splitlines():
                longest = max(longest, len(line))
        ws.column_dimensions[letter].width = max(min_width, min(max_width, longest + 2))


def _band_rows(ws, start_row: int, end_row: int, cols: int) -> None:
    for r in range(start_row, end_row + 1):
        if (r - start_row) % 2 == 1:
            for c in range(1, cols + 1):
                ws.cell(row=r, column=c).fill = BAND_FILL


# --------------------------------------------------------------------------- #
# Sheet builders                                                              #
# --------------------------------------------------------------------------- #

def build_summary(wb: openpyxl.Workbook, findings: dict[str, Any]) -> None:
    ws = wb.active
    ws.title = "Summary"
    ws.sheet_view.showGridLines = False

    ws.column_dimensions["A"].width = 3
    ws["B2"] = "Federated IAM role cleanup report"
    ws["B2"].font = TITLE_FONT

    ws["B4"] = "Account"
    ws["C4"] = findings["account_id"]
    ws["B5"] = "Scanner identity"
    ws["C5"] = findings["scanner_identity"]
    ws["B6"] = "Generated at (UTC)"
    ws["C6"] = findings["generated_at"]
    ws["B7"] = "Unused threshold"
    ws["C7"] = f"{findings['unused_days']} days"
    ws["B8"] = "CloudTrail lookup"
    ws["C8"] = "yes" if findings.get("cloudtrail_check") else "no"

    for r in range(4, 9):
        ws.cell(row=r, column=2).font = BOLD_FONT
        ws.cell(row=r, column=2).alignment = LEFT
        ws.cell(row=r, column=3).alignment = LEFT

    # Headline counts — formulas so the user can audit
    s = findings["summary"]
    ws["B10"] = "Headline counts"
    ws["B10"].font = BOLD_FONT

    counts = [
        ("Total federated roles",           s["total_federated_roles"]),
        (f"  unused ≥ {findings['unused_days']}d",  s["unused_over_threshold"]),
        ("  unconstrained trust",           s["unconstrained"]),
        ("  wildcard-all-workflows",        s["wildcard_all_workflows"]),
        ("  recommend DELETE",              s["recommend_delete"]),
        ("  recommend TIGHTEN",             s["recommend_tighten"]),
    ]
    for i, (label, value) in enumerate(counts, start=11):
        ws.cell(row=i, column=2, value=label).font = BODY_FONT
        c = ws.cell(row=i, column=3, value=value)
        c.font = BOLD_FONT
        c.alignment = RIGHT
        c.number_format = "#,##0"

    # By issuer
    start = 11 + len(counts) + 2
    ws.cell(row=start, column=2, value="By issuer class").font = BOLD_FONT
    ws.cell(row=start + 1, column=2, value="Issuer").font = HEADER_FONT
    ws.cell(row=start + 1, column=3, value="Roles").font  = HEADER_FONT
    ws.cell(row=start + 1, column=2).fill = HEADER_FILL
    ws.cell(row=start + 1, column=3).fill = HEADER_FILL
    for c in (2, 3):
        ws.cell(row=start + 1, column=c).alignment = CENTER
        ws.cell(row=start + 1, column=c).border = BORDER

    row = start + 2
    for cls, n in sorted(s["by_issuer_class"].items(), key=lambda kv: -kv[1]):
        ws.cell(row=row, column=2, value=cls).font = BODY_FONT
        cell = ws.cell(row=row, column=3, value=n)
        cell.font = BODY_FONT
        cell.alignment = RIGHT
        cell.number_format = "#,##0"
        ws.cell(row=row, column=2).border = BORDER
        ws.cell(row=row, column=3).border = BORDER
        row += 1

    # Legend
    row += 2
    ws.cell(row=row, column=2, value="Risk flag legend").font = BOLD_FONT
    row += 1
    legend = [
        ("CRITICAL", "Federated role has no aud or sub condition — any workflow in any repo can assume it.", CRIT_FILL),
        ("HIGH",     "sub condition uses a repo-wide wildcard (repo:org/repo:*).",                          HIGH_FILL),
        ("HARDENING","Trust policy present but not tight (missing aud, StringLike, etc).",                    None),
        ("UNUSED",   f"Role has not been assumed in ≥ {findings['unused_days']} days.",                       UNUSED_FILL),
        ("MISSING",  "No permissions boundary attached — blast radius is unbounded.",                         None),
        ("LONG_SESSION","max_session_duration > 1 hour.",                                                     None),
    ]
    for tag, text, fill in legend:
        ws.cell(row=row, column=2, value=tag).font = BOLD_FONT
        ws.cell(row=row, column=3, value=text).font = BODY_FONT
        ws.cell(row=row, column=3).alignment = LEFT
        if fill is not None:
            ws.cell(row=row, column=2).fill = fill
        row += 1

    _autosize(ws)
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["C"].width = 90


def build_roles(wb: openpyxl.Workbook, findings: dict[str, Any]) -> None:
    ws = wb.create_sheet("Federated Roles")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3

    ws["B2"] = "One row per federated IAM role"
    ws["B2"].font = TITLE_FONT

    headers = [
        "Role name", "Role ARN", "Issuer class", "Provider URL",
        "Last used (days ago)", "Last used region",
        "Created", "MaxSession (s)", "Permissions boundary",
        "aud op", "sub op", "sub values",
        "Risk score", "Risk flags", "Recommendation",
    ]
    header_row = 4
    for i, h in enumerate(headers, start=2):
        c = ws.cell(row=header_row, column=i, value=h)
    _style_header_row(ws, header_row, len(headers) + 1)

    # Sort roles: highest risk first
    roles = sorted(findings["federated_roles"], key=lambda r: -r["risk_score"])

    for i, r in enumerate(roles, start=header_row + 1):
        a = r["trust_analysis"]
        values = [
            r["role_name"],
            r["role_arn"],
            ", ".join(sorted(set(a["provider_class"]))) or "-",
            ", ".join(sorted(set(a["provider_urls"]))) or "-",
            r["last_used_days_ago"] if r["last_used_days_ago"] is not None else "never",
            r["last_used_region"] or "-",
            r["create_date"],
            r["max_session_duration_s"],
            r["permissions_boundary_arn"] or "-",
            a["aud_condition_op"] or "-",
            a["sub_condition_op"] or "-",
            "\n".join(a["sub_values"]) or "-",
            r["risk_score"],
            "\n".join(r["risk_flags"]) or "-",
            r["recommendation"],
        ]
        for j, v in enumerate(values, start=2):
            cell = ws.cell(row=i, column=j, value=v)
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = LEFT if isinstance(v, str) and len(str(v)) > 15 else CENTER

        # Colorize the recommendation cell
        rec = r["recommendation"]
        rec_cell = ws.cell(row=i, column=2 + len(headers) - 1)
        if rec.startswith("DELETE"):
            rec_cell.fill = CRIT_FILL
            rec_cell.font = BOLD_FONT
        elif rec.startswith("TIGHTEN"):
            rec_cell.fill = HIGH_FILL
        elif rec.startswith("ADD"):
            rec_cell.fill = UNUSED_FILL
        else:
            rec_cell.fill = OK_FILL

        # Risk-score numeric formatting
        score_cell = ws.cell(row=i, column=2 + headers.index("Risk score"))
        score_cell.number_format = "#,##0"
        score_cell.alignment = RIGHT

    # Freeze header
    ws.freeze_panes = ws.cell(row=header_row + 1, column=3)

    # Formula: total roles + count of DELETE recommendations at the top,
    # so the user gets audit-checkable totals.
    last_data_row = header_row + len(roles)
    if roles:
        rec_col_letter = get_column_letter(2 + len(headers) - 1)
        ws["B3"] = "Total roles:"
        ws["C3"] = f"=COUNTA(B{header_row + 1}:B{last_data_row})"
        ws["C3"].number_format = "#,##0"
        ws["D3"] = "DELETE:"
        ws["E3"] = f'=COUNTIF({rec_col_letter}{header_row + 1}:{rec_col_letter}{last_data_row},"DELETE*")'
        ws["E3"].number_format = "#,##0"
        ws["F3"] = "TIGHTEN:"
        ws["G3"] = f'=COUNTIF({rec_col_letter}{header_row + 1}:{rec_col_letter}{last_data_row},"TIGHTEN*")'
        ws["G3"].number_format = "#,##0"
        for cell_ref in ("B3", "D3", "F3"):
            ws[cell_ref].font = BOLD_FONT

    # Width tuning
    ws.column_dimensions["B"].width = 32
    ws.column_dimensions["C"].width = 55
    ws.column_dimensions["D"].width = 24
    ws.column_dimensions["E"].width = 35
    ws.column_dimensions["F"].width = 14
    ws.column_dimensions["G"].width = 12
    ws.column_dimensions["H"].width = 20
    ws.column_dimensions["I"].width = 14
    ws.column_dimensions["J"].width = 40
    ws.column_dimensions["K"].width = 14
    ws.column_dimensions["L"].width = 14
    ws.column_dimensions["M"].width = 45
    ws.column_dimensions["N"].width = 11
    ws.column_dimensions["O"].width = 50
    ws.column_dimensions["P"].width = 42


def build_trust_policies(wb: openpyxl.Workbook, findings: dict[str, Any]) -> None:
    ws = wb.create_sheet("Trust Policies")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws["B2"] = "Trust-policy hardening detail"
    ws["B2"].font = TITLE_FONT

    headers = [
        "Role name", "Web identity?", "SAML?",
        "Has aud?", "aud op", "Audiences",
        "Has sub?", "sub op", "Sub wildcards repo?", "Sub wildcards ALL?",
        "Unconstrained?", "Hardening issues",
    ]
    header_row = 4
    for i, h in enumerate(headers, start=2):
        ws.cell(row=header_row, column=i, value=h)
    _style_header_row(ws, header_row, len(headers) + 1)

    for i, r in enumerate(findings["federated_roles"], start=header_row + 1):
        a = r["trust_analysis"]
        values = [
            r["role_name"],
            "Y" if a["is_web_identity"] else "-",
            "Y" if a["is_saml"] else "-",
            "Y" if a["has_aud_condition"] else "N",
            a["aud_condition_op"] or "-",
            ", ".join(a["audiences"]) or "-",
            "Y" if a["has_sub_condition"] else "N",
            a["sub_condition_op"] or "-",
            "Y" if a["sub_wildcards_repo"] else "-",
            "Y" if a["sub_wildcard_all"] else "-",
            "Y" if a["unconstrained"] else "-",
            "\n".join(a["hardening_issues"]) or "-",
        ]
        for j, v in enumerate(values, start=2):
            cell = ws.cell(row=i, column=j, value=v)
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = LEFT if j in (7, 13) else CENTER
        if a["unconstrained"]:
            for j in range(2, 2 + len(headers)):
                ws.cell(row=i, column=j).fill = CRIT_FILL
        elif a["sub_wildcard_all"]:
            for j in range(2, 2 + len(headers)):
                ws.cell(row=i, column=j).fill = HIGH_FILL

    ws.freeze_panes = ws.cell(row=header_row + 1, column=3)
    ws.column_dimensions["B"].width = 32
    for col in range(3, 3 + len(headers)):
        ws.column_dimensions[get_column_letter(col)].width = 18
    ws.column_dimensions["G"].width = 30
    ws.column_dimensions["M"].width = 50


def build_providers(wb: openpyxl.Workbook, findings: dict[str, Any]) -> None:
    ws = wb.create_sheet("Identity Providers")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3

    ws["B2"] = "OIDC + SAML identity providers"
    ws["B2"].font = TITLE_FONT

    headers = ["Kind", "Issuer class", "URL / ARN", "Client IDs / Audience", "Created", "Thumbprints / ValidUntil"]
    header_row = 4
    for i, h in enumerate(headers, start=2):
        ws.cell(row=header_row, column=i, value=h)
    _style_header_row(ws, header_row, len(headers) + 1)

    row = header_row + 1
    for p in findings["oidc_providers"]:
        vals = [
            "OIDC",
            p["issuer_class"],
            p["url"],
            ", ".join(p["client_ids"]) or "-",
            p["create_date"] or "-",
            ", ".join(p.get("thumbprints", [])) or "-",
        ]
        for j, v in enumerate(vals, start=2):
            cell = ws.cell(row=row, column=j, value=v)
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = LEFT
        row += 1
    for p in findings["saml_providers"]:
        vals = ["SAML", p["issuer_class"], p["arn"], "-", p.get("create_date") or "-", p.get("valid_until") or "-"]
        for j, v in enumerate(vals, start=2):
            cell = ws.cell(row=row, column=j, value=v)
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = LEFT
        row += 1

    ws.column_dimensions["B"].width = 8
    ws.column_dimensions["C"].width = 32
    ws.column_dimensions["D"].width = 62
    ws.column_dimensions["E"].width = 30
    ws.column_dimensions["F"].width = 22
    ws.column_dimensions["G"].width = 50


def build_cloudtrail(wb: openpyxl.Workbook, findings: dict[str, Any]) -> None:
    roles_with_ct = [r for r in findings["federated_roles"] if r.get("cloudtrail_90d")]
    if not roles_with_ct:
        return
    ws = wb.create_sheet("CloudTrail 90d")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws["B2"] = f"AssumeRoleWithWebIdentity events (last {findings['unused_days']}d, us-east-1 lookup)"
    ws["B2"].font = TITLE_FONT

    headers = ["Role name", "Role ARN", "Events seen", "Last seen", "Last source IP", "Last errorCode"]
    header_row = 4
    for i, h in enumerate(headers, start=2):
        ws.cell(row=header_row, column=i, value=h)
    _style_header_row(ws, header_row, len(headers) + 1)

    for i, r in enumerate(roles_with_ct, start=header_row + 1):
        ct = r["cloudtrail_90d"]
        vals = [
            r["role_name"], r["role_arn"],
            ct.get("count", 0),
            ct.get("last_seen") or "-",
            ct.get("last_source_ip") or "-",
            ct.get("last_error") or "-",
        ]
        for j, v in enumerate(vals, start=2):
            cell = ws.cell(row=i, column=j, value=v)
            cell.font = BODY_FONT
            cell.border = BORDER
            cell.alignment = LEFT
            if isinstance(v, int):
                cell.number_format = "#,##0"
                cell.alignment = RIGHT
        if ct.get("count", 0) == 0:
            for j in range(2, 8):
                ws.cell(row=i, column=j).fill = UNUSED_FILL

    ws.freeze_panes = ws.cell(row=header_row + 1, column=3)
    ws.column_dimensions["B"].width = 32
    ws.column_dimensions["C"].width = 55
    ws.column_dimensions["D"].width = 14
    ws.column_dimensions["E"].width = 24
    ws.column_dimensions["F"].width = 18
    ws.column_dimensions["G"].width = 20


def build_methodology(wb: openpyxl.Workbook, findings: dict[str, Any]) -> None:
    ws = wb.create_sheet("Methodology")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 110

    ws["B2"] = "How this report was built"
    ws["B2"].font = TITLE_FONT

    text = [
        "",
        "1. Provider enumeration",
        "   • iam:ListOpenIDConnectProviders + iam:GetOpenIDConnectProvider for each ARN.",
        "   • iam:ListSAMLProviders + iam:GetSAMLProvider for each ARN.",
        "   • Each provider URL is classified against a taxonomy of known issuers (GitHub Actions,",
        "     GitLab, CircleCI, Terraform Cloud, Bitbucket, Google, Cognito, EKS IRSA, Azure AD/Entra,",
        "     Okta, Auth0, Buildkite, Vault). Anything else is labeled 'Unknown / custom'.",
        "",
        "2. Role enumeration",
        "   • iam:ListRoles (paginated) returns every role in the account together with its",
        "     AssumeRolePolicyDocument (already URL-decoded by boto3) and its RoleLastUsed metadata.",
        "   • A role is considered federated if any Statement's Action includes",
        "     sts:AssumeRoleWithWebIdentity, sts:AssumeRoleWithSAML, or sts:*.",
        "",
        "3. Trust-policy hardening checks",
        "   • Presence of a token.actions.githubusercontent.com:aud condition (StringEquals).",
        "   • Presence of a *:sub condition. StringEquals is 'strict'; StringLike with a wildcard",
        "     is looser; the special pattern 'repo:org/repo:*' is flagged HIGH because it lets",
        "     every workflow / branch / environment in a repo assume the role.",
        "   • Roles with no aud AND no sub condition are flagged CRITICAL (unconstrained).",
        "",
        "4. Usage detection",
        "   • Primary signal: role.RoleLastUsed.LastUsedDate returned by iam:GetRole.",
        "     This is the same value the console shows on the 'Last activity' tile.",
        "   • Optional CloudTrail spot-check (only if --cloudtrail was passed to scan.py):",
        "     cloudtrail:LookupEvents in us-east-1 for EventName=AssumeRoleWithWebIdentity,",
        f"     filtered client-side to roleArn == the role in question, over the last {findings['unused_days']} days.",
        "     STS is a global service so events land in us-east-1 by default.",
        "",
        "5. Recommendation logic",
        "   • DELETE  — unconstrained trust policy, OR unused AND overly permissive, OR unused with no owner.",
        "   • TIGHTEN — has hardening_issues (missing aud, StringLike without wildcard, repo-wide wildcard).",
        "   • ADD     — otherwise-fine role missing a permissions boundary.",
        "   • OK      — passed all checks; review annually.",
        "",
        "6. Blind spots",
        "   • RoleLastUsed is populated on assumption, not on every API call. AWS docs note it can lag",
        "     up to 4 hours and does not go back beyond 400 days.",
        "   • CloudTrail LookupEvents caps at 50 events per query and 90 days of history; use CloudTrail",
        "     Lake or Athena on the trail's S3 destination for anything longer.",
        "   • This scan is single-account, single-region. For AWS Organizations, run per-account via",
        "     an org-wide read-only role (e.g. OrganizationAccountAccessRole assumed from the mgmt account).",
        "",
        "Sources:",
        "   • Boto3 IAM docs: https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/iam.html",
        "   • RoleLastUsed:   https://docs.aws.amazon.com/IAM/latest/APIReference/API_RoleLastUsed.html",
        "   • CloudTrail STS: https://docs.aws.amazon.com/IAM/latest/UserGuide/cloudtrail-integration.html",
        "   • GitHub OIDC:    https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services",
    ]
    for i, line in enumerate(text, start=3):
        c = ws.cell(row=i, column=2, value=line)
        c.font = BODY_FONT if not line.endswith(("enumeration", "checks", "detection", "logic", "spots", "Sources:")) else BOLD_FONT
        c.alignment = LEFT


# --------------------------------------------------------------------------- #
# Main                                                                       #
# --------------------------------------------------------------------------- #

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("findings_json", help="findings.json from scan.py")
    ap.add_argument("out_xlsx",      help="Output .xlsx path")
    args = ap.parse_args()

    with open(args.findings_json) as f:
        findings = json.load(f)

    wb = openpyxl.Workbook()
    build_summary(wb, findings)
    build_roles(wb, findings)
    build_trust_policies(wb, findings)
    build_providers(wb, findings)
    build_cloudtrail(wb, findings)
    build_methodology(wb, findings)

    wb.save(args.out_xlsx)
    print(f"Wrote {args.out_xlsx}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
