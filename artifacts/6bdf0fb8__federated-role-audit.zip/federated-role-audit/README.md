# Federated IAM Role Audit

A read-only discovery scanner and cleanup report generator for AWS federated
IAM roles (OIDC + SAML). Enumerates every role trusted by a Web-Identity or
SAML provider, classifies it by issuer (GitHub Actions, GitLab, EKS IRSA,
Okta, ...), analyzes the trust policy for hardening gaps, marks roles unused
for ≥ N days, optionally spot-checks CloudTrail, and produces a multi-tab
Excel cleanup report.

Built for the `odisena/otel-collector-infra` OIDC deployment pattern.

---

## What it flags

| Category      | Meaning                                                                                               | Recommendation                     |
| ------------- | ----------------------------------------------------------------------------------------------------- | ---------------------------------- |
| `CRITICAL`    | Trust policy has no `aud` **and** no `sub` condition — any workflow in any repo can assume the role. | **DELETE** (or rewrite immediately) |
| `HIGH`        | `sub` uses a repo-wide wildcard (`repo:org/repo:*`) — every branch/workflow in the repo can assume.  | **TIGHTEN** to a specific `ref`     |
| `HARDENING`   | Trust policy present but weak (missing `aud`, `StringLike` where `StringEquals` would do, etc.).      | **TIGHTEN**                         |
| `UNUSED`      | Role has not been assumed in ≥ `--unused-days` (default 90).                                          | **DELETE** if truly abandoned       |
| `MISSING`     | No permissions boundary attached — blast radius is unbounded on privilege escalation.                 | **ADD** boundary                    |
| `LONG_SESSION`| `MaxSessionDuration` > 1h.                                                                            | Tighten to 1h unless justified      |

Risk score = 100·CRITICAL + 50·HIGH + 30·UNUSED + 20·HARDENING + 10·LONG_SESSION + 5·MISSING.
Roles are sorted highest-risk-first in the report.

---

## Prerequisites

- **Python 3.10+** with `boto3` and `openpyxl` (both are pre-installed in AWS
  CloudShell — no setup needed there).
- **AWS credentials** with the read-only permissions in
  [`iam/audit-policy.json`](./iam/audit-policy.json). Attach that policy to
  the user/role you'll run the scanner as. It grants:
    - `iam:List*` and `iam:Get*` for roles and identity providers
    - `sts:GetCallerIdentity`
    - `cloudtrail:LookupEvents` (only used if you pass `--cloudtrail`)

The scanner never calls a mutating API. There is no `iam:Delete*`,
`iam:Update*`, or `iam:Put*` in the policy — safe to run in production.

---

## Quickstart (CloudShell — recommended)

CloudShell already has `python3`, `boto3`, `openpyxl`, and your credentials.
It's the fastest path.

```bash
# 1. Upload federated-role-audit.zip in CloudShell (Actions → Upload file)
unzip federated-role-audit.zip
cd federated-role-audit

# 2. (One-time) attach the audit policy to your CloudShell user/role.
#    See `iam/audit-policy.json` — either attach it directly or copy the
#    Statement into your existing least-priv admin policy.

# 3. Run the scan
python3 scan.py \
  --unused-days 90 \
  --cloudtrail \
  --expected-repo odisena/otel-collector-infra \
  --out findings.json

# 4. Build the report
python3 report.py findings.json cleanup-report.xlsx

# 5. Download cleanup-report.xlsx from CloudShell (Actions → Download file)
```

Typical runtime on an account with ~50 roles: **10–30 seconds** without
`--cloudtrail`, **1–3 minutes** with it (CloudTrail `LookupEvents` is
throttled to ~2 tps).

---

## Quickstart (local machine)

```bash
pip install boto3 openpyxl

export AWS_PROFILE=your-profile      # or set AWS_ACCESS_KEY_ID / etc.
export AWS_REGION=us-east-1          # any region works — IAM is global

python3 scan.py \
  --profile your-profile \
  --unused-days 90 \
  --cloudtrail \
  --expected-repo odisena/otel-collector-infra \
  --out findings.json

python3 report.py findings.json cleanup-report.xlsx
open cleanup-report.xlsx            # or xdg-open on Linux
```

---

## CLI reference

### `scan.py`

| Flag              | Default    | What it does                                                                                           |
| ----------------- | ---------- | ------------------------------------------------------------------------------------------------------ |
| `--profile`       | `default`  | Named AWS profile from `~/.aws/credentials` / `~/.aws/config`.                                         |
| `--region`        | `us-east-1`| Region for the STS/CloudTrail clients. IAM itself is global.                                           |
| `--unused-days`   | `90`       | Roles not assumed in this many days are flagged `UNUSED`.                                              |
| `--cloudtrail`    | off        | Also `LookupEvents` for `AssumeRoleWithWebIdentity` in **us-east-1** (STS global endpoint lands here). |
| `--expected-repo` | none       | Format `org/repo`. Any GitHub-Actions-federated role whose `sub` values don't include this repo gets an extra `SUSPECT_REPO` hardening flag. |
| `--out`           | `findings.json` | Path for the JSON output.                                                                         |

### `report.py`

```
python3 report.py <findings.json> <report.xlsx>
```

Produces a 6-sheet workbook:

1. **Summary** — headline counts, breakdown by issuer, risk-flag legend.
2. **Federated Roles** — one row per role, sorted by risk score. Color-coded
   Recommendation column (red = DELETE, orange = TIGHTEN, yellow = ADD,
   green = OK). Formulas at the top count `DELETE` and `TIGHTEN` — audit-checkable.
3. **Trust Policies** — trust-policy hardening detail per role.
4. **Identity Providers** — OIDC + SAML providers found in the account.
5. **CloudTrail 90d** — only appears if you passed `--cloudtrail`.
6. **Methodology** — how the scan works, blind spots, data sources.

---

## AWS blind spots you should know about

The scanner documents these in the **Methodology** sheet so a reviewer isn't
misled:

- **`RoleLastUsed` lags up to 4 hours** and only covers ~400 days. A role
  assumed 401 days ago and not since will show as "never used".
- **CloudTrail `LookupEvents` caps at 50 events per query and 90 days of
  history**, is throttled to ~2 tps, and is region-scoped. The scanner
  queries `us-east-1` only (because `AssumeRoleWithWebIdentity` goes through
  the global STS endpoint by default), so a caller using a regional STS
  endpoint like `sts.eu-west-1.amazonaws.com` explicitly will not appear.
- **`iam:ListRoles` is not paginated by trust-policy content.** The scanner
  pages through every role and filters client-side, so on accounts with
  thousands of roles it can take a minute or two.

---

## Sample output

See `sample_output/findings.json` and `sample_output/report.xlsx` for a
synthetic 6-role, 3-OIDC-provider example that exercises every risk
category (unconstrained, wildcard, unused, missing boundary, long session,
OK).

---

## Companion tooling in this repo

The two Terraform modules you already deployed for `otel-collector-infra`
are the counterparts to this audit:

- **`github-oidc-aws`** — provisions the hardened OIDC provider + trust
  policy that this scanner expects to see.
- **`github-oidc-alerting`** — EventBridge + Lambda enricher that watches
  for `AssumeRoleWithWebIdentity` calls not matching your expected shape.

If a scan finds a role that violates your policy, hardening it usually means
either running it through the `github-oidc-aws` module or writing an
equivalent inline trust policy patch.
