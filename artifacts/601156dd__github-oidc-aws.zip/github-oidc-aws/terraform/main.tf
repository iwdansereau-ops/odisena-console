###############################################################################
# GitHub OIDC -> AWS IAM (Keyless CI/CD for OTel Collector Deployments)
#
# Creates:
#   - IAM OIDC Provider for token.actions.githubusercontent.com
#   - IAM Role assumable ONLY by a specific repo/branch/tag/environment
#   - Least-privilege inline policy for OTel Collector deployment tasks
#
# References:
#   - AWS: Configuring OIDC in Amazon Web Services
#     https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services
#   - aws-actions/configure-aws-credentials
#     https://github.com/aws-actions/configure-aws-credentials
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

###############################################################################
# Variables
###############################################################################

variable "aws_region" {
  description = "AWS region for the deployment role and OTel resources."
  type        = string
  default     = "us-east-1"
}

variable "github_org" {
  description = "GitHub organization or user that owns the repository."
  type        = string
}

variable "github_repo" {
  description = "GitHub repository name (without the org prefix)."
  type        = string
}

# Restrict which refs / environments can assume the role.
# Use the most specific pattern possible. Examples:
#   "repo:my-org/my-repo:ref:refs/heads/main"
#   "repo:my-org/my-repo:environment:production"
#   "repo:my-org/my-repo:ref:refs/tags/v*"
# Avoid broad wildcards like "repo:my-org/my-repo:*" in production.
variable "allowed_subjects" {
  description = "List of GitHub OIDC 'sub' claim patterns permitted to assume the role."
  type        = list(string)
  default     = []
}

variable "role_name" {
  description = "Name of the IAM role assumed by GitHub Actions."
  type        = string
  default     = "github-actions-otel-deployer"
}

variable "otel_config_bucket" {
  description = "S3 bucket that stores OTel Collector configuration files."
  type        = string
}

variable "otel_ecs_cluster_arn" {
  description = "ARN of the ECS cluster running the OTel Collector (optional)."
  type        = string
  default     = ""
}

variable "otel_ecs_service_arns" {
  description = "ARNs of ECS services for OTel Collector task deployments."
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Common resource tags."
  type        = map(string)
  default = {
    ManagedBy = "terraform"
    Component = "otel-collector"
    Purpose   = "github-actions-oidc"
  }
}

###############################################################################
# Locals
###############################################################################

locals {
  # If the caller doesn't provide subjects, default to main branch only.
  effective_subjects = length(var.allowed_subjects) > 0 ? var.allowed_subjects : [
    "repo:${var.github_org}/${var.github_repo}:ref:refs/heads/main",
    "repo:${var.github_org}/${var.github_repo}:environment:production",
  ]

  github_oidc_url = "https://token.actions.githubusercontent.com"
  github_oidc_aud = "sts.amazonaws.com"
}

###############################################################################
# GitHub OIDC Provider
#
# NOTE: As of mid-2023 AWS validates the GitHub OIDC provider's TLS chain
# against a trusted root CA, so the thumbprint value is no longer used for
# verification. We still supply a placeholder because the AWS provider
# schema requires the argument. See:
# https://github.blog/changelog/2023-06-27-github-actions-update-on-oidc-integration-with-aws/
###############################################################################

resource "aws_iam_openid_connect_provider" "github" {
  url             = local.github_oidc_url
  client_id_list  = [local.github_oidc_aud]
  thumbprint_list = ["ffffffffffffffffffffffffffffffffffffffff"]

  tags = merge(var.tags, {
    Name = "github-actions-oidc"
  })
}

###############################################################################
# Trust Policy: Only the specified repo/refs/environments can assume the role
###############################################################################

data "aws_iam_policy_document" "trust" {
  statement {
    sid     = "GitHubOIDCAssumeRole"
    effect  = "Allow"
    actions = ["sts:AssumeRoleWithWebIdentity"]

    principals {
      type        = "Federated"
      identifiers = [aws_iam_openid_connect_provider.github.arn]
    }

    # Ensure the token was minted for AWS STS (audience pinning).
    condition {
      test     = "StringEquals"
      variable = "token.actions.githubusercontent.com:aud"
      values   = [local.github_oidc_aud]
    }

    # Restrict which workflows/refs/environments can assume this role.
    # StringLike allows wildcards in patterns (e.g., refs/tags/v*).
    condition {
      test     = "StringLike"
      variable = "token.actions.githubusercontent.com:sub"
      values   = local.effective_subjects
    }
  }
}

resource "aws_iam_role" "github_actions" {
  name                 = var.role_name
  description          = "Assumed by GitHub Actions via OIDC to deploy the OTel Collector."
  assume_role_policy   = data.aws_iam_policy_document.trust.json
  max_session_duration = 3600 # 1 hour

  tags = var.tags
}

###############################################################################
# Least-Privilege Deployment Policy
#
# Covers a typical OTel Collector deployment:
#   - Read/write collector config in S3
#   - Update ECS service / register new task definitions
#   - Pull images from ECR
#   - Write CloudWatch logs and metrics
#   - Read/write specific SSM parameters for collector settings
###############################################################################

data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}
data "aws_region" "current" {}

data "aws_iam_policy_document" "deploy" {
  # ---- S3: OTel config bucket -------------------------------------------------
  statement {
    sid     = "OTelConfigBucketList"
    effect  = "Allow"
    actions = ["s3:ListBucket", "s3:GetBucketLocation"]
    resources = [
      "arn:${data.aws_partition.current.partition}:s3:::${var.otel_config_bucket}",
    ]
  }

  statement {
    sid    = "OTelConfigObjectRW"
    effect = "Allow"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
    ]
    resources = [
      "arn:${data.aws_partition.current.partition}:s3:::${var.otel_config_bucket}/*",
    ]
  }

  # ---- ECR: pull collector image ---------------------------------------------
  statement {
    sid       = "ECRAuth"
    effect    = "Allow"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid    = "ECRPull"
    effect = "Allow"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:GetDownloadUrlForLayer",
      "ecr:BatchGetImage",
      "ecr:DescribeImages",
      "ecr:DescribeRepositories",
    ]
    resources = [
      "arn:${data.aws_partition.current.partition}:ecr:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:repository/otel/*",
    ]
  }

  # ---- ECS: register task definitions & update service -----------------------
  statement {
    sid    = "ECSRegisterTaskDef"
    effect = "Allow"
    actions = [
      "ecs:RegisterTaskDefinition",
      "ecs:DescribeTaskDefinition",
      "ecs:ListTaskDefinitions",
    ]
    resources = ["*"] # ECS requires "*" for these actions
  }

  dynamic "statement" {
    for_each = length(var.otel_ecs_service_arns) > 0 ? [1] : []
    content {
      sid    = "ECSUpdateService"
      effect = "Allow"
      actions = [
        "ecs:UpdateService",
        "ecs:DescribeServices",
        "ecs:ListServices",
        "ecs:DescribeTasks",
        "ecs:ListTasks",
      ]
      resources = var.otel_ecs_service_arns
    }
  }

  dynamic "statement" {
    for_each = var.otel_ecs_cluster_arn != "" ? [1] : []
    content {
      sid       = "ECSDescribeCluster"
      effect    = "Allow"
      actions   = ["ecs:DescribeClusters"]
      resources = [var.otel_ecs_cluster_arn]
    }
  }

  # Required so ECS can pass the task/execution roles when registering a new task def.
  statement {
    sid       = "PassOTelTaskRoles"
    effect    = "Allow"
    actions   = ["iam:PassRole"]
    resources = ["arn:${data.aws_partition.current.partition}:iam::${data.aws_caller_identity.current.account_id}:role/otel-*"]

    condition {
      test     = "StringEquals"
      variable = "iam:PassedToService"
      values   = ["ecs-tasks.amazonaws.com"]
    }
  }

  # ---- SSM: collector runtime parameters -------------------------------------
  statement {
    sid    = "SSMOTelParams"
    effect = "Allow"
    actions = [
      "ssm:GetParameter",
      "ssm:GetParameters",
      "ssm:GetParametersByPath",
      "ssm:PutParameter",
    ]
    resources = [
      "arn:${data.aws_partition.current.partition}:ssm:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:parameter/otel/*",
    ]
  }

  # ---- CloudWatch: logs + custom metrics -------------------------------------
  statement {
    sid    = "CWLogs"
    effect = "Allow"
    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents",
      "logs:DescribeLogGroups",
      "logs:DescribeLogStreams",
    ]
    resources = [
      "arn:${data.aws_partition.current.partition}:logs:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:log-group:/otel/*",
      "arn:${data.aws_partition.current.partition}:logs:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:log-group:/otel/*:log-stream:*",
    ]
  }

  statement {
    sid       = "CWMetrics"
    effect    = "Allow"
    actions   = ["cloudwatch:PutMetricData"]
    resources = ["*"]

    condition {
      test     = "StringEquals"
      variable = "cloudwatch:namespace"
      values   = ["OTel", "OTel/Collector"]
    }
  }
}

resource "aws_iam_role_policy" "deploy" {
  name   = "${var.role_name}-deploy"
  role   = aws_iam_role.github_actions.id
  policy = data.aws_iam_policy_document.deploy.json
}

###############################################################################
# Outputs
###############################################################################

output "role_arn" {
  description = "ARN to reference in the GitHub Actions workflow (role-to-assume)."
  value       = aws_iam_role.github_actions.arn
}

output "oidc_provider_arn" {
  description = "ARN of the GitHub OIDC provider."
  value       = aws_iam_openid_connect_provider.github.arn
}

output "allowed_subjects" {
  description = "Effective list of GitHub OIDC subject patterns permitted to assume the role."
  value       = local.effective_subjects
}
