# Example variable values. Copy to terraform.tfvars and adjust.

aws_region  = "us-east-1"
github_org  = "Odisena"
github_repo = "otel-collector"

# Restrict who can assume the deployment role. Use the tightest patterns you can.
allowed_subjects = [
  "repo:Odisena/otel-collector:ref:refs/heads/main",
  "repo:Odisena/otel-collector:environment:production",
  "repo:Odisena/otel-collector:ref:refs/tags/v*",
]

role_name          = "github-actions-otel-deployer"
otel_config_bucket = "odisena-otel-collector-config"

otel_ecs_cluster_arn = "arn:aws:ecs:us-east-1:123456789012:cluster/observability"
otel_ecs_service_arns = [
  "arn:aws:ecs:us-east-1:123456789012:service/observability/otel-collector",
]
