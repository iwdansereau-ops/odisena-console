# GitHub OIDC → AWS for OTel Collector Deployments

Keyless CI/CD: GitHub Actions assumes a scoped AWS IAM role via OIDC. No
long-lived AWS access keys stored in GitHub.

## Files

- `terraform/main.tf` — OIDC provider, IAM role, least-privilege deploy policy.
- `terraform/example.tfvars` — sample variable values.
- `cloudformation/github-oidc.yaml` — equivalent CloudFormation stack.
- `.github/workflows/deploy-otel-collector.yml` — hardened deployment workflow.

## One-time setup

1. **Deploy the IAM infra** (Terraform or CloudFormation). Note the output
   `role_arn` / `RoleArn`.
2. **In GitHub**, at the repo or org level, create:
   - Repository variable `AWS_DEPLOY_ROLE_ARN` = the role ARN.
   - Repository variable `OTEL_CONFIG_BUCKET` = your S3 config bucket.
   - Environment `production` with required reviewers + optional wait timer.
3. Confirm the `sub` patterns in `allowed_subjects` match your intended
   branches / tags / environments.

## Trust policy scope

The role's trust policy uses two conditions that together prevent
confused-deputy and cross-repo abuse:

- `aud` **must equal** `sts.amazonaws.com` (audience pinning).
- `sub` **must match** one of the patterns in `allowed_subjects`, e.g.
  `repo:Odisena/otel-collector:ref:refs/heads/main`.

Avoid `repo:Org/Repo:*` in production — that lets any workflow in the repo
(including PR-triggered ones) assume the role.

## Workflow hardening highlights

- Default `permissions: contents: read`; `id-token: write` scoped to the jobs
  that need it.
- Third-party actions pinned to commit SHAs (not tags).
- `persist-credentials: false` on checkout to avoid leaking the GITHUB_TOKEN.
- `concurrency` group prevents overlapping deploys.
- `environment: production` enables branch protection + required reviewers.
- Session name embeds `run_id` for easier CloudTrail correlation.

## References

- [Configuring OpenID Connect in Amazon Web Services (GitHub Docs)](https://docs.github.com/en/actions/security-for-github-actions/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services)
- [aws-actions/configure-aws-credentials](https://github.com/aws-actions/configure-aws-credentials)
- [GitHub Actions OIDC → AWS thumbprint change (June 2023)](https://github.blog/changelog/2023-06-27-github-actions-update-on-oidc-integration-with-aws/)
