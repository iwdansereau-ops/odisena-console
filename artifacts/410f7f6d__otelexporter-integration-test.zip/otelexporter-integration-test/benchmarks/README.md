# benchmarks/

Persisted benchmark artifacts consumed by `scripts/bench.sh`.

| File | Purpose |
|---|---|
| `baseline.txt` | Reference benchmark run from `main`. Regenerated only on `main` via `scripts/bench.sh --update-baseline` and committed. Every PR is compared against this. |
| `current.txt`  | Most recent local/CI run. Overwritten each invocation. **Do not commit.** |

## Refreshing the baseline

Run this only on `main` after an intentional, reviewed performance change:

```bash
git checkout main && git pull
scripts/bench.sh --update-baseline --count 10 --time 5s
git add benchmarks/baseline.txt
git commit -m "bench: refresh baseline after <change>"
```

Use higher `--count` and `--time` than a normal PR run so the recorded numbers
are stable and don't produce false positives on every PR.

## Why this file lives in git

Committing the baseline gives every PR reviewer a deterministic reference and
means CI needs zero external storage (no S3 bucket, no artifact server) to
detect regressions. The tradeoff is that hardware changes on CI runners will
require a baseline refresh — that's a feature, not a bug: it forces you to
re-establish the performance floor whenever the measurement platform moves.
