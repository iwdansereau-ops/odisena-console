module github.com/example/customotlpexporter

go 1.22

require (
	github.com/stretchr/testify v1.9.0
	go.opentelemetry.io/collector/component v0.107.0
	go.opentelemetry.io/collector/component/componenttest v0.107.0
	go.opentelemetry.io/collector/config/confighttp v0.107.0
	go.opentelemetry.io/collector/config/configopaque v1.13.0
	go.opentelemetry.io/collector/config/configtls v1.13.0
	go.opentelemetry.io/collector/consumer v0.107.0
	go.opentelemetry.io/collector/exporter v0.107.0
	go.opentelemetry.io/collector/exporter/exportertest v0.107.0
	go.opentelemetry.io/collector/pdata v1.13.0
	go.uber.org/zap v1.27.0
	google.golang.org/protobuf v1.34.2
)
