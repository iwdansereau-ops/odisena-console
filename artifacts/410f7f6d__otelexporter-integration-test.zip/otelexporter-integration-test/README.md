# customotlpexporter — integration test suite

A minimal custom OpenTelemetry Collector exporter (`customotlp`) plus a
Go integration test suite that validates end-to-end OTLP/HTTP trace export.

## What's here

```
otelexporter-integration-test/
├── go.mod
├── exporter/                 # component under test
│   ├── config.go             # Config + Validate
│   ├── factory.go            # exporter.Factory wiring
│   ├── exporter.go           # marshals ptrace.Traces -> OTLP proto -> POST
│   └── exporter_integration_test.go
├── internal/testutil/
│   ├── mock_backend.go       # httptest.Server OTLP/HTTP backend
│   └── telemetry.go          # TestTelemetry helpers for trace fixtures
└── exporter/exporter_bench_test.go  # high-throughput benchmarks
```

## What the test verifies

`TestCustomOTLPExporter_ForwardsTracesOverHTTP` walks the full path:

1. Spins up a `httptest.Server` that decodes OTLP protobuf `ExportRequest`
   messages on `POST /v1/traces`.
2. Builds a Collector-style `Config` that points the custom exporter at the
   mock server (`endpoint`, `traces_url_path`, `timeout`, no compression).
3. Instantiates the exporter through its `exporter.Factory`, starts it with a
   `componenttest.NewNopHost`, and registers `t.Cleanup` for shutdown.
4. Uses `TestTelemetry` to build a deterministic `ptrace.Traces` payload
   (2 spans, mixed attribute types, resource `service.name` etc.).
5. Pushes through `exp.ConsumeTraces(ctx, td)` — the same entry point the
   Collector pipeline uses.
6. Asserts on what the mock received:
   - HTTP envelope: `POST`, path `/v1/traces`, `Content-Type:
     application/x-protobuf`, `HTTP/1.1` protocol, custom `User-Agent`.
   - Payload structure: 1 ResourceSpans → 1 ScopeSpans → 2 spans.
   - Resource attributes: `service.name = checkout-service`,
     `service.version`, `deployment.environment`.
   - Span attributes: `http.method`, `http.route`, `http.status_code`,
     `db.system`, `db.statement`, plus bool/int roundtrips.
   - Identity preserved: non-zero `TraceID`/`SpanID` after
     marshal→transport→unmarshal.
   - Timing: `EndTimestamp > StartTimestamp` for every span.

Two supporting tests round out the suite:

- `TestCustomOTLPExporter_RejectsBadEndpoint` — config validation.
- `TestCustomOTLPExporter_PropagatesServerErrors` — 5xx surfaces as a
  pipeline error via the mock's `FailNextN(1)`.

## Running

```bash
cd otelexporter-integration-test
go mod tidy
go test ./... -v -race
```

## Benchmarks

The suite includes microbenchmarks that isolate each stage of the exporter
hot path plus end-to-end benchmarks that include HTTP/1.1 loopback. All
use **1000 spans per batch** as the primary high-throughput scenario
(configurable via `benchSpansPerBatch`).

| Benchmark | What it measures |
|---|---|
| `BenchmarkTracesTranslation` | `ptrace.Traces` → `ptraceotlp.ExportRequest` wrapper cost. |
| `BenchmarkTracesSerialization` | `MarshalProto()` cost on a 1000-span batch. Reports throughput in bytes/sec. |
| `BenchmarkTracesTranslateAndSerialize` | Combined translate + marshal — the pure CPU work per batch before I/O. |
| `BenchmarkExporterPushTraces_EndToEnd` | Full `ConsumeTraces` path against a discard-body httptest.Server. Reports `spans/sec`. |
| `BenchmarkExporterPushTraces_Parallel` | Same as above but via `b.RunParallel` to catch contention. |
| `BenchmarkTracesBatchSizeScaling` | Sweeps 100/500/1000/2500/5000 spans to see per-span cost curve. |
| `BenchmarkTracesAttributeWidthScaling` | Sweeps 0/4/8/16/32/64 attributes per span — informs tag-cardinality policy upstream. |
| `BenchmarkExporterPushTraces_Gzip` | Full push path with `Compression: "gzip"`. Reports `wire-B/op` so you can trade CPU vs bandwidth against the uncompressed end-to-end run. |

### Running the benchmarks

```bash
# Run every benchmark once with allocation reporting.
go test ./exporter -run='^$' -bench=. -benchmem

# Focus on the 1000-span end-to-end scenario, average 5 runs.
go test ./exporter -run='^$' -bench=BenchmarkExporterPushTraces_EndToEnd \
    -benchmem -benchtime=5s -count=5

# Compare before/after a change with benchstat.
go install golang.org/x/perf/cmd/benchstat@latest
go test ./exporter -run='^$' -bench=. -benchmem -count=10 > old.txt
# ...make change...
go test ./exporter -run='^$' -bench=. -benchmem -count=10 > new.txt
benchstat old.txt new.txt

# CPU / allocation profile of the hot path.
go test ./exporter -run='^$' -bench=BenchmarkTracesTranslateAndSerialize \
    -benchmem -cpuprofile=cpu.out -memprofile=mem.out
go tool pprof -top cpu.out
```

### Interpreting the output

Each line reports `ns/op`, `B/op`, `allocs/op`, and the custom metrics
set via `b.SetBytes` / `b.ReportMetric`:

```
BenchmarkExporterPushTraces_EndToEnd-8   1234   987654 ns/op   1234567 spans/sec   234567 B/op   1234 allocs/op
```

**Guardrails to watch when profiling the exporter for pipeline fitness:**

- `spans/sec` should sit well above the Collector's incoming rate at
  peak — otherwise the exporter is the bottleneck.
- `allocs/op` on `BenchmarkTracesSerialization` should be small and
  roughly *flat* across batch sizes in `BenchmarkTracesBatchSizeScaling`.
  A super-linear growth curve is a red flag for per-span allocation.
- `B/op` on the end-to-end benchmark ≈ payload size + a small constant.
  Growth beyond that suggests the HTTP client is copying the body
  unnecessarily.
- `Parallel` throughput should scale near-linearly with GOMAXPROCS on a
  loopback backend. Sublinear scaling implies lock contention (mutex on
  the client, DNS cache, etc.).

## Regression detection (`scripts/bench.sh`)

`scripts/bench.sh` runs the benchmark suite, saves results to
`benchmarks/current.txt`, and diffs against `benchmarks/baseline.txt` using
`benchstat`. It exits non-zero if any benchmark's `sec/op`, `B/op`, or
`allocs/op` regresses beyond the threshold **with statistical significance**
(rows benchstat marks `~` are ignored).

```bash
# Standard PR check — uses defaults (count=6, benchtime=3s, threshold=5%).
make bench

# Fast local iteration — non-fatal, wider threshold.
make bench-quick

# Refresh the baseline (run this on `main` only, after intentional perf work).
make bench-update
git add benchmarks/baseline.txt
git commit -m "bench: refresh baseline after <change>"

# CI-style run with strict 5% threshold.
make bench-ci
```

Flags accepted by `scripts/bench.sh`:

| Flag | Default | Purpose |
|---|---|---|
| `--baseline PATH`      | `benchmarks/baseline.txt` | Baseline file to diff against. |
| `--results PATH`       | `benchmarks/current.txt`  | Where to save this run. |
| `--config PATH`        | `benchmarks/bench.yml`    | Per-metric thresholds + overrides + ignore-list. |
| `--count N`            | `6`  | `go test -count` (statistical power). |
| `--time DUR`           | `3s` | `go test -benchtime`. |
| `--pattern REGEX`      | `.`  | `go test -bench` filter. |
| `--package PKG`        | `./exporter` | Package(s) to bench. |
| `--threshold PCT`      | —    | Legacy: applies to all three metrics. |
| `--threshold-time PCT`   | `5%` (via config)  | Latency threshold. |
| `--threshold-bytes PCT`  | `10%` (via config) | Bytes/op threshold. |
| `--threshold-allocs PCT` | `5%` (via config)  | Allocs/op threshold. |
| `--json PATH`          | `benchmarks/regressions.json` | Machine-readable summary. |
| `--md PATH`            | `benchmarks/regressions.md`   | Markdown summary for PR comments. |
| `--update-baseline`    | —    | Overwrite baseline with current results. |
| `--no-fail`            | —    | Report regressions but exit 0 (for advisory mode). |

### Per-metric thresholds and per-benchmark overrides

`benchmarks/bench.yml` controls what counts as a regression. The default
file ships tight thresholds on the hot path and looser bands on inherently
noisy benchmarks:

```yaml
thresholds:
  sec/op: 5      # latency — strictest
  B/op: 10       # bytes/op — more headroom for GC-pool churn
  allocs/op: 5   # allocs/op — controls tail latency

overrides:
  - name: "^Benchmark(Traces)?Serialization"   # hot path — tighter
    sec/op: 3
    allocs/op: 3
  - name: "Parallel$"                          # noisier — wider
    sec/op: 10
    B/op: 15
  - name: "BatchSizeScaling"                   # informational
    sec/op: 8

ignore: []                                     # regexes to skip entirely
```

### Environment drift detection

Every results file is prefixed with a header that captures
`git.commit`, `host`, `cpu.model`, `cpu.count`, `go`, `gomaxprocs`, and
`ci`. The detector compares baseline vs current and warns when any of
`host`, `go`, `gomaxprocs`, or `cpu.model` differs — those changes
invalidate the baseline as a comparison target and typically warrant a
refresh. The drift shows up as `⚠️` markers in the PR-comment env table.

### Machine-readable output

`regressions.json` is emitted on every run:

```json
{
  "verdict": "regression",
  "regression_count": 5,
  "thresholds": {"sec/op": 5.0, "B/op": 10.0, "allocs/op": 5.0},
  "baseline_meta": {"git.commit": "abc1234", ...},
  "current_meta":  {"git.commit": "def5678", ...},
  "env_drift_keys": [],
  "rows": [
    {"section":"sec/op","name":"BenchmarkTracesSerialization-8",
     "delta":6.6,"sig":"p=0.002 n=6","threshold":3.0,"is_regression":true}
  ]
}
```

Drop this into any dashboard, badge generator, or bot pipeline downstream.

### Exit codes

- `0` — no significant regression above threshold.
- `1` — regression detected, or the benchmark run itself failed.
- `2` — usage / environment error (missing `go`, bad flag).

### GitHub Actions integration

`.github/workflows/bench.yml` runs `scripts/bench.sh` on every PR that
touches `exporter/`, `internal/`, `go.mod`, `go.sum`, `scripts/bench.sh`, or
the baseline file itself. It:

1. Runs 8 iterations of each benchmark on a 4-core runner.
2. Uploads `current.txt`, `baseline.txt`, and the full log as artifacts.
3. Posts (or updates) a PR comment with the `benchstat` table and the
   pass/fail verdict.
4. Fails the check on any statistically significant regression ≥ 5%.

### Baseline refresh workflow

The baseline is checked into git so every PR has a deterministic reference
and CI needs no external storage. Refresh it only on `main`, only after an
intentional performance change, and use higher `--count`/`--time` than a
normal PR run so the recorded numbers are stable:

```bash
git checkout main && git pull
./scripts/bench.sh --update-baseline --count 10 --time 5s
git add benchmarks/baseline.txt
git commit -m "bench: refresh baseline after <change>"
```

Hardware changes on CI runners will require a refresh — that's intentional,
not a bug: it forces you to re-establish the performance floor whenever the
measurement platform moves.

### Tuning knobs exposed to the benchmarks

- `benchSpansPerBatch` (default `1000`) — primary batch size.
- `benchAttrsPerSpan` / `benchResourceAttrs` — payload width.
- `clientCfg.Compression` — set to `"gzip"` in the benchmark file to
  compare CPU-vs-bandwidth trade-off.
- `clientCfg.MaxIdleConnsPerHost` — already bumped in the parallel
  benchmark to prevent keep-alive starvation.

The mock server binds to `127.0.0.1` on a random port chosen by
`httptest.NewServer`, so the suite is safe to run in CI in parallel.

## Design notes

- **HTTP/1.1**: `httptest.NewServer` (unlike `NewTLSServer` with HTTP/2
  negotiation) serves HTTP/1.1, matching the OTLP/HTTP wire spec assertion in
  the test.
- **Teardown**: both the mock server and the exporter register their shutdown
  via `t.Cleanup`, so even panics/failures don't leak goroutines or sockets.
- **Compression**: explicitly set to `""` so the mock can decode raw protobuf
  without a gzip step. Flip it to `"gzip"` and add a `gzip.NewReader` in the
  mock to exercise that path.
- **Retry/queue**: this exporter is intentionally minimal. Wrap
  `pushTraces` with `exporterhelper.WithRetry` /`WithQueue` if you want to
  test those; the `PropagatesServerErrors` test already produces retryable
  failures.
