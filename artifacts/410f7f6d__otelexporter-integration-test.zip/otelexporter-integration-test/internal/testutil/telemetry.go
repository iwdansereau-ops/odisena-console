package testutil

import (
	"time"

	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/ptrace"
)

// TestTelemetry builds deterministic trace fixtures for exporter tests.
type TestTelemetry struct {
	ServiceName    string
	ServiceVersion string
	Now            time.Time
}

// NewTestTelemetry returns a TestTelemetry with sensible defaults.
func NewTestTelemetry() *TestTelemetry {
	return &TestTelemetry{
		ServiceName:    "integration-test-service",
		ServiceVersion: "1.2.3",
		Now:            time.Date(2026, 7, 2, 12, 0, 0, 0, time.UTC),
	}
}

// SpanSpec describes a single span to produce.
type SpanSpec struct {
	Name       string
	Kind       ptrace.SpanKind
	Attributes map[string]any
	DurationMS int64
	StatusCode ptrace.StatusCode
}

// BuildTraces builds a ptrace.Traces containing one ResourceSpans / one
// ScopeSpans populated with the provided spans and service metadata.
func (tt *TestTelemetry) BuildTraces(scope string, specs ...SpanSpec) ptrace.Traces {
	td := ptrace.NewTraces()
	rs := td.ResourceSpans().AppendEmpty()

	// Resource attributes: service.name / service.version + host.
	rattrs := rs.Resource().Attributes()
	rattrs.PutStr("service.name", tt.ServiceName)
	rattrs.PutStr("service.version", tt.ServiceVersion)
	rattrs.PutStr("host.name", "test-host-01")
	rattrs.PutStr("deployment.environment", "integration-test")

	ss := rs.ScopeSpans().AppendEmpty()
	ss.Scope().SetName(scope)
	ss.Scope().SetVersion("v0.0.1")

	traceID := pcommon.TraceID([16]byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
		0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10})

	for i, spec := range specs {
		span := ss.Spans().AppendEmpty()
		span.SetTraceID(traceID)

		var spanID pcommon.SpanID
		spanID[0] = byte(i + 1)
		spanID[7] = 0xff
		span.SetSpanID(spanID)

		span.SetName(spec.Name)
		if spec.Kind == ptrace.SpanKindUnspecified {
			span.SetKind(ptrace.SpanKindInternal)
		} else {
			span.SetKind(spec.Kind)
		}

		start := tt.Now.Add(time.Duration(i) * time.Millisecond)
		dur := time.Duration(spec.DurationMS) * time.Millisecond
		if dur == 0 {
			dur = 10 * time.Millisecond
		}
		span.SetStartTimestamp(pcommon.NewTimestampFromTime(start))
		span.SetEndTimestamp(pcommon.NewTimestampFromTime(start.Add(dur)))

		for k, v := range spec.Attributes {
			putAny(span.Attributes(), k, v)
		}

		if spec.StatusCode != ptrace.StatusCodeUnset {
			span.Status().SetCode(spec.StatusCode)
		}
	}

	return td
}

// DefaultTraces returns a small representative Traces payload: two spans,
// one server + one internal, with mixed attribute types.
func (tt *TestTelemetry) DefaultTraces() ptrace.Traces {
	return tt.BuildTraces("test-scope",
		SpanSpec{
			Name: "GET /api/orders",
			Kind: ptrace.SpanKindServer,
			Attributes: map[string]any{
				"http.method":      "GET",
				"http.route":       "/api/orders",
				"http.status_code": int64(200),
				"net.peer.ip":      "10.0.0.42",
			},
			DurationMS: 25,
			StatusCode: ptrace.StatusCodeOk,
		},
		SpanSpec{
			Name: "db.query",
			Kind: ptrace.SpanKindClient,
			Attributes: map[string]any{
				"db.system":    "postgresql",
				"db.statement": "SELECT * FROM orders WHERE id = $1",
				"db.rows":      int64(1),
				"cache.hit":    false,
			},
			DurationMS: 8,
			StatusCode: ptrace.StatusCodeOk,
		},
	)
}

func putAny(m pcommon.Map, k string, v any) {
	switch val := v.(type) {
	case string:
		m.PutStr(k, val)
	case int:
		m.PutInt(k, int64(val))
	case int64:
		m.PutInt(k, val)
	case float64:
		m.PutDouble(k, val)
	case bool:
		m.PutBool(k, val)
	default:
		m.PutStr(k, "unsupported")
	}
}
