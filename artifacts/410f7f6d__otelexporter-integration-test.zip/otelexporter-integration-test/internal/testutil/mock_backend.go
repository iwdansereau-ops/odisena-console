// Package testutil provides shared helpers for exporter integration tests:
// a mock OTLP/HTTP backend (httptest.Server) and TestTelemetry fixtures.
package testutil

import (
	"io"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"

	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"go.opentelemetry.io/collector/pdata/ptrace/ptraceotlp"
)

// ReceivedRequest captures a single OTLP/HTTP request received by the mock.
type ReceivedRequest struct {
	Method      string
	Path        string
	ContentType string
	UserAgent   string
	Proto       string // e.g. "HTTP/1.1"
	Traces      ptrace.Traces
	RawBody     []byte
}

// MockOTLPBackend is an httptest.Server that decodes OTLP/HTTP protobuf trace
// requests and records them for assertions. It is safe for concurrent use.
type MockOTLPBackend struct {
	t       testing.TB
	Server  *httptest.Server
	Path    string
	mu      sync.Mutex
	reqs    []ReceivedRequest
	failOn  int    // if > 0, first N requests return 500 (for retry tests)
	failed  int    // counter of failure responses served
	respond []byte // optional response body
}

// NewMockOTLPBackend spins up an HTTP/1.1 httptest.Server on 127.0.0.1 that
// accepts POSTs to `/v1/traces` and decodes OTLP protobuf ExportRequests.
// The server is registered with t.Cleanup for automatic teardown.
func NewMockOTLPBackend(t testing.TB) *MockOTLPBackend {
	t.Helper()
	m := &MockOTLPBackend{
		t:    t,
		Path: "/v1/traces",
	}

	mux := http.NewServeMux()
	mux.HandleFunc(m.Path, m.handleTraces)
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		http.Error(w, "not found: "+r.URL.Path, http.StatusNotFound)
	})

	// httptest.NewServer serves HTTP/1.1 (no TLS/HTTP2 upgrade).
	m.Server = httptest.NewServer(mux)

	t.Cleanup(func() {
		m.Server.Close()
	})

	return m
}

// URL returns the base URL of the mock server (scheme://host:port).
func (m *MockOTLPBackend) URL() string {
	return m.Server.URL
}

// FailNextN forces the mock to respond 500 to the next n requests. Useful for
// exercising retry paths. Must be called before the exporter sends.
func (m *MockOTLPBackend) FailNextN(n int) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.failOn = n
}

// Requests returns a copy of all requests received so far.
func (m *MockOTLPBackend) Requests() []ReceivedRequest {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := make([]ReceivedRequest, len(m.reqs))
	copy(out, m.reqs)
	return out
}

// Len returns the number of requests received so far.
func (m *MockOTLPBackend) Len() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.reqs)
}

func (m *MockOTLPBackend) handleTraces(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "read body: "+err.Error(), http.StatusBadRequest)
		return
	}
	defer r.Body.Close()

	// Serve configured failures first.
	m.mu.Lock()
	if m.failed < m.failOn {
		m.failed++
		m.mu.Unlock()
		http.Error(w, "injected failure", http.StatusInternalServerError)
		return
	}
	m.mu.Unlock()

	req := ptraceotlp.NewExportRequest()
	if err := req.UnmarshalProto(body); err != nil {
		http.Error(w, "unmarshal proto: "+err.Error(), http.StatusBadRequest)
		return
	}

	rec := ReceivedRequest{
		Method:      r.Method,
		Path:        r.URL.Path,
		ContentType: r.Header.Get("Content-Type"),
		UserAgent:   r.Header.Get("User-Agent"),
		Proto:       r.Proto,
		Traces:      req.Traces(),
		RawBody:     body,
	}

	m.mu.Lock()
	m.reqs = append(m.reqs, rec)
	m.mu.Unlock()

	// Success response: empty ExportTraceServiceResponse protobuf.
	resp := ptraceotlp.NewExportResponse()
	respBytes, err := resp.MarshalProto()
	require.NoError(m.t, err)
	w.Header().Set("Content-Type", "application/x-protobuf")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(respBytes)
}
