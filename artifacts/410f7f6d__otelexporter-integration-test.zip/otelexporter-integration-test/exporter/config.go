package customotlpexporter

import (
	"errors"
	"net/url"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/config/confighttp"
)

// Config defines the configuration for the custom OTLP/HTTP traces exporter.
type Config struct {
	confighttp.ClientConfig `mapstructure:",squash"`

	// TracesURLPath is the path appended to the endpoint for trace export.
	// Defaults to "/v1/traces" if unset.
	TracesURLPath string `mapstructure:"traces_url_path"`
}

var _ component.Config = (*Config)(nil)

// Validate ensures required fields are present and well-formed.
func (c *Config) Validate() error {
	if c.Endpoint == "" {
		return errors.New("endpoint must be non-empty")
	}
	if _, err := url.Parse(c.Endpoint); err != nil {
		return err
	}
	return nil
}
