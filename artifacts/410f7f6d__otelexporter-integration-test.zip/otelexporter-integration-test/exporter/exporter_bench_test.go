package customotlpexporter_test

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/collector/component/componenttest"
	"go.opentelemetry.io/collector/config/confighttp"
	"go.opentelemetry.io/collector/exporter/exportertest"
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"go.opentelemetry.io/collector/pdata/ptrace/ptraceotlp"

	customotlp "github.com/example/customotlpexporter/exporter"
)

// Benchmark constants — high-throughput scenario.
const (
	benchSpansPerBatch  = 1000
	benchAttrsPerSpan   = 8
	benchResourceAttrs  = 6
	benchScopeName      = "bench-scope"
	benchServiceName    = "bench-service"
	benchServiceVersion = "9.9.9"
)

// buildBenchTraces produces a ptrace.Traces containing exactly
// spansPerBatch spans across one ResourceSpans / one ScopeSpans, with a
// realistic mix of attribute types. It intentionally avoids the testutil
// helpers to keep allocations tight and predictable for benchmarking.
func buildBenchTraces(spansPerBatch int) ptrace.Traces {
	td := ptrace.NewTraces()
	rs := td.ResourceSpans().AppendEmpty()

	rattrs := rs.Resource().Attributes()
	rattrs.EnsureCapacity(benchResourceAttrs)
	rattrs.PutStr("service.name", benchServiceName)
	rattrs.PutStr("service.version", benchServiceVersion)
	rattrs.PutStr("host.name", "bench-host-01")
	rattrs.PutStr("deployment.environment", "benchmark")
	rattrs.PutStr("cloud.provider", "aws")
	rattrs.PutStr("cloud.region", "us-east-1")

	ss := rs.ScopeSpans().AppendEmpty()
	ss.Scope().SetName(benchScopeName)
	ss.Scope().SetVersion("v1.0.0")

	spans := ss.Spans()
	spans.EnsureCapacity(spansPerBatch)

	traceID := pcommon.TraceID([16]byte{
		0xa1, 0xb2, 0xc3, 0xd4, 0xe5, 0xf6, 0x07, 0x18,
		0x29, 0x3a, 0x4b, 0x5c, 0x6d, 0x7e, 0x8f, 0x90,
	})
	start := time.Date(2026, 7, 2, 12, 0, 0, 0, time.UTC)

	for i := 0; i < spansPerBatch; i++ {
		s := spans.AppendEmpty()
		s.SetTraceID(traceID)

		var spanID pcommon.SpanID
		// Deterministic 8-byte span id derived from i.
		spanID[0] = byte(i)
		spanID[1] = byte(i >> 8)
		spanID[2] = byte(i >> 16)
		spanID[3] = byte(i >> 24)
		spanID[7] = 0xff
		s.SetSpanID(spanID)

		s.SetName(fmt.Sprintf("op-%d", i%64)) // limited cardinality, realistic
		s.SetKind(ptrace.SpanKindServer)

		spanStart := start.Add(time.Duration(i) * time.Microsecond)
		s.SetStartTimestamp(pcommon.NewTimestampFromTime(spanStart))
		s.SetEndTimestamp(pcommon.NewTimestampFromTime(spanStart.Add(2 * time.Millisecond)))

		attrs := s.Attributes()
		attrs.EnsureCapacity(benchAttrsPerSpan)
		attrs.PutStr("http.method", "GET")
		attrs.PutStr("http.route", "/api/v1/resource")
		attrs.PutInt("http.status_code", 200)
		attrs.PutStr("http.scheme", "https")
		attrs.PutStr("net.peer.ip", "10.0.0.42")
		attrs.PutInt("net.peer.port", 8443)
		attrs.PutBool("http.request.cached", i%3 == 0)
		attrs.PutDouble("http.request.duration_ms", 2.0+float64(i%17)*0.1)

		s.Status().SetCode(ptrace.StatusCodeOk)
	}
	return td
}

// BenchmarkTracesTranslation measures the cost of building an OTLP
// ExportRequest wrapper around a ptrace.Traces. This is the "translation"
// half of the export path — no bytes are emitted yet.
//
// A high throughput exporter should keep this well under the per-batch
// budget so the Collector pipeline is not CPU-bound in translation.
func BenchmarkTracesTranslation(b *testing.B) {
	td := buildBenchTraces(benchSpansPerBatch)

	b.ReportAllocs()
	b.SetBytes(int64(td.SpanCount())) // reports "spans/sec" via -benchmem output
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		req := ptraceotlp.NewExportRequestFromTraces(td)
		// Prevent the compiler from eliminating the call.
		if req.Traces().SpanCount() != benchSpansPerBatch {
			b.Fatal("unexpected span count")
		}
	}
}

// BenchmarkTracesSerialization measures the marshal-to-protobuf cost
// (the "serialization" half). This is typically the single largest
// CPU consumer on the exporter hot path.
func BenchmarkTracesSerialization(b *testing.B) {
	td := buildBenchTraces(benchSpansPerBatch)
	req := ptraceotlp.NewExportRequestFromTraces(td)

	// Prime once to report payload size in the benchmark output.
	primed, err := req.MarshalProto()
	require.NoError(b, err)
	b.Logf("serialized payload size: %d bytes (%d spans, ~%.1f B/span)",
		len(primed), benchSpansPerBatch, float64(len(primed))/float64(benchSpansPerBatch))

	b.ReportAllocs()
	b.SetBytes(int64(len(primed)))
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		out, err := req.MarshalProto()
		if err != nil {
			b.Fatal(err)
		}
		if len(out) == 0 {
			b.Fatal("empty payload")
		}
	}
}

// BenchmarkTracesTranslateAndSerialize covers both stages back-to-back —
// the work the exporter must do on every batch before any network I/O.
func BenchmarkTracesTranslateAndSerialize(b *testing.B) {
	td := buildBenchTraces(benchSpansPerBatch)

	b.ReportAllocs()
	b.SetBytes(int64(td.SpanCount()))
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		req := ptraceotlp.NewExportRequestFromTraces(td)
		out, err := req.MarshalProto()
		if err != nil {
			b.Fatal(err)
		}
		if len(out) == 0 {
			b.Fatal("empty payload")
		}
	}
}

// BenchmarkExporterPushTraces_EndToEnd measures the full exporter path
// (translate + marshal + HTTP/1.1 POST + response drain) against a
// zero-cost httptest.Server that discards the body. This isolates
// *exporter* overhead from *backend* processing and answers the core
// question: "does the exporter itself bottleneck the Collector under
// 1000-span batches?"
func BenchmarkExporterPushTraces_EndToEnd(b *testing.B) {
	// Fast-path mock: discard body, return 200 immediately. This keeps the
	// backend out of the measurement so we only pay for exporter work +
	// loopback HTTP/1.1 framing.
	var received int64
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = io.Copy(io.Discard, r.Body)
		_ = r.Body.Close()
		atomic.AddInt64(&received, 1)
		w.WriteHeader(http.StatusOK)
	}))
	b.Cleanup(srv.Close)

	factory := customotlp.NewFactory()
	cfg := factory.CreateDefaultConfig().(*customotlp.Config)
	clientCfg := confighttp.NewDefaultClientConfig()
	clientCfg.Endpoint = srv.URL
	clientCfg.Timeout = 10 * time.Second
	clientCfg.Compression = "" // measure raw serialization; flip to "gzip" to bench that path
	cfg.ClientConfig = clientCfg
	cfg.TracesURLPath = "/v1/traces"
	require.NoError(b, cfg.Validate())

	ctx := context.Background()
	exp, err := factory.CreateTracesExporter(ctx, exportertest.NewNopSettings(), cfg)
	require.NoError(b, err)
	require.NoError(b, exp.Start(ctx, componenttest.NewNopHost()))
	b.Cleanup(func() {
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		_ = exp.Shutdown(shutdownCtx)
	})

	td := buildBenchTraces(benchSpansPerBatch)

	b.ReportAllocs()
	b.SetBytes(int64(td.SpanCount()))
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		if err := exp.ConsumeTraces(ctx, td); err != nil {
			b.Fatal(err)
		}
	}
	b.StopTimer()

	// Sanity: every iteration must have hit the backend exactly once.
	if got := atomic.LoadInt64(&received); got != int64(b.N) {
		b.Fatalf("expected backend to receive %d requests, got %d", b.N, got)
	}
	b.ReportMetric(float64(benchSpansPerBatch*b.N)/b.Elapsed().Seconds(), "spans/sec")
}

// BenchmarkExporterPushTraces_Parallel simulates a high-concurrency
// producer (multiple Collector pipeline workers hitting the exporter
// simultaneously) to catch contention or lock-based bottlenecks.
func BenchmarkExporterPushTraces_Parallel(b *testing.B) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = io.Copy(io.Discard, r.Body)
		_ = r.Body.Close()
		w.WriteHeader(http.StatusOK)
	}))
	b.Cleanup(srv.Close)

	factory := customotlp.NewFactory()
	cfg := factory.CreateDefaultConfig().(*customotlp.Config)
	clientCfg := confighttp.NewDefaultClientConfig()
	clientCfg.Endpoint = srv.URL
	clientCfg.Timeout = 10 * time.Second
	clientCfg.Compression = ""
	// Larger connection pool so parallelism isn't gated by keep-alive limits.
	clientCfg.MaxIdleConns = 200
	clientCfg.MaxIdleConnsPerHost = 200
	cfg.ClientConfig = clientCfg
	cfg.TracesURLPath = "/v1/traces"
	require.NoError(b, cfg.Validate())

	ctx := context.Background()
	exp, err := factory.CreateTracesExporter(ctx, exportertest.NewNopSettings(), cfg)
	require.NoError(b, err)
	require.NoError(b, exp.Start(ctx, componenttest.NewNopHost()))
	b.Cleanup(func() { _ = exp.Shutdown(context.Background()) })

	td := buildBenchTraces(benchSpansPerBatch)

	b.ReportAllocs()
	b.SetBytes(int64(td.SpanCount()))
	b.ResetTimer()

	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			if err := exp.ConsumeTraces(ctx, td); err != nil {
				b.Fatal(err)
			}
		}
	})
	b.StopTimer()

	b.ReportMetric(float64(benchSpansPerBatch*b.N)/b.Elapsed().Seconds(), "spans/sec")
}

// BenchmarkTracesBatchSizeScaling sweeps the batch size to show how
// per-span cost scales. Useful for choosing an optimal batch size in the
// batchprocessor upstream of this exporter.
func BenchmarkTracesBatchSizeScaling(b *testing.B) {
	for _, n := range []int{100, 500, 1000, 2500, 5000} {
		n := n
		b.Run(fmt.Sprintf("spans=%d", n), func(b *testing.B) {
			td := buildBenchTraces(n)
			b.ReportAllocs()
			b.SetBytes(int64(n))
			b.ResetTimer()

			for i := 0; i < b.N; i++ {
				req := ptraceotlp.NewExportRequestFromTraces(td)
				out, err := req.MarshalProto()
				if err != nil {
					b.Fatal(err)
				}
				if len(out) == 0 {
					b.Fatal("empty payload")
				}
			}
		})
	}
}

// buildBenchTracesWithAttrs is a variant of buildBenchTraces that lets you
// dial the attribute count per span. Used by the attribute-width sweep.
func buildBenchTracesWithAttrs(spansPerBatch, attrsPerSpan int) ptrace.Traces {
	td := ptrace.NewTraces()
	rs := td.ResourceSpans().AppendEmpty()
	rattrs := rs.Resource().Attributes()
	rattrs.PutStr("service.name", benchServiceName)
	rattrs.PutStr("service.version", benchServiceVersion)

	ss := rs.ScopeSpans().AppendEmpty()
	ss.Scope().SetName(benchScopeName)

	spans := ss.Spans()
	spans.EnsureCapacity(spansPerBatch)
	traceID := pcommon.TraceID([16]byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16})
	start := time.Date(2026, 7, 2, 12, 0, 0, 0, time.UTC)

	for i := 0; i < spansPerBatch; i++ {
		s := spans.AppendEmpty()
		s.SetTraceID(traceID)
		var spanID pcommon.SpanID
		spanID[0] = byte(i)
		spanID[7] = 0xff
		s.SetSpanID(spanID)
		s.SetName("op")
		s.SetKind(ptrace.SpanKindServer)
		s.SetStartTimestamp(pcommon.NewTimestampFromTime(start))
		s.SetEndTimestamp(pcommon.NewTimestampFromTime(start.Add(time.Millisecond)))

		a := s.Attributes()
		a.EnsureCapacity(attrsPerSpan)
		for j := 0; j < attrsPerSpan; j++ {
			a.PutStr(fmt.Sprintf("attr.%d", j), "value")
		}
	}
	return td
}

// BenchmarkTracesAttributeWidthScaling shows how per-span cost scales with
// attribute count — useful for policy decisions on tag cardinality upstream.
func BenchmarkTracesAttributeWidthScaling(b *testing.B) {
	for _, attrs := range []int{0, 4, 8, 16, 32, 64} {
		attrs := attrs
		b.Run(fmt.Sprintf("attrs=%d", attrs), func(b *testing.B) {
			td := buildBenchTracesWithAttrs(benchSpansPerBatch, attrs)
			b.ReportAllocs()
			b.SetBytes(int64(benchSpansPerBatch))
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				req := ptraceotlp.NewExportRequestFromTraces(td)
				out, err := req.MarshalProto()
				if err != nil {
					b.Fatal(err)
				}
				if len(out) == 0 {
					b.Fatal("empty payload")
				}
			}
		})
	}
}

// BenchmarkExporterPushTraces_Gzip mirrors the end-to-end benchmark but
// enables gzip compression on the HTTP client, quantifying the CPU cost of
// compression against the bandwidth savings. Compare bytes-on-wire against
// BenchmarkExporterPushTraces_EndToEnd to reason about the tradeoff.
func BenchmarkExporterPushTraces_Gzip(b *testing.B) {
	var bytesReceived int64
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		n, _ := io.Copy(io.Discard, r.Body)
		atomic.AddInt64(&bytesReceived, n)
		_ = r.Body.Close()
		w.WriteHeader(http.StatusOK)
	}))
	b.Cleanup(srv.Close)

	factory := customotlp.NewFactory()
	cfg := factory.CreateDefaultConfig().(*customotlp.Config)
	clientCfg := confighttp.NewDefaultClientConfig()
	clientCfg.Endpoint = srv.URL
	clientCfg.Timeout = 10 * time.Second
	clientCfg.Compression = "gzip"
	cfg.ClientConfig = clientCfg
	cfg.TracesURLPath = "/v1/traces"
	require.NoError(b, cfg.Validate())

	ctx := context.Background()
	exp, err := factory.CreateTracesExporter(ctx, exportertest.NewNopSettings(), cfg)
	require.NoError(b, err)
	require.NoError(b, exp.Start(ctx, componenttest.NewNopHost()))
	b.Cleanup(func() { _ = exp.Shutdown(context.Background()) })

	td := buildBenchTraces(benchSpansPerBatch)

	b.ReportAllocs()
	b.SetBytes(int64(td.SpanCount()))
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		if err := exp.ConsumeTraces(ctx, td); err != nil {
			b.Fatal(err)
		}
	}
	b.StopTimer()

	if b.N > 0 {
		avgBytes := float64(atomic.LoadInt64(&bytesReceived)) / float64(b.N)
		b.ReportMetric(avgBytes, "wire-B/op")
	}
	b.ReportMetric(float64(benchSpansPerBatch*b.N)/b.Elapsed().Seconds(), "spans/sec")
}
