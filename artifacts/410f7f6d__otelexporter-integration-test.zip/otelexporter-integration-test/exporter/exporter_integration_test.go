package customotlpexporter_test

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/collector/component/componenttest"
	"go.opentelemetry.io/collector/config/confighttp"
	"go.opentelemetry.io/collector/exporter/exportertest"
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/ptrace"

	customotlp "github.com/example/customotlpexporter/exporter"
	"github.com/example/customotlpexporter/internal/testutil"
)

// TestCustomOTLPExporter_ForwardsTracesOverHTTP is the primary integration
// test. It exercises the full path:
//
//	Collector pipeline -> custom exporter -> OTLP protobuf marshal ->
//	HTTP/1.1 POST -> httptest.Server mock backend -> proto unmarshal.
//
// It then asserts on the payload observed at the backend, including service
// name, span attributes, and structural properties of the request.
func TestCustomOTLPExporter_ForwardsTracesOverHTTP(t *testing.T) {
	// --- 1. Mock backend --------------------------------------------------
	backend := testutil.NewMockOTLPBackend(t)
	t.Logf("mock OTLP backend listening at %s", backend.URL())

	// --- 2. Collector test configuration ---------------------------------
	// Build a Config that points the custom exporter at the mock server.
	// This is the equivalent of the following YAML:
	//
	//     exporters:
	//       customotlp:
	//         endpoint: http://127.0.0.1:PORT
	//         traces_url_path: /v1/traces
	//         timeout: 5s
	//         compression: ""       # disable gzip so the mock can decode raw proto
	factory := customotlp.NewFactory()
	cfg := factory.CreateDefaultConfig().(*customotlp.Config)

	clientCfg := confighttp.NewDefaultClientConfig()
	clientCfg.Endpoint = backend.URL()
	clientCfg.Timeout = 5 * time.Second
	clientCfg.Compression = "" // ensure body is raw protobuf
	cfg.ClientConfig = clientCfg
	cfg.TracesURLPath = "/v1/traces"

	require.NoError(t, cfg.Validate(), "config must validate")

	// --- 3. Build the traces exporter ------------------------------------
	set := exportertest.NewNopSettings()
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	exp, err := factory.CreateTracesExporter(ctx, set, cfg)
	require.NoError(t, err, "creating traces exporter")
	require.NotNil(t, exp)

	host := componenttest.NewNopHost()
	require.NoError(t, exp.Start(ctx, host), "starting exporter")

	// Guarantee cleanup even on test failure.
	t.Cleanup(func() {
		shutdownCtx, cancelShutdown := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancelShutdown()
		assert.NoError(t, exp.Shutdown(shutdownCtx), "shutting down exporter")
	})

	// --- 4. Simulate trace input via TestTelemetry -----------------------
	tt := testutil.NewTestTelemetry()
	tt.ServiceName = "checkout-service"
	tt.ServiceVersion = "4.5.6"
	td := tt.DefaultTraces()

	require.Equal(t, 2, td.SpanCount(), "test fixture should have 2 spans")

	// --- 5. Push through the exporter's ConsumeTraces path ---------------
	require.NoError(t, exp.ConsumeTraces(ctx, td), "ConsumeTraces should succeed")

	// --- 6. Wait for the request to land ---------------------------------
	require.Eventually(t, func() bool {
		return backend.Len() >= 1
	}, 3*time.Second, 10*time.Millisecond, "mock backend never received a request")

	// --- 7. Assertions on the received HTTP request ----------------------
	reqs := backend.Requests()
	require.Len(t, reqs, 1, "exactly one export request expected")
	got := reqs[0]

	t.Run("HTTP envelope", func(t *testing.T) {
		assert.Equal(t, "POST", got.Method)
		assert.Equal(t, "/v1/traces", got.Path)
		assert.Equal(t, "application/x-protobuf", got.ContentType)
		assert.Equal(t, "HTTP/1.1", got.Proto, "OTLP/HTTP must be served over HTTP/1.1")
		assert.Contains(t, got.UserAgent, "customotlp-exporter", "custom UA header must be forwarded")
		assert.NotEmpty(t, got.RawBody, "protobuf body must be present")
	})

	t.Run("payload structure", func(t *testing.T) {
		traces := got.Traces
		require.Equal(t, 1, traces.ResourceSpans().Len(), "one resource")
		rs := traces.ResourceSpans().At(0)

		require.Equal(t, 1, rs.ScopeSpans().Len(), "one scope")
		ss := rs.ScopeSpans().At(0)

		assert.Equal(t, "test-scope", ss.Scope().Name())
		assert.Equal(t, "v0.0.1", ss.Scope().Version())
		require.Equal(t, 2, ss.Spans().Len(), "two spans forwarded")
	})

	t.Run("service resource attributes", func(t *testing.T) {
		rs := got.Traces.ResourceSpans().At(0)
		svcName, ok := rs.Resource().Attributes().Get("service.name")
		require.True(t, ok, "service.name resource attribute must be present")
		assert.Equal(t, "checkout-service", svcName.Str())

		svcVer, ok := rs.Resource().Attributes().Get("service.version")
		require.True(t, ok)
		assert.Equal(t, "4.5.6", svcVer.Str())

		env, ok := rs.Resource().Attributes().Get("deployment.environment")
		require.True(t, ok)
		assert.Equal(t, "integration-test", env.Str())
	})

	t.Run("server span attributes", func(t *testing.T) {
		spans := got.Traces.ResourceSpans().At(0).ScopeSpans().At(0).Spans()
		serverSpan := findSpanByName(t, spans, "GET /api/orders")

		assert.Equal(t, ptrace.SpanKindServer, serverSpan.Kind())
		assert.Equal(t, ptrace.StatusCodeOk, serverSpan.Status().Code())

		assertStrAttr(t, serverSpan.Attributes(), "http.method", "GET")
		assertStrAttr(t, serverSpan.Attributes(), "http.route", "/api/orders")
		assertIntAttr(t, serverSpan.Attributes(), "http.status_code", 200)
		assertStrAttr(t, serverSpan.Attributes(), "net.peer.ip", "10.0.0.42")

		// Non-zero IDs prove the exporter did not drop identity.
		assert.NotEqual(t, pcommon.TraceID{}, serverSpan.TraceID(),
			"TraceID must be preserved through marshal/unmarshal")
		assert.NotEqual(t, pcommon.SpanID{}, serverSpan.SpanID(),
			"SpanID must be preserved through marshal/unmarshal")
	})

	t.Run("client db span attributes", func(t *testing.T) {
		spans := got.Traces.ResourceSpans().At(0).ScopeSpans().At(0).Spans()
		dbSpan := findSpanByName(t, spans, "db.query")

		assert.Equal(t, ptrace.SpanKindClient, dbSpan.Kind())
		assertStrAttr(t, dbSpan.Attributes(), "db.system", "postgresql")
		assertStrAttr(t, dbSpan.Attributes(), "db.statement",
			"SELECT * FROM orders WHERE id = $1")
		assertIntAttr(t, dbSpan.Attributes(), "db.rows", 1)
		assertBoolAttr(t, dbSpan.Attributes(), "cache.hit", false)
	})

	t.Run("timing preserved", func(t *testing.T) {
		spans := got.Traces.ResourceSpans().At(0).ScopeSpans().At(0).Spans()
		for i := 0; i < spans.Len(); i++ {
			s := spans.At(i)
			assert.True(t, s.EndTimestamp() > s.StartTimestamp(),
				"span %q must have end > start", s.Name())
		}
	})
}

// TestCustomOTLPExporter_RejectsBadEndpoint validates config validation.
func TestCustomOTLPExporter_RejectsBadEndpoint(t *testing.T) {
	factory := customotlp.NewFactory()
	cfg := factory.CreateDefaultConfig().(*customotlp.Config)
	// Endpoint left empty.
	require.Error(t, cfg.Validate(), "empty endpoint must fail validation")
}

// TestCustomOTLPExporter_PropagatesServerErrors ensures a 5xx from the backend
// surfaces as an error to the pipeline (so retry/queue can react).
func TestCustomOTLPExporter_PropagatesServerErrors(t *testing.T) {
	backend := testutil.NewMockOTLPBackend(t)
	backend.FailNextN(1) // force a single 500 before success

	factory := customotlp.NewFactory()
	cfg := factory.CreateDefaultConfig().(*customotlp.Config)
	clientCfg := confighttp.NewDefaultClientConfig()
	clientCfg.Endpoint = backend.URL()
	clientCfg.Timeout = 2 * time.Second
	clientCfg.Compression = ""
	cfg.ClientConfig = clientCfg

	require.NoError(t, cfg.Validate())

	ctx := context.Background()
	exp, err := factory.CreateTracesExporter(ctx, exportertest.NewNopSettings(), cfg)
	require.NoError(t, err)
	require.NoError(t, exp.Start(ctx, componenttest.NewNopHost()))
	t.Cleanup(func() { _ = exp.Shutdown(context.Background()) })

	td := testutil.NewTestTelemetry().DefaultTraces()
	err = exp.ConsumeTraces(ctx, td)
	require.Error(t, err, "500 from backend must be propagated as error")
	assert.Contains(t, err.Error(), "500")
	assert.Equal(t, 0, backend.Len(),
		"failed request must not be recorded as a success")
}

// --- helpers ----------------------------------------------------------------

func findSpanByName(t *testing.T, spans ptrace.SpanSlice, name string) ptrace.Span {
	t.Helper()
	for i := 0; i < spans.Len(); i++ {
		s := spans.At(i)
		if s.Name() == name {
			return s
		}
	}
	t.Fatalf("span %q not found in received payload", name)
	return ptrace.Span{}
}

func assertStrAttr(t *testing.T, m pcommon.Map, k, want string) {
	t.Helper()
	v, ok := m.Get(k)
	require.Truef(t, ok, "attribute %q missing", k)
	assert.Equalf(t, want, v.Str(), "attribute %q string value", k)
}

func assertIntAttr(t *testing.T, m pcommon.Map, k string, want int64) {
	t.Helper()
	v, ok := m.Get(k)
	require.Truef(t, ok, "attribute %q missing", k)
	assert.Equalf(t, want, v.Int(), "attribute %q int value", k)
}

func assertBoolAttr(t *testing.T, m pcommon.Map, k string, want bool) {
	t.Helper()
	v, ok := m.Get(k)
	require.Truef(t, ok, "attribute %q missing", k)
	assert.Equalf(t, want, v.Bool(), "attribute %q bool value", k)
}
