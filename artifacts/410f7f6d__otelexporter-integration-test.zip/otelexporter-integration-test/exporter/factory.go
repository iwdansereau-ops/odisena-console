package customotlpexporter

import (
	"context"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/config/confighttp"
	"go.opentelemetry.io/collector/exporter"
	"go.opentelemetry.io/collector/exporter/exporterhelper"
)

const (
	typeStr          = "customotlp"
	defaultTracesURL = "/v1/traces"
)

// NewFactory creates a factory for the custom OTLP/HTTP traces exporter.
func NewFactory() exporter.Factory {
	return exporter.NewFactory(
		component.MustNewType(typeStr),
		createDefaultConfig,
		exporter.WithTraces(createTracesExporter, component.StabilityLevelBeta),
	)
}

func createDefaultConfig() component.Config {
	return &Config{
		ClientConfig:  confighttp.NewDefaultClientConfig(),
		TracesURLPath: defaultTracesURL,
	}
}

func createTracesExporter(
	ctx context.Context,
	set exporter.Settings,
	cfg component.Config,
) (exporter.Traces, error) {
	oCfg := cfg.(*Config)
	e := newTracesExporter(oCfg, set)

	return exporterhelper.NewTracesExporter(
		ctx,
		set,
		cfg,
		e.pushTraces,
		exporterhelper.WithStart(e.start),
		exporterhelper.WithShutdown(e.shutdown),
	)
}
