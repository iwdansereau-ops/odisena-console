package customotlpexporter

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"strings"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/exporter"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"go.opentelemetry.io/collector/pdata/ptrace/ptraceotlp"
	"go.uber.org/zap"
)

// tracesExporter is a minimal OTLP/HTTP traces exporter. It marshals
// ptrace.Traces to OTLP protobuf and POSTs it to the configured endpoint.
type tracesExporter struct {
	cfg    *Config
	set    exporter.Settings
	logger *zap.Logger
	client *http.Client
	url    string
}

func newTracesExporter(cfg *Config, set exporter.Settings) *tracesExporter {
	return &tracesExporter{
		cfg:    cfg,
		set:    set,
		logger: set.Logger,
	}
}

func (e *tracesExporter) start(ctx context.Context, host component.Host) error {
	client, err := e.cfg.ClientConfig.ToClient(ctx, host, e.set.TelemetrySettings)
	if err != nil {
		return fmt.Errorf("failed to build http client: %w", err)
	}
	e.client = client

	endpoint := strings.TrimRight(e.cfg.Endpoint, "/")
	path := e.cfg.TracesURLPath
	if path == "" {
		path = defaultTracesURL
	}
	if !strings.HasPrefix(path, "/") {
		path = "/" + path
	}
	e.url = endpoint + path

	e.logger.Info("customotlp exporter started",
		zap.String("endpoint", e.cfg.Endpoint),
		zap.String("url", e.url),
	)
	return nil
}

func (e *tracesExporter) shutdown(_ context.Context) error {
	// http.Client has no explicit close; idle conns are cleaned via transport.
	if t, ok := http.DefaultTransport.(*http.Transport); ok && e.client != nil {
		t.CloseIdleConnections()
	}
	return nil
}

func (e *tracesExporter) pushTraces(ctx context.Context, td ptrace.Traces) error {
	req := ptraceotlp.NewExportRequestFromTraces(td)
	body, err := req.MarshalProto()
	if err != nil {
		return fmt.Errorf("failed to marshal traces: %w", err)
	}

	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, e.url, bytes.NewReader(body))
	if err != nil {
		return fmt.Errorf("failed to build request: %w", err)
	}
	httpReq.Header.Set("Content-Type", "application/x-protobuf")
	httpReq.Header.Set("User-Agent", "customotlp-exporter/1.0")

	resp, err := e.client.Do(httpReq)
	if err != nil {
		return fmt.Errorf("http post failed: %w", err)
	}
	defer resp.Body.Close()

	// Drain body to allow connection reuse.
	respBody, _ := io.ReadAll(resp.Body)

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("unexpected status %d: %s", resp.StatusCode, string(respBody))
	}
	return nil
}
