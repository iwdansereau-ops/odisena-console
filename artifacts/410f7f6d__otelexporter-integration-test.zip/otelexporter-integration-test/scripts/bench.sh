#!/usr/bin/env bash
# bench.sh — run the exporter benchmark suite and compare against a baseline.
#
# Usage:
#   scripts/bench.sh                              # run + compare against baseline
#   scripts/bench.sh --update-baseline            # overwrite baseline with current
#   scripts/bench.sh --baseline path.txt          # compare against specific baseline
#   scripts/bench.sh --count 10 --time 5s         # override -count / -benchtime
#   scripts/bench.sh --pattern '^BenchmarkTraces' # bench filter regex
#   scripts/bench.sh --package ./exporter         # package(s) to bench
#   scripts/bench.sh --threshold 5                # legacy: all metrics
#   scripts/bench.sh --threshold-time 3           # per-metric thresholds
#   scripts/bench.sh --threshold-bytes 10 --threshold-allocs 5
#   scripts/bench.sh --config custom-thresholds.yml
#   scripts/bench.sh --no-fail                    # advisory mode
#
# Environment overrides (flags win over env):
#   BENCH_COUNT, BENCH_TIME, BENCH_PATTERN, BENCH_PACKAGE,
#   BENCH_BASELINE, BENCH_RESULTS, BENCH_CONFIG,
#   BENCH_THRESHOLD, BENCH_THRESHOLD_TIME, BENCH_THRESHOLD_BYTES,
#   BENCH_THRESHOLD_ALLOCS, BENCH_JSON, BENCH_MD, BENCH_NO_FAIL
#
# Exit codes:
#   0  no statistically significant regression above threshold
#   1  regression detected (or benchmarks failed to run)
#   2  usage / environment error

set -euo pipefail

# ---------- locate repo root -------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${REPO_ROOT}"

# ---------- defaults ---------------------------------------------------------
BENCH_COUNT="${BENCH_COUNT:-6}"
BENCH_TIME="${BENCH_TIME:-3s}"
BENCH_PATTERN="${BENCH_PATTERN:-.}"
BENCH_PACKAGE="${BENCH_PACKAGE:-./exporter}"
BENCH_BASELINE="${BENCH_BASELINE:-benchmarks/baseline.txt}"
BENCH_RESULTS="${BENCH_RESULTS:-benchmarks/current.txt}"
BENCH_CONFIG="${BENCH_CONFIG:-benchmarks/bench.yml}"
BENCH_JSON="${BENCH_JSON:-benchmarks/regressions.json}"
BENCH_MD="${BENCH_MD:-benchmarks/regressions.md}"
BENCH_THRESHOLD="${BENCH_THRESHOLD:-}"
BENCH_THRESHOLD_TIME="${BENCH_THRESHOLD_TIME:-}"
BENCH_THRESHOLD_BYTES="${BENCH_THRESHOLD_BYTES:-}"
BENCH_THRESHOLD_ALLOCS="${BENCH_THRESHOLD_ALLOCS:-}"
BENCH_NO_FAIL="${BENCH_NO_FAIL:-0}"
UPDATE_BASELINE=0

# ---------- flag parsing -----------------------------------------------------
usage() { sed -n '2,30p' "$0"; exit 2; }

while [[ $# -gt 0 ]]; do
  case "$1" in
    --update-baseline)   UPDATE_BASELINE=1; shift ;;
    --baseline)          BENCH_BASELINE="$2"; shift 2 ;;
    --results)           BENCH_RESULTS="$2"; shift 2 ;;
    --config)            BENCH_CONFIG="$2"; shift 2 ;;
    --count)             BENCH_COUNT="$2"; shift 2 ;;
    --time)              BENCH_TIME="$2"; shift 2 ;;
    --pattern)           BENCH_PATTERN="$2"; shift 2 ;;
    --package)           BENCH_PACKAGE="$2"; shift 2 ;;
    --threshold)         BENCH_THRESHOLD="$2"; shift 2 ;;
    --threshold-time)    BENCH_THRESHOLD_TIME="$2"; shift 2 ;;
    --threshold-bytes)   BENCH_THRESHOLD_BYTES="$2"; shift 2 ;;
    --threshold-allocs)  BENCH_THRESHOLD_ALLOCS="$2"; shift 2 ;;
    --json)              BENCH_JSON="$2"; shift 2 ;;
    --md)                BENCH_MD="$2"; shift 2 ;;
    --no-fail)           BENCH_NO_FAIL=1; shift ;;
    -h|--help)           usage ;;
    *)                   echo "unknown flag: $1" >&2; usage ;;
  esac
done

# ---------- pretty output ----------------------------------------------------
if [[ -t 1 ]]; then
  BOLD=$'\033[1m'; RED=$'\033[31m'; GRN=$'\033[32m'; YLW=$'\033[33m'; DIM=$'\033[2m'; RST=$'\033[0m'
else
  BOLD=""; RED=""; GRN=""; YLW=""; DIM=""; RST=""
fi
log()  { printf '%s==>%s %s\n' "${BOLD}" "${RST}" "$*"; }
warn() { printf '%s[warn]%s %s\n' "${YLW}" "${RST}" "$*" >&2; }
err()  { printf '%s[err]%s  %s\n' "${RED}" "${RST}" "$*" >&2; }
ok()   { printf '%s[ok]%s   %s\n' "${GRN}" "${RST}" "$*"; }

# ---------- prerequisites ----------------------------------------------------
command -v go >/dev/null      || { err "go not found in PATH"; exit 2; }
command -v python3 >/dev/null || { err "python3 not found in PATH"; exit 2; }

if ! command -v benchstat >/dev/null; then
  log "installing benchstat"
  GOBIN="${GOBIN:-$(go env GOPATH)/bin}"
  export PATH="${GOBIN}:${PATH}"
  go install golang.org/x/perf/cmd/benchstat@latest
  command -v benchstat >/dev/null || { err "benchstat install failed"; exit 2; }
fi

mkdir -p "$(dirname "${BENCH_RESULTS}")"

# ---------- hardware fingerprint --------------------------------------------
cpu_model() {
  case "$(uname -s)" in
    Linux)  grep -m1 'model name' /proc/cpuinfo 2>/dev/null | sed 's/.*: //' ;;
    Darwin) sysctl -n machdep.cpu.brand_string 2>/dev/null ;;
    *)      echo unknown ;;
  esac
}
cpu_count() {
  case "$(uname -s)" in
    Linux)  nproc 2>/dev/null || echo unknown ;;
    Darwin) sysctl -n hw.ncpu 2>/dev/null || echo unknown ;;
    *)      echo unknown ;;
  esac
}

capture_env() {
  {
    echo "# git.commit: $(git rev-parse --short HEAD 2>/dev/null || echo unknown)"
    echo "# git.branch: $(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo unknown)"
    echo "# git.dirty:  $(git status --porcelain 2>/dev/null | wc -l | tr -d ' ')"
    echo "# host:       $(uname -sm)"
    echo "# cpu.model:  $(cpu_model)"
    echo "# cpu.count:  $(cpu_count)"
    echo "# go:         $(go version)"
    echo "# gomaxprocs: $(go env GOMAXPROCS)"
    echo "# ci:         ${CI:-0}"
    echo "# date:       $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "# count:      ${BENCH_COUNT}"
    echo "# benchtime:  ${BENCH_TIME}"
    echo "# pattern:    ${BENCH_PATTERN}"
    echo "# package:    ${BENCH_PACKAGE}"
  } > "${BENCH_RESULTS}"
}

# ---------- run benchmarks ---------------------------------------------------
log "running benchmarks (${BENCH_COUNT}x, ${BENCH_TIME} each, pattern=${BENCH_PATTERN})"
log "results -> ${BENCH_RESULTS}"
capture_env

# Stability hints (informational, non-fatal).
if [[ "$(uname -s)" == "Linux" ]] && [[ -r /sys/devices/system/cpu/intel_pstate/no_turbo ]]; then
  if [[ "$(cat /sys/devices/system/cpu/intel_pstate/no_turbo)" == "0" ]]; then
    warn "CPU turbo is ON — results will have higher variance. echo 1 | sudo tee /sys/devices/system/cpu/intel_pstate/no_turbo"
  fi
fi
if [[ "${CI:-}" != "" ]]; then
  warn "detected CI — shared runners are noisy; raise --count if benchstat flags 'noisy'"
fi

# Warm build cache (not counted in bench timings).
go build "${BENCH_PACKAGE}" >/dev/null

set +e
go test "${BENCH_PACKAGE}" \
  -run='^$' \
  -bench="${BENCH_PATTERN}" \
  -benchmem \
  -benchtime="${BENCH_TIME}" \
  -count="${BENCH_COUNT}" \
  -timeout=30m \
  | tee -a "${BENCH_RESULTS}"
bench_status=${PIPESTATUS[0]}
set -e

if [[ ${bench_status} -ne 0 ]]; then
  err "go test -bench exited ${bench_status}"
  exit 1
fi
ok "benchmarks complete"

# ---------- update-baseline mode --------------------------------------------
if [[ ${UPDATE_BASELINE} -eq 1 ]]; then
  mkdir -p "$(dirname "${BENCH_BASELINE}")"
  cp "${BENCH_RESULTS}" "${BENCH_BASELINE}"
  ok "baseline updated: ${BENCH_BASELINE}"
  log "commit this file on main to lock in the new performance floor"
  exit 0
fi

# ---------- baseline present? -----------------------------------------------
if [[ ! -f "${BENCH_BASELINE}" ]]; then
  warn "no baseline at ${BENCH_BASELINE} — nothing to compare against"
  log  "to establish one: scripts/bench.sh --update-baseline (run on main)"
  exit 0
fi

# ---------- comparison -------------------------------------------------------
log "comparing against baseline ${BENCH_BASELINE}"
COMPARE_OUT="$(mktemp)"
trap 'rm -f "${COMPARE_OUT}"' EXIT

if ! benchstat "${BENCH_BASELINE}" "${BENCH_RESULTS}" > "${COMPARE_OUT}" 2>&1; then
  err "benchstat failed:"
  cat "${COMPARE_OUT}" >&2
  exit 1
fi

echo
echo "${BOLD}benchstat report${RST}"
echo "${DIM}(negative deltas = faster/less; positive = slower/more)${RST}"
echo "-----------------------------------------------------------------"
cat "${COMPARE_OUT}"
echo "-----------------------------------------------------------------"

# ---------- regression detection --------------------------------------------
# Delegate to scripts/lib/detect_regressions.py — supports per-metric
# thresholds, override rules, ignore-lists, and machine-readable outputs.
DETECT="${SCRIPT_DIR}/lib/detect_regressions.py"
chmod +x "${DETECT}" 2>/dev/null || true

detect_args=("${COMPARE_OUT}"
  --baseline "${BENCH_BASELINE}"
  --current  "${BENCH_RESULTS}"
  --json     "${BENCH_JSON}"
  --md       "${BENCH_MD}"
)
[[ -f "${BENCH_CONFIG}" ]] && detect_args+=(--config "${BENCH_CONFIG}")

# Legacy --threshold sets all three metrics.
if [[ -n "${BENCH_THRESHOLD}" ]]; then
  detect_args+=(--threshold-time  "${BENCH_THRESHOLD}"
                --threshold-bytes "${BENCH_THRESHOLD}"
                --threshold-allocs "${BENCH_THRESHOLD}")
fi
[[ -n "${BENCH_THRESHOLD_TIME}"   ]] && detect_args+=(--threshold-time   "${BENCH_THRESHOLD_TIME}")
[[ -n "${BENCH_THRESHOLD_BYTES}"  ]] && detect_args+=(--threshold-bytes  "${BENCH_THRESHOLD_BYTES}")
[[ -n "${BENCH_THRESHOLD_ALLOCS}" ]] && detect_args+=(--threshold-allocs "${BENCH_THRESHOLD_ALLOCS}")

set +e
python3 "${DETECT}" "${detect_args[@]}"
regression_status=$?
set -e

echo
if [[ ${regression_status} -eq 0 ]]; then
  ok "no significant regressions"
  exit 0
fi

err "performance regression detected"
log "machine-readable summary: ${BENCH_JSON}"
log "markdown summary:        ${BENCH_MD}"
if [[ ${BENCH_NO_FAIL} -eq 1 ]]; then
  warn "--no-fail set; exiting 0 despite regression"
  exit 0
fi
exit 1
