#!/usr/bin/env python3
"""
detect_regressions.py — parse a `benchstat old new` report and flag
statistically significant regressions above configurable per-metric
thresholds.

Usage:
  detect_regressions.py REPORT.txt [--config CONFIG.yml]
                                   [--threshold-time PCT]
                                   [--threshold-bytes PCT]
                                   [--threshold-allocs PCT]
                                   [--ignore REGEX ...]
                                   [--top N]
                                   [--json OUT.json]
                                   [--md OUT.md]

Config file (YAML, all keys optional):
  thresholds:
    sec/op: 5
    B/op: 10
    allocs/op: 5
  overrides:
    - name: "^Benchmark.*Serialization"     # regex on benchmark name
      sec/op: 3
    - name: "^Benchmark.*Parallel"
      sec/op: 10                             # noisier, allow more headroom
  ignore:
    - "^BenchmarkExperimental_"

Exit codes:
  0  no regressions above threshold
  3  regressions found
  2  usage / parse error
"""

from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys
from dataclasses import dataclass, asdict
from typing import Any

try:
    import yaml  # optional
    HAVE_YAML = True
except ImportError:
    HAVE_YAML = False

# --- benchstat row parsing ---------------------------------------------------
#
# A benchstat comparison table looks like:
#
#              │ baseline.txt │              current.txt              │
#              │    sec/op    │    sec/op     vs base                 │
# TracesSerialization-8   985.0µ ± 1%   1050.0µ ± 2%   +6.60% (p=0.002 n=6)
# geomean                 45.20µ         46.90µ         +3.76%
#
# Section headers alternate for sec/op, B/op, allocs/op. We parse each row and
# classify it under the currently active section.

SECTION_RE = re.compile(r"^\s*│?\s*(sec/op|B/op|allocs/op)\b")
# Name is anything non-whitespace up to the first big whitespace block. The
# delta and significance are the trailing "+X.XX% (p=... n=...)" or "~".
ROW_RE = re.compile(
    r"^\s*(?P<name>\S+?-\d+|\S+)\s+.*?"
    r"(?P<delta>[+-]?\d+\.\d+)%\s+"
    r"\((?P<sig>[^)]*)\)\s*$"
)
GEOMEAN_RE = re.compile(r"^\s*geomean\b", re.IGNORECASE)

METRIC_LABELS = {
    "sec/op":    "latency",
    "B/op":      "bytes",
    "allocs/op": "allocs",
}


@dataclass
class Row:
    section: str    # "sec/op" | "B/op" | "allocs/op"
    name: str
    delta: float    # percent
    sig: str        # e.g. "p=0.002 n=6"
    threshold: float
    is_regression: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def parse_report(text: str) -> list[tuple[str, str, float, str]]:
    section = None
    rows = []
    for line in text.splitlines():
        m = SECTION_RE.search(line)
        if m:
            section = m.group(1)
            continue
        if section is None:
            continue
        if GEOMEAN_RE.match(line):
            continue
        m = ROW_RE.match(line)
        if not m:
            continue
        rows.append((section, m.group("name"), float(m.group("delta")), m.group("sig")))
    return rows


def is_significant(sig: str) -> bool:
    """A row is significant if benchstat printed a p-value and did not mark ~."""
    return "p=" in sig and "~" not in sig


def load_config(path: pathlib.Path | None) -> dict[str, Any]:
    if path is None or not path.exists():
        return {}
    if not HAVE_YAML:
        print(f"[warn] pyyaml not installed; ignoring {path}", file=sys.stderr)
        return {}
    with path.open() as f:
        return yaml.safe_load(f) or {}


def resolve_threshold(
    section: str,
    name: str,
    defaults: dict[str, float],
    overrides: list[dict[str, Any]],
) -> float:
    """Pick the tightest applicable threshold for this (section, name)."""
    threshold = defaults.get(section, 5.0)
    for ov in overrides:
        pat = ov.get("name")
        if not pat or not re.search(pat, name):
            continue
        if section in ov:
            threshold = float(ov[section])
    return threshold


def format_delta(delta: float) -> str:
    sign = "+" if delta >= 0 else ""
    return f"{sign}{delta:.2f}%"


def render_markdown(
    regressions: list[Row],
    all_rows: list[Row],
    top_n: int,
    baseline_meta: dict[str, str],
    current_meta: dict[str, str],
) -> str:
    lines = []
    verdict = "🔴 REGRESSION" if regressions else "🟢 CLEAN"
    lines.append(f"**Status:** {verdict}")
    lines.append("")

    if baseline_meta or current_meta:
        lines.append("| | baseline | current |")
        lines.append("|---|---|---|")
        keys = sorted(set(baseline_meta) | set(current_meta))
        for k in keys:
            b = baseline_meta.get(k, "—")
            c = current_meta.get(k, "—")
            marker = "" if b == c else " ⚠️"
            lines.append(f"| `{k}` | {b} | {c}{marker} |")
        lines.append("")

    if regressions:
        top = sorted(regressions, key=lambda r: r.delta, reverse=True)[:top_n]
        lines.append(f"### Top {len(top)} regressions")
        lines.append("")
        lines.append("| metric | benchmark | delta | threshold | significance |")
        lines.append("|---|---|---|---|---|")
        for r in top:
            lines.append(
                f"| {METRIC_LABELS.get(r.section, r.section)} "
                f"| `{r.name}` "
                f"| **{format_delta(r.delta)}** "
                f"| {r.threshold:.1f}% "
                f"| {r.sig} |"
            )
        lines.append("")
        lines.append(f"_Total regressions: {len(regressions)}_")
    else:
        lines.append("No regressions above threshold. ✅")

    return "\n".join(lines) + "\n"


def parse_meta_from_report(text: str) -> dict[str, str]:
    """Read `# key: value` lines we write at the top of each results file."""
    meta = {}
    for line in text.splitlines():
        m = re.match(r"^#\s*([\w.]+):\s+(.+)$", line)
        if not m:
            continue
        meta[m.group(1).strip()] = m.group(2).strip()
    return meta


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("report", type=pathlib.Path, help="benchstat comparison output")
    p.add_argument("--config", type=pathlib.Path, help="YAML config with thresholds/overrides/ignore")
    p.add_argument("--baseline", type=pathlib.Path, help="baseline results file (for metadata comparison)")
    p.add_argument("--current",  type=pathlib.Path, help="current results file (for metadata comparison)")
    p.add_argument("--threshold-time",   type=float, help="override sec/op threshold (percent)")
    p.add_argument("--threshold-bytes",  type=float, help="override B/op threshold (percent)")
    p.add_argument("--threshold-allocs", type=float, help="override allocs/op threshold (percent)")
    p.add_argument("--ignore", action="append", default=[], help="regex(es) of benchmark names to skip")
    p.add_argument("--top", type=int, default=5, help="show top N regressions in markdown")
    p.add_argument("--json", type=pathlib.Path, help="write machine-readable JSON summary")
    p.add_argument("--md",   type=pathlib.Path, help="write markdown summary (for PR comments)")
    args = p.parse_args()

    if not args.report.exists():
        print(f"error: {args.report} not found", file=sys.stderr)
        return 2

    cfg = load_config(args.config)
    defaults = {
        "sec/op":    args.threshold_time   if args.threshold_time   is not None else cfg.get("thresholds", {}).get("sec/op", 5.0),
        "B/op":      args.threshold_bytes  if args.threshold_bytes  is not None else cfg.get("thresholds", {}).get("B/op", 10.0),
        "allocs/op": args.threshold_allocs if args.threshold_allocs is not None else cfg.get("thresholds", {}).get("allocs/op", 5.0),
    }
    overrides = cfg.get("overrides", []) or []
    ignore = list(args.ignore) + list(cfg.get("ignore", []) or [])
    ignore_res = [re.compile(x) for x in ignore]

    report_text = args.report.read_text()
    parsed = parse_report(report_text)

    all_rows: list[Row] = []
    regressions: list[Row] = []
    for section, name, delta, sig in parsed:
        skip = any(r.search(name) for r in ignore_res)
        thr = resolve_threshold(section, name, defaults, overrides)
        is_reg = (
            not skip
            and is_significant(sig)
            and delta > thr
        )
        row = Row(section=section, name=name, delta=delta, sig=sig, threshold=thr, is_regression=is_reg)
        all_rows.append(row)
        if is_reg:
            regressions.append(row)

    baseline_meta = parse_meta_from_report(args.baseline.read_text()) if args.baseline and args.baseline.exists() else {}
    current_meta  = parse_meta_from_report(args.current.read_text())  if args.current  and args.current.exists()  else {}

    # --- console output ------------------------------------------------------
    if regressions:
        print(f"REGRESSIONS DETECTED ({len(regressions)}):")
        for r in sorted(regressions, key=lambda r: r.delta, reverse=True):
            print(f"  [{r.section:>10}] {r.name}: {format_delta(r.delta)} "
                  f"(threshold {r.threshold:.1f}%, {r.sig})")
    else:
        print(f"no regressions above thresholds "
              f"(sec/op={defaults['sec/op']}%, B/op={defaults['B/op']}%, allocs/op={defaults['allocs/op']}%)")

    # --- hardware / env drift warning ---------------------------------------
    drift_keys = ("host", "go", "gomaxprocs", "cpu.model")
    drifted = [k for k in drift_keys
               if k in baseline_meta and k in current_meta
               and baseline_meta[k] != current_meta[k]]
    if drifted:
        print(f"\n[warn] baseline/current env drift on: {', '.join(drifted)}")
        print("[warn] consider refreshing benchmarks/baseline.txt on this hardware")

    # --- machine-readable outputs -------------------------------------------
    if args.json:
        payload = {
            "verdict": "regression" if regressions else "clean",
            "regression_count": len(regressions),
            "thresholds": defaults,
            "baseline_meta": baseline_meta,
            "current_meta": current_meta,
            "env_drift_keys": drifted,
            "rows": [r.to_dict() for r in all_rows],
        }
        args.json.write_text(json.dumps(payload, indent=2))
        print(f"json summary -> {args.json}")

    if args.md:
        args.md.write_text(render_markdown(regressions, all_rows, args.top, baseline_meta, current_meta))
        print(f"markdown summary -> {args.md}")

    return 3 if regressions else 0


if __name__ == "__main__":
    sys.exit(main())
