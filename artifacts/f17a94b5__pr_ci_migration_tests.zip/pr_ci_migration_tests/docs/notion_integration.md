# Notion Integration — Wiring Guide

The migration-test harness talks to two Notion databases:

- **📋 DDL Change Log** — one row per production DDL rollout
- **🚨 RDS Alerts** — existing alerts database (Two-way relation on `DDL Change`)

Three moving pieces:

| Piece | Runs where | Purpose |
|---|---|---|
| `lib/notion_report.sh` | End of `run.sh` on production runs | POSTs a row for the just-completed migration |
| `lib/correlate_alerts.py` | GitHub Actions cron every 5 min | Backfills the `DDL Change` relation on new alerts |
| `lib/cleanup_sla.py` | GitHub Actions cron every Monday | Enforces cleanup SLA + Slack digest |

---

## 1. One-time setup

### 1.1 Create a Notion internal integration

1. Visit https://www.notion.so/profile/integrations → *New integration*.
2. Scope: workspace where the DDL Change Log lives.
3. Capabilities: **Read content**, **Update content**, **Insert content**.
4. Copy the token (starts with `secret_…` or `ntn_…`).

### 1.2 Share the databases with the integration

In Notion, on both **📋 DDL Change Log** and **🚨 RDS Alerts**:
`···` menu → *Connections* → add the integration.

### 1.3 Add secrets to GitHub

Repository → Settings → Secrets and variables → Actions.

**Secrets** (encrypted):

| Name | Value |
|---|---|
| `NOTION_TOKEN` | The token from step 1.1 |
| `SLACK_CLEANUP_WEBHOOK` | Slack incoming-webhook URL for `#rds-cleanup` |

**Variables** (plaintext, safe to commit):

| Name | Value |
|---|---|
| `DDL_LOG_DS_ID` | `c329a821-e7db-4381-9d7a-b414f72adbcd` |
| `ALERTS_DS_ID`  | `3c705447-f798-4f89-b0cd-1618d8fb0436` |

### 1.4 Verify

```bash
gh workflow run alert-correlation.yml -f lookback_min=10
gh workflow run cleanup-sla.yml       -f digest_only=true -f dry_run=true
```

Both should exit 0. The correlation run should log `linked=0 already_linked=X no_match=Y`.

---

## 2. Environment variables for `notion_report.sh`

Set these in the production runner (typically a deploy job) before invoking `ci/migration_tests/run.sh`:

| Variable | Example | Notes |
|---|---|---|
| `NOTION_TOKEN` | `secret_…` | From step 1.1 |
| `NOTION_DS_ID` | `c329a821-…` | Same as `DDL_LOG_DS_ID` |
| `DDL_CHANGE_TITLE` | `Add users.email_verified_at` | Defaults to git commit subject |
| `DDL_CHANGE_TYPE` | `Additive Column` | Must match a select option |
| `DDL_PLAYBOOK_SECTION` | `1. Additive Migrations` | Must match a select option |
| `DDL_RESULT` | `Success` | Success / Success with Warnings / Rolled Back / Failed |
| `DDL_TARGET_TABLE` | `public.users` | Free-form |
| `DDL_PR_URL` | `https://github.com/org/repo/pull/1234` | |
| `DDL_PLAYBOOK_URL` | `https://app.notion.com/p/391c43ec8bdd814d81d6c59ebfd6cb1b` | Deep-link to playbook section |
| `DDL_NOTES` | free text | Anything CI wants to capture |

The following are pulled automatically from harness artifacts and passed to Notion:

- `Lock Timeout Events` — count of `held_ms > LOCK_MAX_MS` events in `locks.jsonl`
- `Max Lock Hold (ms)` — max `held_ms` in `locks.jsonl`
- `Peak Replication Lag (bytes)` — max `replay_lag_bytes` in `replication.jsonl`
- `Peak Retained WAL (bytes)` — max `retained_wal_bytes` in `replication.jsonl`
- `Start Time` / `End Time` — set at run start/end by `run.sh`

---

## 3. Failure modes and how they're handled

| Failure | Behavior |
|---|---|
| `NOTION_TOKEN` unset | `notion_report.sh` logs and skips; build stays green |
| Notion API 429 | Retries up to 3× with 2 s backoff |
| Notion API 5xx / 4xx | Logged as WARN; build stays green (observability plumbing must not block prod) |
| Invalid select option | Notion returns 400; row is not created; digest annotation shows the error |
| Correlation script fails to find matching DDL | Alert is left un-linked; retried on the next cron cycle |
| Cleanup SLA breach + `DIGEST_ONLY=0` | Workflow exits 1, `::error` annotations appear in the run |

**Design rule:** production migrations never fail *because* of Notion. The report is best-effort. The cleanup-SLA gate is the one place where a Notion signal can fail a build, and even then it's opt-out via `DIGEST_ONLY=1`.

---

## 4. Extending the schema

If you add a column to the DDL Change Log:

1. Update `notion_report.sh` `payload` heredoc to include the new property.
2. Match the Notion property type (see `lib/notion_report.sh` for the two shapes used: number and select).
3. Test in a scratch DB first — Notion returns 400 with a helpful message if the property name or type is wrong.
