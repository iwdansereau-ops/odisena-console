# Plan-Regression Detection

Catches migrations that pass all seven playbook assertions but silently make key queries slower — the "index is still there, but the planner stopped choosing it" class of bug.

## How it works

1. **Registry.** `ci/migration_tests/key_queries.yml` lists queries whose plans matter (top hot queries by `total_exec_time * calls` from prod `pg_stat_statements` is a good seed).
2. **Pre-migration capture.** After background load starts but before any DDL, the harness runs `ANALYZE` and then `EXPLAIN (FORMAT JSON, VERBOSE, SETTINGS ON)` for each query. Plans are saved to `plans_before/<name>.json`. `pg_stat_statements` is also snapshotted.
3. **Post-migration capture.** Same again after all `_up.sql` files have applied and subscribers have caught up.
4. **Diff.** `plan_diff.py` walks each plan tree and computes:
   - Total plan cost delta (%)
   - Scan-node count delta (%)
   - Per-relation `Seq Scan` count changes
   - Indexes chosen before vs. after
   - Join-method rank (Hash > Merge > Nested Loop) per join type

## Failure rules

**Default mode (recommended)** — a query fails the build only if it has **both**:

- Cost regression above `PLAN_COST_THRESHOLD_PCT` (default 10%), **and**
- At least one structural regression: a new `Seq Scan` on a table, an index that was in use no longer being chosen, a join-method downgrade, or `scan_count` above `PLAN_NODES_THRESHOLD_PCT`.

This suppresses the noise from normal planner cost jitter (a re-analyzed table can swing ±5–8% with no real regression) while catching every case where the planner actually picks a materially worse strategy.

**Strict mode** (`PLAN_STRICT=1`) — fail on any cost OR node-count regression above threshold, matching the literal reading of "10% cost or scan-node increase." Use for very stable, well-analyzed schemas where jitter is minimal.

## `pg_stat_statements` diff

Captured and reported by default; **not enforced** by default. Reason: mean execution time from `pg_stat_statements` needs sustained representative load to be statistically meaningful — in a short CI run it will be noisy. Turn on with `PGSS_ENFORCE=1` once you're confident your CI load profile is representative.

## Configuration knobs

Set in the workflow env or when invoking `run.sh`:

| Variable | Default | Meaning |
|---|---|---|
| `KEY_QUERIES` | `ci/migration_tests/key_queries.yml` | Registry file path |
| `PLAN_COST_THRESHOLD_PCT` | `10` | Cost-regression trigger |
| `PLAN_NODES_THRESHOLD_PCT` | `10` | Scan-node-count trigger |
| `PLAN_STRICT` | `0` | `1` = fail on cost OR nodes alone |
| `PLAN_BASELINE_DIR` | unset | Optional dir of committed baseline plans to diff against as well |
| `PGSS_ENFORCE` | `0` | `1` = fail on pgss mean-time regressions |

## Committed baseline plans (optional)

Point `PLAN_BASELINE_DIR` at a directory of committed `<name>.json` plans to catch drift that both pre- and post-migration captures share (e.g. an accidentally-dropped index that happened weeks ago and now looks "normal" in both snapshots). Snapshot with:

```bash
KEY_QUERIES=ci/migration_tests/key_queries.yml \
  ci/migration_tests/lib/plan_regression.sh \
  # (call plan_regression::capture "baseline" against a known-good DB, commit the JSON files)
```

## Artifacts

Every CI run uploads:

- `plans_before/<name>.json`, `plans_after/<name>.json` — raw EXPLAIN JSON
- `plan_regression.json` — structured diff and finding list
- `pgss_before.json`, `pgss_after.json`, `pgss_diff.json` — pg_stat_statements snapshots and diff

On failure, the run's stderr summary points reviewers at the specific query and finding — the JSON artifacts are for post-mortem.

## Known limitations

1. `EXPLAIN` (without `ANALYZE`) uses planner estimates. If `pg_stats` is severely out of date, cost numbers are meaningless — the module always runs `ANALYZE` before capture, but that only refreshes what's cheap to sample.
2. Structural checks don't yet cover: `Sort` method changes, `Hash Aggregate` → `Group Aggregate` downgrades, or partition-pruning regressions. Straightforward to add — see `plan_diff.py::compare`.
3. Plans depend on data volume. Small CI seeds may not reproduce the plans prod would choose; combine with periodic baselines captured against a prod-sized snapshot for confidence.
4. The registry expects real bind values inline. Parameterized-query plan capture (`PREPARE` / `EXPLAIN EXECUTE`) is a follow-up.
