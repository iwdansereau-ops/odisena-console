#!/usr/bin/env python3
"""Post a plan-regression digest to Slack, correlated to Notion DDL Change Log.

Reads a report from baseline_aware_analyzer.py and posts a formatted message
to the SLACK_PLAN_WEBHOOK webhook. Each regression row includes:

  - query id
  - regression type(s)
  - current vs 30d-median (cost, scan_count)
  - link to the Notion DDL Change Log row whose Start Time overlaps the
    last 7 days (best-effort correlation)

Notion correlation is best-effort. If NOTION_TOKEN / DDL_LOG_DS_ID are not
set, we still post the digest without DDL links.

Never fails the workflow — always exit 0 unless a truly fatal arg error.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

NOTION_TOKEN = os.environ.get("NOTION_TOKEN", "")
DDL_LOG_DS_ID = os.environ.get("DDL_LOG_DS_ID", "")
NOTION_VERSION = "2025-09-03"
SLACK_WEBHOOK = os.environ.get("SLACK_PLAN_WEBHOOK", "")
NOTION_API = "https://api.notion.com/v1"


def _http(method: str, url: str, headers: dict, body: bytes | None = None,
          timeout: int = 15) -> tuple[int, bytes]:
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except Exception as e:
        return 0, str(e).encode()


def _fetch_recent_ddl_rows() -> list[dict]:
    """Return DDL Change Log rows started in the last 7 days."""
    if not (NOTION_TOKEN and DDL_LOG_DS_ID):
        return []
    since = (dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=7)).isoformat()
    body = json.dumps({
        "filter": {
            "property": "Start Time",
            "date": {"on_or_after": since},
        },
        "page_size": 100,
    }).encode()
    status, resp = _http(
        "POST",
        f"{NOTION_API}/data_sources/{DDL_LOG_DS_ID}/query",
        headers={
            "Authorization": f"Bearer {NOTION_TOKEN}",
            "Notion-Version": NOTION_VERSION,
            "Content-Type": "application/json",
        },
        body=body,
    )
    if status != 200:
        print(f"slack_digest: notion query failed ({status}): {resp[:200]!r}",
              file=sys.stderr)
        return []
    data = json.loads(resp.decode())
    return data.get("results", [])


def _row_title(row: dict) -> str:
    props = row.get("properties", {})
    for _, v in props.items():
        if v.get("type") == "title":
            parts = v.get("title", [])
            return "".join(p.get("plain_text", "") for p in parts) or "(untitled)"
    return "(untitled)"


def _row_related_alerts(row: dict) -> list[str]:
    """Return list of query ids/text mentioned in Related Alerts prop."""
    props = row.get("properties", {})
    rel = props.get("Related Alerts") or {}
    if rel.get("type") == "rich_text":
        parts = rel.get("rich_text", [])
        return ["".join(p.get("plain_text", "") for p in parts)]
    return []


def _match_ddl_for_query(query_id: str, ddl_rows: list[dict]) -> dict | None:
    ql = query_id.lower()
    for row in ddl_rows:
        title = _row_title(row).lower()
        if ql in title:
            return row
        for txt in _row_related_alerts(row):
            if ql in txt.lower():
                return row
    # Fallback: return the most recent DDL row if any exist (weakest signal)
    if ddl_rows:
        return ddl_rows[0]
    return None


def _kinds_summary(findings: list[dict]) -> str:
    kinds = []
    for f in findings:
        if f.get("severity") == "regress" and f.get("kind") not in kinds:
            kinds.append(f["kind"])
    return ", ".join(kinds) if kinds else "n/a"


def build_blocks(report: dict, ddl_rows: list[dict]) -> list[dict]:
    total = report.get("total_queries", 0)
    regressed = report.get("regression_count", 0)
    no_base = len(report.get("queries_without_baseline", []))

    ok_icon = "✅" if regressed == 0 else "🚨"
    header = (
        f"{ok_icon} Weekly plan-regression digest — "
        f"{regressed}/{total} queries regressed vs 30-day baseline"
    )

    blocks: list[dict] = [
        {"type": "header", "text": {"type": "plain_text", "text": header}},
        {"type": "context", "elements": [{
            "type": "mrkdwn",
            "text": (f"*Window:* rolling 30d  |  *Thresholds:* cost ±"
                     f"{report.get('config', {}).get('cost_threshold_pct', 10)}%, "
                     f"nodes ±"
                     f"{report.get('config', {}).get('nodes_threshold_pct', 10)}%"
                     f"  |  *No baseline yet:* {no_base}"),
        }]},
        {"type": "divider"},
    ]

    if regressed == 0:
        blocks.append({"type": "section", "text": {
            "type": "mrkdwn",
            "text": ("All key queries within threshold. "
                     "Baselines rolled forward for another week."),
        }})
        return blocks

    lines = []
    for q in report.get("queries", []):
        if q.get("status") != "regress":
            continue
        name = q["name"]
        cost_pct = q.get("cost_delta_pct", 0)
        nodes_pct = q.get("nodes_delta_pct", 0)
        cur = q.get("current", {})
        base = q.get("baseline", {})
        kinds = _kinds_summary(q.get("findings", []))

        ddl_link = ""
        match = _match_ddl_for_query(name, ddl_rows)
        if match:
            page_url = match.get("url") or ""
            title = _row_title(match)
            if page_url:
                ddl_link = f"\n  DDL: <{page_url}|{title}>"

        line = (
            f"• *`{name}`* — {kinds}\n"
            f"  cost {cur.get('total_cost', 0):.0f} vs "
            f"median {base.get('median_total_cost', 0):.0f} "
            f"({cost_pct:+.1f}%) | "
            f"nodes {cur.get('scan_count', 0)} vs "
            f"median {base.get('median_scan_count', 0):.1f} "
            f"({nodes_pct:+.1f}%)"
            f"{ddl_link}"
        )
        lines.append(line)

    # Slack sections cap at 3000 chars; chunk defensively
    chunk: list[str] = []
    chunk_len = 0
    for line in lines:
        if chunk_len + len(line) + 2 > 2800 and chunk:
            blocks.append({"type": "section", "text": {
                "type": "mrkdwn", "text": "\n".join(chunk),
            }})
            chunk, chunk_len = [], 0
        chunk.append(line)
        chunk_len += len(line) + 2
    if chunk:
        blocks.append({"type": "section", "text": {
            "type": "mrkdwn", "text": "\n".join(chunk),
        }})

    blocks.append({
        "type": "context",
        "elements": [{
            "type": "mrkdwn",
            "text": ("Remediation: check the linked DDL Change Log row for "
                     "recent schema changes; re-run `ANALYZE` on the affected "
                     "tables; if still regressed, roll back the last migration "
                     "in that window and open a ticket."),
        }],
    })
    return blocks


def post_to_slack(blocks: list[dict]) -> int:
    if not SLACK_WEBHOOK:
        print("slack_digest: SLACK_PLAN_WEBHOOK not set — printing to stdout instead",
              file=sys.stderr)
        print(json.dumps({"blocks": blocks}, indent=2))
        return 0
    body = json.dumps({"blocks": blocks}).encode()
    status, resp = _http("POST", SLACK_WEBHOOK,
                         {"Content-Type": "application/json"}, body=body)
    if status < 200 or status >= 300:
        print(f"slack_digest: post failed ({status}): {resp[:200]!r}",
              file=sys.stderr)
        return 1
    print(f"slack_digest: posted {len(blocks)} blocks (status {status})",
          file=sys.stderr)
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True,
                    help="path to baseline_aware_analyzer JSON report")
    ap.add_argument("--dry-run", action="store_true",
                    help="print blocks to stdout instead of posting")
    args = ap.parse_args()

    report_path = Path(args.report)
    if not report_path.exists():
        print(f"slack_digest: report not found: {report_path}", file=sys.stderr)
        sys.exit(1)
    report = json.loads(report_path.read_text())

    ddl_rows = _fetch_recent_ddl_rows()
    blocks = build_blocks(report, ddl_rows)

    if args.dry_run:
        print(json.dumps({"blocks": blocks}, indent=2))
        sys.exit(0)

    sys.exit(post_to_slack(blocks))


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        print(f"slack_digest.py: internal error: {e}", file=sys.stderr)
        sys.exit(1)
