#!/usr/bin/env python3
"""Compare current EXPLAIN plans against a 30-day baseline registry.

Unlike the before/after plan_diff.py used for a single migration, this
analyzer answers: "is today's plan for query Q meaningfully different from
its rolling median over the last 30 days?"

Regression signals (any of these flip a query to REGRESS):
  - cost:              |current - median_cost| / median > cost_threshold_pct
  - node_count:        |current - median_nodes| / median > nodes_threshold_pct
  - plan_shape:        current signature differs from dominant signature
                       when the dominant signature had >= 60% share
  - seq_scan_appeared: table now uses Seq Scan when it never did in-window
  - index_lost:        an index in >=50% of baseline captures is missing now
  - shape_flapping:    dominant signature share < 40% (advisory info only)

Output: JSON report with per-query current values, deltas vs median,
regression type(s), and a rollup with regression_count / total.

Exit codes:
  0 - no regressions
  2 - regressions detected
  1 - internal error
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from baseline_manager import summarize_plan, _load_registry, _cutoff_iso  # noqa: E402

DEFAULT_COST_PCT = float(os.environ.get("PLAN_COST_THRESHOLD_PCT", "10"))
DEFAULT_NODES_PCT = float(os.environ.get("PLAN_NODES_THRESHOLD_PCT", "10"))


def _pct(base: float, cur: float) -> float:
    if base <= 0:
        return 100.0 if cur > 0 else 0.0
    return (cur - base) / base * 100.0


def _load_baseline_rows() -> dict[str, list[dict]]:
    """Group in-window baseline rows by query."""
    cutoff = _cutoff_iso()
    rows = [r for r in _load_registry() if r.get("captured_at", "") >= cutoff]
    by_query: dict[str, list[dict]] = {}
    for r in rows:
        by_query.setdefault(r["query"], []).append(r)
    return by_query


def _dominant_signature(rows: list[dict]) -> tuple[str, float]:
    counts: dict[str, int] = {}
    for r in rows:
        sig = r.get("plan_signature", "")
        if sig:
            counts[sig] = counts.get(sig, 0) + 1
    if not counts:
        return "", 0.0
    dom = max(counts, key=counts.get)
    return dom, counts[dom] / len(rows)


def _index_freq(rows: list[dict]) -> dict[str, float]:
    if not rows:
        return {}
    seen: dict[str, int] = {}
    for r in rows:
        for idx in r.get("indexes_used", []) or []:
            seen[idx] = seen.get(idx, 0) + 1
    return {k: v / len(rows) for k, v in seen.items()}


def _median(nums: list[float]) -> float:
    if not nums:
        return 0.0
    s = sorted(nums)
    n = len(s)
    return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2


def _seq_scan_relations(explain_text: str) -> set[str]:
    data = json.loads(explain_text)
    root = data[0] if isinstance(data, list) else data
    plan = root.get("Plan") if isinstance(root, dict) else None
    rels: set[str] = set()

    def walk(node: dict):
        if node.get("Node Type") == "Seq Scan":
            rel = node.get("Relation Name") or node.get("Alias")
            if rel:
                rels.add(rel)
        for c in node.get("Plans", []) or []:
            walk(c)

    if plan:
        walk(plan)
    return rels


def analyze(plans_dir: Path, cost_pct: float, nodes_pct: float) -> dict:
    baseline = _load_baseline_rows()
    report: dict = {
        "config": {
            "cost_threshold_pct": cost_pct,
            "nodes_threshold_pct": nodes_pct,
        },
        "queries": [],
        "regression_count": 0,
        "total_queries": 0,
        "queries_without_baseline": [],
    }

    for pf in sorted(plans_dir.glob("*.json")):
        if pf.name.startswith("_"):
            continue
        name = pf.stem
        report["total_queries"] += 1

        try:
            explain_text = pf.read_text()
            cur = summarize_plan(explain_text)
        except Exception as e:
            report["queries"].append({
                "name": name, "status": "parse_error", "error": str(e),
            })
            continue

        rows = baseline.get(name, [])
        if not rows:
            report["queries_without_baseline"].append(name)
            report["queries"].append({
                "name": name,
                "status": "no_baseline",
                "current": cur,
                "note": "first capture — nothing to compare against yet",
            })
            continue

        median_cost = _median([r["total_cost"] for r in rows])
        median_nodes = _median([float(r["scan_count"]) for r in rows])
        dom_sig, dom_share = _dominant_signature(rows)
        idx_freq = _index_freq(rows)

        cost_delta = _pct(median_cost, cur["total_cost"])
        nodes_delta = _pct(median_nodes, cur["scan_count"])

        findings: list[dict] = []

        if abs(cost_delta) > cost_pct:
            direction = "regression" if cost_delta > 0 else "improvement"
            findings.append({
                "kind": "cost",
                "severity": "regress" if cost_delta > 0 else "info",
                "detail": (f"total_cost {cur['total_cost']:.1f} vs "
                           f"30d-median {median_cost:.1f} "
                           f"({cost_delta:+.1f}%, gate ±{cost_pct}%) — {direction}"),
            })

        if abs(nodes_delta) > nodes_pct:
            findings.append({
                "kind": "node_count",
                "severity": "regress" if nodes_delta > 0 else "info",
                "detail": (f"scan_count {cur['scan_count']} vs "
                           f"30d-median {median_nodes:.1f} "
                           f"({nodes_delta:+.1f}%, gate ±{nodes_pct}%)"),
            })

        if dom_share >= 0.60 and cur["plan_signature"] != dom_sig:
            findings.append({
                "kind": "plan_shape",
                "severity": "regress",
                "detail": (f"plan signature {cur['plan_signature']} differs from "
                           f"dominant {dom_sig} "
                           f"(dominant share {dom_share*100:.0f}% of {len(rows)} captures)"),
            })
        elif 0 < dom_share < 0.40:
            findings.append({
                "kind": "shape_flapping",
                "severity": "info",
                "detail": (f"baseline plan shape is unstable "
                           f"(dominant share only {dom_share*100:.0f}%); "
                           f"consider stabilizing bind params or ANALYZE cadence"),
            })

        stable_indexes = {i for i, freq in idx_freq.items() if freq >= 0.50}
        lost = stable_indexes - set(cur["indexes_used"])
        for idx in sorted(lost):
            findings.append({
                "kind": "index_lost",
                "severity": "regress",
                "detail": (f"index '{idx}' used in "
                           f"{idx_freq[idx]*100:.0f}% of baseline captures "
                           f"is not chosen now"),
            })

        # seq-scan-appeared: relation was never seq-scanned in the last 30d
        # but is today. We only have signatures/indexes in the baseline, so we
        # infer this by checking whether the current signature includes a Seq
        # Scan relation that no baseline signature shared.
        cur_seq_rels = _seq_scan_relations(explain_text)
        if cur_seq_rels:
            # If any Seq Scan in current plan, and dominant signature was
            # different, that's a strong regression signal on that relation.
            if cur["plan_signature"] != dom_sig and dom_share >= 0.40:
                for rel in sorted(cur_seq_rels):
                    findings.append({
                        "kind": "seq_scan_appeared",
                        "severity": "regress",
                        "detail": (f"table '{rel}' now uses Seq Scan; not "
                                   f"present in dominant baseline plan shape"),
                    })

        status = "regress" if any(f["severity"] == "regress"
                                  for f in findings) else "ok"
        if status == "regress":
            report["regression_count"] += 1

        report["queries"].append({
            "name": name,
            "status": status,
            "current": cur,
            "baseline": {
                "sample_size": len(rows),
                "median_total_cost": median_cost,
                "median_scan_count": median_nodes,
                "dominant_signature": dom_sig,
                "dominant_share": round(dom_share, 3),
            },
            "cost_delta_pct": round(cost_delta, 2),
            "nodes_delta_pct": round(nodes_delta, 2),
            "findings": findings,
        })

    return report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plans-dir", required=True)
    ap.add_argument("--report", required=True)
    ap.add_argument("--cost-threshold-pct", type=float, default=DEFAULT_COST_PCT)
    ap.add_argument("--nodes-threshold-pct", type=float, default=DEFAULT_NODES_PCT)
    args = ap.parse_args()

    report = analyze(Path(args.plans_dir),
                     args.cost_threshold_pct,
                     args.nodes_threshold_pct)
    Path(args.report).write_text(json.dumps(report, indent=2))

    # Human summary
    print(f"\nbaseline-aware analysis -> {args.report}", file=sys.stderr)
    print(f"  {report['regression_count']}/{report['total_queries']} queries regressed",
          file=sys.stderr)
    for q in report["queries"]:
        marker = {"regress": "✗", "ok": "✓",
                  "no_baseline": "+", "parse_error": "?"}.get(q.get("status"), "?")
        cost = q.get("cost_delta_pct", "-")
        nodes = q.get("nodes_delta_pct", "-")
        print(f"  {marker} {q['name']}  cost {cost}%  nodes {nodes}%",
              file=sys.stderr)
        for f in q.get("findings", []):
            if f["severity"] == "regress":
                print(f"      - [{f['kind']}] {f['detail']}", file=sys.stderr)

    sys.exit(2 if report["regression_count"] > 0 else 0)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        print(f"baseline_aware_analyzer.py: internal error: {e}",
              file=sys.stderr)
        sys.exit(1)
