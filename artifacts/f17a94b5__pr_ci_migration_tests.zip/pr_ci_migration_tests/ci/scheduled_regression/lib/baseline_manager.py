#!/usr/bin/env python3
"""Rolling 30-day baseline registry for plan-regression detection.

Stores one JSONL record per (query, capture_ts) with plan summary metrics:
  - total_cost
  - scan_count (structural node count)
  - plan_signature (stable hash of Node Types + relations + indexes)
  - indexes_used (list)
  - captured_at (ISO8601 UTC)

Storage backends (auto-selected):
  1. S3 (if BASELINE_S3_URI is set, s3://bucket/prefix)
  2. Local workspace directory fallback (BASELINE_DIR, default: ./baselines)

The registry keeps a rolling 30-day window. Older records are pruned on
every write so the file never grows without bound.

Public CLI:
  baseline_manager.py capture <plans_dir> [--label monday-YYYYMMDD]
  baseline_manager.py medians  [--out <file>]     # per-query p50 over window
  baseline_manager.py prune                       # drop >30d records
  baseline_manager.py list                        # summary counts
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import statistics
import subprocess
import sys
import tempfile
from pathlib import Path

WINDOW_DAYS = int(os.environ.get("BASELINE_WINDOW_DAYS", "30"))
BASELINE_DIR = Path(os.environ.get("BASELINE_DIR", "./baselines"))
BASELINE_S3_URI = os.environ.get("BASELINE_S3_URI", "").rstrip("/")
REGISTRY_NAME = "plan_baseline.jsonl"

SCAN_NODES = {
    "Seq Scan", "Index Scan", "Index Only Scan", "Bitmap Heap Scan",
    "Bitmap Index Scan", "CTE Scan", "Subquery Scan", "Function Scan",
    "Values Scan", "Foreign Scan", "Sample Scan", "TID Scan",
}


# --------------------- storage abstraction ------------------------

def _s3_enabled() -> bool:
    return bool(BASELINE_S3_URI) and BASELINE_S3_URI.startswith("s3://")


def _s3_registry_uri() -> str:
    return f"{BASELINE_S3_URI}/{REGISTRY_NAME}"


def _load_registry() -> list[dict]:
    if _s3_enabled():
        try:
            with tempfile.NamedTemporaryFile("w+", suffix=".jsonl", delete=False) as tf:
                path = tf.name
            r = subprocess.run(
                ["aws", "s3", "cp", _s3_registry_uri(), path],
                capture_output=True, text=True,
            )
            if r.returncode != 0:
                # missing key is fine — first run
                return []
            with open(path) as f:
                return [json.loads(l) for l in f if l.strip()]
        except FileNotFoundError:
            print("baseline_manager: aws CLI missing; falling back to local dir",
                  file=sys.stderr)

    BASELINE_DIR.mkdir(parents=True, exist_ok=True)
    p = BASELINE_DIR / REGISTRY_NAME
    if not p.exists():
        return []
    return [json.loads(l) for l in p.read_text().splitlines() if l.strip()]


def _save_registry(records: list[dict]) -> None:
    body = "\n".join(json.dumps(r, sort_keys=True) for r in records) + "\n"
    if _s3_enabled():
        try:
            with tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False) as tf:
                tf.write(body)
                path = tf.name
            r = subprocess.run(
                ["aws", "s3", "cp", path, _s3_registry_uri()],
                capture_output=True, text=True,
            )
            if r.returncode == 0:
                return
            print(f"baseline_manager: S3 upload failed: {r.stderr}", file=sys.stderr)
        except FileNotFoundError:
            pass
    BASELINE_DIR.mkdir(parents=True, exist_ok=True)
    (BASELINE_DIR / REGISTRY_NAME).write_text(body)


# --------------------- summarization -----------------------------

def _walk(node: dict, sig_parts: list[str], indexes: set[str],
          scan_count: list[int]) -> None:
    nt = node.get("Node Type", "?")
    rel = node.get("Relation Name") or node.get("Alias") or ""
    sig_parts.append(f"{nt}:{rel}")
    if nt in SCAN_NODES:
        scan_count[0] += 1
    if nt in ("Index Scan", "Index Only Scan", "Bitmap Index Scan"):
        if idx := node.get("Index Name"):
            indexes.add(idx)
    for child in node.get("Plans", []) or []:
        _walk(child, sig_parts, indexes, scan_count)


def summarize_plan(explain_text: str) -> dict:
    data = json.loads(explain_text)
    root = data[0] if isinstance(data, list) else data
    plan = root.get("Plan") if isinstance(root, dict) else None
    if not plan:
        raise ValueError("no Plan in EXPLAIN JSON")
    sig_parts: list[str] = []
    indexes: set[str] = set()
    scan_count = [0]
    _walk(plan, sig_parts, indexes, scan_count)
    sig = hashlib.sha1("|".join(sig_parts).encode()).hexdigest()[:16]
    return {
        "total_cost": float(plan.get("Total Cost", 0.0)),
        "scan_count": scan_count[0],
        "plan_signature": sig,
        "indexes_used": sorted(indexes),
    }


# --------------------- operations --------------------------------

def _now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def _cutoff_iso() -> str:
    return (dt.datetime.now(dt.timezone.utc)
            - dt.timedelta(days=WINDOW_DAYS)).isoformat()


def cmd_capture(args) -> int:
    plans_dir = Path(args.plans_dir)
    if not plans_dir.is_dir():
        print(f"capture: {plans_dir} is not a directory", file=sys.stderr)
        return 2
    label = args.label or f"cap-{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d-%H%M')}"
    ts = _now_iso()
    records = _load_registry()
    added = 0
    for pf in sorted(plans_dir.glob("*.json")):
        if pf.name.startswith("_"):
            continue
        try:
            summary = summarize_plan(pf.read_text())
        except Exception as e:
            print(f"capture: skip {pf.name}: {e}", file=sys.stderr)
            continue
        records.append({
            "query": pf.stem,
            "captured_at": ts,
            "label": label,
            **summary,
        })
        added += 1
    # prune
    cutoff = _cutoff_iso()
    kept = [r for r in records if r.get("captured_at", "") >= cutoff]
    _save_registry(kept)
    print(f"baseline_manager: captured {added} plans as label={label}; "
          f"registry size {len(kept)} (window {WINDOW_DAYS}d)")
    return 0


def cmd_medians(args) -> int:
    records = _load_registry()
    cutoff = _cutoff_iso()
    fresh = [r for r in records if r.get("captured_at", "") >= cutoff]
    by_query: dict[str, list[dict]] = {}
    for r in fresh:
        by_query.setdefault(r["query"], []).append(r)
    medians: dict[str, dict] = {}
    for query, rows in by_query.items():
        costs = [r["total_cost"] for r in rows if "total_cost" in r]
        nodes = [r["scan_count"] for r in rows if "scan_count" in r]
        sig_counts: dict[str, int] = {}
        for r in rows:
            sig = r.get("plan_signature", "")
            if sig:
                sig_counts[sig] = sig_counts.get(sig, 0) + 1
        dominant_sig = max(sig_counts, key=sig_counts.get) if sig_counts else ""
        medians[query] = {
            "sample_size": len(rows),
            "window_days": WINDOW_DAYS,
            "median_total_cost": statistics.median(costs) if costs else 0.0,
            "median_scan_count": statistics.median(nodes) if nodes else 0,
            "dominant_signature": dominant_sig,
            "signature_share": (sig_counts.get(dominant_sig, 0) / len(rows))
                                if rows else 0.0,
            "first_seen": min((r["captured_at"] for r in rows), default=""),
            "last_seen": max((r["captured_at"] for r in rows), default=""),
        }
    out_body = json.dumps(medians, indent=2, sort_keys=True)
    if args.out:
        Path(args.out).write_text(out_body)
        print(f"medians -> {args.out} ({len(medians)} queries)")
    else:
        print(out_body)
    return 0


def cmd_prune(args) -> int:
    records = _load_registry()
    cutoff = _cutoff_iso()
    kept = [r for r in records if r.get("captured_at", "") >= cutoff]
    dropped = len(records) - len(kept)
    _save_registry(kept)
    print(f"pruned {dropped} records older than {cutoff}; kept {len(kept)}")
    return 0


def cmd_list(args) -> int:
    records = _load_registry()
    by_query: dict[str, int] = {}
    for r in records:
        by_query[r.get("query", "?")] = by_query.get(r.get("query", "?"), 0) + 1
    print(f"registry: {len(records)} records across {len(by_query)} queries "
          f"(backend: {'S3' if _s3_enabled() else 'local:' + str(BASELINE_DIR)})")
    for q, n in sorted(by_query.items()):
        print(f"  {q}: {n}")
    return 0


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    cap = sub.add_parser("capture", help="append plans from a directory")
    cap.add_argument("plans_dir")
    cap.add_argument("--label", default=None)
    cap.set_defaults(func=cmd_capture)

    med = sub.add_parser("medians", help="compute per-query 30d medians")
    med.add_argument("--out", default=None)
    med.set_defaults(func=cmd_medians)

    prn = sub.add_parser("prune", help="drop records older than window")
    prn.set_defaults(func=cmd_prune)

    lst = sub.add_parser("list", help="show record counts per query")
    lst.set_defaults(func=cmd_list)

    args = ap.parse_args()
    sys.exit(args.func(args))


if __name__ == "__main__":
    main()
