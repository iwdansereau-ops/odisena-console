#!/usr/bin/env bash
# Monday plan-regression runner.
#
# Modes:
#   compare  (default) — capture current plans, compare against 30d baseline,
#                        append current capture to baseline, post Slack digest
#   refresh            — wipe & rebuild the baseline from a single fresh capture
#                        (use rarely, after a major schema overhaul)
#   dry-run            — compare + build digest, but print blocks instead of posting
#
# Required env:
#   STAGING_PUB_URI              psql URI for staging publisher/primary
#   NOTION_TOKEN                 (optional) enables DDL correlation
#   DDL_LOG_DS_ID                (optional) Notion data source id
#   SLACK_PLAN_WEBHOOK           (optional) target webhook; missing = stdout
#   BASELINE_S3_URI              (optional) s3://bucket/prefix; missing = local dir
#   PLAN_COST_THRESHOLD_PCT      default 10
#   PLAN_NODES_THRESHOLD_PCT     default 10
#
# Exit codes:
#   0 - completed (regressions still trigger digest + non-zero downstream flag)
#   1 - infra/setup failure
#   2 - regressions detected
set -euo pipefail

MODE="${1:-compare}"

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MIGRATION_LIB="$(cd "$HERE/../migration_tests" && pwd)"
REGISTRY="${PLAN_REGISTRY:-$MIGRATION_LIB/key_queries.yml}"

# Prefer prod_shapes.sql-derived registry if present (top-20 mapping upgrade)
if [[ -f "$MIGRATION_LIB/prod_shapes.yml" ]]; then
  REGISTRY="$MIGRATION_LIB/prod_shapes.yml"
  echo "scheduled_regression: using prod_shapes.yml registry"
fi

if [[ -z "${STAGING_PUB_URI:-}" ]]; then
  echo "ERROR: STAGING_PUB_URI must be set" >&2
  exit 1
fi

OUT_ROOT="${OUT_ROOT:-$HERE/_out}"
STAMP="$(date -u +%Y%m%d-%H%M%S)"
RUN_DIR="$OUT_ROOT/monday-$STAMP"
PLANS_DIR="$RUN_DIR/plans"
mkdir -p "$PLANS_DIR"
echo "scheduled_regression: run dir $RUN_DIR"

# ------------------------------------------------------------------
# Bring in existing plan_regression::capture from migration_tests/lib
# ------------------------------------------------------------------
# The capture function references $HERE/lib/... so we set HERE to
# migration_tests before sourcing, then restore.
_SR_HERE="$HERE"
# shellcheck disable=SC1091
HERE="$MIGRATION_LIB" source "$MIGRATION_LIB/lib/log.sh"
# shellcheck disable=SC1091
HERE="$MIGRATION_LIB" source "$MIGRATION_LIB/lib/plan_regression.sh"

# ------------------------------------------------------------------
# Capture current plans
# ------------------------------------------------------------------
log INFO "capturing current plans against staging"
HERE="$MIGRATION_LIB" plan_regression::capture "monday-$STAMP" \
  "$STAGING_PUB_URI" "$REGISTRY" "$PLANS_DIR"

HERE="$_SR_HERE"

# ------------------------------------------------------------------
# Refresh mode wipes the registry before capture (rare)
# ------------------------------------------------------------------
if [[ "$MODE" == "refresh" ]]; then
  log WARN "REFRESH mode: rebuilding baseline from this capture only"
  # A refresh is done by pruning to a window of 0 days first — simulate by
  # temporarily overriding the window to 0 during the prune call.
  BASELINE_WINDOW_DAYS=0 python3 "$HERE/lib/baseline_manager.py" prune || true
fi

# ------------------------------------------------------------------
# Analyze vs 30d rolling baseline
# ------------------------------------------------------------------
REPORT="$RUN_DIR/report.json"
log INFO "analyzing plans vs 30d baseline"
set +e
python3 "$HERE/lib/baseline_aware_analyzer.py" \
  --plans-dir "$PLANS_DIR" \
  --report "$REPORT" \
  --cost-threshold-pct "${PLAN_COST_THRESHOLD_PCT:-10}" \
  --nodes-threshold-pct "${PLAN_NODES_THRESHOLD_PCT:-10}"
ANALYZE_RC=$?
set -e

case "$ANALYZE_RC" in
  0) log INFO "no regressions detected" ;;
  2) log ERR  "regressions detected (see $REPORT)" ;;
  *) log ERR  "analyzer failed rc=$ANALYZE_RC" ;;
esac

# ------------------------------------------------------------------
# Post Slack digest (never blocks even on failure)
# ------------------------------------------------------------------
DIGEST_ARGS=(--report "$REPORT")
if [[ "$MODE" == "dry-run" ]]; then
  DIGEST_ARGS+=(--dry-run)
fi

log INFO "posting Slack digest"
python3 "$HERE/lib/slack_digest.py" "${DIGEST_ARGS[@]}" || \
  log WARN "slack digest post failed (non-fatal)"

# ------------------------------------------------------------------
# Append current capture to rolling baseline (only after successful compare)
# ------------------------------------------------------------------
if [[ "$ANALYZE_RC" -ne 1 && "$MODE" != "dry-run" ]]; then
  log INFO "appending capture to rolling baseline"
  python3 "$HERE/lib/baseline_manager.py" capture "$PLANS_DIR" \
    --label "monday-$STAMP"
fi

log INFO "done (analyzer rc=$ANALYZE_RC)"
exit "$ANALYZE_RC"
