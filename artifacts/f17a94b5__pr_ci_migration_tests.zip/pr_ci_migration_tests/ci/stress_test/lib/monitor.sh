#!/usr/bin/env bash
# monitor.sh — 1-second-cadence sampler for the stress test.
#
# Emits JSONL with fields useful for both live watchdogs and the post-run
# analyzer. Runs in the background; killed by stress_test.sh on exit.

monitor::start() {
  local pub_uri="$1"
  local sub_uri="$2"
  local out_file="$3"
  local interval="${MONITOR_INTERVAL_S:-1}"

  ( set +e
    while true; do
      local ts
      ts="$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ)"

      # Publisher replay lag + slot state
      local row
      row="$(psql "$pub_uri" -XAt -F '|' -c "
        SELECT
          coalesce(pg_current_wal_lsn()::text, ''),
          coalesce(sr.replay_lsn::text, ''),
          coalesce(pg_wal_lsn_diff(pg_current_wal_lsn(), sr.replay_lsn), 0)::bigint AS replay_lag_bytes,
          coalesce(pg_wal_lsn_diff(pg_current_wal_lsn(), rs.confirmed_flush_lsn), 0)::bigint AS retained_wal_bytes,
          coalesce(rs.slot_name, ''),
          coalesce(rs.active::text, 'f'),
          coalesce(sr.state, ''),
          coalesce(EXTRACT(EPOCH FROM sr.replay_lag)::bigint, 0) AS replay_lag_s
        FROM pg_replication_slots rs
        LEFT JOIN pg_stat_replication sr ON sr.application_name = rs.slot_name
        WHERE rs.slot_type = 'logical'
        ORDER BY replay_lag_bytes DESC
        LIMIT 1;
      " 2>/dev/null || echo "|||0|0|||f|")"

      IFS='|' read -r cur_lsn replay_lsn lag_b wal_b slot active state lag_s <<< "$row"

      # Publisher-side counters
      local pub_tps
      pub_tps="$(psql "$pub_uri" -XAt -c "
        SELECT coalesce(sum(xact_commit)::text, '0')
        FROM pg_stat_database
        WHERE datname = current_database();
      " 2>/dev/null || echo 0)"

      # Backfill progress row (if any active)
      local bf
      bf="$(psql "$pub_uri" -XAt -F '|' -c "
        SELECT backfill_id, status, rows_done, total_rows
        FROM ops.backfill_progress
        WHERE status IN ('running','paused')
        ORDER BY started_at DESC
        LIMIT 1;
      " 2>/dev/null || echo "|||")"
      IFS='|' read -r bf_id bf_status bf_done bf_total <<< "$bf"

      printf '{"ts":"%s","replay_lag_bytes":%s,"retained_wal_bytes":%s,"replay_lag_s":%s,"slot":"%s","slot_active":"%s","stream_state":"%s","pub_commit_total":%s,"backfill_id":"%s","backfill_status":"%s","backfill_rows_done":%s,"backfill_total":%s}\n' \
        "$ts" \
        "${lag_b:-0}" "${wal_b:-0}" "${lag_s:-0}" \
        "${slot:-}" "${active:-f}" "${state:-}" \
        "${pub_tps:-0}" \
        "${bf_id:-}" "${bf_status:-}" "${bf_done:-0}" "${bf_total:-0}" \
        >> "$out_file"

      sleep "$interval"
    done
  ) &
  MONITOR_PID=$!
  echo "$MONITOR_PID" > /tmp/stress_monitor.pid
}

monitor::stop() {
  if [[ -f /tmp/stress_monitor.pid ]]; then
    local pid
    pid=$(cat /tmp/stress_monitor.pid)
    kill "$pid" 2>/dev/null || true
    wait "$pid" 2>/dev/null || true
    rm -f /tmp/stress_monitor.pid
  fi
}
