#!/usr/bin/env bash
# abort_enforcer.sh — validates that the backfill runbook's pause/abort
# triggers actually fire when their thresholds are breached.
#
# Runs alongside monitor.sh. Watches replay lag; when it stays above the
# pause-trigger ceiling for `TRIGGER_HOLD_S` seconds, it:
#   1. Records "expected pause" with a timestamp.
#   2. Waits up to PAUSE_RESPONSE_S seconds for backfill_progress.status
#      to flip to 'paused' (via the runbook's automation).
#   3. Logs pass/fail with the actual response latency.
#
# If the trigger never fires, this is the CANONICAL FAILURE for stress
# testing — it means the runbook's documented pause/resume doesn't work.

abort_enforcer::start() {
  local pub_uri="$1"
  local ceiling_bytes="$2"           # e.g. 524288000 = 500 MB
  local trigger_hold_s="${3:-60}"    # runbook says 60s consecutive
  local pause_response_s="${4:-90}"  # allow 90s for pause to take effect
  local out_file="$5"

  export PUB_URI="$pub_uri" \
         CEILING="$ceiling_bytes" \
         HOLD_S="$trigger_hold_s" \
         RESPONSE_S="$pause_response_s" \
         OUT="$out_file"

  ( set +e
    local breach_start=""
    local pause_expected_at=""
    while true; do
      local lag
      lag=$(psql "$PUB_URI" -XAt -c "
        SELECT coalesce(pg_wal_lsn_diff(pg_current_wal_lsn(), sr.replay_lsn), 0)::bigint
          FROM pg_stat_replication sr
         ORDER BY 1 DESC LIMIT 1;
      " 2>/dev/null || echo 0)

      local now_epoch
      now_epoch=$(date +%s)

      if (( lag > CEILING )); then
        if [[ -z "$breach_start" ]]; then
          breach_start=$now_epoch
          echo "{\"event\":\"breach_start\",\"ts\":\"$(date -u +%FT%TZ)\",\"lag_bytes\":$lag,\"ceiling_bytes\":$CEILING}" >> "$OUT"
        fi
        local held=$(( now_epoch - breach_start ))
        if (( held >= HOLD_S && -z "$pause_expected_at" )); then
          pause_expected_at=$now_epoch
          echo "{\"event\":\"pause_expected\",\"ts\":\"$(date -u +%FT%TZ)\",\"held_s\":$held,\"lag_bytes\":$lag}" >> "$OUT"
        fi
      else
        if [[ -n "$breach_start" ]]; then
          echo "{\"event\":\"breach_end\",\"ts\":\"$(date -u +%FT%TZ)\",\"held_s\":$(( now_epoch - breach_start )),\"lag_bytes\":$lag}" >> "$OUT"
        fi
        breach_start=""
      fi

      # Check for pause response
      if [[ -n "$pause_expected_at" ]]; then
        local status
        status=$(psql "$PUB_URI" -XAt -c "
          SELECT status FROM ops.backfill_progress
          WHERE status IN ('running','paused','aborted')
          ORDER BY started_at DESC LIMIT 1;
        " 2>/dev/null || echo "")
        local elapsed=$(( now_epoch - pause_expected_at ))
        if [[ "$status" == "paused" || "$status" == "aborted" ]]; then
          echo "{\"event\":\"pause_observed\",\"ts\":\"$(date -u +%FT%TZ)\",\"response_latency_s\":$elapsed,\"observed_status\":\"$status\",\"verdict\":\"PASS\"}" >> "$OUT"
          pause_expected_at=""
        elif (( elapsed > RESPONSE_S )); then
          echo "{\"event\":\"pause_missing\",\"ts\":\"$(date -u +%FT%TZ)\",\"response_latency_s\":$elapsed,\"observed_status\":\"$status\",\"verdict\":\"FAIL\"}" >> "$OUT"
          pause_expected_at=""
        fi
      fi

      sleep 2
    done
  ) &
  ABORT_PID=$!
  echo "$ABORT_PID" > /tmp/stress_abort.pid
}

abort_enforcer::stop() {
  if [[ -f /tmp/stress_abort.pid ]]; then
    kill "$(cat /tmp/stress_abort.pid)" 2>/dev/null || true
    rm -f /tmp/stress_abort.pid
  fi
}

# Injects a synthetic replay-lag delay by pausing the subscriber apply worker.
# Used in failure-mode tests where you want to prove the pause trigger works
# without needing to overwhelm the publisher.
abort_enforcer::inject_lag() {
  local sub_uri="$1"
  local sub_name="$2"
  local hold_s="$3"

  echo "[inject] disabling subscription $sub_name for ${hold_s}s to force lag"
  psql "$sub_uri" -v ON_ERROR_STOP=1 -c "ALTER SUBSCRIPTION $sub_name DISABLE;"
  sleep "$hold_s"
  psql "$sub_uri" -v ON_ERROR_STOP=1 -c "ALTER SUBSCRIPTION $sub_name ENABLE;"
  echo "[inject] re-enabled $sub_name"
}
