#!/usr/bin/env python3
"""analyze.py — post-run analyzer for the stress-test harness.

Reads:
  $ARTIFACTS/monitor.jsonl        1-second replication + backfill samples
  $ARTIFACTS/phases.jsonl         phase start/end timestamps
  $ARTIFACTS/abort_events.jsonl   pause-trigger enforcer events

Emits:
  $ARTIFACTS/report.md   human-readable pass/fail per phase
  $ARTIFACTS/report.json machine-readable metrics
  stdout                 short summary
  exit 0 → all bands GREEN
  exit 1 → any RED band (SLO breach OR pause trigger did not fire)
  exit 2 → data missing / analyzer error

Success thresholds (bytes = MB × 1024²):

  Phase 0 (baseline, no load):
    p95 replay_lag ≤   10 MB     GREEN
    p95 replay_lag ≤   50 MB     YELLOW
    p95 replay_lag  >  50 MB     RED

  Phase 1 (steady + backfill):
    p95 replay_lag ≤  200 MB     GREEN
    p95 replay_lag ≤  500 MB     YELLOW
    p95 replay_lag  >  500 MB     RED  (crosses runbook's yellow line)

  Phase 2 (50% spike):
    p95 replay_lag ≤  500 MB     GREEN
    p95 replay_lag ≤ 1024 MB     YELLOW
    p95 replay_lag  > 1024 MB    RED   (breaches runbook's SLO)
    peak replay_lag ≤ 1500 MB    (transient breach permitted for < 60s)

  Phase 3 (cool-down):
    time-to-catchup ≤  180 s     GREEN
    time-to-catchup ≤  600 s     YELLOW
    time-to-catchup  >  600 s    RED   (subscriber cannot keep up)

  Phase 4 (failure-mode injection):
    Every 'pause_expected' event must have a matching 'pause_observed'
    with response_latency_s ≤ PAUSE_RESPONSE_S.
    Any 'pause_missing' event → RED.
"""

from __future__ import annotations

import json
import os
import statistics
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterable


MB = 1024 * 1024

THRESHOLDS = {
    "0": {"p95_green": 10 * MB,  "p95_yellow":   50 * MB},
    "1": {"p95_green": 200 * MB, "p95_yellow":  500 * MB},
    "2": {"p95_green": 500 * MB, "p95_yellow": 1024 * MB, "peak_yellow": 1500 * MB},
    "3": {"catchup_green_s": 180, "catchup_yellow_s": 600},
}


@dataclass
class Phase:
    name: str
    start: datetime | None = None
    end: datetime | None = None
    samples: list[dict] = field(default_factory=list)


def parse_ts(s: str) -> datetime | None:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None


def load_jsonl(path: Path) -> Iterable[dict]:
    if not path.exists():
        return
    with path.open() as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue


def pct(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    values = sorted(values)
    k = (len(values) - 1) * (p / 100.0)
    f = int(k)
    c = min(f + 1, len(values) - 1)
    if f == c:
        return values[f]
    return values[f] + (values[c] - values[f]) * (k - f)


def band(name: str, value: float, green_max: float, yellow_max: float,
         higher_is_worse: bool = True) -> tuple[str, str]:
    if higher_is_worse:
        if value <= green_max:
            b = "GREEN"
        elif value <= yellow_max:
            b = "YELLOW"
        else:
            b = "RED"
    else:  # lower is worse (unused here, kept for symmetry)
        if value >= green_max:
            b = "GREEN"
        elif value >= yellow_max:
            b = "YELLOW"
        else:
            b = "RED"
    return name, b


def fmt_bytes(b: float) -> str:
    if b >= 1024 * MB:
        return f"{b / (1024 * MB):.2f} GB"
    if b >= MB:
        return f"{b / MB:.1f} MB"
    if b >= 1024:
        return f"{b / 1024:.1f} KB"
    return f"{int(b)} B"


def analyze(artifacts: Path) -> tuple[int, dict, str]:
    # Load phases
    phases: dict[str, Phase] = {}
    for evt in load_jsonl(artifacts / "phases.jsonl"):
        name = evt.get("phase")
        state = evt.get("state")
        ts = parse_ts(evt.get("ts", ""))
        if name not in phases:
            phases[name] = Phase(name=name)
        if state == "start":
            phases[name].start = ts
        elif state == "end":
            phases[name].end = ts

    # Bucket monitor samples by phase
    samples = list(load_jsonl(artifacts / "monitor.jsonl"))
    for s in samples:
        ts = parse_ts(s.get("ts", ""))
        if not ts:
            continue
        for p in phases.values():
            if p.start and p.end and p.start <= ts <= p.end:
                p.samples.append(s)
                break

    # Load abort events
    abort_events = list(load_jsonl(artifacts / "abort_events.jsonl"))

    verdict = "GREEN"
    report_rows: list[str] = []
    metrics: dict = {}

    def worsen(new: str):
        nonlocal verdict
        order = {"GREEN": 0, "YELLOW": 1, "RED": 2}
        if order[new] > order[verdict]:
            verdict = new

    # ---- Phase 0/1/2 lag analysis ----
    for phase_name in ("0", "1", "2"):
        if phase_name not in phases or not phases[phase_name].samples:
            continue
        p = phases[phase_name]
        lags = [float(s.get("replay_lag_bytes", 0)) for s in p.samples]
        thr = THRESHOLDS[phase_name]
        p95 = pct(lags, 95)
        peak = max(lags) if lags else 0
        mean = statistics.mean(lags) if lags else 0

        _, p95_band = band("p95", p95, thr["p95_green"], thr["p95_yellow"])
        worsen(p95_band)

        peak_band = "GREEN"
        if phase_name == "2":
            _, peak_band = band("peak", peak, thr["p95_yellow"], thr.get("peak_yellow", thr["p95_yellow"] * 1.5))
            worsen(peak_band)

        metrics[f"phase_{phase_name}"] = {
            "duration_s": (p.end - p.start).total_seconds() if p.start and p.end else 0,
            "sample_count": len(lags),
            "replay_lag_p50_bytes": pct(lags, 50),
            "replay_lag_p95_bytes": p95,
            "replay_lag_peak_bytes": peak,
            "replay_lag_mean_bytes": mean,
            "p95_band": p95_band,
            "peak_band": peak_band,
        }
        report_rows.append(
            f"| Phase {phase_name} | {fmt_bytes(mean)} | {fmt_bytes(pct(lags, 50))} | "
            f"{fmt_bytes(p95)} | {fmt_bytes(peak)} | {p95_band} |"
        )

    # ---- Phase 3 catch-up analysis ----
    if "3" in phases and phases["3"].samples:
        p = phases["3"]
        target = 10 * MB
        catchup_s = None
        for s in p.samples:
            if float(s.get("replay_lag_bytes", 0)) < target:
                ts = parse_ts(s.get("ts", ""))
                if ts and p.start:
                    catchup_s = (ts - p.start).total_seconds()
                    break
        if catchup_s is None:
            catchup_s = (p.end - p.start).total_seconds() if p.start and p.end else 0
            catchup_band = "RED"
        else:
            thr = THRESHOLDS["3"]
            if catchup_s <= thr["catchup_green_s"]:
                catchup_band = "GREEN"
            elif catchup_s <= thr["catchup_yellow_s"]:
                catchup_band = "YELLOW"
            else:
                catchup_band = "RED"
        worsen(catchup_band)
        metrics["phase_3"] = {
            "catchup_duration_s": catchup_s,
            "catchup_band": catchup_band,
        }
        report_rows.append(
            f"| Phase 3 (catch-up) | — | — | — | {catchup_s:.1f} s | {catchup_band} |"
        )

    # ---- Phase 4 pause-trigger verification ----
    expected = [e for e in abort_events if e.get("event") == "pause_expected"]
    observed = [e for e in abort_events if e.get("event") == "pause_observed"]
    missing  = [e for e in abort_events if e.get("event") == "pause_missing"]

    if expected or missing:
        latencies = [e["response_latency_s"] for e in observed if "response_latency_s" in e]
        fm_band = "RED" if missing else ("YELLOW" if not observed else "GREEN")
        worsen(fm_band)
        metrics["phase_4"] = {
            "expected_pauses": len(expected),
            "observed_pauses": len(observed),
            "missing_pauses":  len(missing),
            "response_latency_p95_s": pct(latencies, 95) if latencies else None,
            "response_latency_max_s": max(latencies) if latencies else None,
            "band": fm_band,
        }
        report_rows.append(
            f"| Phase 4 (pause triggers) | expected={len(expected)} | "
            f"observed={len(observed)} | missing={len(missing)} | "
            f"p95={pct(latencies, 95):.1f}s | {fm_band} |"
            if latencies else
            f"| Phase 4 (pause triggers) | expected={len(expected)} | "
            f"observed={len(observed)} | missing={len(missing)} | — | {fm_band} |"
        )

    # ---- Report ----
    lines = [
        f"# Stress-Test Report — verdict: **{verdict}**",
        "",
        f"Artifacts: `{artifacts}`",
        "",
        "## Per-Phase Summary",
        "",
        "| Phase | Mean lag | p50 lag | p95 lag | Peak / catchup / triggers | Band |",
        "|---|---|---|---|---|---|",
        *report_rows,
        "",
        "## Threshold Reference",
        "",
        "- **Phase 0 baseline** — p95 ≤ 10 MB green, ≤ 50 MB yellow.",
        "- **Phase 1 steady + backfill** — p95 ≤ 200 MB green, ≤ 500 MB yellow.",
        "- **Phase 2 50% spike** — p95 ≤ 500 MB green, ≤ 1 GB yellow, peak ≤ 1.5 GB.",
        "- **Phase 3 cool-down** — catchup ≤ 180 s green, ≤ 600 s yellow.",
        "- **Phase 4 pause triggers** — 0 missing pauses AND p95 response ≤ configured PAUSE_RESPONSE_S.",
        "",
    ]

    if missing:
        lines.extend([
            "## ⚠️ Pause-Trigger Failures",
            "",
            "The following breaches did NOT result in an observed pause. This means the",
            "runbook's documented pause/resume automation is not working end-to-end:",
            "",
        ])
        for m in missing:
            lines.append(
                f"- {m.get('ts','?')}: response_latency={m.get('response_latency_s','?')}s, "
                f"observed_status={m.get('observed_status','?')}"
            )
        lines.append("")

    (artifacts / "report.md").write_text("\n".join(lines))
    (artifacts / "report.json").write_text(json.dumps({
        "verdict": verdict,
        "metrics": metrics,
    }, indent=2, default=str))

    summary = f"verdict={verdict} " + " ".join(
        f"{k}.p95={fmt_bytes(v['replay_lag_p95_bytes'])}"
        for k, v in metrics.items()
        if isinstance(v, dict) and "replay_lag_p95_bytes" in v
    )
    exit_code = 1 if verdict == "RED" else 0
    return exit_code, metrics, summary


def main() -> int:
    if len(sys.argv) < 2:
        print("usage: analyze.py <artifacts_dir>", file=sys.stderr)
        return 2
    artifacts = Path(sys.argv[1])
    if not artifacts.exists():
        print(f"artifacts dir not found: {artifacts}", file=sys.stderr)
        return 2
    try:
        code, metrics, summary = analyze(artifacts)
    except Exception as e:
        print(f"analyzer error: {e}", file=sys.stderr)
        return 2
    print(summary)
    print(f"report: {artifacts / 'report.md'}")
    return code


if __name__ == "__main__":
    sys.exit(main())
