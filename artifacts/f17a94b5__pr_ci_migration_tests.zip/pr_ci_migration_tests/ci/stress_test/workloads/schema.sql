-- schema.sql — synthetic OLTP schema for stress testing
-- Mirrors the shape of production without any real PII/data.
-- Loaded once at test start (or reused if already present with correct row counts).

CREATE SCHEMA IF NOT EXISTS stress;

CREATE TABLE IF NOT EXISTS stress.accounts (
    id           bigserial PRIMARY KEY,
    external_id  uuid       NOT NULL DEFAULT gen_random_uuid(),
    balance      bigint     NOT NULL DEFAULT 0,
    tier         text       NOT NULL DEFAULT 'standard',
    created_at   timestamptz NOT NULL DEFAULT now(),
    updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS accounts_external_id_idx ON stress.accounts (external_id);
CREATE INDEX IF NOT EXISTS accounts_updated_at_idx  ON stress.accounts (updated_at DESC);

CREATE TABLE IF NOT EXISTS stress.events (
    id           bigserial PRIMARY KEY,
    account_id   bigint     NOT NULL,
    event_type   text       NOT NULL,
    payload      jsonb      NOT NULL DEFAULT '{}'::jsonb,
    created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS events_account_id_idx  ON stress.events (account_id, created_at DESC);
CREATE INDEX IF NOT EXISTS events_created_at_idx  ON stress.events (created_at DESC);

CREATE TABLE IF NOT EXISTS stress.line_items (
    id           bigserial PRIMARY KEY,
    account_id   bigint     NOT NULL,
    amount       bigint     NOT NULL,
    status       text       NOT NULL DEFAULT 'pending',
    created_at   timestamptz NOT NULL DEFAULT now(),
    updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS line_items_status_idx     ON stress.line_items (status) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS line_items_account_idx    ON stress.line_items (account_id, updated_at DESC);

-- Backfill target — mimics the "add nullable column, backfill later" pattern
-- from the 2 TB backfill runbook. Deliberately huge so backfills are non-trivial.
CREATE TABLE IF NOT EXISTS stress.users_bf (
    id            bigserial PRIMARY KEY,
    email         text       NOT NULL,
    email_verified_at timestamptz,   -- ← the column being backfilled
    created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS users_bf_email_idx ON stress.users_bf (email);
CREATE INDEX IF NOT EXISTS users_bf_unverified_idx
    ON stress.users_bf (id) WHERE email_verified_at IS NULL;

-- Ops bookkeeping (same schema as the backfill runbook)
CREATE SCHEMA IF NOT EXISTS ops;
CREATE TABLE IF NOT EXISTS ops.backfill_progress (
    backfill_id       text        PRIMARY KEY,
    target_table      text        NOT NULL,
    target_column     text,
    started_at        timestamptz NOT NULL DEFAULT now(),
    finished_at       timestamptz,
    last_id_processed bigint,
    total_rows        bigint,
    rows_done         bigint      NOT NULL DEFAULT 0,
    chunk_size        int         NOT NULL,
    sleep_ms          int         NOT NULL,
    status            text        NOT NULL DEFAULT 'running'
                      CHECK (status IN ('running','paused','done','aborted','failed')),
    aborted_reason    text,
    updated_at        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS backfill_progress_status_idx
    ON ops.backfill_progress (status, updated_at DESC);

-- Add tables to the publication (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_publication WHERE pubname = 'stress_pub') THEN
    CREATE PUBLICATION stress_pub
      FOR TABLE stress.accounts, stress.events, stress.line_items, stress.users_bf;
  END IF;
END $$;
