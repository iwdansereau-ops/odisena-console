#!/usr/bin/env bash
# seed.sh — populate stress tables to a target row count.
#
# Default targets are calibrated so the staging DB approximates a 2 TB
# production shape without needing 2 TB of disk:
#   accounts:   5M   rows  (~500 MB with indexes)
#   events:    50M   rows  (~15 GB with indexes)
#   line_items: 20M  rows  (~5 GB)
#   users_bf:  10M   rows  (~2 GB — this is the backfill target)
#
# On db.r6g.4xlarge staging with local SSD this seeds in ~20 min.
# Override with env vars if you want a smaller smoke run.

set -euo pipefail

: "${PUB_URI:?PUB_URI required}"
: "${ACCOUNTS_N:=5000000}"
: "${EVENTS_N:=50000000}"
: "${LINE_ITEMS_N:=20000000}"
: "${USERS_BF_N:=10000000}"
: "${BATCH:=100000}"

log() { echo "[$(date +%H:%M:%S)] $*"; }

log "seeding accounts (target=$ACCOUNTS_N)"
psql "$PUB_URI" -v ON_ERROR_STOP=1 -c "
  INSERT INTO stress.accounts (balance, tier, created_at)
  SELECT (random()*100000)::bigint,
         (ARRAY['standard','gold','platinum'])[1 + (random()*2)::int],
         now() - (random()*365)::int * interval '1 day'
    FROM generate_series(1, $ACCOUNTS_N)
    ON CONFLICT DO NOTHING;
"

log "seeding events (target=$EVENTS_N in $BATCH-row batches)"
BATCHES=$(( (EVENTS_N + BATCH - 1) / BATCH ))
for ((i=0; i<BATCHES; i++)); do
  psql "$PUB_URI" -v ON_ERROR_STOP=1 -c "
    INSERT INTO stress.events (account_id, event_type, payload, created_at)
    SELECT 1 + (random() * ($ACCOUNTS_N - 1))::bigint,
           (ARRAY['view','click','purchase','refund'])[1 + (random()*3)::int],
           jsonb_build_object('seed', true, 'i', gs),
           now() - (random()*180)::int * interval '1 day'
      FROM generate_series(1, $BATCH) gs;
  " >/dev/null
  if (( (i+1) % 10 == 0 )); then log "  events batch $((i+1))/$BATCHES"; fi
done

log "seeding line_items (target=$LINE_ITEMS_N)"
BATCHES=$(( (LINE_ITEMS_N + BATCH - 1) / BATCH ))
for ((i=0; i<BATCHES; i++)); do
  psql "$PUB_URI" -v ON_ERROR_STOP=1 -c "
    INSERT INTO stress.line_items (account_id, amount, status, created_at, updated_at)
    SELECT 1 + (random() * ($ACCOUNTS_N - 1))::bigint,
           (random() * 100000)::bigint,
           (ARRAY['pending','processed','failed'])[1 + (random()*2)::int],
           now() - (random()*90)::int * interval '1 day',
           now();
    " >/dev/null
done

log "seeding users_bf (target=$USERS_BF_N — email_verified_at initially NULL)"
BATCHES=$(( (USERS_BF_N + BATCH - 1) / BATCH ))
for ((i=0; i<BATCHES; i++)); do
  psql "$PUB_URI" -v ON_ERROR_STOP=1 -c "
    INSERT INTO stress.users_bf (email, created_at)
    SELECT 'user_' || gs || '_' || md5(random()::text) || '@example.test',
           now() - (random()*730)::int * interval '1 day'
      FROM generate_series(1, $BATCH) gs;
  " >/dev/null
done

log "ANALYZE"
psql "$PUB_URI" -v ON_ERROR_STOP=1 -c "ANALYZE stress.accounts, stress.events, stress.line_items, stress.users_bf;"

log "seed complete"
psql "$PUB_URI" -c "
  SELECT relname, n_live_tup, pg_size_pretty(pg_total_relation_size(relid)) AS size
    FROM pg_stat_user_tables
   WHERE schemaname = 'stress'
   ORDER BY n_live_tup DESC;
"
