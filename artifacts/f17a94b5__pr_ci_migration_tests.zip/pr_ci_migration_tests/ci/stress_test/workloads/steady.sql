-- steady.sql — baseline OLTP workload for 2 TB RDS stress test
-- Approximates production write mix: 70% write / 30% read.
-- Run with: pgbench -f workloads/steady.sql -c ${CLIENTS} -j ${JOBS} -T ${DURATION}
--
-- Variables (set with -D):
--   :hot_id_max     max id in the "hot" range (recent rows, ~1% of table)
--   :cold_id_max    max id anywhere (governs cold-read distribution)
--   :account_max    max id in accounts table for point lookups
--
-- Every txn is < 20 ms on p95 baseline hardware; increase CLIENTS to raise throughput.

\set hot_id     random(1, :hot_id_max)
\set cold_id    random(1, :cold_id_max)
\set aid        random(1, :account_max)
\set delta      random(-500, 500)
\set write_dice random(1, 100)

BEGIN;

-- 40% of txns: hot-row UPDATE (typical user action)
\if :write_dice <= 40
  UPDATE stress.accounts
     SET balance = balance + :delta,
         updated_at = now()
   WHERE id = :aid;

-- 20% of txns: INSERT into events (append-mostly)
\elif :write_dice <= 60
  INSERT INTO stress.events (account_id, event_type, payload, created_at)
       VALUES (:aid,
               'txn',
               jsonb_build_object('delta', :delta, 'src', 'steady'),
               now());

-- 10% of txns: UPDATE hot subset (index-covered)
\elif :write_dice <= 70
  UPDATE stress.line_items
     SET status = CASE WHEN status = 'pending' THEN 'processed' ELSE status END,
         updated_at = now()
   WHERE id = :hot_id;

-- 30% of txns: read queries (mixed hot/cold)
\else
  SELECT a.id, a.balance,
         (SELECT count(*) FROM stress.events e WHERE e.account_id = a.id) AS event_count
    FROM stress.accounts a
   WHERE a.id = :aid;
\endif

COMMIT;
