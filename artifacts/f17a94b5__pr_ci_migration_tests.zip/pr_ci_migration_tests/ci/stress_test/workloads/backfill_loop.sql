-- backfill_loop.sql — canonical chunked backfill from the 2 TB runbook.
-- Backfills stress.users_bf.email_verified_at using the pattern the runbook
-- codifies: keyset pagination, FOR UPDATE SKIP LOCKED, per-chunk lock_timeout,
-- external abort switch on ops.backfill_progress.status.
--
-- Invoke with:
--   psql "$PUB_URI" \
--     -v ON_ERROR_STOP=1 \
--     -v backfill_id="'my_id'" -v batch=5000 -v sleep_ms=250 \
--     -f workloads/backfill_loop.sql
--
-- The abort_enforcer.sh watches ops.backfill_progress and expects to see
-- status flip to 'paused' when the runbook's automation triggers fire.

DO $$
DECLARE
  _bid    text := :backfill_id;
  _batch  int  := :batch;
  _sleep  int  := :sleep_ms;
  _last   bigint;
  _rows   int;
BEGIN
  INSERT INTO ops.backfill_progress
    (backfill_id, target_table, target_column, chunk_size, sleep_ms,
     total_rows, last_id_processed)
  VALUES
    (_bid, 'stress.users_bf', 'email_verified_at', _batch, _sleep,
     (SELECT count(*) FROM stress.users_bf WHERE email_verified_at IS NULL),
     0)
  ON CONFLICT (backfill_id) DO UPDATE SET
    status = 'running', updated_at = now();

  SELECT last_id_processed INTO _last
    FROM ops.backfill_progress WHERE backfill_id = _bid;

  LOOP
    IF (SELECT status FROM ops.backfill_progress WHERE backfill_id = _bid)
       NOT IN ('running') THEN
      RAISE NOTICE 'backfill % status is not running; exiting loop', _bid;
      EXIT;
    END IF;

    BEGIN
      PERFORM set_config('lock_timeout',      '2000',  true);
      PERFORM set_config('statement_timeout', '60000', true);

      WITH batch AS (
        SELECT id FROM stress.users_bf
         WHERE id > _last AND email_verified_at IS NULL
         ORDER BY id LIMIT _batch
         FOR UPDATE SKIP LOCKED
      )
      UPDATE stress.users_bf u
         SET email_verified_at = COALESCE(u.email_verified_at, u.created_at)
        FROM batch b
       WHERE u.id = b.id
      RETURNING u.id INTO _last;

      GET DIAGNOSTICS _rows = ROW_COUNT;

      UPDATE ops.backfill_progress
         SET last_id_processed = _last,
             rows_done         = rows_done + _rows,
             updated_at        = now()
       WHERE backfill_id = _bid;
    EXCEPTION WHEN OTHERS THEN
      UPDATE ops.backfill_progress
         SET status = 'failed', aborted_reason = SQLERRM, updated_at = now()
       WHERE backfill_id = _bid;
      RAISE;
    END;

    EXIT WHEN _rows = 0;
    PERFORM pg_sleep(_sleep / 1000.0);
  END LOOP;

  UPDATE ops.backfill_progress
     SET status      = CASE WHEN status = 'running' THEN 'done' ELSE status END,
         finished_at = now(),
         updated_at  = now()
   WHERE backfill_id = _bid;
END $$;
