-- spike.sql — 50% write-throughput spike layered on top of steady.sql
-- Runs in a SEPARATE pgbench process, concurrent with steady.sql.
-- The math: if steady drives N txn/s at 70% writes, this driver adds 0.5*N
-- ALL-WRITE txn/s → net write rate goes from 0.7N to 1.2N (+71% writes).
-- That is calibrated to reproduce the "afternoon batch job + retail flash sale"
-- profile we've observed causing real replay-lag incidents.
--
-- Every txn here is a write. No reads. This is deliberately mean.
--
-- Run with: pgbench -f workloads/spike.sql -c ${SPIKE_CLIENTS} -T ${SPIKE_DURATION}

\set aid    random(1, :account_max)
\set delta  random(-2000, 2000)
\set batch  random(1, 20)

BEGIN;

-- Big-fanout INSERT: one txn writes multiple rows to events + line_items.
-- This is what actually blows out WAL volume during a spike.
INSERT INTO stress.events (account_id, event_type, payload, created_at)
SELECT :aid,
       'spike',
       jsonb_build_object('i', gs, 'delta', :delta),
       now()
  FROM generate_series(1, :batch) gs;

INSERT INTO stress.line_items (account_id, amount, status, created_at, updated_at)
SELECT :aid,
       :delta * gs,
       'pending',
       now(),
       now()
  FROM generate_series(1, :batch) gs;

UPDATE stress.accounts
   SET balance = balance + (:delta * :batch),
       updated_at = now()
 WHERE id = :aid;

COMMIT;
