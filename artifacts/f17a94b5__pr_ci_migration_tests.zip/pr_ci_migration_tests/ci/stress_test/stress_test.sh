#!/usr/bin/env bash
# stress_test.sh — 2 TB RDS staging stress test.
#
# Runs a five-phase experiment against a staging pub+sub topology:
#   Phase 0  Baseline steady load (10 min) — establish idle behavior
#   Phase 1  Steady load + backfill (30 min) — normal-day validation
#   Phase 2  50% spike overlay (10 min) — the actual stress
#   Phase 3  Post-spike cool-down (10 min) — verifies catch-up
#   Phase 4  Failure-mode injection (variable) — proves pause triggers fire
#
# Every phase emits its start/end timestamps to $ARTIFACTS/phases.jsonl so
# the analyzer can slice metrics by phase.
#
# Required env:
#   PUB_URI, SUB_URI           libpq URIs for staging publisher + subscriber
#   SUB_NAME                   subscription name on the subscriber
#
# Optional (with defaults chosen for a 2 TB staging fleet):
#   STEADY_CLIENTS=20   STEADY_JOBS=4     STEADY_DURATION_S=1800
#   SPIKE_CLIENTS=10    SPIKE_JOBS=2      SPIKE_DURATION_S=600
#   BASELINE_DURATION_S=600  COOLDOWN_DURATION_S=600
#   BACKFILL_CHUNK=5000  BACKFILL_SLEEP_MS=250
#   LAG_CEILING_BYTES=524288000        # 500 MB — the runbook's yellow line
#   LAG_ABORT_BYTES=1073741824         # 1 GB — the runbook's red line
#   TRIGGER_HOLD_S=60                  # runbook requires 60s consecutive breach
#   PAUSE_RESPONSE_S=90                # allow 90s for automation to react
#   PHASES=0,1,2,3,4                   # skip phases by omitting from CSV
#   FAILURE_MODES=lag,slot,cpu         # which injection tests to run in phase 4
#
# Exit codes:
#   0  test completed; analyzer decides pass/fail
#   4  environment / setup error
#   5  monitor or workload crashed mid-run

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$HERE/lib/monitor.sh"
source "$HERE/lib/abort_enforcer.sh"

: "${PUB_URI:?PUB_URI required}"
: "${SUB_URI:?SUB_URI required}"
: "${SUB_NAME:?SUB_NAME required}"

: "${STEADY_CLIENTS:=20}"
: "${STEADY_JOBS:=4}"
: "${STEADY_DURATION_S:=1800}"
: "${SPIKE_CLIENTS:=10}"
: "${SPIKE_JOBS:=2}"
: "${SPIKE_DURATION_S:=600}"
: "${BASELINE_DURATION_S:=600}"
: "${COOLDOWN_DURATION_S:=600}"
: "${BACKFILL_CHUNK:=5000}"
: "${BACKFILL_SLEEP_MS:=250}"
: "${LAG_CEILING_BYTES:=524288000}"
: "${LAG_ABORT_BYTES:=1073741824}"
: "${TRIGGER_HOLD_S:=60}"
: "${PAUSE_RESPONSE_S:=90}"
: "${PHASES:=0,1,2,3,4}"
: "${FAILURE_MODES:=lag}"

: "${ACCOUNTS_N:=5000000}"
: "${HOT_ID_MAX:=$(( ACCOUNTS_N / 100 ))}"
: "${COLD_ID_MAX:=$ACCOUNTS_N}"

ARTIFACTS="${ARTIFACTS:-/tmp/stress_test_$(date +%s)}"
mkdir -p "$ARTIFACTS"
echo "artifacts: $ARTIFACTS"

log() { echo "[$(date +%H:%M:%S)] $*" | tee -a "$ARTIFACTS/run.log"; }
phase_mark() {
  local phase="$1" state="$2"
  printf '{"phase":"%s","state":"%s","ts":"%s"}\n' \
    "$phase" "$state" "$(date -u +%FT%T.%3NZ)" >> "$ARTIFACTS/phases.jsonl"
  log "=== phase $phase :: $state ==="
}

phase_active() {
  [[ ",$PHASES," == *",$1,"* ]]
}

cleanup() {
  local rc=$?
  monitor::stop || true
  abort_enforcer::stop || true
  # Kill any lingering pgbench
  pkill -f 'pgbench.*workloads/(steady|spike).sql' 2>/dev/null || true
  # Try to re-enable subscription if a failure-mode injection left it disabled
  psql "$SUB_URI" -c "ALTER SUBSCRIPTION $SUB_NAME ENABLE;" 2>/dev/null || true
  log "artifacts written to $ARTIFACTS (exit=$rc)"
  return "$rc"
}
trap cleanup EXIT

log "=== stress test starting ==="
log "publisher = $(psql "$PUB_URI" -Atc 'SELECT version()' 2>/dev/null | head -c 80)"
log "subscriber= $(psql "$SUB_URI" -Atc 'SELECT version()' 2>/dev/null | head -c 80)"

# --- Pre-flight: schema must be loaded
psql "$PUB_URI" -XAt -c "SELECT 1 FROM information_schema.schemata WHERE schema_name = 'stress'" \
  | grep -q 1 || { log "FATAL: run workloads/schema.sql + seed.sh first"; exit 4; }

# --- Start monitor
monitor::start "$PUB_URI" "$SUB_URI" "$ARTIFACTS/monitor.jsonl"
log "monitor started (pid=$(cat /tmp/stress_monitor.pid))"

# ============================================================
# Phase 0 — Baseline (no load)
# ============================================================
if phase_active 0; then
  phase_mark "0" "start"
  log "baseline: no load for ${BASELINE_DURATION_S}s"
  sleep "$BASELINE_DURATION_S"
  phase_mark "0" "end"
fi

# ============================================================
# Phase 1 — Steady load + concurrent backfill
# ============================================================
if phase_active 1; then
  phase_mark "1" "start"

  log "kicking off steady pgbench ($STEADY_CLIENTS clients, $STEADY_DURATION_S s)"
  pgbench "$PUB_URI" \
    -f "$HERE/workloads/steady.sql" \
    -D hot_id_max="$HOT_ID_MAX" \
    -D cold_id_max="$COLD_ID_MAX" \
    -D account_max="$ACCOUNTS_N" \
    -c "$STEADY_CLIENTS" -j "$STEADY_JOBS" \
    -T "$STEADY_DURATION_S" \
    --no-vacuum \
    > "$ARTIFACTS/pgbench_steady.log" 2>&1 &
  STEADY_PID=$!

  # Give load 30s to ramp, then start backfill
  sleep 30
  log "starting backfill (chunk=$BACKFILL_CHUNK, sleep=${BACKFILL_SLEEP_MS}ms)"
  BACKFILL_ID="stress_users_bf_$(date +%Y%m%d_%H%M%S)"
  psql "$PUB_URI" -v ON_ERROR_STOP=1 \
    -v backfill_id="$BACKFILL_ID" \
    -v batch="$BACKFILL_CHUNK" \
    -v sleep_ms="$BACKFILL_SLEEP_MS" \
    -f "$HERE/workloads/backfill_loop.sql" \
    > "$ARTIFACTS/backfill.log" 2>&1 &
  BACKFILL_PID=$!

  # Wait for steady to finish; backfill piggybacks
  wait "$STEADY_PID" || { log "steady pgbench exited non-zero"; }
  phase_mark "1" "end"
fi

# ============================================================
# Phase 2 — 50% spike overlay
# ============================================================
if phase_active 2; then
  phase_mark "2" "start"

  # Resume steady at same intensity (baseline for the spike)
  log "resuming steady load + spike overlay"
  pgbench "$PUB_URI" \
    -f "$HERE/workloads/steady.sql" \
    -D hot_id_max="$HOT_ID_MAX" -D cold_id_max="$COLD_ID_MAX" -D account_max="$ACCOUNTS_N" \
    -c "$STEADY_CLIENTS" -j "$STEADY_JOBS" \
    -T "$SPIKE_DURATION_S" \
    --no-vacuum \
    > "$ARTIFACTS/pgbench_steady_during_spike.log" 2>&1 &
  STEADY_PID=$!

  pgbench "$PUB_URI" \
    -f "$HERE/workloads/spike.sql" \
    -D account_max="$ACCOUNTS_N" \
    -c "$SPIKE_CLIENTS" -j "$SPIKE_JOBS" \
    -T "$SPIKE_DURATION_S" \
    --no-vacuum \
    > "$ARTIFACTS/pgbench_spike.log" 2>&1 &
  SPIKE_PID=$!

  wait "$STEADY_PID" "$SPIKE_PID" || true
  phase_mark "2" "end"
fi

# ============================================================
# Phase 3 — Cool-down (catch-up validation)
# ============================================================
if phase_active 3; then
  phase_mark "3" "start"
  log "cool-down: no load; measuring catch-up for up to ${COOLDOWN_DURATION_S}s"

  # Wait until replay_lag_bytes drops below 10 MB, or timeout
  local_deadline=$(( $(date +%s) + COOLDOWN_DURATION_S ))
  CATCHUP_TARGET_BYTES=10485760
  CATCHUP_S=0
  while (( $(date +%s) < local_deadline )); do
    lag=$(psql "$PUB_URI" -XAt -c "
      SELECT coalesce(pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn), 0)::bigint
        FROM pg_stat_replication ORDER BY 1 DESC LIMIT 1;
    " 2>/dev/null || echo 0)
    if (( lag < CATCHUP_TARGET_BYTES )); then
      CATCHUP_S=$(( $(date +%s) - $(date -u -d "$(head -1 "$ARTIFACTS/phases.jsonl" | python3 -c 'import json,sys; print(json.loads(sys.stdin.read()).get("ts",""))')" +%s 2>/dev/null || echo 0) ))
      log "caught up in observed window (lag=${lag}B)"
      break
    fi
    sleep 5
  done
  phase_mark "3" "end"
fi

# ============================================================
# Phase 4 — Failure-mode injection
# ============================================================
if phase_active 4; then
  phase_mark "4" "start"
  log "starting abort-trigger enforcer (ceiling=${LAG_CEILING_BYTES}B, hold=${TRIGGER_HOLD_S}s)"
  abort_enforcer::start \
    "$PUB_URI" \
    "$LAG_CEILING_BYTES" \
    "$TRIGGER_HOLD_S" \
    "$PAUSE_RESPONSE_S" \
    "$ARTIFACTS/abort_events.jsonl"

  # Restart a backfill so there's something to pause
  BACKFILL_ID="stress_users_bf_fm_$(date +%Y%m%d_%H%M%S)"
  psql "$PUB_URI" -v ON_ERROR_STOP=1 \
    -v backfill_id="$BACKFILL_ID" \
    -v batch="$BACKFILL_CHUNK" \
    -v sleep_ms="$BACKFILL_SLEEP_MS" \
    -f "$HERE/workloads/backfill_loop.sql" \
    > "$ARTIFACTS/backfill_fm.log" 2>&1 &
  BACKFILL_PID=$!

  # Run each failure-mode injection
  IFS=',' read -ra MODES <<< "$FAILURE_MODES"
  for mode in "${MODES[@]}"; do
    case "$mode" in
      lag)
        log "[FM-lag] injecting 180s of subscriber pause to synthesize lag"
        abort_enforcer::inject_lag "$SUB_URI" "$SUB_NAME" 180
        # Give the pause trigger + automation time to react
        sleep $(( PAUSE_RESPONSE_S + 30 ))
        # If backfill was paused by automation, resume it
        psql "$PUB_URI" -c "
          UPDATE ops.backfill_progress
             SET status = 'running', updated_at = now()
           WHERE backfill_id = '$BACKFILL_ID' AND status = 'paused';
        " > /dev/null 2>&1 || true
        ;;
      slot)
        log "[FM-slot] intentionally inflating retained_wal (drop, re-create subscription)"
        # Simulate a slot bloat event
        psql "$SUB_URI" -c "ALTER SUBSCRIPTION $SUB_NAME DISABLE;" || true
        sleep 300  # 5 min of WAL retention
        psql "$SUB_URI" -c "ALTER SUBSCRIPTION $SUB_NAME ENABLE;" || true
        ;;
      cpu)
        log "[FM-cpu] launching CPU pressure via aggressive spike"
        pgbench "$PUB_URI" \
          -f "$HERE/workloads/spike.sql" \
          -D account_max="$ACCOUNTS_N" \
          -c $(( SPIKE_CLIENTS * 3 )) -j "$SPIKE_JOBS" \
          -T 300 --no-vacuum \
          > "$ARTIFACTS/pgbench_fm_cpu.log" 2>&1 || true
        ;;
      *)
        log "unknown failure-mode: $mode"
        ;;
    esac
  done

  # Clean up backfill
  psql "$PUB_URI" -c "
    UPDATE ops.backfill_progress
       SET status = 'aborted', aborted_reason = 'stress test end', updated_at = now()
     WHERE backfill_id = '$BACKFILL_ID';
  " > /dev/null 2>&1 || true

  abort_enforcer::stop
  phase_mark "4" "end"
fi

log "=== stress test complete ==="
log "run analyzer: python3 $HERE/lib/analyze.py $ARTIFACTS"
