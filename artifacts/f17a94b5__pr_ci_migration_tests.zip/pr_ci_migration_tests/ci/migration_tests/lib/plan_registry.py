#!/usr/bin/env python3
"""Parse ci/migration_tests/key_queries.yml -> newline-delimited JSON.

Registry format:

    - name: user_lookup_by_email
      mode: plan            # plan | analyze  (default: plan)
      thresholds:           # optional per-query overrides
        cost_pct: 15
        nodes_pct: 20
      sql: |
        SELECT id, email FROM users WHERE email = 'test@example.com';

We intentionally read the file as YAML if PyYAML is available, else fall
back to a minimal parser that handles the subset we document. Zero external
dependency in CI is worth the ~30 lines.
"""
from __future__ import annotations
import json
import sys
from pathlib import Path


def _load_with_yaml(text: str):
    import yaml  # type: ignore
    return yaml.safe_load(text)


def _strip_inline_comment(v: str) -> str:
    # Handle the common case; not full YAML string semantics (which we tell
    # users to install PyYAML for).
    i = v.find(" #")
    return (v[:i] if i >= 0 else v).strip()


def _load_minimal(text: str):
    """Support just the documented schema. Not a general YAML parser."""
    entries: list[dict] = []
    cur: dict | None = None
    in_sql = False
    sql_lines: list[str] = []
    sql_indent = 0
    for raw in text.splitlines():
        line = raw.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            if in_sql:
                sql_lines.append("")
            continue
        stripped = line.lstrip()
        indent = len(line) - len(stripped)
        if in_sql:
            if indent >= sql_indent and line.strip():
                sql_lines.append(line[sql_indent:])
                continue
            cur["sql"] = "\n".join(sql_lines).strip()  # type: ignore[index]
            in_sql = False; sql_lines = []
        if stripped.startswith("- "):
            if cur:
                entries.append(cur)
            cur = {}
            stripped = stripped[2:]
            if ":" in stripped:
                k, _, v = stripped.partition(":")
                cur[k.strip()] = _strip_inline_comment(v)
            continue
        if ":" in stripped:
            k, _, v = stripped.partition(":")
            k = k.strip(); v = _strip_inline_comment(v)
            if v == "|":
                in_sql = True
                sql_indent = indent + 2
                sql_lines = []
                continue
            if k == "thresholds":
                cur.setdefault("thresholds", {})  # type: ignore[union-attr]
                continue
            if cur is not None and k in ("cost_pct", "nodes_pct"):
                try:
                    cur.setdefault("thresholds", {})[k] = int(v)  # type: ignore[union-attr]
                except ValueError:
                    print(f"registry: bad int for {k}: {v!r}", file=sys.stderr)
                    sys.exit(2)
            elif cur is not None:
                cur[k] = v
    if in_sql and cur is not None:
        cur["sql"] = "\n".join(sql_lines).strip()
    if cur:
        entries.append(cur)
    return entries


def main():
    if len(sys.argv) != 2:
        print("usage: plan_registry.py <registry.yml>", file=sys.stderr); sys.exit(2)
    text = Path(sys.argv[1]).read_text()
    try:
        data = _load_with_yaml(text)
    except Exception:
        # PyYAML missing (ImportError) or shadowed/broken — fall back to the
        # minimal parser rather than crashing CI over a YAML library issue.
        data = _load_minimal(text)
    if not isinstance(data, list):
        print("registry must be a YAML list", file=sys.stderr); sys.exit(2)
    for entry in data:
        if not entry.get("name") or not entry.get("sql"):
            print(f"registry entry missing name or sql: {entry}", file=sys.stderr); sys.exit(2)
        entry.setdefault("mode", "plan")
        entry.setdefault("thresholds", {})
        print(json.dumps(entry))


if __name__ == "__main__":
    main()
