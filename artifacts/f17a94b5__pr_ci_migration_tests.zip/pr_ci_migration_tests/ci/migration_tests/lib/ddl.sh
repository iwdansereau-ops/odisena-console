# shellcheck shell=bash
# DDL application with lock_timeout + retry, matching the playbook's safe wrapper.

ddl::apply_direct() {
  # For subscriber-side DDL where lock contention is not expected.
  local uri="$1" file="$2"
  psql "$uri" -v ON_ERROR_STOP=1 -X -q -f "$file"
}

ddl::apply_with_retry() {
  # Publisher-side DDL under real load. Retries on lock_timeout / deadlock.
  local uri="$1" file="$2"
  local max_attempts="${DDL_MAX_ATTEMPTS:-30}"
  local attempt=1
  local sleep_s=1
  local wrapped
  wrapped=$(mktemp)
  # Wrap the migration in a transaction with strict timeouts. If the file
  # begins with a `-- ddl:no-txn` marker (e.g. CREATE INDEX CONCURRENTLY),
  # skip wrapping and rely on the statement's own semantics.
  if head -1 "$file" | grep -q '^-- ddl:no-txn'; then
    cp "$file" "$wrapped"
  else
    {
      echo "BEGIN;"
      echo "SET LOCAL lock_timeout = '${DDL_LOCK_TIMEOUT:-2s}';"
      echo "SET LOCAL statement_timeout = '${DDL_STMT_TIMEOUT:-15s}';"
      echo "SET LOCAL idle_in_transaction_session_timeout = '5s';"
      cat "$file"
      echo
      echo "COMMIT;"
    } > "$wrapped"
  fi

  while (( attempt <= max_attempts )); do
    if psql "$uri" -v ON_ERROR_STOP=1 -X -q -f "$wrapped" 2> >(tee -a /tmp/ddl.err >&2); then
      rm -f "$wrapped"
      log INFO "  ok on attempt $attempt: $(basename "$file")"
      return 0
    fi
    # Retry only on transient lock/deadlock errors
    if grep -qE "canceling statement due to lock timeout|deadlock detected|could not obtain lock" /tmp/ddl.err; then
      log WARN "  lock contention on attempt $attempt; sleeping ${sleep_s}s"
      sleep "$sleep_s"
      sleep_s=$(( sleep_s < 30 ? sleep_s * 2 : 30 ))
      attempt=$(( attempt + 1 ))
      : > /tmp/ddl.err
      continue
    fi
    log ERR "  non-retriable failure applying $(basename "$file")"
    rm -f "$wrapped"
    return 1
  done
  rm -f "$wrapped"
  log ERR "  exhausted $max_attempts attempts on $(basename "$file")"
  return 1
}

ddl::assert_no_invalid_indexes() {
  local uri="$1"
  local invalid
  invalid=$(psql "$uri" -Atc "
    SELECT string_agg(n.nspname||'.'||c.relname, ', ')
    FROM pg_index i
    JOIN pg_class c ON c.oid = i.indexrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE NOT i.indisvalid")
  if [[ -n "$invalid" ]]; then
    log ERR "invalid indexes present: $invalid"
    return 1
  fi
  log INFO "no invalid indexes"
  return 0
}
