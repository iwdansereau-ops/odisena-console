#!/usr/bin/env python3
"""cleanup_sla.py — enforce 4-phase cleanup SLA on the DDL Change Log.

Fails the CI build (exit 1) if any row is stuck in cleanup phases P1/P2 for
longer than the SLA window, and posts a weekly digest to Slack.

Rules (all configurable via env):
  * P0 → P1 must happen within 3  days of DDL start   (SLA_P0_DAYS)
  * P1 → P2 must happen within 7  days                (SLA_P1_DAYS)
  * P2 → P3 must happen within 14 days                (SLA_P2_DAYS)
  * Row Result must not be "Failed" without an owner  (checks Executed By)

The script queries the DDL Change Log via the Notion API and prints a
GitHub-Actions-friendly annotation for each violation.

Required env:
  NOTION_TOKEN       Integration token
  DDL_LOG_DS_ID      Data source ID of "📋 DDL Change Log"

Optional env:
  SLACK_WEBHOOK_URL      Slack incoming-webhook URL. If set, digest is posted.
  SLA_P0_DAYS            default 3
  SLA_P1_DAYS            default 7
  SLA_P2_DAYS            default 14
  DIGEST_ONLY            "1" → never fail build, only post digest
  DRY_RUN                "1" → skip Slack post, log intended payload
  LOG_LEVEL              default INFO

Exit codes:
  0  no violations, or DIGEST_ONLY=1
  1  one or more SLA violations found
  2  API error
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from typing import Any

API = "https://api.notion.com/v1"
VERSION = "2022-06-28"


def env(name: str, default: str | None = None) -> str:
    v = os.environ.get(name, default)
    if v is None:
        logging.error("missing required env var: %s", name)
        sys.exit(2)
    return v


def api(method: str, path: str, body: dict | None = None) -> dict[str, Any]:
    url = f"{API}{path}"
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {env('NOTION_TOKEN')}")
    req.add_header("Notion-Version", VERSION)
    req.add_header("Content-Type", "application/json")
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body_text = e.read().decode(errors="replace")
            if e.code == 429 and attempt < 2:
                time.sleep(2)
                continue
            logging.error("HTTP %s on %s %s: %s", e.code, method, path, body_text)
            raise
        except urllib.error.URLError as e:
            if attempt < 2:
                time.sleep(1)
                continue
            raise
    raise RuntimeError("unreachable")


def query_all(ds_id: str, filt: dict | None = None) -> list[dict]:
    pages: list[dict] = []
    cursor: str | None = None
    while True:
        body: dict[str, Any] = {"page_size": 100}
        if filt:
            body["filter"] = filt
        if cursor:
            body["start_cursor"] = cursor
        res = api("POST", f"/data_sources/{ds_id}/query", body)
        pages.extend(res.get("results", []))
        if not res.get("has_more"):
            break
        cursor = res.get("next_cursor")
    return pages


def parse_iso(s: str | None) -> datetime | None:
    if not s:
        return None
    s = s.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def prop_str(page: dict, name: str) -> str:
    p = page.get("properties", {}).get(name, {})
    t = p.get("type")
    if t == "title":
        return "".join(x.get("plain_text", "") for x in p.get("title", []))
    if t == "select":
        sel = p.get("select") or {}
        return sel.get("name", "") or ""
    if t == "status":
        st = p.get("status") or {}
        return st.get("name", "") or ""
    if t == "rich_text":
        return "".join(x.get("plain_text", "") for x in p.get("rich_text", []))
    if t == "url":
        return p.get("url", "") or ""
    return ""


def prop_date_start(page: dict, name: str) -> datetime | None:
    p = page.get("properties", {}).get(name, {})
    if p.get("type") != "date":
        return None
    d = p.get("date") or {}
    return parse_iso(d.get("start"))


def prop_last_edited(page: dict) -> datetime | None:
    return parse_iso(page.get("last_edited_time"))


def prop_checkbox(page: dict, name: str) -> bool:
    p = page.get("properties", {}).get(name, {})
    return bool(p.get("checkbox")) if p.get("type") == "checkbox" else False


def evaluate(row: dict, now: datetime, slas: dict[str, int]) -> str | None:
    """Return violation message or None."""
    phase = prop_str(row, "Cleanup Phase")
    if not phase or phase == "N/A":
        return None
    if prop_checkbox(row, "Cleanup Complete"):
        return None
    start = prop_date_start(row, "Start Time") or prop_last_edited(row)
    if not start:
        return None
    age_days = (now - start).days
    title = prop_str(row, "Change") or "(untitled)"
    result = prop_str(row, "Result")

    # Phase-specific budget
    if phase.startswith("P0"):
        budget = slas["p0"]
    elif phase.startswith("P1"):
        budget = slas["p1"]
    elif phase.startswith("P2"):
        budget = slas["p2"]
    else:
        return None

    if age_days > budget:
        return (
            f"❌ SLA breach: '{title}' stuck in {phase} for {age_days}d "
            f"(budget {budget}d, result={result or 'unknown'})"
        )
    if age_days > budget * 0.75:
        return (
            f"⚠️  SLA warning: '{title}' in {phase} for {age_days}d "
            f"(75% of {budget}d budget)"
        )
    return None


def post_slack(webhook: str, blocks: list[dict], text: str) -> None:
    payload = {"text": text, "blocks": blocks}
    req = urllib.request.Request(
        webhook,
        data=json.dumps(payload).encode(),
        method="POST",
    )
    req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=10) as resp:
        resp.read()


def main() -> int:
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(message)s",
    )
    ds = env("DDL_LOG_DS_ID")
    slas = {
        "p0": int(env("SLA_P0_DAYS", "3")),
        "p1": int(env("SLA_P1_DAYS", "7")),
        "p2": int(env("SLA_P2_DAYS", "14")),
    }
    digest_only = env("DIGEST_ONLY", "0") == "1"
    dry_run = env("DRY_RUN", "0") == "1"

    # Pull all rows whose Cleanup Phase is not N/A and not complete
    filt = {
        "and": [
            {"property": "Cleanup Complete", "checkbox": {"equals": False}},
            {"property": "Cleanup Phase", "select": {"does_not_equal": "N/A"}},
        ]
    }
    try:
        rows = query_all(ds, filt)
    except Exception as e:
        logging.error("query failed: %s", e)
        return 2
    logging.info("evaluating %d active cleanup rows", len(rows))

    now = datetime.now(timezone.utc)
    violations: list[str] = []
    warnings: list[str] = []
    for row in rows:
        msg = evaluate(row, now, slas)
        if not msg:
            continue
        if msg.startswith("❌"):
            violations.append(msg)
            print(f"::error title=Cleanup SLA breach::{msg}")
        else:
            warnings.append(msg)
            print(f"::warning title=Cleanup SLA warning::{msg}")

    # Digest
    header = f"🧹 DDL Cleanup SLA — {len(violations)} breach(es), {len(warnings)} warning(s)"
    body_lines = ["*Breaches*"] + (violations or ["_none_"]) + ["", "*Warnings*"] + (warnings or ["_none_"])
    text = "\n".join([header, ""] + body_lines)
    logging.info("digest:\n%s", text)

    webhook = os.environ.get("SLACK_WEBHOOK_URL", "")
    if webhook and not dry_run:
        try:
            post_slack(webhook, [
                {"type": "header", "text": {"type": "plain_text", "text": header}},
                {"type": "section", "text": {"type": "mrkdwn", "text": "\n".join(body_lines[:40])}},
            ], text)
            logging.info("posted digest to Slack")
        except Exception as e:
            logging.error("slack post failed: %s", e)
    elif webhook and dry_run:
        logging.info("(dry_run) skipping Slack post")

    if violations and not digest_only:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
