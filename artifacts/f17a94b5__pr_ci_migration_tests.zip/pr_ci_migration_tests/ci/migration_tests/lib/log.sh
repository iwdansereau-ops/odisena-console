# shellcheck shell=bash
log() {
  local level="$1"; shift
  printf '[%s] [%s] %s\n' "$(date -Iseconds)" "$level" "$*" >&2
}
