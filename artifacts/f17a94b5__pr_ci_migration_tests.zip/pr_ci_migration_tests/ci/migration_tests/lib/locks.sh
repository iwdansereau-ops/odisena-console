# shellcheck shell=bash
# Sample pg_locks during migration and enforce max hold time on
# AccessExclusiveLock (playbook assertion 2).

LOCK_MON_PID=""

locks::start_watchdog() {
  local uri="$1" max_ms="$2" outfile="$3"
  # Sample every 200ms so we can catch a >2s hold reliably.
  ( while true; do
      psql "$uri" -Atc "
        SELECT jsonb_agg(jsonb_build_object(
          'ts', extract(epoch from now())*1000,
          'relation', relation::regclass::text,
          'mode', mode,
          'granted', granted,
          'pid', l.pid,
          'xact_age_ms', extract(epoch from (now() - a.xact_start))*1000,
          'query', a.query
        ))
        FROM pg_locks l
        LEFT JOIN pg_stat_activity a ON a.pid = l.pid
        WHERE mode = 'AccessExclusiveLock' AND granted;" \
        >> "$outfile" 2>/dev/null
      sleep 0.2
    done ) &
  LOCK_MON_PID=$!
  log INFO "lock watchdog pid=$LOCK_MON_PID (max_hold=${max_ms}ms)"
}

locks::stop_watchdog() {
  [[ -n "$LOCK_MON_PID" ]] || return 0
  kill "$LOCK_MON_PID" 2>/dev/null || true
  wait "$LOCK_MON_PID" 2>/dev/null || true
  LOCK_MON_PID=""
}

locks::assert_no_long_hold() {
  local logfile="$1" max_ms="$2"
  # Group consecutive observations of the same (pid, relation, mode) and
  # compute the observed hold span. If any span exceeds max_ms, fail.
  python3 - "$logfile" "$max_ms" <<'PY'
import json, sys, collections
path, max_ms = sys.argv[1], int(sys.argv[2])
spans = collections.defaultdict(lambda: [None, None])  # key -> [first_ts, last_ts]
with open(path) as f:
    for line in f:
        line = line.strip()
        if not line or line == 'null': continue
        try:
            rows = json.loads(line)
        except Exception:
            continue
        if not rows: continue
        for r in rows:
            key = (r.get('pid'), r.get('relation'), r.get('mode'))
            ts = r.get('ts')
            if spans[key][0] is None:
                spans[key][0] = ts
            spans[key][1] = ts
violations = []
for key, (a, b) in spans.items():
    if a is None or b is None: continue
    dur = b - a
    if dur > max_ms:
        violations.append((key, dur))
if violations:
    for (pid, rel, mode), dur in violations:
        print(f"  VIOLATION: pid={pid} rel={rel} mode={mode} held for {dur:.0f}ms (>{max_ms}ms)", file=sys.stderr)
    sys.exit(1)
print(f"  OK: no AccessExclusiveLock held longer than {max_ms}ms")
PY
}
