# shellcheck shell=bash
# Plan-regression detection.
#
# Captures EXPLAIN (FORMAT JSON) for a registry of key queries before and
# after the migration, compares them, and fails the build if any query
# regresses beyond the configured thresholds. Optionally captures
# pg_stat_statements deltas for reporting.
#
# Public API:
#   plan_regression::capture <label> <uri> <registry.yml> <out_dir>
#   plan_regression::compare <before_dir> <after_dir> <report_out>
#   plan_regression::snapshot_pgss <label> <uri> <out_file>
#   plan_regression::diff_pgss <before_file> <after_file> <report_out>

: "${PLAN_COST_THRESHOLD_PCT:=10}"          # cost regression trigger
: "${PLAN_NODES_THRESHOLD_PCT:=10}"         # scan-node count trigger
: "${PLAN_STRICT:=0}"                       # 1 = literal "cost OR nodes > threshold"
: "${PLAN_BASELINE_DIR:=}"                  # optional committed baselines
: "${PGSS_ENFORCE:=0}"                      # 1 = fail on pgss mean_time regression

plan_regression::_ensure_pgss() {
  local uri="$1"
  local has
  has=$(psql "$uri" -Atc "SELECT count(*) FROM pg_extension WHERE extname='pg_stat_statements'")
  if [[ "$has" == "0" ]]; then
    psql "$uri" -c "CREATE EXTENSION IF NOT EXISTS pg_stat_statements" >/dev/null 2>&1 || {
      log WARN "pg_stat_statements not available; skipping pgss capture"
      return 1
    }
  fi
  return 0
}

plan_regression::_analyze_touched() {
  # Refresh planner stats on every table in the public schema (bounded work
  # in CI). Without this, cost comparisons are noise.
  local uri="$1"
  log INFO "  ANALYZE (refreshing planner stats)"
  psql "$uri" -c "ANALYZE" >/dev/null
}

plan_regression::capture() {
  local label="$1" uri="$2" registry="$3" outdir="$4"
  mkdir -p "$outdir"
  plan_regression::_analyze_touched "$uri"

  # Parse the registry with the Python helper (yaml -> jsonl of queries)
  local queries_jsonl="$outdir/_queries.jsonl"
  python3 "$HERE/lib/plan_registry.py" "$registry" > "$queries_jsonl"

  local total=0 captured=0
  while IFS= read -r line; do
    total=$(( total + 1 ))
    local name mode sql
    name=$(jq -r '.name' <<<"$line")
    mode=$(jq -r '.mode // "plan"' <<<"$line")
    sql=$(jq -r '.sql'  <<<"$line")

    local explain_kind="EXPLAIN (FORMAT JSON, VERBOSE, BUFFERS OFF, SETTINGS ON)"
    if [[ "$mode" == "analyze" ]]; then
      # Safety: never ANALYZE-execute a DML statement
      if [[ "$sql" =~ ^[[:space:]]*(INSERT|UPDATE|DELETE|MERGE|TRUNCATE|COPY|ALTER|DROP|CREATE) ]]; then
        log WARN "  refusing EXPLAIN ANALYZE on non-SELECT query '$name'; falling back to plan-only"
      else
        explain_kind="EXPLAIN (FORMAT JSON, ANALYZE, VERBOSE, BUFFERS, SETTINGS ON, TIMING OFF)"
      fi
    fi

    local out="$outdir/${name}.json"
    if psql "$uri" -Atq -v ON_ERROR_STOP=1 \
        -c "$explain_kind $sql" > "$out" 2>"$outdir/${name}.err"; then
      captured=$(( captured + 1 ))
    else
      log WARN "  EXPLAIN failed for '$name' (see ${name}.err); skipping in diff"
      rm -f "$out"
    fi
  done < "$queries_jsonl"

  log INFO "captured ${captured}/${total} plans (${label}) -> $outdir"
  [[ "$captured" -gt 0 ]] || { log ERR "no plans captured for $label"; return 1; }
  return 0
}

plan_regression::compare() {
  local before="$1" after="$2" report="$3"
  local baseline_arg=""
  if [[ -n "$PLAN_BASELINE_DIR" && -d "$PLAN_BASELINE_DIR" ]]; then
    baseline_arg="--baseline $PLAN_BASELINE_DIR"
  fi
  local strict_arg=""
  [[ "$PLAN_STRICT" == "1" ]] && strict_arg="--strict"

  python3 "$HERE/lib/plan_diff.py" \
    --before "$before" --after "$after" \
    $baseline_arg $strict_arg \
    --cost-threshold-pct "$PLAN_COST_THRESHOLD_PCT" \
    --nodes-threshold-pct "$PLAN_NODES_THRESHOLD_PCT" \
    --report "$report"
  local rc=$?
  case "$rc" in
    0) log INFO "no plan regressions detected" ;;
    2) log ERR "plan regressions detected (see $report)" ;;
    *) log ERR "plan diff tool failed (rc=$rc)" ;;
  esac
  return "$rc"
}

plan_regression::snapshot_pgss() {
  local label="$1" uri="$2" out="$3"
  plan_regression::_ensure_pgss "$uri" || { : > "$out"; return 0; }
  psql "$uri" -Atc "
    SELECT jsonb_agg(row_to_json(t)) FROM (
      SELECT queryid, calls, total_exec_time, mean_exec_time, rows, query
      FROM pg_stat_statements
      WHERE query NOT ILIKE '%pg_stat_statements%'
        AND query NOT ILIKE 'EXPLAIN%'
        AND query NOT ILIKE 'ANALYZE%'
    ) t;" > "$out"
  log INFO "pgss snapshot ($label) -> $out"
}

plan_regression::diff_pgss() {
  local before="$1" after="$2" report="$3"
  local enforce_arg=""
  [[ "$PGSS_ENFORCE" == "1" ]] && enforce_arg="--enforce"
  python3 "$HERE/lib/pgss_diff.py" \
    --before "$before" --after "$after" \
    --mean-threshold-pct "$PLAN_COST_THRESHOLD_PCT" \
    --report "$report" $enforce_arg
  local rc=$?
  if (( rc == 2 )); then
    log ERR "pg_stat_statements regressions detected (see $report)"
  fi
  return "$rc"
}
