#!/usr/bin/env python3
"""Diff two pg_stat_statements snapshots and flag regressions.

Reporting is default-on; gating is opt-in via --enforce because pgss numbers
in a short CI run are noisy without sustained representative load. Use as a
qualitative signal alongside plan_diff.py.

Exit codes:
  0 - no gate failure (regressions may be reported)
  2 - gate failed (only when --enforce)
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path


def load(path: str) -> dict:
    text = Path(path).read_text().strip()
    if not text or text == "null":
        return {}
    data = json.loads(text)
    out: dict = {}
    for row in data or []:
        # Key on queryid; fall back to a hash of query
        key = str(row.get("queryid") or hash(row.get("query", "")))
        out[key] = row
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--before", required=True)
    ap.add_argument("--after", required=True)
    ap.add_argument("--mean-threshold-pct", type=float, default=10.0)
    ap.add_argument("--min-calls", type=int, default=50,
                    help="ignore queries with fewer than N calls in the after snapshot")
    ap.add_argument("--report", required=True)
    ap.add_argument("--enforce", action="store_true")
    args = ap.parse_args()

    before = load(args.before)
    after = load(args.after)

    report: dict = {"regressions": [], "new_queries": [], "gate_failed": False}
    for key, a_row in after.items():
        calls_after = float(a_row.get("calls", 0) or 0)
        if calls_after < args.min_calls:
            continue
        mean_after = float(a_row.get("mean_exec_time", 0) or 0)
        b_row = before.get(key)
        if not b_row:
            report["new_queries"].append({
                "queryid": key,
                "mean_exec_time": mean_after,
                "calls": calls_after,
                "query": (a_row.get("query") or "")[:200],
            })
            continue
        mean_before = float(b_row.get("mean_exec_time", 0) or 0)
        if mean_before <= 0:
            continue
        delta_pct = (mean_after - mean_before) / mean_before * 100.0
        if delta_pct > args.mean_threshold_pct:
            report["regressions"].append({
                "queryid": key,
                "mean_before": round(mean_before, 3),
                "mean_after": round(mean_after, 3),
                "delta_pct": round(delta_pct, 2),
                "calls": calls_after,
                "query": (a_row.get("query") or "")[:200],
            })
    if args.enforce and report["regressions"]:
        report["gate_failed"] = True

    Path(args.report).write_text(json.dumps(report, indent=2))

    print(f"\npg_stat_statements diff -> {args.report}", file=sys.stderr)
    for r in report["regressions"]:
        print(f"  ✗ queryid={r['queryid']} mean {r['mean_before']}ms -> {r['mean_after']}ms "
              f"(+{r['delta_pct']}%)", file=sys.stderr)
    for r in report["new_queries"][:5]:
        print(f"  + new: queryid={r['queryid']} mean={r['mean_exec_time']:.2f}ms", file=sys.stderr)
    print(f"  regressions: {len(report['regressions'])}  "
          f"new: {len(report['new_queries'])}  enforce: {args.enforce}", file=sys.stderr)

    sys.exit(2 if report["gate_failed"] else 0)


if __name__ == "__main__":
    main()
