#!/usr/bin/env bash
# lib/notion_report.sh
#
# Post a row to the Notion "📋 DDL Change Log" data source at the end of a
# successful production migration run.
#
# The harness produces artifacts in $ARTIFACTS: locks.jsonl, replication.jsonl,
# plan_regression.json, parity_*.txt. This module extracts summary metrics from
# those artifacts and POSTs them to the Notion API.
#
# Environment (all optional except NOTION_TOKEN + NOTION_DS_ID):
#   NOTION_TOKEN           Notion internal integration token (GitHub secret)
#   NOTION_DS_ID           Data source ID of the DDL Change Log DB
#   NOTION_VERSION         API version (default: 2022-06-28)
#   DDL_CHANGE_TITLE       Title for the row (default: git commit subject)
#   DDL_CHANGE_TYPE        one of the Change Type select options
#   DDL_PLAYBOOK_SECTION   one of the Playbook Section select options
#   DDL_RESULT             Success | "Success with Warnings" | Rolled Back | Failed
#   DDL_TARGET_TABLE       schema.table
#   DDL_PR_URL             URL of the merged PR
#   DDL_PLAYBOOK_URL       Deep link to the relevant Notion playbook section
#   DDL_START_ISO          ISO-8601 start timestamp (default: from artifacts)
#   DDL_END_ISO            ISO-8601 end timestamp (default: now)
#   DDL_NOTES              free-form notes appended to the row body

set -euo pipefail

notion_report::_json_escape() {
  # Portable JSON string escape (quotes + backslashes + control chars)
  python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))' <<<"$1"
}

notion_report::_max_number_field() {
  # $1 jsonl file, $2 field name
  local file="$1" field="$2"
  [[ -f "$file" ]] || { echo 0; return; }
  python3 - "$file" "$field" <<'PY'
import json, sys
path, field = sys.argv[1], sys.argv[2]
best = 0
try:
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            v = rec.get(field)
            if isinstance(v, (int, float)) and v > best:
                best = v
    print(int(best))
except FileNotFoundError:
    print(0)
PY
}

notion_report::_count_events() {
  local file="$1"
  [[ -f "$file" ]] || { echo 0; return; }
  # Count records where held_ms > LOCK_MAX_MS (default 2000)
  python3 - "$file" "${LOCK_MAX_MS:-2000}" <<'PY'
import json, sys
path, threshold = sys.argv[1], int(sys.argv[2])
n = 0
try:
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(rec.get('held_ms'), (int, float)) and rec['held_ms'] > threshold:
                n += 1
    print(n)
except FileNotFoundError:
    print(0)
PY
}

notion_report::post() {
  local artifacts="$1"

  if [[ -z "${NOTION_TOKEN:-}" || -z "${NOTION_DS_ID:-}" ]]; then
    log INFO "NOTION_TOKEN / NOTION_DS_ID not set; skipping DDL Change Log post"
    return 0
  fi

  local title="${DDL_CHANGE_TITLE:-$(git log -1 --pretty=%s 2>/dev/null || echo "Untitled DDL change")}"
  local change_type="${DDL_CHANGE_TYPE:-Other}"
  local section="${DDL_PLAYBOOK_SECTION:-1. Additive Migrations}"
  local result="${DDL_RESULT:-Success}"
  local target="${DDL_TARGET_TABLE:-}"
  local pr_url="${DDL_PR_URL:-}"
  local playbook_url="${DDL_PLAYBOOK_URL:-}"
  local start_iso="${DDL_START_ISO:-$(date -u +%Y-%m-%dT%H:%M:%SZ)}"
  local end_iso="${DDL_END_ISO:-$(date -u +%Y-%m-%dT%H:%M:%SZ)}"
  local notes="${DDL_NOTES:-Autologged by CI harness}"

  # Extract metrics from artifacts
  local lock_events max_lock_ms peak_lag peak_wal
  lock_events="$(notion_report::_count_events "$artifacts/locks.jsonl")"
  max_lock_ms="$(notion_report::_max_number_field "$artifacts/locks.jsonl" held_ms)"
  peak_lag="$(notion_report::_max_number_field "$artifacts/replication.jsonl" replay_lag_bytes)"
  peak_wal="$(notion_report::_max_number_field "$artifacts/replication.jsonl" retained_wal_bytes)"

  # Escape strings for JSON safely
  local title_j type_j section_j result_j target_j notes_j
  title_j=$(notion_report::_json_escape "$title")
  type_j=$(notion_report::_json_escape "$change_type")
  section_j=$(notion_report::_json_escape "$section")
  result_j=$(notion_report::_json_escape "$result")
  target_j=$(notion_report::_json_escape "$target")
  notes_j=$(notion_report::_json_escape "$notes")

  local url_props=""
  if [[ -n "$pr_url" ]]; then
    url_props+=", \"PR Link\": {\"url\": $(notion_report::_json_escape "$pr_url")}"
  fi
  if [[ -n "$playbook_url" ]]; then
    url_props+=", \"Playbook Link\": {\"url\": $(notion_report::_json_escape "$playbook_url")}"
  fi

  local payload
  payload=$(cat <<JSON
{
  "parent": {"type": "data_source_id", "data_source_id": "$NOTION_DS_ID"},
  "properties": {
    "Change":            {"title":     [{"text": {"content": $title_j}}]},
    "Change Type":       {"select":    {"name": $type_j}},
    "Playbook Section":  {"select":    {"name": $section_j}},
    "Result":            {"select":    {"name": $result_j}},
    "Status":            {"status":    {"name": "Done"}},
    "Target Table":      {"rich_text": [{"text": {"content": $target_j}}]},
    "Notes":             {"rich_text": [{"text": {"content": $notes_j}}]},
    "Start Time":        {"date":      {"start": "$start_iso"}},
    "End Time":          {"date":      {"start": "$end_iso"}},
    "Lock Timeout Events":          {"number": $lock_events},
    "Max Lock Hold (ms)":           {"number": $max_lock_ms},
    "Peak Replication Lag (bytes)": {"number": $peak_lag},
    "Peak Retained WAL (bytes)":    {"number": $peak_wal},
    "P0 Prereqs Done":              {"checkbox": true}
    $url_props
  }
}
JSON
)

  log INFO "posting DDL Change Log row to Notion (events=$lock_events, max_lock=${max_lock_ms}ms, peak_lag=${peak_lag}B)"
  local resp status
  resp=$(curl -sS -o /tmp/notion_resp.$$ -w '%{http_code}' \
    -X POST https://api.notion.com/v1/pages \
    -H "Authorization: Bearer $NOTION_TOKEN" \
    -H "Notion-Version: ${NOTION_VERSION:-2022-06-28}" \
    -H "Content-Type: application/json" \
    -d "$payload") || true
  status="$resp"

  if [[ "$status" =~ ^2 ]]; then
    log INFO "DDL Change Log row created (HTTP $status)"
    local page_url
    page_url=$(python3 -c 'import json,sys; print(json.load(sys.stdin).get("url",""))' </tmp/notion_resp.$$ 2>/dev/null || true)
    [[ -n "$page_url" ]] && log INFO "row url: $page_url"
    rm -f /tmp/notion_resp.$$
    return 0
  else
    log WARN "Notion POST failed (HTTP $status). Response:"
    cat /tmp/notion_resp.$$ >&2 || true
    rm -f /tmp/notion_resp.$$
    # Non-fatal: don't fail the build for observability plumbing
    return 0
  fi
}
