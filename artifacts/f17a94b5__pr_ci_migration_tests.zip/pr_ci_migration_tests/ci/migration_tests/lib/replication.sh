# shellcheck shell=bash
# Logical replication health, catch-up, and slot monitoring.

REPL_MON_PID=""

replication::assert_healthy() {
  local uri="$1"
  local wal_level slots
  wal_level=$(psql "$PUB_URI" -Atc "SHOW wal_level")
  if [[ "$wal_level" != "logical" ]]; then
    log ERR "publisher wal_level=$wal_level (need 'logical')"
    return 1
  fi
  slots=$(psql "$PUB_URI" -Atc "SELECT count(*) FROM pg_replication_slots WHERE slot_type='logical'")
  if (( slots == 0 )); then
    log ERR "no logical replication slots present on publisher"
    return 1
  fi
  local sub_active
  sub_active=$(psql "$SUB_URI" -Atc "SELECT count(*) FROM pg_stat_subscription WHERE pid IS NOT NULL")
  if (( sub_active == 0 )); then
    log ERR "no active subscription workers on subscriber"
    return 1
  fi
  log INFO "replication healthy: $slots slot(s), $sub_active subscription worker(s)"
  return 0
}

replication::wait_for_catchup() {
  local pub_uri="$1" timeout="$2"
  local target
  target=$(psql "$pub_uri" -Atc "SELECT pg_current_wal_lsn()")
  log INFO "waiting for subscribers to reach $target (timeout ${timeout}s)"
  local deadline=$(( SECONDS + timeout ))
  local caught
  while (( SECONDS < deadline )); do
    caught=$(psql "$pub_uri" -Atc "
      SELECT bool_and(confirmed_flush_lsn >= '$target'::pg_lsn)
      FROM pg_replication_slots
      WHERE slot_type='logical'")
    if [[ "$caught" == "t" ]]; then
      log INFO "subscribers caught up in $(( timeout - (deadline - SECONDS) ))s"
      return 0
    fi
    sleep 2
  done
  log ERR "TIMEOUT waiting for subscriber catch-up (target=$target)"
  psql "$pub_uri" -c "
    SELECT slot_name, active,
           pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), confirmed_flush_lsn)) AS lag
    FROM pg_replication_slots WHERE slot_type='logical';" >&2
  return 1
}

replication::start_monitor() {
  local uri="$1" wal_ceiling_mb="$2" outfile="$3"
  ( while true; do
      psql "$uri" -Atc "
        SELECT jsonb_build_object(
          'ts', now(),
          'slots', jsonb_agg(jsonb_build_object(
            'slot_name', slot_name,
            'active', active,
            'retained_wal_bytes', pg_wal_lsn_diff(pg_current_wal_lsn(), restart_lsn),
            'confirmed_lag_bytes', pg_wal_lsn_diff(pg_current_wal_lsn(), confirmed_flush_lsn)
          ))
        )
        FROM pg_replication_slots WHERE slot_type='logical';" \
        >> "$outfile" 2>/dev/null
      sleep 2
    done ) &
  REPL_MON_PID=$!
  log INFO "replication monitor pid=$REPL_MON_PID (ceiling ${wal_ceiling_mb} MiB)"
}

replication::stop_monitor() {
  [[ -n "$REPL_MON_PID" ]] || return 0
  kill "$REPL_MON_PID" 2>/dev/null || true
  wait "$REPL_MON_PID" 2>/dev/null || true
  REPL_MON_PID=""
}

replication::assert_slot_healthy() {
  local logfile="$1" ceiling_mb="$2"
  # Peak retained WAL, and any inactive-slot observation
  local inactive
  inactive=$(grep -c '"active": false' "$logfile" 2>/dev/null || echo 0)
  if (( inactive > 0 )); then
    log ERR "logical slot went inactive during run ($inactive observations)"
    return 1
  fi
  # Peak retained wal in MB
  local peak_mb
  peak_mb=$(python3 - "$logfile" <<'PY'
import json, sys
peak = 0
with open(sys.argv[1]) as f:
    for line in f:
        line = line.strip()
        if not line: continue
        try:
            d = json.loads(line)
        except Exception:
            continue
        for s in d.get("slots") or []:
            v = s.get("retained_wal_bytes") or 0
            if v > peak: peak = v
print(peak // (1024*1024))
PY
)
  log INFO "peak retained WAL: ${peak_mb} MiB (ceiling ${ceiling_mb})"
  if (( peak_mb > ceiling_mb )); then
    log ERR "retained WAL exceeded ceiling"
    return 1
  fi
  return 0
}
