#!/usr/bin/env python3
"""correlate_alerts.py — link RDS Alerts rows to the in-flight DDL Change Log row.

Run periodically (e.g. every 5 min via cron) OR one-shot after each production
migration. For every alert whose `Fired At` timestamp falls inside an active
DDL Change Log window (Start Time ≤ fired ≤ End Time, or Start Time ≤ fired
and no End Time yet), populate the alert's DDL Change relation.

Uses the Notion API directly (not the MCP wrapper), so it can run inside a
GitHub Actions job or a plain cron container.

Required env:
  NOTION_TOKEN           Integration token with access to both databases
  DDL_LOG_DS_ID          Data source ID of "📋 DDL Change Log"
  ALERTS_DS_ID           Data source ID of "🚨 RDS Alerts"
  ALERT_RELATION_PROP    Name of the relation property on the Alerts DB that
                         points back to the DDL Change Log (default: "DDL Change")
  ALERTS_LOOKBACK_MIN    Only correlate alerts fired in the last N minutes
                         (default: 60)

Optional env:
  DRY_RUN                Set to "1" to log intended writes without executing.
  LOG_LEVEL              INFO | DEBUG (default INFO)

Exit codes:
  0 success (0 or more alerts correlated)
  1 configuration error
  2 API error preventing progress
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from typing import Any

API = "https://api.notion.com/v1"
VERSION = "2022-06-28"


def env(name: str, default: str | None = None) -> str:
    v = os.environ.get(name, default)
    if v is None:
        logging.error("missing required env var: %s", name)
        sys.exit(1)
    return v


def api(method: str, path: str, body: dict | None = None) -> dict[str, Any]:
    url = f"{API}{path}"
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Authorization", f"Bearer {env('NOTION_TOKEN')}")
    req.add_header("Notion-Version", VERSION)
    req.add_header("Content-Type", "application/json")
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body_text = e.read().decode(errors="replace")
            if e.code == 429 and attempt < 2:
                logging.warning("rate limited; sleeping 2s (attempt %d)", attempt + 1)
                time.sleep(2)
                continue
            logging.error("HTTP %s on %s %s: %s", e.code, method, path, body_text)
            raise
        except urllib.error.URLError as e:
            if attempt < 2:
                time.sleep(1)
                continue
            logging.error("URL error on %s %s: %s", method, path, e)
            raise
    raise RuntimeError("unreachable")


def query_ds(ds_id: str, filt: dict | None = None) -> list[dict]:
    """Query a data source, handling pagination."""
    pages: list[dict] = []
    start_cursor: str | None = None
    while True:
        body: dict[str, Any] = {"page_size": 100}
        if filt:
            body["filter"] = filt
        if start_cursor:
            body["start_cursor"] = start_cursor
        result = api("POST", f"/data_sources/{ds_id}/query", body)
        pages.extend(result.get("results", []))
        if not result.get("has_more"):
            break
        start_cursor = result.get("next_cursor")
    return pages


def parse_iso(s: str | None) -> datetime | None:
    if not s:
        return None
    # Notion returns ISO-8601 with Z or offset
    s = s.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def get_date_prop(page: dict, prop: str) -> datetime | None:
    p = page.get("properties", {}).get(prop, {})
    date = p.get("date") if p.get("type") == "date" else None
    if not date:
        return None
    return parse_iso(date.get("start"))


def get_end_prop(page: dict, prop: str) -> datetime | None:
    p = page.get("properties", {}).get(prop, {})
    date = p.get("date") if p.get("type") == "date" else None
    if not date:
        return None
    return parse_iso(date.get("end"))


def find_ddl_row_for(fired_at: datetime, ddl_rows: list[dict]) -> str | None:
    """Return the ID of the DDL row whose window covers `fired_at`, or None."""
    best: tuple[datetime, str] | None = None
    for row in ddl_rows:
        start = get_date_prop(row, "Start Time")
        if not start:
            continue
        end = get_date_prop(row, "End Time") or datetime.now(timezone.utc)
        # Allow a 60s slack on each side to catch alerts that fire just before/after
        window_start = start - timedelta(seconds=60)
        window_end = end + timedelta(seconds=60)
        if window_start <= fired_at <= window_end:
            # Prefer the most-recently-started matching window
            if best is None or start > best[0]:
                best = (start, row["id"])
    return best[1] if best else None


def alert_already_linked(alert: dict, prop_name: str) -> bool:
    rel = alert.get("properties", {}).get(prop_name, {})
    ids = rel.get("relation", []) if rel.get("type") == "relation" else []
    return len(ids) > 0


def main() -> int:
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(message)s",
    )
    ddl_ds = env("DDL_LOG_DS_ID")
    alerts_ds = env("ALERTS_DS_ID")
    rel_prop = env("ALERT_RELATION_PROP", "DDL Change")
    lookback_min = int(env("ALERTS_LOOKBACK_MIN", "60"))
    dry_run = env("DRY_RUN", "0") == "1"

    since = datetime.now(timezone.utc) - timedelta(minutes=lookback_min)
    logging.info(
        "correlating alerts fired since %s (lookback=%dmin, dry_run=%s)",
        since.isoformat(), lookback_min, dry_run,
    )

    # 1. Pull recent alerts
    alert_filter = {
        "property": "Fired At",
        "date": {"after": since.isoformat()},
    }
    try:
        alerts = query_ds(alerts_ds, alert_filter)
    except Exception as e:
        logging.error("failed to query alerts DB: %s", e)
        return 2
    logging.info("found %d recent alerts", len(alerts))

    # 2. Pull DDL log rows whose window could overlap (Start Time >= since - 24h)
    ddl_filter = {
        "property": "Start Time",
        "date": {"after": (since - timedelta(hours=24)).isoformat()},
    }
    try:
        ddl_rows = query_ds(ddl_ds, ddl_filter)
    except Exception as e:
        logging.error("failed to query DDL log: %s", e)
        return 2
    logging.info("candidate DDL rows: %d", len(ddl_rows))

    linked = skipped_already = skipped_no_match = 0
    for alert in alerts:
        fired = get_date_prop(alert, "Fired At")
        if not fired:
            continue
        if alert_already_linked(alert, rel_prop):
            skipped_already += 1
            continue
        ddl_id = find_ddl_row_for(fired, ddl_rows)
        if not ddl_id:
            skipped_no_match += 1
            continue
        title = ""
        title_prop = alert.get("properties", {}).get("Title", {})
        if title_prop.get("type") == "title":
            title = "".join(t.get("plain_text", "") for t in title_prop.get("title", []))
        logging.info("linking alert %s '%s' → DDL %s", alert["id"][:8], title, ddl_id[:8])
        if dry_run:
            linked += 1
            continue
        try:
            api("PATCH", f"/pages/{alert['id']}", {
                "properties": {rel_prop: {"relation": [{"id": ddl_id}]}}
            })
            linked += 1
        except Exception as e:
            logging.error("failed to update alert %s: %s", alert["id"], e)

    logging.info(
        "done: linked=%d already_linked=%d no_match=%d",
        linked, skipped_already, skipped_no_match,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
