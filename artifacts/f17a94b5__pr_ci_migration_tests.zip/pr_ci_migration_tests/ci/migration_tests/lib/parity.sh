# shellcheck shell=bash
# Row-count + rolling-hash parity between publisher and subscriber.
# Gap B in the coverage analysis, and playbook assertion 4.

parity::_row_hash() {
  # A stable rolling hash: md5 of concatenated md5s of full rows ordered by
  # primary key. Falls back to ctid ordering if the table has no PK.
  local uri="$1" table="$2"
  psql "$uri" -Atc "
    WITH pk AS (
      SELECT string_agg(quote_ident(a.attname), ',' ORDER BY x.n) AS cols
      FROM (
        SELECT unnest(conkey) WITH ORDINALITY AS (attnum, n), conrelid
        FROM pg_constraint
        WHERE contype = 'p' AND conrelid = '$table'::regclass
      ) x
      JOIN pg_attribute a ON a.attrelid = x.conrelid AND a.attnum = x.attnum
    )
    SELECT count(*) || ':' || COALESCE(md5(string_agg(row_md5, '' ORDER BY row_md5)), '<empty>')
    FROM (
      SELECT md5(t::text) AS row_md5 FROM $table t
    ) s;
  "
}

parity::verify() {
  local pub_uri="$1" sub_uri="$2" tables="$3"
  local fail=0
  local t p s
  echo "table|publisher|subscriber|status"
  for t in $tables; do
    p=$(parity::_row_hash "$pub_uri" "$t" 2>/dev/null || echo "ERR")
    s=$(parity::_row_hash "$sub_uri" "$t" 2>/dev/null || echo "ERR")
    if [[ "$p" == "$s" && "$p" != "ERR" ]]; then
      echo "$t|$p|$s|OK"
    else
      echo "$t|$p|$s|MISMATCH"
      fail=1
    fi
  done
  if (( fail )); then
    log ERR "parity mismatch detected"
    return 1
  fi
  log INFO "parity verified across ${tables} tables"
  return 0
}
