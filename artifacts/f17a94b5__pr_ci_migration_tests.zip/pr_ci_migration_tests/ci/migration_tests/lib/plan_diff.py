#!/usr/bin/env python3
"""Compare EXPLAIN (FORMAT JSON) captures and flag regressions.

Exit codes:
  0 - no regressions
  2 - regressions detected (build should fail)
  1 - internal error
"""
from __future__ import annotations
import argparse
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path


SCAN_NODES = {
    "Seq Scan", "Index Scan", "Index Only Scan", "Bitmap Heap Scan",
    "Bitmap Index Scan", "CTE Scan", "Subquery Scan", "Function Scan",
    "Values Scan", "Foreign Scan", "Sample Scan", "TID Scan",
}
JOIN_METHOD_RANK = {"Hash Join": 3, "Merge Join": 2, "Nested Loop": 1}


@dataclass
class PlanSummary:
    total_cost: float = 0.0
    startup_cost: float = 0.0
    plan_rows: float = 0.0
    seq_scans_by_rel: dict[str, int] = field(default_factory=dict)
    index_scans_by_rel: dict[str, int] = field(default_factory=dict)
    indexes_used: set[str] = field(default_factory=set)
    scan_count: int = 0
    node_types: dict[str, int] = field(default_factory=dict)
    joins: list[tuple[str, str]] = field(default_factory=list)  # (join_type, method)


def _walk(node: dict, s: PlanSummary):
    nt = node.get("Node Type", "?")
    s.node_types[nt] = s.node_types.get(nt, 0) + 1
    if nt in SCAN_NODES:
        s.scan_count += 1
        rel = node.get("Relation Name") or node.get("Alias") or "?"
        if nt == "Seq Scan":
            s.seq_scans_by_rel[rel] = s.seq_scans_by_rel.get(rel, 0) + 1
        elif nt in ("Index Scan", "Index Only Scan", "Bitmap Index Scan"):
            s.index_scans_by_rel[rel] = s.index_scans_by_rel.get(rel, 0) + 1
            if idx := node.get("Index Name"):
                s.indexes_used.add(idx)
    if "Join Type" in node:
        s.joins.append((node["Join Type"], nt))
    for child in node.get("Plans", []) or []:
        _walk(child, s)


def summarize(explain_json_text: str) -> PlanSummary:
    data = json.loads(explain_json_text)
    root = data[0] if isinstance(data, list) else data
    plan = root.get("Plan") if isinstance(root, dict) else None
    if not plan:
        raise ValueError("no Plan in EXPLAIN JSON")
    s = PlanSummary(
        total_cost=float(plan.get("Total Cost", 0.0)),
        startup_cost=float(plan.get("Startup Cost", 0.0)),
        plan_rows=float(plan.get("Plan Rows", 0.0)),
    )
    _walk(plan, s)
    return s


def _pct(before: float, after: float) -> float:
    if before <= 0:
        return 100.0 if after > 0 else 0.0
    return (after - before) / before * 100.0


@dataclass
class Finding:
    kind: str            # "cost" | "scan_nodes" | "seq_scan" | "index_lost" | "join_downgrade"
    detail: str
    severity: str        # "regress" | "info"


def compare(before: PlanSummary, after: PlanSummary,
            cost_pct_gate: float, nodes_pct_gate: float,
            strict: bool) -> list[Finding]:
    findings: list[Finding] = []

    cost_delta = _pct(before.total_cost, after.total_cost)
    if cost_delta > cost_pct_gate:
        findings.append(Finding("cost",
            f"total cost {before.total_cost:.1f} -> {after.total_cost:.1f} "
            f"(+{cost_delta:.1f}%, gate +{cost_pct_gate}%)", "regress"))

    nodes_delta = _pct(before.scan_count, after.scan_count)
    if nodes_delta > nodes_pct_gate:
        findings.append(Finding("scan_nodes",
            f"scan-node count {before.scan_count} -> {after.scan_count} "
            f"(+{nodes_delta:.1f}%, gate +{nodes_pct_gate}%)", "regress"))

    # Structural signals — these matter more than raw cost in practice.
    for rel, cnt in after.seq_scans_by_rel.items():
        prev = before.seq_scans_by_rel.get(rel, 0)
        if cnt > prev:
            findings.append(Finding("seq_scan",
                f"table '{rel}' now uses Seq Scan (was {prev}, now {cnt}); "
                f"an index may have been dropped or made unusable", "regress"))

    lost = before.indexes_used - after.indexes_used
    for idx in sorted(lost):
        findings.append(Finding("index_lost",
            f"index '{idx}' no longer chosen by the planner", "regress"))

    # Detect join-method downgrade on the same join type
    before_joins = {jt: JOIN_METHOD_RANK.get(m, 0) for jt, m in before.joins}
    after_joins  = {jt: JOIN_METHOD_RANK.get(m, 0) for jt, m in after.joins}
    for jt, rank in after_joins.items():
        if jt in before_joins and rank < before_joins[jt]:
            findings.append(Finding("join_downgrade",
                f"join '{jt}' downgraded (rank {before_joins[jt]} -> {rank}); "
                f"planner switched to a less scalable method", "regress"))

    # Non-strict default: require BOTH a cost regression AND a structural
    # signal before failing. This suppresses noise from planner cost jitter.
    if not strict:
        cost_regressions = [f for f in findings if f.kind == "cost"]
        structural = [f for f in findings if f.kind in
                      ("seq_scan", "index_lost", "join_downgrade", "scan_nodes")]
        if cost_regressions and not structural:
            # Demote to info
            for f in cost_regressions:
                f.severity = "info"
    return findings


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--before", required=True)
    ap.add_argument("--after", required=True)
    ap.add_argument("--baseline", default=None,
                    help="optional directory of committed baseline plans")
    ap.add_argument("--cost-threshold-pct", type=float, default=10.0)
    ap.add_argument("--nodes-threshold-pct", type=float, default=10.0)
    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--report", required=True)
    args = ap.parse_args()

    before_dir = Path(args.before)
    after_dir = Path(args.after)
    baseline_dir = Path(args.baseline) if args.baseline else None

    report: dict = {"queries": [], "gate_failed": False, "config": {
        "cost_threshold_pct": args.cost_threshold_pct,
        "nodes_threshold_pct": args.nodes_threshold_pct,
        "strict": args.strict,
    }}

    for after_path in sorted(after_dir.glob("*.json")):
        name = after_path.stem
        before_path = before_dir / after_path.name
        if not before_path.exists():
            report["queries"].append({"name": name, "status": "new_query", "findings": []})
            continue
        try:
            b = summarize(before_path.read_text())
            a = summarize(after_path.read_text())
        except Exception as e:
            report["queries"].append({"name": name, "status": "parse_error", "error": str(e)})
            continue
        findings = compare(b, a, args.cost_threshold_pct,
                           args.nodes_threshold_pct, args.strict)

        entry = {
            "name": name,
            "before": {"total_cost": b.total_cost, "scan_count": b.scan_count,
                       "indexes_used": sorted(b.indexes_used)},
            "after": {"total_cost": a.total_cost, "scan_count": a.scan_count,
                      "indexes_used": sorted(a.indexes_used)},
            "cost_delta_pct": round(_pct(b.total_cost, a.total_cost), 2),
            "nodes_delta_pct": round(_pct(b.scan_count, a.scan_count), 2),
            "findings": [f.__dict__ for f in findings],
            "status": "regress" if any(f.severity == "regress" for f in findings) else "ok",
        }

        # Extra: compare to committed baseline if present
        if baseline_dir and (baseline_dir / after_path.name).exists():
            try:
                base = summarize((baseline_dir / after_path.name).read_text())
                baseline_findings = compare(
                    base, a, args.cost_threshold_pct,
                    args.nodes_threshold_pct, args.strict)
                entry["baseline_status"] = ("regress"
                    if any(f.severity == "regress" for f in baseline_findings)
                    else "ok")
                entry["baseline_findings"] = [f.__dict__ for f in baseline_findings]
                if entry["baseline_status"] == "regress":
                    entry["status"] = "regress"
            except Exception as e:
                entry["baseline_error"] = str(e)

        if entry["status"] == "regress":
            report["gate_failed"] = True
        report["queries"].append(entry)

    Path(args.report).write_text(json.dumps(report, indent=2))

    # Human-readable summary to stderr
    print(f"\nplan-regression report -> {args.report}", file=sys.stderr)
    for q in report["queries"]:
        marker = {"regress": "✗", "ok": "✓", "new_query": "+", "parse_error": "?"}.get(q.get("status"), "?")
        cost = q.get("cost_delta_pct", "-"); nodes = q.get("nodes_delta_pct", "-")
        print(f"  {marker} {q['name']}  cost {cost}%  nodes {nodes}%", file=sys.stderr)
        for f in q.get("findings", []):
            if f["severity"] == "regress":
                print(f"      - [{f['kind']}] {f['detail']}", file=sys.stderr)

    sys.exit(2 if report["gate_failed"] else 0)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        print(f"plan_diff.py: internal error: {e}", file=sys.stderr)
        sys.exit(1)
