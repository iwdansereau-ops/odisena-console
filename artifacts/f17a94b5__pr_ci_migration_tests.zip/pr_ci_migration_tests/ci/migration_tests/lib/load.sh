# shellcheck shell=bash
# Background write load against the publisher. Gap A in the coverage analysis.
#
# Uses pgbench with -N (skip pgbench_tellers/branches updates -> more index
# activity) plus an optional custom script. If pgbench_accounts does not
# exist, initializes a minimal schema so tests run on any DB.

LOAD_PID=""

load::_ensure_bench_schema() {
  local uri="$1"
  local has
  has=$(psql "$uri" -Atc "SELECT to_regclass('public.pgbench_accounts') IS NOT NULL")
  if [[ "$has" != "t" ]]; then
    log INFO "initializing pgbench schema"
    pgbench -i -s "${LOAD_SCALE:-10}" "$uri" >/dev/null
  fi
}

load::start() {
  local uri="$1" clients="$2" duration="$3" logfile="$4"
  load::_ensure_bench_schema "$uri"

  # Custom mixed workload: reads + writes touching indexed columns and
  # holding brief transactions, which is what actually surfaces lock queue
  # issues. Written inline so no external file is needed.
  local script
  script=$(mktemp --suffix=.sql)
  cat > "$script" <<'SQL'
\set aid random(1, 100000 * :scale)
\set bid random(1, 1 * :scale)
\set delta random(-5000, 5000)
BEGIN;
SELECT abalance FROM pgbench_accounts WHERE aid = :aid;
UPDATE pgbench_accounts SET abalance = abalance + :delta WHERE aid = :aid;
INSERT INTO pgbench_history (tid, bid, aid, delta, mtime) VALUES (1, :bid, :aid, :delta, CURRENT_TIMESTAMP);
COMMIT;
SQL

  log INFO "starting background load: ${clients} clients for ${duration}s"
  ( pgbench -n -c "$clients" -j "$(( clients / 4 > 0 ? clients / 4 : 1 ))" \
      -T "$duration" -f "$script" "$uri" \
      > "$logfile" 2>&1 ) &
  LOAD_PID=$!
  # Confirm it started
  sleep 1
  if ! kill -0 "$LOAD_PID" 2>/dev/null; then
    log ERR "pgbench failed to start; see $logfile"
    return 1
  fi
  log INFO "load pid=$LOAD_PID"
}

load::stop() {
  [[ -n "$LOAD_PID" ]] || return 0
  if kill -0 "$LOAD_PID" 2>/dev/null; then
    kill "$LOAD_PID" 2>/dev/null || true
    wait "$LOAD_PID" 2>/dev/null || true
    log INFO "background load stopped"
  fi
  LOAD_PID=""
}
