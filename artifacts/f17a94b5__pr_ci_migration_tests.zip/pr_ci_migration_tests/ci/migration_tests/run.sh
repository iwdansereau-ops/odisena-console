#!/usr/bin/env bash
# ci/migration_tests/run.sh
#
# End-to-end migration test harness. Applies subscriber-then-publisher DDL
# through a safe wrapper against a publisher + logical subscriber, under
# concurrent write load, then verifies parity, rollback, and idempotency.
#
# Environment (all required unless noted):
#   PUB_URI            libpq URI for the publisher DB
#   SUB_URI            libpq URI for the subscriber DB
#   MIGRATION_DIR      dir containing NN_up.sql, NN_down.sql,
#                                     NN_sub_up.sql, NN_sub_down.sql
#   PARITY_TABLES      space-separated table names to check (optional; auto-detect if unset)
#   LOAD_DURATION      seconds of background load (default: 120)
#   LOAD_CLIENTS       pgbench -c (default: 20)
#   CATCHUP_TIMEOUT    seconds to wait for subscriber catch-up (default: 600)
#   LOCK_MAX_MS        max acceptable AccessExclusiveLock hold time in ms (default: 2000)
#   SLOT_WAL_MAX_MB    peak retained_wal ceiling in MiB (default: 5120)
#
# Exit codes:
#   0  all assertions passed
#   1  DDL failure or lock/replication assertion violation
#   2  parity mismatch
#   3  rollback or idempotency failure
#   4  environment / setup error

set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/log.sh
source "$HERE/lib/log.sh"
# shellcheck source=lib/ddl.sh
source "$HERE/lib/ddl.sh"
# shellcheck source=lib/load.sh
source "$HERE/lib/load.sh"
# shellcheck source=lib/parity.sh
source "$HERE/lib/parity.sh"
# shellcheck source=lib/replication.sh
source "$HERE/lib/replication.sh"
# shellcheck source=lib/locks.sh
source "$HERE/lib/locks.sh"
# shellcheck source=lib/plan_regression.sh
source "$HERE/lib/plan_regression.sh"
# shellcheck source=lib/notion_report.sh
source "$HERE/lib/notion_report.sh"

: "${PUB_URI:?PUB_URI required}"
: "${SUB_URI:?SUB_URI required}"
: "${MIGRATION_DIR:?MIGRATION_DIR required}"
[[ -d "$MIGRATION_DIR" ]] || { log ERR "MIGRATION_DIR not found: $MIGRATION_DIR"; exit 4; }

: "${LOAD_DURATION:=120}"
: "${LOAD_CLIENTS:=20}"
: "${CATCHUP_TIMEOUT:=600}"
: "${LOCK_MAX_MS:=2000}"
: "${SLOT_WAL_MAX_MB:=5120}"

# Plan-regression module
: "${KEY_QUERIES:=$HERE/key_queries.yml}"
: "${PLAN_COST_THRESHOLD_PCT:=10}"
: "${PLAN_NODES_THRESHOLD_PCT:=10}"
: "${PLAN_STRICT:=0}"
: "${PLAN_BASELINE_DIR:=}"
: "${PGSS_ENFORCE:=0}"
export PLAN_COST_THRESHOLD_PCT PLAN_NODES_THRESHOLD_PCT PLAN_STRICT PLAN_BASELINE_DIR PGSS_ENFORCE

ARTIFACTS="${GITHUB_WORKSPACE:-/tmp}/migration_test_artifacts"
mkdir -p "$ARTIFACTS"

cleanup() {
  local rc=$?
  load::stop || true
  locks::stop_watchdog || true
  replication::stop_monitor || true
  log INFO "artifacts written to $ARTIFACTS (exit=$rc)"
  return "$rc"
}
trap cleanup EXIT

RUN_START_ISO="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
export DDL_START_ISO="${DDL_START_ISO:-$RUN_START_ISO}"

log INFO "=== migration test starting ==="
log INFO "publisher=$(psql "$PUB_URI" -Atc "SELECT version()")"
log INFO "subscriber=$(psql "$SUB_URI" -Atc "SELECT version()")"

# --- 0. Verify publisher is a logical publisher and subscriber is subscribed
replication::assert_healthy || exit 4

# --- 1. Auto-detect parity tables if not provided (all tables in the publication)
if [[ -z "${PARITY_TABLES:-}" ]]; then
  PARITY_TABLES=$(psql "$PUB_URI" -Atc \
    "SELECT string_agg(schemaname||'.'||tablename, ' ')
     FROM pg_publication_tables
     WHERE pubname IN (SELECT pubname FROM pg_publication)")
fi
export PARITY_TABLES
log INFO "parity tables: ${PARITY_TABLES:-<none>}"

# --- 2. Start background load + monitors
load::start "$PUB_URI" "$LOAD_CLIENTS" "$LOAD_DURATION" "$ARTIFACTS/load.log"
locks::start_watchdog "$PUB_URI" "$LOCK_MAX_MS" "$ARTIFACTS/locks.jsonl"
replication::start_monitor "$PUB_URI" "$SLOT_WAL_MAX_MB" "$ARTIFACTS/replication.jsonl"

# Let load ramp up
sleep 3

# --- 2b. Capture pre-migration plans + pgss snapshot
if [[ -f "$KEY_QUERIES" ]]; then
  log INFO "capturing pre-migration plans from $KEY_QUERIES"
  plan_regression::capture "before" "$PUB_URI" "$KEY_QUERIES" "$ARTIFACTS/plans_before" || exit 4
  plan_regression::snapshot_pgss "before" "$PUB_URI" "$ARTIFACTS/pgss_before.json" || true
else
  log WARN "no key_queries.yml at $KEY_QUERIES; skipping plan-regression module"
fi

# --- 3. Apply subscriber-first additive DDL
for f in $(ls "$MIGRATION_DIR"/*_sub_up.sql 2>/dev/null | sort); do
  log INFO "sub  up: $(basename "$f")"
  ddl::apply_direct "$SUB_URI" "$f"
done

# --- 4. Apply publisher DDL through the safe wrapper (lock_timeout + retries)
for f in $(ls "$MIGRATION_DIR"/*_up.sql 2>/dev/null | grep -v _sub_up | sort); do
  log INFO "pub  up: $(basename "$f")"
  ddl::apply_with_retry "$PUB_URI" "$f" || { log ERR "DDL failed after retries"; exit 1; }
done

# --- 5. Wait for logical catch-up
replication::wait_for_catchup "$PUB_URI" "$CATCHUP_TIMEOUT" || exit 1

# --- 6. Assertion 4: row-count + rolling-hash parity
parity::verify "$PUB_URI" "$SUB_URI" "$PARITY_TABLES" > "$ARTIFACTS/parity_after_up.txt" || exit 2

# --- 7. Assertions 1,2,5: check that locks and replication stayed within bounds
locks::assert_no_long_hold "$ARTIFACTS/locks.jsonl" "$LOCK_MAX_MS" || exit 1
replication::assert_slot_healthy "$ARTIFACTS/replication.jsonl" "$SLOT_WAL_MAX_MB" || exit 1

# --- 8. Assertion detection of invalid indexes
ddl::assert_no_invalid_indexes "$PUB_URI" || exit 1
ddl::assert_no_invalid_indexes "$SUB_URI" || exit 1

# --- 8b. Plan-regression gate
if [[ -f "$KEY_QUERIES" ]]; then
  log INFO "capturing post-migration plans"
  plan_regression::capture "after" "$PUB_URI" "$KEY_QUERIES" "$ARTIFACTS/plans_after" || exit 4
  plan_regression::snapshot_pgss "after" "$PUB_URI" "$ARTIFACTS/pgss_after.json" || true
  plan_regression::compare \
    "$ARTIFACTS/plans_before" "$ARTIFACTS/plans_after" \
    "$ARTIFACTS/plan_regression.json" || exit 5
  plan_regression::diff_pgss \
    "$ARTIFACTS/pgss_before.json" "$ARTIFACTS/pgss_after.json" \
    "$ARTIFACTS/pgss_diff.json" || exit 5
fi

# --- 9. Assertion 6: run rollbacks, re-verify parity
for f in $(ls "$MIGRATION_DIR"/*_down.sql 2>/dev/null | grep -v _sub_down | sort -r); do
  log INFO "pub down: $(basename "$f")"
  ddl::apply_with_retry "$PUB_URI" "$f" || { log ERR "rollback failed"; exit 3; }
done
for f in $(ls "$MIGRATION_DIR"/*_sub_down.sql 2>/dev/null | sort -r); do
  log INFO "sub down: $(basename "$f")"
  ddl::apply_direct "$SUB_URI" "$f"
done
replication::wait_for_catchup "$PUB_URI" "$CATCHUP_TIMEOUT" || exit 3
parity::verify "$PUB_URI" "$SUB_URI" "$PARITY_TABLES" > "$ARTIFACTS/parity_after_down.txt" || exit 3

# --- 10. Assertion 7: re-apply up, confirm idempotency + parity again
for f in $(ls "$MIGRATION_DIR"/*_sub_up.sql 2>/dev/null | sort); do
  ddl::apply_direct "$SUB_URI" "$f"
done
for f in $(ls "$MIGRATION_DIR"/*_up.sql 2>/dev/null | grep -v _sub_up | sort); do
  ddl::apply_with_retry "$PUB_URI" "$f" || { log ERR "re-apply (idempotency) failed"; exit 3; }
done
replication::wait_for_catchup "$PUB_URI" "$CATCHUP_TIMEOUT" || exit 3
parity::verify "$PUB_URI" "$SUB_URI" "$PARITY_TABLES" > "$ARTIFACTS/parity_after_reup.txt" || exit 3

log INFO "=== all 7 assertions PASSED ==="

# --- 11. Post row to Notion DDL Change Log (best-effort, non-fatal)
export DDL_END_ISO="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
notion_report::post "$ARTIFACTS" || true
