"""
Generate a realistic benchmark dataset simulating 100 runs of a fixed CPU-intensive
workload (matrix multiply + prime sieve, roughly 2e9 CPU instructions) across
five CI environments.

Numeric anchors from published sources:
- GitHub Actions hosted: ~2.66% CoV (CodSpeed, 2025, 100-run study)
- AWS EC2 tuned dedicated host: ~0.56% CoV (MongoDB perf team methodology)
- Bare-metal self-hosted: <2% CoV, detectable regressions >=1.94% (arXiv 2411.05491)
- QEMU ARM-on-x86 (TCG): 8-12x slowdown vs native, elevated jitter from
  translation-cache warm-up
- Container with cgroup CPU quota: bimodal distribution due to throttling epochs

Instruction counts come from a Valgrind/cachegrind-like model where the baseline
is fully deterministic (RSD ~0%), with slight variance introduced by JIT/lib
version drift on hosted runners.
"""

import json
import math
import random
from pathlib import Path

random.seed(20260702)

# 100 runs per environment
N = 100

# Baseline: workload takes ~4.20s on a modern x86 core, executing ~2.05e9 instructions
BASELINE_WALL_SEC = 4.20
BASELINE_INSTRUCTIONS = 2_054_318_722


def sample_normal(mean: float, cov: float) -> float:
    """Sample from a normal distribution with a given mean and coefficient of variation."""
    return random.gauss(mean, mean * cov)


def sample_lognormal_right_tailed(mean: float, cov: float, tail_prob: float, tail_mult: float) -> float:
    """Normal distribution with a right-tailed outlier population.

    Roughly `tail_prob` fraction of samples are multiplied by `tail_mult`, modelling
    noisy-neighbor / preemption spikes typical of shared cloud runners.
    """
    base = random.gauss(mean, mean * cov)
    if random.random() < tail_prob:
        base *= tail_mult
    return base


def sample_bimodal(mean: float, quota_frac: float, throttled_mult: float, cov: float) -> float:
    """Bimodal distribution modelling cgroup CPU-quota throttling epochs."""
    if random.random() < quota_frac:
        m = mean * throttled_mult
    else:
        m = mean
    return random.gauss(m, m * cov)


ENVIRONMENTS = [
    {
        "id": "gh-hosted",
        "name": "GitHub Actions",
        "subtitle": "ubuntu-latest · standard hosted",
        "hardware": "Azure D2s v3 · 2 vCPU · 7 GB RAM",
        "cost_per_hour": 0.008,
        "provisioning": "Instant (managed)",
        "isolation": "Shared VM (noisy neighbours)",
        "wall_mean": BASELINE_WALL_SEC * 1.02,  # slight cloud tax
        "wall_sampler": lambda m: sample_lognormal_right_tailed(m, cov=0.0266, tail_prob=0.06, tail_mult=1.12),
        "instr_mean": BASELINE_INSTRUCTIONS,
        # Hosted runner image drift → tiny instruction-count variance from glibc/JIT
        "instr_cov": 0.0009,
    },
    {
        "id": "aws-ec2",
        "name": "AWS EC2",
        "subtitle": "c6i.4xlarge · dedicated host, tuned",
        "hardware": "Intel Ice Lake · 8 dedicated cores · CPU pinning + `performance` governor",
        "cost_per_hour": 0.680,
        "provisioning": "~2 min (Terraform)",
        "isolation": "Dedicated host, HT off, NUMA-bound",
        "wall_mean": BASELINE_WALL_SEC * 0.94,  # tuned Ice Lake is a bit faster
        "wall_sampler": lambda m: sample_normal(m, cov=0.0056),
        "instr_mean": BASELINE_INSTRUCTIONS,
        "instr_cov": 0.0001,
    },
    {
        "id": "bare-metal",
        "name": "Bare-Metal Self-Hosted",
        "subtitle": "on-prem Ryzen 9 7950X · isolated",
        "hardware": "AMD Zen 4 · 16 cores · SMT off · isolcpus=8-15",
        "cost_per_hour": 0.190,  # amortized capex + power
        "provisioning": "Physical — permanent",
        "isolation": "Single-tenant, kernel core-isolation",
        "wall_mean": BASELINE_WALL_SEC * 0.78,  # fastest silicon on the list
        "wall_sampler": lambda m: sample_normal(m, cov=0.0038),
        "instr_mean": BASELINE_INSTRUCTIONS,
        "instr_cov": 0.00005,
    },
    {
        "id": "qemu-arm",
        "name": "QEMU ARM-on-x86",
        "subtitle": "aarch64 guest · TCG software emulation",
        "hardware": "QEMU 8.2 TCG on x86_64 host · no KVM",
        "cost_per_hour": 0.012,
        "provisioning": "~30s (Docker)",
        "isolation": "Emulated CPU (dynamic binary translation)",
        "wall_mean": BASELINE_WALL_SEC * 9.4,  # ~9-10x slowdown consistent with Linaro
        # TCG translation cache warm-up produces the first-few-run bump + high steady-state jitter
        "wall_sampler": lambda m: sample_lognormal_right_tailed(m, cov=0.041, tail_prob=0.12, tail_mult=1.25),
        # Guest instruction count differs from host: ARM ISA emits ~1.42x more instructions
        # for the same workload (fewer complex addressing modes), and TCG adds helper calls.
        "instr_mean": int(BASELINE_INSTRUCTIONS * 1.42),
        "instr_cov": 0.0018,
    },
    {
        "id": "container",
        "name": "Container (cgroup quota)",
        "subtitle": "Docker · --cpus=2 --cpu-shares=512",
        "hardware": "Shared host · CFS bandwidth 200000/100000 µs",
        "cost_per_hour": 0.025,
        "provisioning": "~5s (pull + run)",
        "isolation": "cgroup v2 · CPU quota throttling",
        "wall_mean": BASELINE_WALL_SEC * 1.06,
        # Bimodal: ~18% of runs land in a quota-exhausted epoch and get throttled ~1.35x
        "wall_sampler": lambda m: sample_bimodal(m, quota_frac=0.18, throttled_mult=1.35, cov=0.019),
        "instr_mean": BASELINE_INSTRUCTIONS,
        "instr_cov": 0.0002,
    },
]


def summarize(values):
    xs = sorted(values)
    n = len(xs)
    mean = sum(xs) / n
    var = sum((x - mean) ** 2 for x in xs) / (n - 1)
    std = math.sqrt(var)
    cov = std / mean if mean else 0.0
    median = xs[n // 2] if n % 2 else 0.5 * (xs[n // 2 - 1] + xs[n // 2])
    p05 = xs[int(0.05 * n)]
    p95 = xs[int(0.95 * n) - 1]
    p99 = xs[int(0.99 * n) - 1]
    iqr = xs[int(0.75 * n) - 1] - xs[int(0.25 * n)]
    return {
        "n": n,
        "min": xs[0],
        "max": xs[-1],
        "mean": mean,
        "median": median,
        "std": std,
        "cov": cov,
        "p05": p05,
        "p95": p95,
        "p99": p99,
        "iqr": iqr,
        "range": xs[-1] - xs[0],
    }


def env_payload(env):
    wall = [max(0.05, env["wall_sampler"](env["wall_mean"])) for _ in range(N)]
    instr = [int(random.gauss(env["instr_mean"], env["instr_mean"] * env["instr_cov"])) for _ in range(N)]
    runs = [
        {"run": i + 1, "wall_sec": round(w, 4), "instructions": inst}
        for i, (w, inst) in enumerate(zip(wall, instr))
    ]
    wall_stats = summarize(wall)
    instr_stats = summarize(instr)
    # Cachegrind-style breakdown (mean values, deterministic under Valgrind)
    ir = instr_stats["mean"]
    cache = {
        "Ir": int(ir),  # instructions retired
        "I1_miss": int(ir * 0.00042),  # L1 instruction misses
        "LLi_miss": int(ir * 0.00003),  # last-level i-cache misses
        "Dr": int(ir * 0.31),  # data reads
        "D1r_miss": int(ir * 0.00580),
        "LLdr_miss": int(ir * 0.00019),
        "Dw": int(ir * 0.15),  # data writes
        "D1w_miss": int(ir * 0.00120),
        "LLdw_miss": int(ir * 0.00007),
    }
    # ARM-on-x86 pushes cache misses up because of code bloat + TCG helper calls
    if env["id"] == "qemu-arm":
        for k in list(cache.keys()):
            if "miss" in k:
                cache[k] = int(cache[k] * 1.9)
    # Cycles estimated: Ir + miss penalties (10 for L1, 200 for LLC)
    est_cycles = (
        cache["Ir"]
        + 10 * (cache["I1_miss"] + cache["D1r_miss"] + cache["D1w_miss"])
        + 200 * (cache["LLi_miss"] + cache["LLdr_miss"] + cache["LLdw_miss"])
    )
    # Score: composite of wall CoV (lower better) + instruction determinism.
    # Anchor 0.001 CoV = 100 (bare-metal territory), 0.05 CoV = 0.
    # Instruction determinism bonus up to +5. No cap on the raw score so
    # environments with lower CoV always sort above ones with higher CoV.
    cov = wall_stats["cov"]
    noise_score = max(0.0, 100.0 * (1.0 - (cov - 0.001) / 0.049))
    instr_bonus = max(0.0, 5.0 * (1.0 - instr_stats["cov"] / 0.002))
    noise_score = round(noise_score + instr_bonus, 1)
    # % chance of a false positive at a 2% regression gate — normal-approx two-sided
    # For CoV c and gate g on the mean of a *single* run (worst case), fp ~ 2*(1 - Φ(g/c))
    from statistics import NormalDist
    fp_rate_2pct = 2 * (1 - NormalDist(0, 1).cdf(0.02 / max(cov, 1e-6)))
    fp_rate_2pct = round(min(1.0, max(0.0, fp_rate_2pct)) * 100, 2)
    return {
        "id": env["id"],
        "name": env["name"],
        "subtitle": env["subtitle"],
        "hardware": env["hardware"],
        "cost_per_hour": env["cost_per_hour"],
        "provisioning": env["provisioning"],
        "isolation": env["isolation"],
        "runs": runs,
        "wall": wall_stats,
        "instructions": instr_stats,
        "cachegrind": cache,
        "estimated_cycles": est_cycles,
        "noise_score": noise_score,
        "false_positive_rate_pct": fp_rate_2pct,
    }


def main():
    data = {
        "generated_at": "2026-07-02T03:47:00-04:00",
        "workload": {
            "name": "cpu-mix-v3",
            "description": "512×512 f64 matmul (BLAS-agnostic naive triple loop) + Sieve of Eratosthenes up to 5,000,000. Single-threaded, warmed-up, three trim runs discarded.",
            "runs_per_env": N,
            "target_instructions": BASELINE_INSTRUCTIONS,
        },
        "environments": [env_payload(env) for env in ENVIRONMENTS],
    }
    out = Path(__file__).parent.parent / "client" / "src" / "data" / "benchmarks.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(data, indent=2))
    print(f"Wrote {out} — {out.stat().st_size:,} bytes")

    # Also print a quick summary
    for env in data["environments"]:
        print(
            f"{env['name']:28s} "
            f"median={env['wall']['median']:.3f}s  "
            f"CoV={env['wall']['cov']*100:.2f}%  "
            f"jitter(p95-p05)={env['wall']['p95']-env['wall']['p05']:.3f}s  "
            f"score={env['noise_score']}  "
            f"fp@2%={env['false_positive_rate_pct']}%"
        )


if __name__ == "__main__":
    main()
