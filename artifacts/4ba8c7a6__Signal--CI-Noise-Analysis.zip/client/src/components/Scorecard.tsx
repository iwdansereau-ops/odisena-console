import { Environment, ENV_COLORS } from "@/data/types";
import { Card } from "@/components/ui/card";
import { Sparkline } from "@/components/Sparkline";
import { fmtSec, fmtPct, scoreGrade } from "@/lib/format";

interface Props {
  envs: Environment[];
}

export function Scorecard({ envs }: Props) {
  return (
    <div className="overflow-x-auto -mx-6 md:mx-0">
      <div className="min-w-[900px] px-6 md:px-0">
        <div className="grid grid-cols-[minmax(200px,1.5fr)_80px_120px_140px_130px_130px_130px] gap-x-4 text-[11px] uppercase tracking-widest text-muted-foreground font-mono pb-3 border-b border-border">
          <div>environment</div>
          <div>grade</div>
          <div>score</div>
          <div className="text-right">median</div>
          <div className="text-right">CoV</div>
          <div className="text-right">jitter p95−p05</div>
          <div>trend · 100 runs</div>
        </div>
        {envs.map((env) => {
          const g = scoreGrade(env.noise_score);
          const c = ENV_COLORS[env.id].light;
          const gradeColor =
            g.tone === "excellent"
              ? "text-emerald-500 border-emerald-500/40 bg-emerald-500/10"
              : g.tone === "good"
              ? "text-primary border-primary/40 bg-primary/10"
              : g.tone === "fair"
              ? "text-amber-500 border-amber-500/40 bg-amber-500/10"
              : "text-rose-500 border-rose-500/40 bg-rose-500/10";
          return (
            <div
              key={env.id}
              className="grid grid-cols-[minmax(200px,1.5fr)_80px_120px_140px_130px_130px_130px] gap-x-4 items-center py-4 border-b border-border/60 hover-elevate rounded-sm"
              data-testid={`scorecard-row-${env.id}`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <span className="h-8 w-1 rounded-full shrink-0" style={{ background: c }} />
                <div className="min-w-0">
                  <div className="text-sm font-medium truncate">{env.name}</div>
                  <div className="text-[11px] text-muted-foreground font-mono truncate">{env.subtitle}</div>
                </div>
              </div>
              <div>
                <span className={`inline-flex items-center justify-center px-2 py-0.5 rounded-sm border font-mono text-[13px] font-semibold ${gradeColor}`}>
                  {g.grade}
                </span>
              </div>
              <div className="font-mono text-lg font-semibold">
                {env.noise_score.toFixed(1)}
                <span className="text-muted-foreground text-xs font-normal ml-0.5">/100</span>
              </div>
              <div className="text-right font-mono text-sm">{fmtSec(env.wall.median, 3)}</div>
              <div className="text-right font-mono text-sm">
                <span className={env.wall.cov < 0.01 ? "text-emerald-500" : env.wall.cov < 0.03 ? "text-foreground" : "text-rose-500"}>
                  {fmtPct(env.wall.cov)}
                </span>
              </div>
              <div className="text-right font-mono text-sm">{fmtSec(env.wall.p95 - env.wall.p05, 3)}</div>
              <div>
                <Sparkline
                  values={env.runs.map((r) => r.wall_sec)}
                  color={c}
                  width={130}
                  height={36}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
