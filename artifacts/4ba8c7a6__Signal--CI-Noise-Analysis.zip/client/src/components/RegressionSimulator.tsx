import { useState } from "react";
import { Environment, ENV_COLORS } from "@/data/types";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { fmtPct } from "@/lib/format";

// Standard normal CDF (Abramowitz & Stegun 26.2.17 approximation)
function normalCDF(z: number): number {
  const t = 1 / (1 + 0.2316419 * Math.abs(z));
  const d = 0.3989423 * Math.exp(-(z * z) / 2);
  const p =
    d * t *
    (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return z > 0 ? 1 - p : p;
}

function fpRate(cov: number, gatePct: number): number {
  const z = gatePct / 100 / Math.max(cov, 1e-6);
  return 2 * (1 - normalCDF(z));
}

interface Props {
  envs: Environment[];
}

export function RegressionSimulator({ envs }: Props) {
  const [gate, setGate] = useState(2);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_380px] gap-6">
      <Card className="p-6 border-border">
        <div className="grid grid-cols-[minmax(200px,1.5fr)_100px_1fr_100px] gap-x-4 text-[11px] uppercase tracking-widest text-muted-foreground font-mono pb-3 border-b border-border">
          <div>environment</div>
          <div className="text-right">CoV</div>
          <div>false positive @ {gate.toFixed(1)}%</div>
          <div className="text-right">rate</div>
        </div>
        {envs.map((env) => {
          const rate = fpRate(env.wall.cov, gate);
          const c = ENV_COLORS[env.id].light;
          const tone = rate < 0.01 ? "text-emerald-500" : rate < 0.1 ? "text-amber-500" : "text-rose-500";
          return (
            <div
              key={env.id}
              className="grid grid-cols-[minmax(200px,1.5fr)_100px_1fr_100px] gap-x-4 items-center py-3 border-b border-border/60"
              data-testid={`sim-row-${env.id}`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <span className="h-6 w-1 rounded-full shrink-0" style={{ background: c }} />
                <span className="text-sm font-medium truncate">{env.name}</span>
              </div>
              <div className="text-right font-mono text-xs text-muted-foreground">
                {fmtPct(env.wall.cov)}
              </div>
              <div>
                <div className="relative h-3 rounded-sm bg-muted/60 overflow-hidden">
                  <div
                    className="absolute inset-y-0 left-0"
                    style={{
                      width: `${Math.min(100, rate * 100)}%`,
                      background: rate < 0.01 ? "hsl(158 64% 40%)" : rate < 0.1 ? "hsl(32 95% 50%)" : "hsl(340 82% 55%)",
                    }}
                  />
                </div>
              </div>
              <div className={`text-right font-mono text-sm ${tone}`}>
                {(rate * 100).toFixed(rate < 0.001 ? 3 : 2)}%
              </div>
            </div>
          );
        })}
      </Card>

      <div className="space-y-4">
        <Card className="p-5 border-border">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono mb-3">
            regression gate
          </div>
          <div className="font-mono text-3xl font-semibold" style={{ color: "hsl(var(--primary))" }}>
            {gate.toFixed(1)}%
          </div>
          <div className="text-xs text-muted-foreground mt-1 mb-4">
            deviation from baseline mean that fails the run
          </div>
          <Slider
            value={[gate]}
            onValueChange={(v) => setGate(v[0])}
            min={0.5}
            max={15}
            step={0.1}
            data-testid="slider-gate"
          />
          <div className="flex justify-between text-[10px] text-muted-foreground font-mono mt-2">
            <span>0.5%</span>
            <span>15%</span>
          </div>
        </Card>

        <Card className="p-5 border-border">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono mb-2">
            interpretation
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            A tight gate catches small regressions but only works on quiet runners. A loose gate
            works everywhere but misses real degradations. The math is unforgiving: at a{" "}
            <span className="text-foreground font-mono">{gate.toFixed(1)}%</span> gate, an
            environment with 3% CoV will fire spurious alerts on roughly{" "}
            <span className="text-foreground font-mono">
              {(fpRate(0.03, gate) * 100).toFixed(0)}%
            </span>{" "}
            of clean runs. Use cachegrind's deterministic instruction count as the primary gate;
            keep wall-clock as advisory.
          </p>
        </Card>
      </div>
    </div>
  );
}
