import { Environment, ENV_COLORS } from "@/data/types";
import { fmtSec } from "@/lib/format";

interface BoxPlotProps {
  envs: Environment[];
  logScale?: boolean;
}

/** Horizontal box-and-whisker plot showing wall-clock distribution per environment. */
export function BoxPlot({ envs, logScale = false }: BoxPlotProps) {
  const allValues = envs.flatMap((e) => e.runs.map((r) => r.wall_sec));
  let xmin = Math.min(...allValues);
  let xmax = Math.max(...allValues);
  const pad = (xmax - xmin) * 0.03;
  xmin = Math.max(0.01, xmin - pad);
  xmax = xmax + pad;

  const scale = (v: number) => {
    if (logScale) {
      const lmin = Math.log10(xmin);
      const lmax = Math.log10(xmax);
      return ((Math.log10(v) - lmin) / (lmax - lmin)) * 100;
    }
    return ((v - xmin) / (xmax - xmin)) * 100;
  };

  const rowHeight = 68;

  // Compute nice tick positions
  const ticks = logScale
    ? [1, 2, 5, 10, 20, 50, 100].filter((t) => t >= xmin && t <= xmax)
    : (() => {
        const range = xmax - xmin;
        const step = range / 6;
        const out: number[] = [];
        for (let t = Math.ceil(xmin / step) * step; t <= xmax; t += step) out.push(Number(t.toFixed(2)));
        return out;
      })();

  return (
    <div className="w-full">
      {/* Axis */}
      <div className="relative ml-[172px] mr-4 mb-2 h-4 text-[10px] text-muted-foreground font-mono">
        {ticks.map((t) => (
          <span
            key={t}
            className="absolute -translate-x-1/2"
            style={{ left: `${scale(t)}%` }}
          >
            {t.toFixed(t < 10 ? 1 : 0)}s
          </span>
        ))}
      </div>
      <div className="relative">
        {envs.map((env, idx) => {
          const c = ENV_COLORS[env.id]?.light ?? "hsl(var(--primary))";
          const { min, max, median, p05, p95 } = env.wall;
          const q1 = env.wall.median - env.wall.iqr / 2;
          const q3 = env.wall.median + env.wall.iqr / 2;
          return (
            <div
              key={env.id}
              className="grid grid-cols-[172px_1fr] items-center border-t border-border/60"
              style={{ height: rowHeight }}
              data-testid={`box-${env.id}`}
            >
              {/* Label */}
              <div className="pr-4">
                <div className="text-sm font-medium truncate">{env.name}</div>
                <div className="text-[11px] text-muted-foreground font-mono mt-0.5">
                  CoV {(env.wall.cov * 100).toFixed(2)}%
                </div>
              </div>
              {/* Plot */}
              <div className="relative h-full mr-4">
                {/* whisker line */}
                <div
                  className="absolute top-1/2 h-px -translate-y-1/2"
                  style={{
                    left: `${scale(p05)}%`,
                    width: `${scale(p95) - scale(p05)}%`,
                    background: c,
                    opacity: 0.5,
                  }}
                />
                {/* full range as fainter line */}
                <div
                  className="absolute top-1/2 h-px -translate-y-1/2"
                  style={{
                    left: `${scale(min)}%`,
                    width: `${scale(max) - scale(min)}%`,
                    background: c,
                    opacity: 0.2,
                  }}
                />
                {/* min tick */}
                <div className="absolute top-1/2 -translate-y-1/2 w-px h-3" style={{ left: `${scale(min)}%`, background: c, opacity: 0.5 }} />
                {/* max tick */}
                <div className="absolute top-1/2 -translate-y-1/2 w-px h-3" style={{ left: `${scale(max)}%`, background: c, opacity: 0.5 }} />
                {/* IQR box */}
                <div
                  className="absolute top-1/2 h-7 -translate-y-1/2 rounded-sm border"
                  style={{
                    left: `${scale(q1)}%`,
                    width: `${Math.max(0.4, scale(q3) - scale(q1))}%`,
                    background: c,
                    opacity: 0.28,
                    borderColor: c,
                  }}
                />
                {/* median line */}
                <div
                  className="absolute top-1/2 h-8 -translate-y-1/2 w-[2px] rounded-full"
                  style={{ left: `${scale(median)}%`, background: c }}
                  title={`median ${fmtSec(median)}`}
                />
                {/* individual sample dots (subsample so we don't overdraw) */}
                {env.runs.filter((_, i) => i % 3 === 0).map((r, i) => (
                  <div
                    key={i}
                    className="absolute top-1/2 -translate-y-1/2 w-1 h-1 rounded-full"
                    style={{
                      left: `${scale(r.wall_sec)}%`,
                      background: c,
                      opacity: 0.55,
                      transform: `translate(-50%, ${((i * 7) % 5 - 2) * 4}px)`,
                    }}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
