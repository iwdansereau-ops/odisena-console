import { Environment, ENV_COLORS } from "@/data/types";
import { fmtInstructions } from "@/lib/format";

interface Props {
  envs: Environment[];
}

/**
 * Bar chart comparing mean instruction counts (from Valgrind/cachegrind).
 * Lower CoV = more deterministic. Bar width encodes count, sub-bar encodes CoV.
 */
export function InstructionChart({ envs }: Props) {
  const max = Math.max(...envs.map((e) => e.instructions.mean));
  return (
    <div className="space-y-4">
      {envs.map((env) => {
        const c = ENV_COLORS[env.id]?.light ?? "hsl(var(--primary))";
        const pct = (env.instructions.mean / max) * 100;
        const covPct = env.instructions.cov * 100;
        return (
          <div key={env.id} className="grid grid-cols-[172px_1fr_92px] gap-4 items-center">
            <div className="min-w-0">
              <div className="text-sm font-medium truncate">{env.name}</div>
              <div className="text-[11px] text-muted-foreground font-mono">
                {fmtInstructions(env.instructions.mean)}
              </div>
            </div>
            <div className="relative h-7 rounded-sm bg-muted/50 overflow-hidden">
              <div
                className="absolute inset-y-0 left-0 rounded-sm"
                style={{ width: `${pct}%`, background: c, opacity: 0.9 }}
              />
              {/* CoV overlay marker */}
              <div
                className="absolute inset-y-0 border-r border-dashed opacity-70"
                style={{
                  left: `${pct * (1 - env.instructions.cov * 3)}%`,
                  borderColor: "hsl(var(--foreground))",
                }}
              />
            </div>
            <div className="font-mono text-xs text-right">
              <span className={covPct < 0.05 ? "text-emerald-500" : covPct < 0.5 ? "text-foreground" : "text-rose-500"}>
                σ {covPct.toFixed(3)}%
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
