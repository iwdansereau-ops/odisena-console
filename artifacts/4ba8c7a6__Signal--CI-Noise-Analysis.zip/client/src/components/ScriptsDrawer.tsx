import { useState } from "react";
import { Environment, ENV_COLORS } from "@/data/types";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";

interface Props {
  open: boolean;
  onClose: () => void;
  envs: Environment[];
}

const SCRIPTS: Record<string, { title: string; script: string }> = {
  "gh-hosted": {
    title: ".github/workflows/benchmark.yml",
    script: `# GitHub-hosted Actions runner (standard, ubuntu-latest)
# WARNING: shared Azure VM, ~2.66% CoV expected.
name: bench
on: [push]
jobs:
  bench:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Install valgrind
        run: sudo apt-get update && sudo apt-get install -y valgrind
      - name: Warm-up
        run: for i in 1 2 3; do ./bench/cpu-mix > /dev/null; done
      - name: Wall-clock (100 runs)
        run: |
          for i in $(seq 1 100); do
            /usr/bin/time -f "%e" ./bench/cpu-mix 2>> wall.txt > /dev/null
          done
      - name: Cachegrind (deterministic instruction count)
        run: |
          valgrind --tool=cachegrind --cachegrind-out-file=cg.out ./bench/cpu-mix
          cg_annotate cg.out --auto=no > cachegrind.txt
      - uses: actions/upload-artifact@v4
        with: { name: results, path: "wall.txt cachegrind.txt" }`,
  },
  "aws-ec2": {
    title: "aws-ec2-dedicated.sh",
    script: `#!/usr/bin/env bash
# AWS EC2 c6i.4xlarge on a Dedicated Host, tuned per MongoDB perf methodology.
# Target: <1% CoV.
set -euo pipefail

# --- One-time tuning (run at instance bring-up) ---
# Pin CPU governor
sudo cpupower frequency-set -g performance
# Disable hyperthreading
echo off | sudo tee /sys/devices/system/cpu/smt/control
# Disable NUMA balancing + swap
echo 0 | sudo tee /proc/sys/kernel/numa_balancing
sudo swapoff -a
# Disable ASLR for repeatability
echo 0 | sudo tee /proc/sys/kernel/randomize_va_space

# --- Benchmark ---
# Pin to isolated cores 4-7 on NUMA node 0
CORES=4-7
for i in $(seq 1 100); do
  numactl --cpunodebind=0 --membind=0 \\
    taskset -c $CORES \\
    /usr/bin/time -f "%e" ./bench/cpu-mix 2>> wall.txt > /dev/null
done

# Cachegrind
valgrind --tool=cachegrind \\
  --cachegrind-out-file=cg.out \\
  taskset -c $CORES ./bench/cpu-mix
cg_annotate cg.out --auto=no > cachegrind.txt`,
  },
  "bare-metal": {
    title: "self-hosted-runner.sh",
    script: `#!/usr/bin/env bash
# On-prem bare-metal self-hosted runner. Ryzen 9 7950X, 16C/32T with SMT off.
# Target: <0.5% CoV — best-in-class.
set -euo pipefail

# --- Boot flags (in /etc/default/grub) ---
# GRUB_CMDLINE_LINUX="isolcpus=8-15 nohz_full=8-15 rcu_nocbs=8-15 intel_pstate=disable"

# --- Runtime tuning ---
sudo cpupower frequency-set -g performance
echo off | sudo tee /sys/devices/system/cpu/smt/control
# Kick systemd services off isolated cores
sudo systemctl set-property --runtime -- system.slice AllowedCPUs=0-7
sudo systemctl set-property --runtime -- user.slice AllowedCPUs=0-7

# --- Benchmark on isolated cores ---
for i in $(seq 1 100); do
  chrt -f 99 taskset -c 8-11 \\
    /usr/bin/time -f "%e" ./bench/cpu-mix 2>> wall.txt > /dev/null
  sleep 0.5   # let cache line up between runs
done

# Cachegrind — instruction count is fully deterministic here
valgrind --tool=cachegrind --cachegrind-out-file=cg.out \\
  taskset -c 8-11 ./bench/cpu-mix
cg_annotate cg.out --auto=no > cachegrind.txt`,
  },
  "qemu-arm": {
    title: "qemu-aarch64.sh",
    script: `#!/usr/bin/env bash
# QEMU aarch64 TCG on x86_64 host (no KVM — pure software emulation).
# Expect ~9-10x slowdown and elevated jitter from translation-cache warm-up.
set -euo pipefail

# Cross-compile the workload for aarch64
aarch64-linux-gnu-gcc -O2 -static bench/cpu-mix.c -o bench/cpu-mix-arm64

# Warm the TCG translation cache
for i in 1 2 3 4 5; do
  qemu-aarch64 -cpu cortex-a72 ./bench/cpu-mix-arm64 > /dev/null
done

for i in $(seq 1 100); do
  /usr/bin/time -f "%e" \\
    qemu-aarch64 -cpu cortex-a72 ./bench/cpu-mix-arm64 \\
    2>> wall.txt > /dev/null
done

# Cachegrind of the guest binary (via QEMU-cross valgrind)
# NOTE: instruction count reflects the ARM ISA, not x86 host.
valgrind --tool=cachegrind --cachegrind-out-file=cg.out \\
  qemu-aarch64 -cpu cortex-a72 ./bench/cpu-mix-arm64
cg_annotate cg.out --auto=no > cachegrind.txt`,
  },
  "container": {
    title: "docker-cgroup-quota.sh",
    script: `#!/usr/bin/env bash
# Docker container with CFS bandwidth throttling — the pathological case.
# Bimodal wall-clock: normal + throttled epochs when quota exhausts.
set -euo pipefail

docker run --rm \\
  --cpus="2.0" \\
  --cpu-shares=512 \\
  --cpu-period=100000 --cpu-quota=200000 \\
  -v "$PWD:/work" -w /work \\
  ubuntu:24.04 bash -c '
    apt-get update -qq && apt-get install -y -qq valgrind time
    for i in $(seq 1 100); do
      /usr/bin/time -f "%e" ./bench/cpu-mix 2>> wall.txt > /dev/null
    done
    valgrind --tool=cachegrind --cachegrind-out-file=cg.out ./bench/cpu-mix
    cg_annotate cg.out --auto=no > cachegrind.txt
  '`,
  },
};

export function ScriptsDrawer({ open, onClose, envs }: Props) {
  const [active, setActive] = useState(envs[0]?.id ?? "");
  const [copied, setCopied] = useState<string | null>(null);
  const script = SCRIPTS[active];

  const copy = () => {
    navigator.clipboard.writeText(script.script);
    setCopied(active);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <Sheet open={open} onOpenChange={(v) => !v && onClose()}>
      <SheetContent side="right" className="w-full sm:max-w-[720px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Collection scripts</SheetTitle>
          <SheetDescription>
            Exact shell used to collect each environment's dataset. Copy, adapt, run.
          </SheetDescription>
        </SheetHeader>
        <div className="mt-6">
          <div className="flex flex-wrap gap-1 mb-4">
            {envs.map((env) => (
              <button
                key={env.id}
                onClick={() => setActive(env.id)}
                data-testid={`script-tab-${env.id}`}
                className={`px-3 py-1.5 rounded-sm text-xs font-medium border transition-colors ${
                  active === env.id
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-transparent text-muted-foreground border-border hover:border-primary/50 hover:text-foreground"
                }`}
              >
                <span
                  className="inline-block w-2 h-2 rounded-full mr-2 align-middle"
                  style={{ background: ENV_COLORS[env.id].light }}
                />
                {env.name}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between mb-2">
            <code className="text-xs font-mono text-muted-foreground">{script?.title}</code>
            <Button size="sm" variant="ghost" onClick={copy} className="gap-2 text-xs" data-testid="button-copy-script">
              {copied === active ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
              {copied === active ? "copied" : "copy"}
            </Button>
          </div>
          <pre className="text-[11.5px] font-mono leading-relaxed p-4 rounded-md bg-muted/40 border border-border overflow-x-auto whitespace-pre">
{script?.script}
          </pre>
        </div>
      </SheetContent>
    </Sheet>
  );
}
