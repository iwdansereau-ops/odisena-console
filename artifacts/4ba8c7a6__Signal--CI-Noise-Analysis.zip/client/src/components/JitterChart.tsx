import { Environment, ENV_COLORS } from "@/data/types";
import { useMemo } from "react";
import { fmtSec } from "@/lib/format";

interface Props {
  env: Environment;
  height?: number;
}

/** Run-vs-time scatter showing per-run wall clock, with median + p05/p95 band. */
export function JitterChart({ env, height = 180 }: Props) {
  const c = ENV_COLORS[env.id]?.light ?? "hsl(var(--primary))";

  const { paddedMin, paddedMax } = useMemo(() => {
    const vals = env.runs.map((r) => r.wall_sec);
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const pad = (max - min) * 0.15 || max * 0.02;
    return { paddedMin: min - pad, paddedMax: max + pad };
  }, [env]);

  const width = 560;
  const paddingLeft = 44;
  const paddingRight = 8;
  const paddingTop = 8;
  const paddingBottom = 20;
  const plotW = width - paddingLeft - paddingRight;
  const plotH = height - paddingTop - paddingBottom;

  const xScale = (i: number) => paddingLeft + (i / (env.runs.length - 1)) * plotW;
  const yScale = (v: number) => paddingTop + (1 - (v - paddedMin) / (paddedMax - paddedMin)) * plotH;

  const yTicks = 4;
  const ticks: number[] = [];
  for (let i = 0; i <= yTicks; i++) {
    ticks.push(paddedMin + ((paddedMax - paddedMin) * i) / yTicks);
  }

  const { median, p05, p95 } = env.wall;

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className="w-full h-auto"
      preserveAspectRatio="xMidYMid meet"
    >
      {/* Grid */}
      {ticks.map((t) => (
        <g key={t}>
          <line
            x1={paddingLeft}
            x2={width - paddingRight}
            y1={yScale(t)}
            y2={yScale(t)}
            stroke="hsl(var(--border))"
            strokeWidth={0.5}
            strokeDasharray="2 2"
          />
          <text
            x={paddingLeft - 6}
            y={yScale(t) + 3}
            fontSize="9"
            textAnchor="end"
            fill="hsl(var(--muted-foreground))"
            fontFamily="var(--font-mono)"
          >
            {t.toFixed(2)}s
          </text>
        </g>
      ))}

      {/* p05-p95 band */}
      <rect
        x={paddingLeft}
        y={yScale(p95)}
        width={plotW}
        height={yScale(p05) - yScale(p95)}
        fill={c}
        opacity={0.09}
      />

      {/* median line */}
      <line
        x1={paddingLeft}
        x2={width - paddingRight}
        y1={yScale(median)}
        y2={yScale(median)}
        stroke={c}
        strokeWidth={1}
        strokeDasharray="4 3"
        opacity={0.6}
      />

      {/* dots */}
      {env.runs.map((r) => (
        <circle
          key={r.run}
          cx={xScale(r.run - 1)}
          cy={yScale(r.wall_sec)}
          r={1.75}
          fill={c}
          opacity={0.75}
        >
          <title>{`Run #${r.run}: ${fmtSec(r.wall_sec, 4)}`}</title>
        </circle>
      ))}

      {/* Bottom axis */}
      <text
        x={paddingLeft}
        y={height - 4}
        fontSize="9"
        fill="hsl(var(--muted-foreground))"
        fontFamily="var(--font-mono)"
      >
        run 1
      </text>
      <text
        x={width - paddingRight}
        y={height - 4}
        fontSize="9"
        textAnchor="end"
        fill="hsl(var(--muted-foreground))"
        fontFamily="var(--font-mono)"
      >
        run {env.runs.length}
      </text>
    </svg>
  );
}
