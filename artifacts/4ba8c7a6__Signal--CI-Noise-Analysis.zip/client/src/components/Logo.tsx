export function Logo({ className = "h-6 w-6" }: { className?: string }) {
  // Signal-through-noise: three ascending bars (signal) inside a squared frame,
  // with a scan line crossing them. Paul Rand geometry, single accent color.
  return (
    <svg
      viewBox="0 0 24 24"
      className={className}
      aria-label="Signal — CI noise analysis"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect x="2" y="2" width="20" height="20" rx="4" stroke="currentColor" strokeWidth="1.5" />
      <path d="M6 15 L10 11 L14 13 L18 8" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" strokeLinejoin="miter" />
      <circle cx="18" cy="8" r="1.5" fill="currentColor" />
      <line x1="2" y1="18" x2="22" y2="18" stroke="currentColor" strokeWidth="1" strokeDasharray="2 2" opacity="0.4" />
    </svg>
  );
}
