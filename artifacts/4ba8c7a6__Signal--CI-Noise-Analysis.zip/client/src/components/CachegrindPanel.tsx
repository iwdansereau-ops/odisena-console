import { Environment } from "@/data/types";
import { Card } from "@/components/ui/card";
import { fmtInstructions, fmtNum } from "@/lib/format";

interface Props {
  env: Environment;
}

export function CachegrindPanel({ env }: Props) {
  const cg = env.cachegrind;
  const rows: [string, string, number, string][] = [
    ["Ir", "Instructions retired", cg.Ir, ""],
    ["I1_miss", "L1 instruction cache misses", cg.I1_miss, `${((cg.I1_miss / cg.Ir) * 100).toFixed(3)}% of Ir`],
    ["LLi_miss", "Last-level i-cache misses", cg.LLi_miss, `${((cg.LLi_miss / cg.Ir) * 100).toFixed(4)}% of Ir`],
    ["Dr", "Data reads", cg.Dr, `${((cg.Dr / cg.Ir) * 100).toFixed(1)}% of Ir`],
    ["D1r_miss", "L1 data read misses", cg.D1r_miss, `${((cg.D1r_miss / cg.Dr) * 100).toFixed(3)}% of Dr`],
    ["LLdr_miss", "LL data read misses", cg.LLdr_miss, `${((cg.LLdr_miss / cg.Dr) * 100).toFixed(4)}% of Dr`],
    ["Dw", "Data writes", cg.Dw, `${((cg.Dw / cg.Ir) * 100).toFixed(1)}% of Ir`],
    ["D1w_miss", "L1 data write misses", cg.D1w_miss, `${((cg.D1w_miss / cg.Dw) * 100).toFixed(3)}% of Dw`],
    ["LLdw_miss", "LL data write misses", cg.LLdw_miss, `${((cg.LLdw_miss / cg.Dw) * 100).toFixed(4)}% of Dw`],
  ];
  return (
    <Card className="p-5 border-border">
      <div className="flex items-baseline justify-between mb-4">
        <div>
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono">
            cachegrind — {env.name}
          </div>
          <div className="text-sm text-muted-foreground mt-1">
            estimated cycles: <span className="font-mono text-foreground">{fmtInstructions(env.estimated_cycles)}</span>
          </div>
        </div>
      </div>
      <div className="divide-y divide-border">
        {rows.map(([k, desc, val, ratio]) => (
          <div key={k} className="grid grid-cols-[80px_1fr_auto] gap-3 py-2 items-baseline">
            <code className="text-xs font-mono text-primary">{k}</code>
            <div className="text-xs text-muted-foreground truncate">{desc}</div>
            <div className="text-right">
              <div className="font-mono text-sm">{fmtNum(val)}</div>
              {ratio && <div className="text-[10px] text-muted-foreground font-mono">{ratio}</div>}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
