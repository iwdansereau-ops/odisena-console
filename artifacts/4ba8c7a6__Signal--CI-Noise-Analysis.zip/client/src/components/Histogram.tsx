import { Environment, ENV_COLORS } from "@/data/types";

interface Props {
  env: Environment;
  bins?: number;
  height?: number;
}

export function Histogram({ env, bins = 24, height = 100 }: Props) {
  const c = ENV_COLORS[env.id]?.light ?? "hsl(var(--primary))";
  const vals = env.runs.map((r) => r.wall_sec);
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  const step = (max - min) / bins || 1;
  const counts = new Array(bins).fill(0);
  vals.forEach((v) => {
    const bi = Math.min(bins - 1, Math.floor((v - min) / step));
    counts[bi]++;
  });
  const maxC = Math.max(...counts);
  const barW = 100 / bins;

  return (
    <svg viewBox={`0 0 100 ${height}`} className="w-full h-auto" preserveAspectRatio="none">
      {counts.map((n, i) => {
        const h = (n / maxC) * (height - 4);
        return (
          <rect
            key={i}
            x={i * barW + 0.15}
            y={height - h}
            width={barW - 0.3}
            height={h}
            fill={c}
            opacity={0.75}
          />
        );
      })}
    </svg>
  );
}
