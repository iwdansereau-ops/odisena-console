interface SparklineProps {
  values: number[];
  color: string;
  width?: number;
  height?: number;
  showBand?: boolean;
}

export function Sparkline({ values, color, width = 220, height = 42, showBand = true }: SparklineProps) {
  if (values.length === 0) return null;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const dx = width / (values.length - 1 || 1);
  const points = values.map((v, i) => [i * dx, height - ((v - min) / range) * (height - 4) - 2] as const);
  const path = points.map(([x, y], i) => (i === 0 ? `M${x},${y}` : `L${x},${y}`)).join(" ");
  const sorted = [...values].sort((a, b) => a - b);
  const p05 = sorted[Math.floor(0.05 * sorted.length)];
  const p95 = sorted[Math.ceil(0.95 * sorted.length) - 1];
  const p05Y = height - ((p05 - min) / range) * (height - 4) - 2;
  const p95Y = height - ((p95 - min) / range) * (height - 4) - 2;

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
      {showBand && (
        <rect
          x={0}
          y={Math.min(p05Y, p95Y)}
          width={width}
          height={Math.abs(p95Y - p05Y)}
          fill={color}
          opacity={0.12}
        />
      )}
      <path d={path} fill="none" stroke={color} strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}
