export function fmtSec(v: number, digits = 3): string {
  return v.toFixed(digits) + "s";
}

export function fmtMs(v: number, digits = 1): string {
  return (v * 1000).toFixed(digits) + "ms";
}

export function fmtPct(v: number, digits = 2): string {
  return (v * 100).toFixed(digits) + "%";
}

export function fmtNum(v: number, digits = 0): string {
  return v.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

export function fmtCompact(v: number): string {
  return new Intl.NumberFormat("en-US", { notation: "compact", maximumFractionDigits: 2 }).format(v);
}

export function fmtInstructions(v: number): string {
  // e.g. 2.05 B, 918 M
  if (v >= 1e9) return (v / 1e9).toFixed(2) + " B";
  if (v >= 1e6) return (v / 1e6).toFixed(1) + " M";
  if (v >= 1e3) return (v / 1e3).toFixed(1) + " K";
  return v.toString();
}

export function scoreGrade(score: number): { grade: string; tone: "excellent" | "good" | "fair" | "poor" } {
  if (score >= 95) return { grade: "A+", tone: "excellent" };
  if (score >= 85) return { grade: "A", tone: "excellent" };
  if (score >= 70) return { grade: "B", tone: "good" };
  if (score >= 50) return { grade: "C", tone: "fair" };
  if (score >= 25) return { grade: "D", tone: "poor" };
  return { grade: "F", tone: "poor" };
}
