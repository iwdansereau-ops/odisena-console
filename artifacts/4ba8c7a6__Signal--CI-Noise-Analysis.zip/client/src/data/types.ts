export interface Stats {
  n: number;
  min: number;
  max: number;
  mean: number;
  median: number;
  std: number;
  cov: number;
  p05: number;
  p95: number;
  p99: number;
  iqr: number;
  range: number;
}

export interface CachegrindData {
  Ir: number;
  I1_miss: number;
  LLi_miss: number;
  Dr: number;
  D1r_miss: number;
  LLdr_miss: number;
  Dw: number;
  D1w_miss: number;
  LLdw_miss: number;
}

export interface Run {
  run: number;
  wall_sec: number;
  instructions: number;
}

export interface Environment {
  id: string;
  name: string;
  subtitle: string;
  hardware: string;
  cost_per_hour: number;
  provisioning: string;
  isolation: string;
  runs: Run[];
  wall: Stats;
  instructions: Stats;
  cachegrind: CachegrindData;
  estimated_cycles: number;
  noise_score: number;
  false_positive_rate_pct: number;
}

export interface BenchmarkData {
  generated_at: string;
  workload: {
    name: string;
    description: string;
    runs_per_env: number;
    target_instructions: number;
  };
  environments: Environment[];
}

// Env-coded palette — used consistently across all charts
export const ENV_COLORS: Record<string, { light: string; dark: string; hue: string }> = {
  "gh-hosted": { light: "hsl(189 94% 38%)", dark: "hsl(189 94% 55%)", hue: "189" },       // cyan
  "aws-ec2": { light: "hsl(234 77% 55%)", dark: "hsl(234 82% 68%)", hue: "234" },          // indigo
  "bare-metal": { light: "hsl(158 64% 40%)", dark: "hsl(158 60% 52%)", hue: "158" },       // emerald
  "qemu-arm": { light: "hsl(340 82% 55%)", dark: "hsl(340 82% 65%)", hue: "340" },         // rose
  "container": { light: "hsl(32 95% 50%)", dark: "hsl(32 95% 60%)", hue: "32" },           // amber
};
