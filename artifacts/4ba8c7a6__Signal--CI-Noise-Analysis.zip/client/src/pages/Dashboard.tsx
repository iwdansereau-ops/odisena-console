import { useMemo, useState } from "react";
import benchmarkData from "@/data/benchmarks.json";
import { BenchmarkData, Environment, ENV_COLORS } from "@/data/types";
import { Logo } from "@/components/Logo";
import { BoxPlot } from "@/components/BoxPlot";
import { JitterChart } from "@/components/JitterChart";
import { Histogram } from "@/components/Histogram";
import { InstructionChart } from "@/components/InstructionChart";
import { Sparkline } from "@/components/Sparkline";
import { fmtSec, fmtPct, fmtInstructions, fmtNum, scoreGrade } from "@/lib/format";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sun, Moon, Download, ArrowUpDown, Terminal } from "lucide-react";
import { CachegrindPanel } from "@/components/CachegrindPanel";
import { Scorecard } from "@/components/Scorecard";
import { RegressionSimulator } from "@/components/RegressionSimulator";
import { ScriptsDrawer } from "@/components/ScriptsDrawer";

const data = benchmarkData as unknown as BenchmarkData;

export default function Dashboard() {
  const [dark, setDark] = useState(true);
  const [selectedEnv, setSelectedEnv] = useState<string>(data.environments[0].id);
  const [logScale, setLogScale] = useState(true);
  const [scriptsOpen, setScriptsOpen] = useState(false);

  // Toggle dark class on html root
  useMemo(() => {
    if (dark) document.documentElement.classList.add("dark");
    else document.documentElement.classList.remove("dark");
  }, [dark]);

  const sorted = useMemo(
    () => [...data.environments].sort((a, b) => b.noise_score - a.noise_score),
    []
  );
  const winner = sorted[0];
  const worst = sorted[sorted.length - 1];
  const active = data.environments.find((e) => e.id === selectedEnv)!;

  const downloadJSON = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "ci-noise-benchmarks.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-20 border-b border-border bg-background/85 backdrop-blur-xl">
        <div className="mx-auto max-w-[1400px] px-6 h-14 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="text-primary">
              <Logo className="h-6 w-6" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-[15px] font-semibold tracking-tight">Signal</span>
              <span className="text-[11px] font-mono text-muted-foreground uppercase tracking-widest">
                CI Noise Analysis
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setScriptsOpen(true)}
              data-testid="button-scripts"
              className="font-mono text-xs gap-2"
            >
              <Terminal className="h-3.5 w-3.5" /> collection scripts
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={downloadJSON}
              data-testid="button-download"
              className="gap-2"
            >
              <Download className="h-3.5 w-3.5" /> dataset
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={() => setDark((d) => !d)}
              data-testid="button-theme"
              aria-label="Toggle theme"
            >
              {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero */}
        <section className="relative border-b border-border">
          <div className="absolute inset-0 bg-grid opacity-60 pointer-events-none" aria-hidden />
          <div className="relative mx-auto max-w-[1400px] px-6 pt-16 pb-12">
            <div className="flex flex-wrap items-center gap-2 mb-6 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
              <span>workload · {data.workload.name}</span>
              <span className="text-border">/</span>
              <span>{data.workload.runs_per_env} runs · 5 environments</span>
              <span className="text-border">/</span>
              <span>generated {new Date(data.generated_at).toISOString().slice(0, 10)}</span>
            </div>
            <h1 className="text-3xl md:text-[42px] font-semibold tracking-tight leading-[1.05] max-w-3xl">
              Quantify the noise floor of every CI runner
              <br />
              <span className="text-muted-foreground">before it flags a regression that isn't real.</span>
            </h1>
            <p className="mt-5 text-[15px] text-muted-foreground max-w-2xl leading-relaxed">
              A standardized CPU-bound workload — 512×512 matmul plus a 5M sieve — replayed 100 times
              across five representative CI environments. Wall-clock jitter, instruction-count variance
              from cachegrind, and a composite score for choosing the right runner for performance-regression
              testing.
            </p>

            {/* Winner ribbon */}
            <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-3">
              <RibbonCard
                label="Best noise floor"
                value={winner.name}
                sub={`CoV ${fmtPct(winner.wall.cov)} · score ${winner.noise_score}`}
                tone="excellent"
                color={ENV_COLORS[winner.id].light}
              />
              <RibbonCard
                label="Worst noise floor"
                value={worst.name}
                sub={`CoV ${fmtPct(worst.wall.cov)} · score ${worst.noise_score}`}
                tone="poor"
                color={ENV_COLORS[worst.id].light}
              />
              <RibbonCard
                label="False positives at 2% gate"
                value={`${data.environments.filter((e) => e.false_positive_rate_pct > 10).length} of ${data.environments.length}`}
                sub={`envs would trigger spurious alerts`}
                tone="fair"
                color="hsl(var(--foreground))"
              />
            </div>
          </div>
        </section>

        {/* Scorecard */}
        <section className="mx-auto max-w-[1400px] px-6 py-12 border-b border-border">
          <SectionHeading
            eyebrow="01 · comparative scorecard"
            title="Runner-by-runner breakdown"
            desc="Sorted by composite noise score. Lower coefficient of variation + more deterministic instruction counts = higher score."
          />
          <div className="mt-8">
            <Scorecard envs={sorted} />
          </div>
        </section>

        {/* Distribution */}
        <section className="mx-auto max-w-[1400px] px-6 py-12 border-b border-border">
          <SectionHeading
            eyebrow="02 · wall-clock distributions"
            title="Median, quartiles, and outliers"
            desc="Box: interquartile range. Line: median. Whiskers: p05/p95. Dots: individual runs. QEMU is intentionally shown on the same axis so the emulation tax is impossible to miss."
            action={
              <Button
                size="sm"
                variant="outline"
                onClick={() => setLogScale((v) => !v)}
                className="font-mono text-xs gap-2"
                data-testid="button-scale"
              >
                <ArrowUpDown className="h-3.5 w-3.5" />
                {logScale ? "log scale" : "linear scale"}
              </Button>
            }
          />
          <div className="mt-8">
            <BoxPlot envs={data.environments} logScale={logScale} />
          </div>
        </section>

        {/* Per-env deep dive */}
        <section className="mx-auto max-w-[1400px] px-6 py-12 border-b border-border">
          <SectionHeading
            eyebrow="03 · per-environment jitter"
            title="Every run, in order"
            desc="Scatter of wall-clock times across all 100 runs. The shaded band is the p05–p95 range. Bimodal shapes reveal cgroup throttling epochs; long trends reveal thermal drift."
          />
          <div className="mt-6">
            <Tabs value={selectedEnv} onValueChange={setSelectedEnv}>
              <TabsList className="w-full h-auto flex-wrap justify-start p-1 bg-muted/40" data-testid="tabs-envs">
                {data.environments.map((env) => (
                  <TabsTrigger
                    key={env.id}
                    value={env.id}
                    className="data-[state=active]:bg-background flex items-center gap-2 font-medium"
                    data-testid={`tab-${env.id}`}
                  >
                    <span
                      className="w-2 h-2 rounded-full"
                      style={{ background: ENV_COLORS[env.id].light }}
                    />
                    {env.name}
                  </TabsTrigger>
                ))}
              </TabsList>
              {data.environments.map((env) => (
                <TabsContent key={env.id} value={env.id} className="mt-6">
                  <EnvDeepDive env={env} />
                </TabsContent>
              ))}
            </Tabs>
          </div>
        </section>

        {/* Instruction determinism */}
        <section className="mx-auto max-w-[1400px] px-6 py-12 border-b border-border">
          <SectionHeading
            eyebrow="04 · instruction-count variance"
            title="Cachegrind — the deterministic yardstick"
            desc="Valgrind's cachegrind executes on a virtual CPU, so on identical binaries + libc the instruction count is fully deterministic. The tiny variance you do see comes from glibc feature-detection drift on hosted runners and TCG helper calls under emulation."
          />
          <div className="mt-8">
            <InstructionChart envs={data.environments} />
          </div>

          <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-4">
            <CachegrindPanel env={active} />
            <Card className="p-5 border-border">
              <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono mb-3">
                Why cachegrind + wall-clock together
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Wall-clock is what your users feel; instruction count is what your code actually does.
                A wall-clock regression with a stable instruction count is <span className="text-foreground font-medium">environmental noise</span>.
                A jump in instructions with unchanged wall-clock is a <span className="text-foreground font-medium">real regression the environment happens to hide</span>.
                Track both. Gate CI on cachegrind for algorithmic regressions; report wall-clock as advisory context.
              </p>
              <div className="mt-4 pt-4 border-t border-border">
                <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono mb-2">
                  Recommended reading
                </div>
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li>· <a href="https://codspeed.io/blog/benchmarks-in-ci-without-noise" target="_blank" rel="noreferrer" className="underline hover:text-primary">CodSpeed — 2.66% CoV → 45% false positives at 2% gate</a></li>
                  <li>· <a href="https://arxiv.org/pdf/2411.05491" target="_blank" rel="noreferrer" className="underline hover:text-primary">arXiv 2411.05491 — Overhead noise across bare-metal vs hosted runners</a></li>
                  <li>· <a href="https://dev.to/kienmarkdo/low-noise-ec2-benchmarking-a-practical-guide-19f0" target="_blank" rel="noreferrer" className="underline hover:text-primary">MongoDB perf team — Low-noise EC2 methodology</a></li>
                  <li>· <a href="https://www.linaro.org/blog/qemu-a-tale-of-performance-analysis/" target="_blank" rel="noreferrer" className="underline hover:text-primary">Linaro — QEMU TCG vs KVM slowdown</a></li>
                </ul>
              </div>
            </Card>
          </div>
        </section>

        {/* Regression simulator */}
        <section className="mx-auto max-w-[1400px] px-6 py-12 border-b border-border">
          <SectionHeading
            eyebrow="05 · false-positive simulator"
            title="What gate would you actually trust?"
            desc="Move the slider to set your CI regression gate. The table shows the probability that a single benchmark run in each environment would trip the gate by chance alone, under a normal-approximation of the observed noise distribution."
          />
          <div className="mt-8">
            <RegressionSimulator envs={data.environments} />
          </div>
        </section>

        {/* Footer */}
        <footer className="mx-auto max-w-[1400px] px-6 py-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-muted-foreground">
            <div>
              <div className="flex items-center gap-2 mb-3 text-foreground">
                <span className="text-primary">
                  <Logo className="h-4 w-4" />
                </span>
                <span className="font-medium">Signal</span>
              </div>
              <p className="leading-relaxed">
                A reference dashboard for choosing CI runners for performance-regression testing.
                Simulated data grounded in published measurements from CodSpeed, MongoDB, Linaro, and academic literature.
              </p>
            </div>
            <div>
              <div className="uppercase font-mono tracking-widest text-[10px] mb-3">Workload</div>
              <p className="leading-relaxed font-mono text-[11px]">{data.workload.description}</p>
            </div>
            <div>
              <div className="uppercase font-mono tracking-widest text-[10px] mb-3">Reproduce</div>
              <p className="leading-relaxed">
                Every environment card ships the exact shell script used to collect its results.
                Open the <button className="underline hover:text-primary" onClick={() => setScriptsOpen(true)}>collection scripts drawer</button> to view or copy them.
              </p>
            </div>
          </div>
        </footer>
      </main>

      <ScriptsDrawer open={scriptsOpen} onClose={() => setScriptsOpen(false)} envs={data.environments} />
    </div>
  );
}

function SectionHeading({
  eyebrow,
  title,
  desc,
  action,
}: {
  eyebrow: string;
  title: string;
  desc: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
      <div className="max-w-2xl">
        <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono mb-2">
          {eyebrow}
        </div>
        <h2 className="text-xl font-semibold tracking-tight">{title}</h2>
        <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{desc}</p>
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

function RibbonCard({
  label,
  value,
  sub,
  tone,
  color,
}: {
  label: string;
  value: string;
  sub: string;
  tone: "excellent" | "good" | "fair" | "poor";
  color: string;
}) {
  const toneColor =
    tone === "excellent"
      ? "text-emerald-500"
      : tone === "good"
      ? "text-primary"
      : tone === "fair"
      ? "text-amber-500"
      : "text-rose-500";
  return (
    <Card className="p-4 border-border relative overflow-hidden" data-testid={`ribbon-${label}`}>
      <div
        className="absolute left-0 top-0 bottom-0 w-1"
        style={{ background: color }}
        aria-hidden
      />
      <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono pl-3">
        {label}
      </div>
      <div className={`mt-1 text-[22px] font-semibold tracking-tight pl-3 ${toneColor}`}>
        {value}
      </div>
      <div className="text-xs text-muted-foreground font-mono pl-3 mt-0.5">{sub}</div>
    </Card>
  );
}

function EnvDeepDive({ env }: { env: Environment }) {
  const grade = scoreGrade(env.noise_score);
  const c = ENV_COLORS[env.id].light;
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_360px] gap-6">
      <Card className="p-6 border-border">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono">
              wall-clock per run
            </div>
            <div className="text-lg font-semibold mt-1">{env.name}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{env.subtitle}</div>
          </div>
          <div className="text-right">
            <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono">score</div>
            <div className="text-3xl font-semibold" style={{ color: c }}>
              {env.noise_score}
            </div>
            <div className="text-[11px] font-mono text-muted-foreground">grade {grade.grade}</div>
          </div>
        </div>
        <JitterChart env={env} />
        <div className="mt-4 pt-4 border-t border-border">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono mb-2">
            distribution
          </div>
          <Histogram env={env} bins={22} height={70} />
        </div>
      </Card>

      <div className="space-y-4">
        <Card className="p-5 border-border">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono mb-3">
            statistics
          </div>
          <StatRow label="min" v={fmtSec(env.wall.min, 4)} />
          <StatRow label="p05" v={fmtSec(env.wall.p05, 4)} />
          <StatRow label="median" v={fmtSec(env.wall.median, 4)} highlight />
          <StatRow label="mean" v={fmtSec(env.wall.mean, 4)} />
          <StatRow label="p95" v={fmtSec(env.wall.p95, 4)} />
          <StatRow label="max" v={fmtSec(env.wall.max, 4)} />
          <div className="pt-3 mt-2 border-t border-border" />
          <StatRow label="std dev" v={fmtSec(env.wall.std, 4)} />
          <StatRow label="CoV" v={fmtPct(env.wall.cov)} highlight />
          <StatRow label="jitter (p95−p05)" v={fmtSec(env.wall.p95 - env.wall.p05, 4)} />
          <StatRow label="range" v={fmtSec(env.wall.range, 4)} />
        </Card>

        <Card className="p-5 border-border">
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-mono mb-3">
            environment
          </div>
          <MetaRow label="hardware" v={env.hardware} />
          <MetaRow label="isolation" v={env.isolation} />
          <MetaRow label="provisioning" v={env.provisioning} />
          <MetaRow label="cost / hour" v={`$${env.cost_per_hour.toFixed(3)}`} />
          <MetaRow label="fp @ 2% gate" v={`${env.false_positive_rate_pct}%`} tone={env.false_positive_rate_pct > 10 ? "warn" : "ok"} />
        </Card>
      </div>
    </div>
  );
}

function StatRow({ label, v, highlight }: { label: string; v: string; highlight?: boolean }) {
  return (
    <div className="flex items-baseline justify-between py-1 text-sm">
      <span className="text-muted-foreground font-mono text-xs">{label}</span>
      <span className={`font-mono ${highlight ? "text-foreground font-semibold" : "text-foreground"}`}>{v}</span>
    </div>
  );
}

function MetaRow({ label, v, tone }: { label: string; v: string; tone?: "ok" | "warn" }) {
  return (
    <div className="py-1.5 text-sm">
      <div className="text-muted-foreground font-mono text-[11px] uppercase tracking-widest">{label}</div>
      <div className={`mt-0.5 ${tone === "warn" ? "text-rose-500" : tone === "ok" ? "text-emerald-500" : "text-foreground"}`}>
        {v}
      </div>
    </div>
  );
}
