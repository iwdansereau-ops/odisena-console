# ddb-iam-refactor

Analyze a raw JSON IAM policy for DynamoDB, flag security risks (wildcards, dangerous actions, missing conditions), and emit a refactored **least-privilege** version. Handles both:

- **Identity-based policies** — attached to IAM roles/users/groups
- **Resource-based policies** — attached to a DynamoDB table via `PutResourcePolicy`

Optionally validates the result with **AWS IAM Access Analyzer** (`ValidatePolicy` + `CheckNoNewAccess`), including the DynamoDB-specific resource-policy checks (`validatePolicyResourceType=AWS::DynamoDB::Table`).

## Install

```bash
cd ddb-iam-refactor
python -m pip install -e .        # or: pip install boto3 (for AWS integration)
```

Only the standard library is required for the core tool. `boto3` unlocks direct API calls; alternatively the tool will shell out to `aws accessanalyzer ...` if the AWS CLI is on `PATH`.

## Usage

### Identity-based policy

```bash
ddb-iam-refactor samples/overprivileged.json \
  --policy-type identity \
  --account-id 123456789012 --region us-east-1 \
  --tables Orders Customers AuditLog \
  -o refactored.json
```

### Resource-based policy

```bash
ddb-iam-refactor samples/resource_policy_risky.json \
  --policy-type resource \
  --inventory samples/resource_inventory.json \
  -o refactored_resource.json
```

`--policy-type auto` (the default) detects the type from the presence of a `Principal` block.

## Resource-based policy audit

The analyzer applies resource-policy-specific checks:

| Code | Meaning |
|------|---------|
| `E_RES_NO_PRINCIPAL` | Allow statement missing required `Principal` |
| `E_TYPE_MISMATCH_ID` / `E_TYPE_MISMATCH_RES` | Declared vs. detected policy type disagree |
| `W_PRINCIPAL_STAR` | `Principal: "*"` with no scoping condition |
| `W_PRINCIPAL_STAR_CONDITIONED` | `Principal: "*"` but at least one scoping key present |
| `W_PRINCIPAL_ACCOUNT_ROOT` | Grants to `:root` / bare account id |
| `W_NOTPRINCIPAL` | `NotPrincipal` used |
| `I_CROSS_ACCOUNT_NO_COND` | External-account principal without `aws:SourceAccount` / `aws:PrincipalOrgID` |
| `W_RES_MULTI_TABLE` | Policy references more than one table (DynamoDB attaches to exactly one) |
| `E_RES_POLICY_TOO_LARGE` | > 20 KB (DynamoDB's cap) |

Scoping conditions understood by the analyzer include: `aws:PrincipalArn`, `aws:PrincipalOrgID`, `aws:PrincipalAccount`, `aws:PrincipalTag/*`, `aws:SourceAccount`, `aws:SourceArn`, `aws:SourceOrgID`, `aws:SourceIp`, `aws:SourceVpc`, `aws:SourceVpce`.

## Resource-based policy refactor

The refactor engine, when running in resource-policy mode:

1. Normalizes `Principal` blocks (drops unsupported keys, dedupes ARNs, collapses single-item lists).
2. Rewrites every Allow statement to reference **only the attached table's ARN(s)** — base table, `/index/*`, `/stream/*`, `/backup/*`, `/export/*`, `/import/*` as the action requires.
3. Drops account-scoped actions (e.g. `dynamodb:ListTables`, `dynamodb:DescribeLimits`) that don't operate on a specific resource.
4. Preserves any `Condition` from the input.
5. Applies caller-scoping conditions from your inventory's `scoping` block:
   - `principal_arns` → `ArnEquals aws:PrincipalArn`
   - `source_accounts` → `StringEquals aws:SourceAccount`
   - `principal_org_id` → `StringEquals aws:PrincipalOrgID`
   - `source_vpce` → `StringEquals aws:SourceVpce`
   - `source_ips` → `IpAddress aws:SourceIp`
   - `principal_tag` → `StringEquals aws:PrincipalTag/<key>`
   - `require_tls: true` (default) → `Bool aws:SecureTransport = true`
6. Refuses to blindly propagate `NotPrincipal`. If your inventory supplies `principal_arns`, they replace the removed `NotPrincipal`; otherwise the offending statement is dropped with a note.
7. Copies `Deny` statements through verbatim.
8. Warns if the result exceeds DynamoDB's 20 KB cap.

### Resource-policy inventory

```json
{
  "policy_type": "RESOURCE_POLICY",
  "account_id": "123456789012",
  "region": "us-east-1",
  "attached_table": "Orders",
  "tables": {"Orders": {}},
  "scoping": {
    "principal_arns":   ["arn:aws:iam::444455556666:role/PaymentsAppRole"],
    "source_accounts":  ["444455556666"],
    "principal_org_id": "o-abc1234567",
    "source_vpce":      ["vpce-0abcdef1234567890"],
    "require_tls":      true
  }
}
```

## Access Analyzer integration

Two checks run automatically (skip with `--no-validate`):

1. **`ValidatePolicy`** — When `--policy-type resource` is in effect, the tool calls Access Analyzer with `policyType=RESOURCE_POLICY` and `validatePolicyResourceType=AWS::DynamoDB::Table`, which triggers DynamoDB-specific checks in addition to the generic ones. For identity policies it uses `policyType=IDENTITY_POLICY`.
2. **`CheckNoNewAccess`** — Compares the refactored policy against the original in the appropriate policy type, proving the refactor didn't widen access.

## Programmatic use

```python
from ddb_iam_refactor import (
    analyze, refactor,
    refactor_identity_policy, refactor_resource_policy,
    validate_policy, validate_resource_policy, check_no_new_access,
    detect_policy_type,
)

policy_type = detect_policy_type(policy_dict)     # 'IDENTITY_POLICY' or 'RESOURCE_POLICY'
findings, usage = analyze(policy_dict, policy_type=policy_type)
new_policy, notes = refactor(policy_dict, inventory_dict, policy_type=policy_type)

aa1 = validate_resource_policy(new_policy)         # DynamoDB-specific checks
aa2 = check_no_new_access(existing=policy_dict, new=new_policy,
                          policy_type=policy_type)
```

## Exit codes

| code | meaning |
|------|---------|
| 0    | success, no critical findings |
| 2    | critical findings in the input policy |
