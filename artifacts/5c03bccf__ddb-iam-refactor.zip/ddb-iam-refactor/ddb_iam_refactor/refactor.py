"""
Refactor engine for DynamoDB IAM policies.

Two entry points:
  * refactor_identity_policy() - splits by access level, scopes Resource
    to specific table ARNs.
  * refactor_resource_policy()  - normalizes Principal, forces every
    statement to reference exactly one table ARN (matching the resource
    the policy is attached to), and promotes caller-scoping conditions
    (aws:PrincipalArn, aws:SourceAccount, aws:PrincipalOrgID, ...).

The top-level `refactor()` dispatches on inventory["policy_type"] / an
explicit argument / auto-detection.
"""

from __future__ import annotations

import copy
from typing import Any

from .actions import (
    ACCOUNT,
    ACTION_INDEX,
    BACKUP,
    EXPORT,
    GLOBAL,
    IMPORT_,
    INDEX,
    STREAM,
    TABLE,
    WRITE,
    TAGGING,
    PERMISSIONS,
)
from .analyzer import _as_list, _expand_actions
from .policy_type import IDENTITY, RESOURCE, detect_policy_type


# ---------------------------------------------------------------------------
# Shared ARN helpers
# ---------------------------------------------------------------------------

def _table_arn(inv: dict, table: str) -> str:
    return f"arn:aws:dynamodb:{inv['region']}:{inv['account_id']}:table/{table}"


def _resource_arns_for(action: str, inventory: dict, tables: list[str]) -> list[str]:
    """Build the tightest ARN set for a given action + table list."""
    meta = ACTION_INDEX[action]
    kinds = meta["resources"]
    arns: list[str] = []
    for t in tables:
        base = _table_arn(inventory, t)
        for k in kinds:
            if k == TABLE:
                arns.append(base)
            elif k == INDEX:
                arns.append(f"{base}/index/*")
            elif k == STREAM:
                arns.append(f"{base}/stream/*")
            elif k == BACKUP:
                arns.append(f"{base}/backup/*")
            elif k == EXPORT:
                arns.append(f"{base}/export/*")
            elif k == IMPORT_:
                arns.append(f"{base}/import/*")
            elif k == GLOBAL:
                arns.append(f"arn:aws:dynamodb::{inventory['account_id']}:global-table/{t}")
            elif k == ACCOUNT:
                arns.append(f"arn:aws:dynamodb:{inventory['region']}:{inventory['account_id']}:*")
    seen: set = set()
    out: list[str] = []
    for a in arns:
        if a not in seen:
            seen.add(a)
            out.append(a)
    return out


def _bucket_by_level(actions: list[str]) -> dict[str, list[str]]:
    buckets: dict[str, list[str]] = {}
    for a in actions:
        buckets.setdefault(ACTION_INDEX[a]["level"], []).append(a)
    for v in buckets.values():
        v.sort()
    return buckets


def _merge_conditions(conditions: list[dict]) -> dict:
    merged: dict = {}
    for c in conditions:
        if not isinstance(c, dict):
            continue
        for op, kv in c.items():
            if not isinstance(kv, dict):
                continue
            merged.setdefault(op, {}).update(kv)
    return merged


# ---------------------------------------------------------------------------
# Identity-policy refactor (unchanged behavior)
# ---------------------------------------------------------------------------

def refactor_identity_policy(policy: dict, inventory: dict) -> tuple[dict, list[str]]:
    notes: list[str] = []
    new_policy: dict[str, Any] = {"Version": "2012-10-17", "Statement": []}

    if not inventory.get("tables"):
        raise ValueError("Inventory must list at least one table.")

    statements = _as_list(policy.get("Statement"))
    intended_actions: set[str] = set()
    intended_conditions: list[dict] = []
    passthrough: list[dict] = []

    for stmt in statements:
        if not isinstance(stmt, dict):
            continue
        if stmt.get("Effect") == "Deny":
            passthrough.append(copy.deepcopy(stmt))
            continue
        if stmt.get("Effect") != "Allow":
            continue
        raw = _as_list(stmt.get("Action"))
        known, _ = _expand_actions(raw)
        if not known and raw == ["*"]:
            known, _ = _expand_actions(["dynamodb:*"])
            notes.append(
                "Expanded Action:'*' to the full dynamodb:* action set. "
                "Review: the original also granted non-DynamoDB actions."
            )
        intended_actions.update(known)
        if stmt.get("Condition"):
            intended_conditions.append(stmt["Condition"])

    buckets = _bucket_by_level(sorted(intended_actions))
    sid_counter = 0

    for level, acts in buckets.items():
        by_kinds: dict[tuple, list[str]] = {}
        for a in acts:
            key = tuple(ACTION_INDEX[a]["resources"])
            by_kinds.setdefault(key, []).append(a)

        for _, actions_for_kinds in by_kinds.items():
            applicable_tables = [
                t for t, meta in inventory["tables"].items()
                if not meta.get("levels") or level in meta["levels"]
            ]
            if not applicable_tables:
                continue

            resources: list[str] = []
            for a in actions_for_kinds:
                resources.extend(_resource_arns_for(a, inventory, applicable_tables))
            seen: set[str] = set()
            uniq_resources = []
            for r in resources:
                if r not in seen:
                    seen.add(r)
                    uniq_resources.append(r)

            sid_counter += 1
            sid = f"DynamoDB{level.replace(' ', '')}Access{sid_counter:02d}"
            stmt = {
                "Sid": sid,
                "Effect": "Allow",
                "Action": [f"dynamodb:{a.split(':',1)[1]}" for a in actions_for_kinds],
                "Resource": uniq_resources,
            }
            if intended_conditions and level in (WRITE, PERMISSIONS, TAGGING):
                stmt["Condition"] = _merge_conditions(intended_conditions)
            new_policy["Statement"].append(stmt)

    new_policy["Statement"].extend(passthrough)
    if not new_policy["Statement"]:
        notes.append("No Allow statements were produced - check your inventory.")
    return new_policy, notes


# ---------------------------------------------------------------------------
# Resource-policy refactor
# ---------------------------------------------------------------------------

def _normalize_principal(principal: Any, notes: list[str], stmt_idx: int) -> Any:
    """Return a well-formed Principal block.

    - Drop unsupported keys (only "AWS", "Service", "Federated", "CanonicalUser" are valid).
    - Deduplicate ARNs.
    - Collapse single-item lists to scalars for readability.
    - Warn if Principal is "*" (caller must supply a Condition to scope it).
    """
    _VALID_KEYS = {"AWS", "Service", "Federated", "CanonicalUser"}

    if principal == "*":
        notes.append(
            f"Statement[{stmt_idx}]: Principal '*' preserved - ensure a scoping "
            "Condition is present (aws:PrincipalArn / aws:PrincipalOrgID / aws:SourceAccount)."
        )
        return "*"

    if not isinstance(principal, dict):
        return principal

    out: dict = {}
    for k, v in principal.items():
        if k not in _VALID_KEYS:
            notes.append(f"Statement[{stmt_idx}]: Dropped unsupported Principal key {k!r}.")
            continue
        vs = _as_list(v)
        # dedupe, preserve order
        seen: set = set()
        cleaned: list = []
        for item in vs:
            if item not in seen:
                seen.add(item)
                cleaned.append(item)
        if len(cleaned) == 1:
            out[k] = cleaned[0]
        elif cleaned:
            out[k] = cleaned
    return out


def _scoped_table_arn(inventory: dict) -> str:
    """Build the ARN of the table this resource policy attaches to.

    A resource-based policy attaches to ONE table. Inventory must therefore
    identify exactly one table (or provide `attached_table`).
    """
    if inventory.get("attached_table"):
        return _table_arn(inventory, inventory["attached_table"])
    tables = list(inventory.get("tables", {}).keys())
    if len(tables) != 1:
        raise ValueError(
            "Resource-policy refactor requires inventory.attached_table "
            "or exactly one entry in inventory.tables (got {}).".format(len(tables))
        )
    return _table_arn(inventory, tables[0])


def _build_scoping_condition(inventory: dict, existing: list[dict]) -> dict:
    """Merge existing Conditions with caller-scoping conditions from inventory.

    Inventory recognizes an optional `scoping` block:
        "scoping": {
          "principal_arns":     ["arn:aws:iam::111122223333:role/AppRole"],
          "source_accounts":    ["111122223333"],
          "principal_org_id":   "o-abc123",
          "source_vpce":        ["vpce-0abc..."],
          "source_ips":         ["203.0.113.0/24"],
          "principal_tag":      {"team": "payments"}
        }
    Each present key becomes an appropriate Condition operator.
    """
    merged = _merge_conditions(existing)
    scoping = inventory.get("scoping") or {}

    if scoping.get("principal_arns"):
        vals = list(scoping["principal_arns"])
        merged.setdefault("ArnEquals", {})["aws:PrincipalArn"] = (
            vals[0] if len(vals) == 1 else vals
        )
    if scoping.get("source_accounts"):
        vals = list(scoping["source_accounts"])
        merged.setdefault("StringEquals", {})["aws:SourceAccount"] = (
            vals[0] if len(vals) == 1 else vals
        )
    if scoping.get("principal_org_id"):
        merged.setdefault("StringEquals", {})["aws:PrincipalOrgID"] = scoping["principal_org_id"]
    if scoping.get("source_vpce"):
        vals = list(scoping["source_vpce"])
        merged.setdefault("StringEquals", {})["aws:SourceVpce"] = (
            vals[0] if len(vals) == 1 else vals
        )
    if scoping.get("source_ips"):
        merged.setdefault("IpAddress", {})["aws:SourceIp"] = list(scoping["source_ips"])
    if scoping.get("principal_tag"):
        for tag_key, tag_val in scoping["principal_tag"].items():
            merged.setdefault("StringEquals", {})[f"aws:PrincipalTag/{tag_key}"] = tag_val

    # aws:SecureTransport is a cheap universal guard.
    if scoping.get("require_tls", True):
        merged.setdefault("Bool", {}).setdefault("aws:SecureTransport", "true")

    return merged


def refactor_resource_policy(policy: dict, inventory: dict) -> tuple[dict, list[str]]:
    """
    Refactor a DynamoDB resource-based policy.

    Every Allow statement is:
      - Rewritten to reference exactly the ARN(s) of the attached table
        (base, index/*, stream/*) - kinds are chosen per action.
      - Grouped by access level with a normalized Principal.
      - Combined with a merged Condition that (a) preserves any Condition
        the input carried, and (b) applies inventory-supplied scoping
        (aws:PrincipalArn / aws:SourceAccount / aws:PrincipalOrgID /
         aws:SourceVpce / aws:SourceIp / aws:PrincipalTag/<k>).

    Deny statements are copied through verbatim so they retain their bite.
    """
    notes: list[str] = []
    new_policy: dict[str, Any] = {"Version": "2012-10-17", "Statement": []}

    base_arn = _scoped_table_arn(inventory)

    # Collapse Allow statements grouped by Principal (JSON key) so that
    # different callers keep separate statements.
    by_principal: dict[str, dict] = {}
    passthrough: list[dict] = []

    import json as _json

    for i, stmt in enumerate(_as_list(policy.get("Statement"))):
        if not isinstance(stmt, dict):
            continue
        if stmt.get("Effect") == "Deny":
            passthrough.append(copy.deepcopy(stmt))
            continue
        if stmt.get("Effect") != "Allow":
            continue

        raw_actions = _as_list(stmt.get("Action"))
        known, _ = _expand_actions(raw_actions)
        if not known and raw_actions == ["*"]:
            known, _ = _expand_actions(["dynamodb:*"])
            notes.append(f"Statement[{i}]: expanded Action '*' to dynamodb:*.")

        raw_principal = stmt.get("Principal")
        if raw_principal is None and "NotPrincipal" in stmt:
            # NotPrincipal is inherently unsafe; the analyzer already flagged it.
            # We refuse to blindly propagate it into the refactor.
            notes.append(
                f"Statement[{i}]: NotPrincipal dropped during refactor. "
                "Add explicit Principal ARNs to the inventory 'scoping' block."
            )
            # Fall back to inventory-scoping principal(s) if provided.
            scoping = inventory.get("scoping") or {}
            scoped_arns = list(scoping.get("principal_arns") or [])
            if not scoped_arns:
                notes.append(
                    f"Statement[{i}]: skipped - NotPrincipal removed and no "
                    "inventory.scoping.principal_arns provided to substitute."
                )
                continue
            raw_principal = {"AWS": scoped_arns[0] if len(scoped_arns) == 1 else scoped_arns}

        principal = _normalize_principal(raw_principal, notes, i)
        if principal is None:
            # Nothing to grant to.
            continue
        principal_key = _json.dumps(principal, sort_keys=True)

        group = by_principal.setdefault(principal_key, {
            "principal": principal,
            "actions": set(),
            "conditions": [],
        })
        group["actions"].update(known)
        if stmt.get("Condition"):
            group["conditions"].append(stmt["Condition"])

    sid_counter = 0
    for _key, group in by_principal.items():
        acts = sorted(group["actions"])
        if not acts:
            continue

        # For resource policies, ARNs are constrained to the attached table.
        # Bucket actions by resource-kind so we do not emit /index/* or
        # /stream/* ARNs against actions that don't operate on them.
        by_kinds: dict[tuple, list[str]] = {}
        for a in acts:
            key = tuple(ACTION_INDEX[a]["resources"])
            by_kinds.setdefault(key, []).append(a)

        for kinds, actions_for_kinds in by_kinds.items():
            if ACCOUNT in kinds:
                notes.append(
                    "Dropped account-scoped action(s) from resource policy: "
                    + ", ".join(sorted(actions_for_kinds))
                    + " - these do not act on a specific table."
                )
                continue

            resources: list[str] = []
            for k in kinds:
                if k == TABLE:
                    resources.append(base_arn)
                elif k == INDEX:
                    resources.append(f"{base_arn}/index/*")
                elif k == STREAM:
                    resources.append(f"{base_arn}/stream/*")
                elif k == BACKUP:
                    resources.append(f"{base_arn}/backup/*")
                elif k == EXPORT:
                    resources.append(f"{base_arn}/export/*")
                elif k == IMPORT_:
                    resources.append(f"{base_arn}/import/*")
                elif k == GLOBAL:
                    # Global-table ARNs are not directly attachable, skip.
                    continue

            # Dedupe resources.
            seen: set = set()
            resources = [r for r in resources if not (r in seen or seen.add(r))]
            if not resources:
                continue

            condition = _build_scoping_condition(inventory, group["conditions"])

            sid_counter += 1
            sid = f"ResourcePolicyAccess{sid_counter:02d}"
            new_stmt: dict = {
                "Sid": sid,
                "Effect": "Allow",
                "Principal": group["principal"],
                "Action": [f"dynamodb:{a.split(':',1)[1]}" for a in actions_for_kinds],
                "Resource": resources[0] if len(resources) == 1 else resources,
            }
            if condition:
                new_stmt["Condition"] = condition
            new_policy["Statement"].append(new_stmt)

    new_policy["Statement"].extend(passthrough)

    if not new_policy["Statement"]:
        notes.append("No Allow statements were produced - check your inventory.")

    # Sanity check size (DynamoDB caps at 20 KB).
    size = len(_json.dumps(new_policy))
    if size > 20 * 1024:
        notes.append(
            f"WARNING: refactored resource policy is {size} bytes, over DynamoDB's 20480-byte cap."
        )

    return new_policy, notes


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

def refactor(policy: dict, inventory: dict,
             policy_type: str | None = None) -> tuple[dict, list[str]]:
    """Dispatch to the identity or resource refactor based on policy_type.

    Inventory may include ``"policy_type": "IDENTITY_POLICY"|"RESOURCE_POLICY"``.
    An explicit ``policy_type`` argument overrides both.
    """
    if policy_type is None:
        policy_type = inventory.get("policy_type") or detect_policy_type(policy)

    if policy_type == RESOURCE:
        return refactor_resource_policy(policy, inventory)
    return refactor_identity_policy(policy, inventory)
