"""Human-readable report generation."""

from __future__ import annotations

import json
from typing import Any

from .analyzer import ActionUsage, Finding

_SEV_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
_SEV_COLOR = {
    "CRITICAL": "\033[1;31m",
    "HIGH": "\033[31m",
    "MEDIUM": "\033[33m",
    "LOW": "\033[36m",
    "INFO": "\033[37m",
}
_RESET = "\033[0m"


def render_text_report(
    original: dict,
    refactored: dict,
    findings: list[Finding],
    original_usage: dict[str, ActionUsage],
    refactored_usage: dict[str, ActionUsage],
    aa_validate: dict,
    aa_no_new_access: dict,
    notes: list[str],
    policy_type: str = "IDENTITY_POLICY",
    use_color: bool = True,
) -> str:
    def c(sev: str) -> str:
        return f"{_SEV_COLOR[sev]}{sev}{_RESET}" if use_color else sev

    lines: list[str] = []
    lines.append("=" * 72)
    lines.append(f" DynamoDB IAM Policy - Refactor Report ({policy_type})")
    lines.append("=" * 72)

    # ---------- Risk findings ----------
    lines.append("")
    lines.append("## Risk analysis (input policy)")
    if not findings:
        lines.append("  No risks detected.")
    else:
        for f in sorted(findings, key=lambda f: (_SEV_ORDER[f.severity], f.code)):
            lines.append(
                f"  [{c(f.severity)}] {f.code}  stmt#{f.statement_index}  {f.message}"
            )
            if f.path:
                lines.append(f"      path:        {f.path}")
            if f.remediation:
                lines.append(f"      remediation: {f.remediation}")

    # ---------- Action → resource map ----------
    lines.append("")
    lines.append("## Action → resource mapping (refactored policy)")
    if not refactored_usage:
        lines.append("  (no DynamoDB actions granted)")
    else:
        by_level: dict[str, list[ActionUsage]] = {}
        for u in refactored_usage.values():
            by_level.setdefault(u.level, []).append(u)
        for level in ("List", "Read", "Write", "Tagging", "Permissions management"):
            if level not in by_level:
                continue
            lines.append(f"  [{level}]")
            for u in sorted(by_level[level], key=lambda x: x.action):
                lines.append(f"    - {u.action}")
                for r in u.resources:
                    lines.append(f"        → {r}")

    # ---------- Access Analyzer: ValidatePolicy ----------
    lines.append("")
    aa_hdr = f"## IAM Access Analyzer - ValidatePolicy ({aa_validate['backend']}"
    aa_hdr += f", policyType={aa_validate.get('policy_type','?')}"
    if aa_validate.get("validate_policy_resource_type"):
        aa_hdr += f", resourceType={aa_validate['validate_policy_resource_type']}"
    aa_hdr += ")"
    lines.append(aa_hdr)
    if aa_validate.get("error"):
        lines.append(f"  skipped: {aa_validate['error']}")
    aa_findings = aa_validate.get("findings", [])
    if not aa_findings and not aa_validate.get("error"):
        lines.append("  No findings. Policy is syntactically valid.")
    for f in aa_findings:
        ftype = f.get("findingType", "?")
        code = f.get("issueCode", "?")
        msg = f.get("message") or f.get("findingDetails") or ""
        lines.append(f"  [{ftype}] {code}: {msg}")

    # ---------- Access Analyzer: CheckNoNewAccess ----------
    lines.append("")
    lines.append(
        f"## IAM Access Analyzer - CheckNoNewAccess ({aa_no_new_access['backend']}, "
        f"policyType={aa_no_new_access.get('policy_type','?')})"
    )
    if aa_no_new_access.get("error"):
        lines.append(f"  skipped: {aa_no_new_access['error']}")
    else:
        res = aa_no_new_access.get("result")
        msg = aa_no_new_access.get("message") or ""
        lines.append(f"  result: {res}   {msg}")
        for r in aa_no_new_access.get("reasons", []) or []:
            lines.append(f"    - {r}")

    if notes:
        lines.append("")
        lines.append("## Refactor notes")
        for n in notes:
            lines.append(f"  - {n}")

    lines.append("")
    return "\n".join(lines)


def render_json_report(**payload: Any) -> str:
    def _default(o: Any):
        if hasattr(o, "to_dict"):
            return o.to_dict()
        if hasattr(o, "__dict__"):
            return o.__dict__
        raise TypeError(f"Not serializable: {type(o).__name__}")
    return json.dumps(payload, indent=2, default=_default)
