"""
Catalog of Amazon DynamoDB IAM actions, categorized by access level and
resource type they operate on. Used to (a) classify risk and (b) rewrite
`Resource: "*"` into scoped ARNs.

Sources: AWS Service Authorization Reference — Amazon DynamoDB.
"""

from __future__ import annotations

# Access levels roughly follow the AWS IAM "Access level" taxonomy.
# LIST/READ are lower risk; WRITE/TAGGING/PERMISSIONS are higher.
LIST = "List"
READ = "Read"
WRITE = "Write"
TAGGING = "Tagging"
PERMISSIONS = "Permissions management"

# Resource shapes used to build ARNs.
#   TABLE      -> arn:aws:dynamodb:{region}:{account}:table/{table}
#   INDEX      -> arn:aws:dynamodb:{region}:{account}:table/{table}/index/*
#   STREAM     -> arn:aws:dynamodb:{region}:{account}:table/{table}/stream/*
#   BACKUP     -> arn:aws:dynamodb:{region}:{account}:table/{table}/backup/*
#   EXPORT     -> arn:aws:dynamodb:{region}:{account}:table/{table}/export/*
#   IMPORT     -> arn:aws:dynamodb:{region}:{account}:table/{table}/import/*
#   GLOBAL     -> arn:aws:dynamodb::{account}:global-table/{name}
#   ACCOUNT    -> arn:aws:dynamodb:{region}:{account}:* (account-scoped, no
#                 table-level resource — e.g. ListTables, DescribeLimits)
TABLE = "table"
INDEX = "index"
STREAM = "stream"
BACKUP = "backup"
EXPORT = "export"
IMPORT_ = "import"
GLOBAL = "global-table"
ACCOUNT = "account"

# Actions that are especially dangerous — flagged even when scoped.
HIGH_BLAST_RADIUS = {
    "dynamodb:DeleteTable",
    "dynamodb:DeleteBackup",
    "dynamodb:RestoreTableFromBackup",
    "dynamodb:RestoreTableToPointInTime",
    "dynamodb:PurchaseReservedCapacityOfferings",
    "dynamodb:ExportTableToPointInTime",
    "dynamodb:ImportTable",
}

# (action, access_level, [resource_kinds])
_CATALOG: list[tuple[str, str, list[str]]] = [
    # --- Item read ------------------------------------------------------
    ("BatchGetItem", READ, [TABLE]),
    ("GetItem", READ, [TABLE]),
    ("Query", READ, [TABLE, INDEX]),
    ("Scan", READ, [TABLE, INDEX]),
    ("ConditionCheckItem", READ, [TABLE]),
    ("GetRecords", READ, [STREAM]),
    ("GetShardIterator", READ, [STREAM]),
    ("DescribeStream", READ, [STREAM]),
    ("PartiQLSelect", READ, [TABLE, INDEX]),
    # --- Item write -----------------------------------------------------
    ("PutItem", WRITE, [TABLE]),
    ("UpdateItem", WRITE, [TABLE]),
    ("DeleteItem", WRITE, [TABLE]),
    ("BatchWriteItem", WRITE, [TABLE]),
    ("PartiQLInsert", WRITE, [TABLE]),
    ("PartiQLUpdate", WRITE, [TABLE]),
    ("PartiQLDelete", WRITE, [TABLE]),
    ("ExecuteStatement", WRITE, [TABLE]),
    ("ExecuteTransaction", WRITE, [TABLE]),
    ("BatchExecuteStatement", WRITE, [TABLE]),
    # --- Table management ----------------------------------------------
    ("CreateTable", WRITE, [TABLE]),
    ("CreateTableReplica", WRITE, [TABLE]),
    ("UpdateTable", WRITE, [TABLE]),
    ("UpdateTableReplicaAutoScaling", WRITE, [TABLE]),
    ("DeleteTable", WRITE, [TABLE]),
    ("DeleteTableReplica", WRITE, [TABLE]),
    ("DescribeTable", READ, [TABLE]),
    ("DescribeTableReplicaAutoScaling", READ, [TABLE]),
    ("DescribeContinuousBackups", READ, [TABLE]),
    ("DescribeContributorInsights", READ, [TABLE, INDEX]),
    ("DescribeKinesisStreamingDestination", READ, [TABLE]),
    ("DescribeTimeToLive", READ, [TABLE]),
    ("UpdateContinuousBackups", WRITE, [TABLE]),
    ("UpdateContributorInsights", WRITE, [TABLE, INDEX]),
    ("UpdateKinesisStreamingDestination", WRITE, [TABLE]),
    ("UpdateTimeToLive", WRITE, [TABLE]),
    ("EnableKinesisStreamingDestination", WRITE, [TABLE]),
    ("DisableKinesisStreamingDestination", WRITE, [TABLE]),
    # --- Backups / restore ---------------------------------------------
    ("CreateBackup", WRITE, [TABLE]),
    ("DeleteBackup", WRITE, [BACKUP]),
    ("DescribeBackup", READ, [BACKUP]),
    ("RestoreTableFromBackup", WRITE, [TABLE, BACKUP]),
    ("RestoreTableToPointInTime", WRITE, [TABLE]),
    # --- Exports / imports ---------------------------------------------
    ("ExportTableToPointInTime", WRITE, [TABLE, EXPORT]),
    ("DescribeExport", READ, [EXPORT]),
    ("ImportTable", WRITE, [TABLE, IMPORT_]),
    ("DescribeImport", READ, [IMPORT_]),
    # --- Global tables --------------------------------------------------
    ("CreateGlobalTable", WRITE, [GLOBAL, TABLE]),
    ("UpdateGlobalTable", WRITE, [GLOBAL, TABLE]),
    ("UpdateGlobalTableSettings", WRITE, [GLOBAL]),
    ("DescribeGlobalTable", READ, [GLOBAL]),
    ("DescribeGlobalTableSettings", READ, [GLOBAL]),
    # --- Tags -----------------------------------------------------------
    ("TagResource", TAGGING, [TABLE]),
    ("UntagResource", TAGGING, [TABLE]),
    ("ListTagsOfResource", READ, [TABLE]),
    # --- Account / listing (no per-table resource) ---------------------
    ("ListTables", LIST, [ACCOUNT]),
    ("ListBackups", LIST, [ACCOUNT]),
    ("ListGlobalTables", LIST, [ACCOUNT]),
    ("ListExports", LIST, [ACCOUNT]),
    ("ListImports", LIST, [ACCOUNT]),
    ("ListStreams", LIST, [ACCOUNT]),
    ("ListContributorInsights", LIST, [ACCOUNT]),
    ("DescribeLimits", READ, [ACCOUNT]),
    ("DescribeEndpoints", READ, [ACCOUNT]),
    ("DescribeReservedCapacity", READ, [ACCOUNT]),
    ("DescribeReservedCapacityOfferings", READ, [ACCOUNT]),
    ("PurchaseReservedCapacityOfferings", WRITE, [ACCOUNT]),
    # --- Resource policies (permissions management) --------------------
    ("GetResourcePolicy", READ, [TABLE]),
    ("PutResourcePolicy", PERMISSIONS, [TABLE]),
    ("DeleteResourcePolicy", PERMISSIONS, [TABLE]),
]

# Normalized: dynamodb:Action -> {level, resources}
ACTION_INDEX: dict[str, dict] = {
    f"dynamodb:{name}": {"level": level, "resources": kinds}
    for name, level, kinds in _CATALOG
}

# Lowercase lookup for case-insensitive matching.
ACTION_INDEX_LC: dict[str, str] = {k.lower(): k for k in ACTION_INDEX}


def canonical(action: str) -> str | None:
    """Return the canonically-cased action name, or None if unknown."""
    return ACTION_INDEX_LC.get(action.lower())


def expand_wildcard(pattern: str) -> list[str]:
    """Expand a `dynamodb:*` / `dynamodb:Describe*` style pattern."""
    import fnmatch

    if ":" not in pattern:
        return []
    service, _ = pattern.split(":", 1)
    if service.lower() != "dynamodb":
        return []
    lc = pattern.lower()
    return sorted(
        {ACTION_INDEX_LC[k] for k in ACTION_INDEX_LC if fnmatch.fnmatchcase(k, lc)}
    )
