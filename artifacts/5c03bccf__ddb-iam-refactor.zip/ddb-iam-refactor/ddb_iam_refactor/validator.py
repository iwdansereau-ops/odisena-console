"""
Thin wrapper around AWS IAM Access Analyzer.

Order of preference:
  1. boto3 (if installed + credentials available) - programmatic.
  2. `aws accessanalyzer ...` CLI - subprocess fallback.
  3. Offline mode - emit a note that no validation was run.

Exposed checks:
  - validate_policy():           generic policy validation (identity or resource).
  - validate_resource_policy():  convenience wrapper for
                                 policyType=RESOURCE_POLICY,
                                 validatePolicyResourceType=AWS::DynamoDB::Table.
  - check_no_new_access(existing, new): confirm the refactored policy grants
                                         no *new* access relative to the original.
                                         Works for both IDENTITY_POLICY and
                                         RESOURCE_POLICY.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from typing import Any

# Access Analyzer validation-resource-type identifier for DynamoDB tables.
AA_RESOURCE_TYPE_DDB_TABLE = "AWS::DynamoDB::Table"


def _try_boto3():
    try:
        import boto3  # type: ignore
        from botocore.exceptions import BotoCoreError, ClientError  # type: ignore
        return boto3, (BotoCoreError, ClientError)
    except Exception:
        return None, ()


# ---------------------------------------------------------------------------
# validate_policy
# ---------------------------------------------------------------------------

def validate_policy(
    policy: dict,
    policy_type: str = "IDENTITY_POLICY",
    validate_policy_resource_type: str | None = None,
) -> dict:
    """
    Run AWS Access Analyzer ValidatePolicy.

    Args:
        policy: parsed JSON policy document.
        policy_type: 'IDENTITY_POLICY' or 'RESOURCE_POLICY'.
        validate_policy_resource_type: only meaningful when policy_type is
            'RESOURCE_POLICY'. e.g. 'AWS::DynamoDB::Table' - Access Analyzer
            will then run DynamoDB-specific checks (Resource ARN match,
            Principal shape, supported condition keys) in addition to the
            generic resource-policy checks.

    Returns:
        {
          "backend": "boto3" | "cli" | "offline",
          "policy_type": policy_type,
          "validate_policy_resource_type": <str|None>,
          "findings": [ {findingType, issueCode, message, locations}, ... ],
          "error": <str|None>,
        }
    """
    payload = json.dumps(policy, separators=(",", ":"))
    if policy_type != "RESOURCE_POLICY":
        # AA rejects validatePolicyResourceType outside RESOURCE_POLICY.
        validate_policy_resource_type = None

    boto3, boto_errs = _try_boto3()
    if boto3 is not None:
        try:
            client = boto3.client("accessanalyzer")
            paginator = client.get_paginator("validate_policy")
            paginate_kwargs: dict[str, Any] = {
                "policyDocument": payload,
                "policyType": policy_type,
            }
            if validate_policy_resource_type:
                paginate_kwargs["validatePolicyResourceType"] = validate_policy_resource_type
            findings: list[dict] = []
            for page in paginator.paginate(**paginate_kwargs):
                for f in page.get("findings", []):
                    findings.append(
                        {
                            "findingType": f.get("findingType"),
                            "issueCode": f.get("issueCode"),
                            "message": f.get("findingDetails") or f.get("learnMoreLink"),
                            "locations": f.get("locations", []),
                        }
                    )
            return {
                "backend": "boto3",
                "policy_type": policy_type,
                "validate_policy_resource_type": validate_policy_resource_type,
                "findings": findings,
                "error": None,
            }
        except boto_errs as e:  # type: ignore[misc]
            boto_err_msg = str(e)
        except Exception as e:
            boto_err_msg = f"{type(e).__name__}: {e}"
    else:
        boto_err_msg = "boto3 not installed"

    if shutil.which("aws"):
        try:
            cli = [
                "aws", "accessanalyzer", "validate-policy",
                "--policy-document", payload,
                "--policy-type", policy_type,
                "--output", "json",
            ]
            if validate_policy_resource_type:
                cli += ["--validate-policy-resource-type", validate_policy_resource_type]
            proc = subprocess.run(cli, capture_output=True, text=True, timeout=60)
            if proc.returncode == 0:
                data = json.loads(proc.stdout or "{}")
                return {
                    "backend": "cli",
                    "policy_type": policy_type,
                    "validate_policy_resource_type": validate_policy_resource_type,
                    "findings": data.get("findings", []),
                    "error": None,
                }
            return {
                "backend": "cli",
                "policy_type": policy_type,
                "validate_policy_resource_type": validate_policy_resource_type,
                "findings": [],
                "error": proc.stderr.strip() or f"exit {proc.returncode}",
            }
        except Exception as e:
            return {
                "backend": "cli",
                "policy_type": policy_type,
                "validate_policy_resource_type": validate_policy_resource_type,
                "findings": [],
                "error": f"{type(e).__name__}: {e}",
            }

    return {
        "backend": "offline",
        "policy_type": policy_type,
        "validate_policy_resource_type": validate_policy_resource_type,
        "findings": [],
        "error": f"AWS Access Analyzer not reachable ({boto_err_msg}); "
                 "install boto3 with credentials or the AWS CLI to enable validation.",
    }


def validate_resource_policy(policy: dict) -> dict:
    """Validate a DynamoDB resource-based policy.

    Shortcut for validate_policy(policy, 'RESOURCE_POLICY',
    'AWS::DynamoDB::Table').
    """
    return validate_policy(
        policy,
        policy_type="RESOURCE_POLICY",
        validate_policy_resource_type=AA_RESOURCE_TYPE_DDB_TABLE,
    )


# ---------------------------------------------------------------------------
# check_no_new_access
# ---------------------------------------------------------------------------

def check_no_new_access(
    existing: dict,
    new: dict,
    policy_type: str = "IDENTITY_POLICY",
) -> dict:
    """Confirm `new` grants no access that `existing` did not.

    Works with policy_type='IDENTITY_POLICY' or 'RESOURCE_POLICY'.
    Returns {backend, result: "PASS"|"FAIL"|"UNKNOWN", message, reasons, error}.
    """
    existing_doc = json.dumps(existing, separators=(",", ":"))
    new_doc = json.dumps(new, separators=(",", ":"))

    boto3, boto_errs = _try_boto3()
    if boto3 is not None:
        try:
            client = boto3.client("accessanalyzer")
            resp = client.check_no_new_access(
                newPolicyDocument=new_doc,
                existingPolicyDocument=existing_doc,
                policyType=policy_type,
            )
            return {
                "backend": "boto3",
                "policy_type": policy_type,
                "result": resp.get("result", "UNKNOWN"),
                "message": resp.get("message"),
                "reasons": resp.get("reasons", []),
                "error": None,
            }
        except boto_errs as e:  # type: ignore[misc]
            err = str(e)
        except Exception as e:
            err = f"{type(e).__name__}: {e}"
    else:
        err = "boto3 not installed"

    if shutil.which("aws"):
        try:
            proc = subprocess.run(
                [
                    "aws", "accessanalyzer", "check-no-new-access",
                    "--existing-policy-document", existing_doc,
                    "--new-policy-document", new_doc,
                    "--policy-type", policy_type,
                    "--output", "json",
                ],
                capture_output=True, text=True, timeout=60,
            )
            if proc.returncode == 0:
                data = json.loads(proc.stdout or "{}")
                return {
                    "backend": "cli",
                    "policy_type": policy_type,
                    "result": data.get("result", "UNKNOWN"),
                    "message": data.get("message"),
                    "reasons": data.get("reasons", []),
                    "error": None,
                }
            return {
                "backend": "cli",
                "policy_type": policy_type,
                "result": "UNKNOWN", "message": None, "reasons": [],
                "error": proc.stderr.strip() or f"exit {proc.returncode}",
            }
        except Exception as e:
            return {
                "backend": "cli",
                "policy_type": policy_type,
                "result": "UNKNOWN", "message": None, "reasons": [],
                "error": f"{type(e).__name__}: {e}",
            }

    return {
        "backend": "offline",
        "policy_type": policy_type,
        "result": "UNKNOWN",
        "message": None,
        "reasons": [],
        "error": f"Access Analyzer not reachable ({err}).",
    }
