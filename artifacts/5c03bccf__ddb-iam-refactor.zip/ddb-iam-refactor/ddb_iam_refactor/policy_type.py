"""
Policy-type detection and shared constants for identity vs. resource-based
DynamoDB policies.

DynamoDB resource-based policies (attached to a table or stream via
PutResourcePolicy) MUST contain a Principal (or NotPrincipal) block and
their Resource must match the ARN of the resource they are attached to.
Identity-based policies MUST NOT contain a Principal.
"""

from __future__ import annotations

from typing import Any

IDENTITY = "IDENTITY_POLICY"
RESOURCE = "RESOURCE_POLICY"

# Access Analyzer resourceType for DynamoDB resource policies.
AA_RESOURCE_TYPE_DDB_TABLE = "AWS::DynamoDB::Table"

# Condition keys that are meaningful for scoping resource-based DynamoDB
# policies. Presence of any one of these narrows a broad Principal like
# "*" or "AWS: *" into a specific caller shape.
SCOPING_CONDITION_KEYS = {
    "aws:PrincipalArn",
    "aws:PrincipalOrgID",
    "aws:PrincipalOrgPaths",
    "aws:PrincipalAccount",
    "aws:PrincipalTag",  # aws:PrincipalTag/<key>
    "aws:SourceAccount",
    "aws:SourceArn",
    "aws:SourceOrgID",
    "aws:SourceIp",
    "aws:SourceVpc",
    "aws:SourceVpce",
    "aws:PrincipalIsAWSService",
    "aws:PrincipalServiceName",
}

# Case-insensitive comparison uses the lower-cased set below.
SCOPING_CONDITION_KEYS_LC = {k.lower() for k in SCOPING_CONDITION_KEYS}


def _as_list(v: Any) -> list:
    if v is None:
        return []
    if isinstance(v, list):
        return v
    return [v]


def detect_policy_type(policy: dict) -> str:
    """Heuristically classify a policy as IDENTITY_POLICY or RESOURCE_POLICY.

    Rule: if ANY statement carries a Principal / NotPrincipal, it must be
    a resource-based policy — that syntax is invalid for identity policies.
    """
    if not isinstance(policy, dict):
        return IDENTITY
    for stmt in _as_list(policy.get("Statement")):
        if not isinstance(stmt, dict):
            continue
        if "Principal" in stmt or "NotPrincipal" in stmt:
            return RESOURCE
    return IDENTITY


def flatten_condition_keys(condition: dict | None) -> set[str]:
    """Return the set of condition keys used inside a Condition block."""
    out: set[str] = set()
    if not isinstance(condition, dict):
        return out
    for _op, kv in condition.items():
        if not isinstance(kv, dict):
            continue
        for key in kv.keys():
            out.add(key)
    return out


def condition_scopes_principal(condition: dict | None) -> bool:
    """True if the Condition narrows caller identity/source in any way."""
    keys_lc = {k.lower() for k in flatten_condition_keys(condition)}
    # aws:PrincipalTag/<tagname> — match by prefix.
    for k in keys_lc:
        if k in SCOPING_CONDITION_KEYS_LC:
            return True
        if k.startswith("aws:principaltag/"):
            return True
    return False
