"""
Risk analyzer for DynamoDB IAM policies.

Given a parsed policy document, produces a structured list of Findings
(severity, code, message, path) plus a summary of every DynamoDB action
present and how it is currently scoped.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Any, Iterable

from .actions import (
    ACTION_INDEX,
    HIGH_BLAST_RADIUS,
    PERMISSIONS,
    WRITE,
    canonical,
    expand_wildcard,
)
from .policy_type import (
    IDENTITY,
    RESOURCE,
    condition_scopes_principal,
    detect_policy_type,
)

# Severity ladder
CRITICAL = "CRITICAL"
HIGH = "HIGH"
MEDIUM = "MEDIUM"
LOW = "LOW"
INFO = "INFO"


@dataclass
class Finding:
    severity: str
    code: str
    message: str
    statement_index: int
    path: str = ""
    remediation: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ActionUsage:
    action: str
    level: str
    resources: list[str] = field(default_factory=list)
    statement_indices: list[int] = field(default_factory=list)


def _as_list(v: Any) -> list:
    if v is None:
        return []
    if isinstance(v, list):
        return v
    return [v]


def _expand_actions(raw_actions: Iterable[str]) -> tuple[list[str], list[str]]:
    """Return (known_dynamodb_actions, unknown_or_non_ddb_patterns)."""
    known: set[str] = set()
    unknown: list[str] = []
    for a in raw_actions:
        if not isinstance(a, str):
            unknown.append(repr(a))
            continue
        if a == "*":
            # Full wildcard — expand to every DDB action *and* flag.
            known.update(ACTION_INDEX.keys())
            unknown.append(a)
            continue
        if "*" in a or "?" in a:
            expanded = expand_wildcard(a)
            if expanded:
                known.update(expanded)
            else:
                unknown.append(a)
            continue
        c = canonical(a)
        if c:
            known.add(c)
        else:
            unknown.append(a)
    return sorted(known), unknown


def analyze(
    policy: dict, policy_type: str | None = None
) -> tuple[list[Finding], dict[str, ActionUsage]]:
    """Audit a DynamoDB IAM policy.

    ``policy_type`` is IDENTITY_POLICY, RESOURCE_POLICY, or None (auto-detect
    from presence of a Principal block).
    """
    findings: list[Finding] = []
    usage: dict[str, ActionUsage] = {}

    if not isinstance(policy, dict):
        findings.append(
            Finding(CRITICAL, "E_NOT_OBJECT", "Policy is not a JSON object.", -1)
        )
        return findings, usage

    detected = detect_policy_type(policy)
    if policy_type is None:
        policy_type = detected
    elif policy_type != detected:
        if policy_type == IDENTITY and detected == RESOURCE:
            findings.append(
                Finding(
                    CRITICAL, "E_TYPE_MISMATCH_ID",
                    "Policy declared IDENTITY_POLICY but contains a Principal - "
                    "identity policies cannot specify Principal.",
                    -1,
                    remediation="Remove Principal blocks or set --policy-type resource.",
                )
            )
        elif policy_type == RESOURCE and detected == IDENTITY:
            findings.append(
                Finding(
                    CRITICAL, "E_TYPE_MISMATCH_RES",
                    "Policy declared RESOURCE_POLICY but no statement has a Principal - "
                    "resource-based policies MUST specify Principal.",
                    -1,
                    remediation="Add a Principal block to each Allow statement.",
                )
            )

    version = policy.get("Version")
    if version not in ("2012-10-17", "2008-10-17"):
        findings.append(
            Finding(
                MEDIUM,
                "W_VERSION",
                f"Policy Version should be '2012-10-17' (got {version!r}).",
                -1,
                path="Version",
                remediation='Set "Version": "2012-10-17".',
            )
        )

    statements = _as_list(policy.get("Statement"))
    if not statements:
        findings.append(
            Finding(CRITICAL, "E_NO_STATEMENTS", "Policy has no Statement.", -1)
        )
        return findings, usage

    for i, stmt in enumerate(statements):
        if not isinstance(stmt, dict):
            findings.append(
                Finding(CRITICAL, "E_BAD_STMT", "Statement is not an object.", i))
            continue

        effect = stmt.get("Effect")
        if effect not in ("Allow", "Deny"):
            findings.append(
                Finding(HIGH, "E_EFFECT", f"Invalid Effect {effect!r}.", i,
                        path=f"Statement[{i}].Effect"))

        actions = _as_list(stmt.get("Action")) + _as_list(stmt.get("NotAction"))
        if stmt.get("NotAction"):
            findings.append(
                Finding(
                    HIGH,
                    "W_NOTACTION",
                    "NotAction is discouraged; it grants every action except those listed.",
                    i,
                    path=f"Statement[{i}].NotAction",
                    remediation="Replace NotAction with an explicit Action allow-list.",
                )
            )
        if stmt.get("NotResource"):
            findings.append(
                Finding(
                    HIGH, "W_NOTRESOURCE",
                    "NotResource is discouraged; scope with explicit Resource ARNs instead.",
                    i, path=f"Statement[{i}].NotResource",
                )
            )

        resources = _as_list(stmt.get("Resource"))
        conditions = stmt.get("Condition") or {}

        # Only continue analysis for Allow statements — Deny with wildcard is
        # generally fine.
        known_actions, unknown_actions = _expand_actions(actions)

        for u in unknown_actions:
            if u == "*":
                findings.append(
                    Finding(
                        CRITICAL,
                        "W_ACTION_STAR",
                        'Action "*" grants every AWS action, not just DynamoDB.',
                        i,
                        path=f"Statement[{i}].Action",
                        remediation='Replace with an explicit list of "dynamodb:*" actions.',
                    )
                )
            elif u.lower().startswith("dynamodb:"):
                findings.append(
                    Finding(
                        HIGH if "*" in u else MEDIUM,
                        "W_ACTION_WILDCARD" if "*" in u else "W_ACTION_UNKNOWN",
                        f"Action {u!r} is a wildcard/unknown DynamoDB action.",
                        i,
                        path=f"Statement[{i}].Action",
                        remediation="List each dynamodb:XxxItem action explicitly.",
                    )
                )
            else:
                findings.append(
                    Finding(
                        MEDIUM, "W_ACTION_NON_DDB",
                        f"Non-DynamoDB action {u!r} in a DynamoDB policy.",
                        i, path=f"Statement[{i}].Action",
                        remediation="Move non-DynamoDB actions to a separate statement or policy.",
                    )
                )

        # Resource-side risks
        if effect == "Allow":
            for r in resources:
                if r == "*":
                    findings.append(
                        Finding(
                            CRITICAL,
                            "W_RESOURCE_STAR",
                            'Resource "*" grants access to every DynamoDB table in the account.',
                            i,
                            path=f"Statement[{i}].Resource",
                            remediation="List explicit table ARNs, e.g. arn:aws:dynamodb:us-east-1:123456789012:table/Orders.",
                        )
                    )
                elif isinstance(r, str) and r.endswith(":table/*"):
                    findings.append(
                        Finding(
                            HIGH, "W_RESOURCE_TABLE_STAR",
                            f"Resource {r!r} matches every table in the region/account.",
                            i, path=f"Statement[{i}].Resource",
                            remediation="Enumerate table names explicitly.",
                        )
                    )

            # High-blast-radius actions
            for a in known_actions:
                if a in HIGH_BLAST_RADIUS:
                    has_condition = bool(conditions)
                    findings.append(
                        Finding(
                            HIGH if has_condition else CRITICAL,
                            "W_DANGEROUS_ACTION",
                            f"{a} is destructive/irreversible.",
                            i,
                            path=f"Statement[{i}].Action",
                            remediation="Restrict to a dedicated admin role and add a Condition (e.g. aws:MultiFactorAuthPresent).",
                        )
                    )
                if ACTION_INDEX[a]["level"] == PERMISSIONS:
                    findings.append(
                        Finding(
                            HIGH, "W_PERM_MGMT",
                            f"{a} manages resource policies (permissions management).",
                            i, path=f"Statement[{i}].Action",
                            remediation="Separate from data-plane statements; gate with MFA.",
                        )
                    )

            # Write actions with no Condition are worth calling out.
            write_actions = [
                a for a in known_actions if ACTION_INDEX[a]["level"] == WRITE
            ]
            if write_actions and not conditions and any(r == "*" for r in resources):
                findings.append(
                    Finding(
                        HIGH,
                        "W_UNCONDITIONED_WRITE",
                        f"{len(write_actions)} write action(s) allowed on '*' with no Condition.",
                        i,
                        path=f"Statement[{i}]",
                        remediation="Add aws:SourceIp / aws:PrincipalTag / dynamodb:LeadingKeys conditions.",
                    )
                )

            # Populate usage index
            for a in known_actions:
                u = usage.setdefault(
                    a, ActionUsage(action=a, level=ACTION_INDEX[a]["level"])
                )
                for r in resources:
                    if r not in u.resources:
                        u.resources.append(r)
                if i not in u.statement_indices:
                    u.statement_indices.append(i)

        has_principal = "Principal" in stmt or "NotPrincipal" in stmt

        if policy_type == IDENTITY and has_principal:
            findings.append(
                Finding(
                    HIGH, "W_ID_HAS_PRINCIPAL",
                    "Principal only applies to resource policies; identity policies must not include one.",
                    i, path=f"Statement[{i}].Principal",
                    remediation="Remove Principal, or reprocess this as --policy-type resource.",
                )
            )

        if policy_type == RESOURCE:
            _audit_resource_statement(stmt, i, findings)

    if policy_type == RESOURCE:
        _audit_resource_policy_shape(policy, findings)

    return findings, usage


# ---------------------------------------------------------------------------
# Resource-based policy specific audits
# ---------------------------------------------------------------------------

def _principal_is_open(principal) -> bool:
    """True when Principal effectively equals '*' or {"AWS": "*"}."""
    if principal == "*":
        return True
    if isinstance(principal, dict):
        for _k, v in principal.items():
            vs = _as_list(v)
            if any(x == "*" for x in vs):
                return True
    return False


def _principal_broad_accounts(principal) -> list:
    """Return account-root grants that widen access to a whole account."""
    hits = []
    if isinstance(principal, dict):
        aws = _as_list(principal.get("AWS"))
        for a in aws:
            if isinstance(a, str):
                if a.endswith(":root") or (a.isdigit() and len(a) == 12):
                    hits.append(a)
    return hits


def _audit_resource_statement(stmt: dict, i: int, findings: list) -> None:
    effect = stmt.get("Effect")
    principal = stmt.get("Principal")
    not_principal = stmt.get("NotPrincipal")
    condition = stmt.get("Condition") or {}

    if effect == "Allow" and principal is None and not_principal is None:
        findings.append(
            Finding(
                CRITICAL, "E_RES_NO_PRINCIPAL",
                "Resource-based Allow statement is missing Principal.",
                i, path=f"Statement[{i}]",
                remediation='Add "Principal": {"AWS": "arn:aws:iam::ACCT:role/Name"} or equivalent.',
            )
        )

    if not_principal is not None:
        findings.append(
            Finding(
                HIGH, "W_NOTPRINCIPAL",
                "NotPrincipal grants access to everyone EXCEPT the listed principals.",
                i, path=f"Statement[{i}].NotPrincipal",
                remediation="Replace with an explicit Principal allow-list.",
            )
        )

    if effect == "Allow" and _principal_is_open(principal):
        if not condition_scopes_principal(condition):
            findings.append(
                Finding(
                    CRITICAL, "W_PRINCIPAL_STAR",
                    'Principal "*" without a scoping Condition grants access to every AWS account.',
                    i, path=f"Statement[{i}].Principal",
                    remediation="Add a Condition on aws:PrincipalArn, aws:PrincipalOrgID, "
                                "aws:SourceAccount, aws:SourceVpce, or aws:SourceIp.",
                )
            )
        else:
            findings.append(
                Finding(
                    MEDIUM, "W_PRINCIPAL_STAR_CONDITIONED",
                    'Principal "*" is scoped only by Condition - verify the keys are what you expect.',
                    i, path=f"Statement[{i}].Principal",
                )
            )

    for acct in _principal_broad_accounts(principal):
        findings.append(
            Finding(
                HIGH, "W_PRINCIPAL_ACCOUNT_ROOT",
                f"Principal {acct!r} grants access to every identity in that account.",
                i, path=f"Statement[{i}].Principal.AWS",
                remediation="Grant specific role/user ARNs rather than :root or bare account ids.",
            )
        )

    if isinstance(principal, dict):
        aws = _as_list(principal.get("AWS"))
        for a in aws:
            if isinstance(a, str) and a.startswith("arn:aws:iam::"):
                acct = a.split(":")[4]
                if acct and acct.isdigit() and not condition_scopes_principal(condition):
                    findings.append(
                        Finding(
                            LOW, "I_CROSS_ACCOUNT_NO_COND",
                            f"Principal {a} has no aws:SourceAccount / aws:PrincipalOrgID condition - confirm intent.",
                            i, path=f"Statement[{i}].Principal.AWS",
                            remediation="Add aws:SourceAccount or aws:PrincipalOrgID to defend against confused-deputy patterns.",
                        )
                    )
                    break


def _audit_resource_policy_shape(policy: dict, findings: list) -> None:
    import json as _json
    size = len(_json.dumps(policy))
    if size > 20 * 1024:
        findings.append(
            Finding(
                CRITICAL, "E_RES_POLICY_TOO_LARGE",
                f"Resource policy is {size} bytes; DynamoDB limit is 20480.",
                -1, remediation="Consolidate statements or split across resources.",
            )
        )

    tables = set()
    for stmt in _as_list(policy.get("Statement")):
        if not isinstance(stmt, dict):
            continue
        for r in _as_list(stmt.get("Resource")):
            if not isinstance(r, str) or not r.startswith("arn:aws:dynamodb:"):
                continue
            parts = r.split(":", 5)
            if len(parts) >= 6 and parts[5].startswith("table/"):
                tables.add(parts[5].split("/", 2)[1])
    if len(tables) > 1:
        findings.append(
            Finding(
                HIGH, "W_RES_MULTI_TABLE",
                f"Resource policy references multiple tables: {sorted(tables)}. "
                "A DynamoDB resource policy is attached to ONE table; cross-table ARNs are ineffective.",
                -1,
                remediation="Keep only ARNs for the table this policy is attached to.",
            )
        )
