"""Command-line entry point."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .analyzer import analyze
from .policy_type import IDENTITY, RESOURCE, detect_policy_type
from .refactor import refactor
from .report import render_json_report, render_text_report
from .validator import (
    AA_RESOURCE_TYPE_DDB_TABLE,
    check_no_new_access,
    validate_policy,
)


def _load_json(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        sys.exit(f"error: {path} not found")
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError as e:
        sys.exit(f"error: {path} is not valid JSON: {e}")


def _resolve_policy_type(args, policy: dict) -> str:
    if args.policy_type == "identity":
        return IDENTITY
    if args.policy_type == "resource":
        return RESOURCE
    return detect_policy_type(policy)


def _build_inventory(args, policy_type: str) -> dict:
    if args.inventory:
        inv = _load_json(args.inventory)
        inv.setdefault("account_id", args.account_id)
        inv.setdefault("region", args.region)
        if args.attached_table:
            inv["attached_table"] = args.attached_table
        inv["policy_type"] = policy_type
        return inv

    if policy_type == RESOURCE:
        if not (args.account_id and args.region and args.attached_table):
            sys.exit(
                "error: resource-policy mode requires --inventory FILE, "
                "OR --account-id, --region, and --attached-table NAME."
            )
        return {
            "account_id": args.account_id,
            "region": args.region,
            "attached_table": args.attached_table,
            "tables": {args.attached_table: {}},
            "policy_type": policy_type,
        }

    if not args.tables:
        sys.exit(
            "error: identity-policy mode requires --inventory FILE, "
            "OR --account-id, --region, and --tables T1 T2 ..."
        )
    return {
        "account_id": args.account_id,
        "region": args.region,
        "tables": {t: {} for t in args.tables},
        "policy_type": policy_type,
    }


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ddb-iam-refactor",
        description=(
            "Analyze and refactor DynamoDB IAM policies to least privilege. "
            "Supports both identity-based (IAM role/user) policies and "
            "resource-based (PutResourcePolicy) policies."
        ),
    )
    p.add_argument("policy", help="Path to input JSON policy.")
    p.add_argument(
        "--policy-type", choices=("auto", "identity", "resource"), default="auto",
        help="Policy type. Default 'auto' - detected from presence of Principal.",
    )
    p.add_argument("--inventory", help="Path to JSON inventory file.")
    p.add_argument("--account-id", help="12-digit AWS account id.")
    p.add_argument("--region", help='AWS region, e.g. "us-east-1".')
    p.add_argument("--tables", nargs="*",
                   help="Table names (identity-policy mode).")
    p.add_argument("--attached-table",
                   help="Table the resource-based policy is attached to.")
    p.add_argument("-o", "--output", help="Write refactored policy to this file.")
    p.add_argument(
        "--format", choices=("text", "json"), default="text",
        help="Report format written to stdout.",
    )
    p.add_argument(
        "--no-validate", action="store_true",
        help="Skip AWS IAM Access Analyzer calls.",
    )
    p.add_argument("--no-color", action="store_true", help="Disable ANSI color.")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    policy = _load_json(args.policy)
    policy_type = _resolve_policy_type(args, policy)
    inventory = _build_inventory(args, policy_type)

    findings, orig_usage = analyze(policy, policy_type=policy_type)
    refactored, notes = refactor(policy, inventory, policy_type=policy_type)
    _, refactored_usage = analyze(refactored, policy_type=policy_type)

    if args.no_validate:
        aa_v = {
            "backend": "offline", "policy_type": policy_type,
            "validate_policy_resource_type": None,
            "findings": [], "error": "skipped by --no-validate",
        }
        aa_n = {
            "backend": "offline", "policy_type": policy_type,
            "result": "UNKNOWN", "message": None, "reasons": [],
            "error": "skipped by --no-validate",
        }
    else:
        resource_type = AA_RESOURCE_TYPE_DDB_TABLE if policy_type == RESOURCE else None
        aa_v = validate_policy(
            refactored,
            policy_type=policy_type,
            validate_policy_resource_type=resource_type,
        )
        aa_n = check_no_new_access(
            existing=policy, new=refactored, policy_type=policy_type,
        )

    if args.output:
        Path(args.output).write_text(json.dumps(refactored, indent=2) + "\n")

    if args.format == "json":
        print(render_json_report(
            policy_type=policy_type,
            findings=findings,
            refactored_policy=refactored,
            original_usage=orig_usage,
            refactored_usage=refactored_usage,
            access_analyzer_validate=aa_v,
            access_analyzer_no_new_access=aa_n,
            notes=notes,
        ))
    else:
        print(render_text_report(
            original=policy,
            refactored=refactored,
            findings=findings,
            original_usage=orig_usage,
            refactored_usage=refactored_usage,
            aa_validate=aa_v,
            aa_no_new_access=aa_n,
            notes=notes,
            policy_type=policy_type,
            use_color=not args.no_color and sys.stdout.isatty(),
        ))
        if not args.output:
            print("## Refactored policy")
            print(json.dumps(refactored, indent=2))

    has_critical = any(f.severity == "CRITICAL" for f in findings)
    return 2 if has_critical else 0


if __name__ == "__main__":
    raise SystemExit(main())
