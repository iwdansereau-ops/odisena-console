"""DynamoDB IAM policy refactor toolkit."""

from .analyzer import ActionUsage, Finding, analyze
from .policy_type import IDENTITY, RESOURCE, detect_policy_type
from .refactor import refactor, refactor_identity_policy, refactor_resource_policy
from .validator import (
    AA_RESOURCE_TYPE_DDB_TABLE,
    check_no_new_access,
    validate_policy,
    validate_resource_policy,
)

__all__ = [
    "analyze",
    "refactor",
    "refactor_identity_policy",
    "refactor_resource_policy",
    "detect_policy_type",
    "validate_policy",
    "validate_resource_policy",
    "check_no_new_access",
    "AA_RESOURCE_TYPE_DDB_TABLE",
    "IDENTITY",
    "RESOURCE",
    "Finding",
    "ActionUsage",
]
__version__ = "0.2.0"
