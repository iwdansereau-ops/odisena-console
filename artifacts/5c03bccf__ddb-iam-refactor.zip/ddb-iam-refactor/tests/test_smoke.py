"""Smoke tests — do not require AWS credentials."""

import json
from pathlib import Path

from ddb_iam_refactor import analyze, refactor
from ddb_iam_refactor.actions import expand_wildcard, canonical

SAMPLES = Path(__file__).parent.parent / "samples"


def test_wildcard_expansion_covers_common_actions():
    all_ddb = expand_wildcard("dynamodb:*")
    for a in ["dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:DeleteTable"]:
        assert a in all_ddb
    describes = expand_wildcard("dynamodb:Describe*")
    assert "dynamodb:DescribeTable" in describes
    assert "dynamodb:GetItem" not in describes


def test_canonical_case_insensitive():
    assert canonical("dynamodb:getitem") == "dynamodb:GetItem"
    assert canonical("dynamodb:BOGUS") is None


def test_analyze_flags_wildcards():
    policy = json.loads((SAMPLES / "overprivileged.json").read_text())
    findings, usage = analyze(policy)
    codes = {f.code for f in findings}
    assert "W_RESOURCE_STAR" in codes
    assert "W_ACTION_NON_DDB" in codes  # s3:GetObject
    # dynamodb:* should expand and include DeleteTable
    assert "dynamodb:DeleteTable" in usage
    # DeleteTable is high blast radius
    assert any(f.code == "W_DANGEROUS_ACTION" for f in findings)


def test_refactor_produces_scoped_arns():
    policy = json.loads((SAMPLES / "realistic.json").read_text())
    inv = json.loads((SAMPLES / "inventory.json").read_text())
    new_policy, notes = refactor(policy, inv)
    assert new_policy["Version"] == "2012-10-17"
    # Should have at least Read and Write statements
    levels = {s["Sid"] for s in new_policy["Statement"]}
    assert any("Read" in s for s in levels)
    assert any("Write" in s for s in levels)
    # No Resource "*" should remain in the refactored policy
    for s in new_policy["Statement"]:
        for r in s.get("Resource", []):
            assert r != "*"
            assert "table/Orders" in r or "table/Customers" in r or "table/AuditLog" in r \
                or r.endswith(":*")
    # Customers is Read-only per inventory — must not appear in Write statement
    for s in new_policy["Statement"]:
        if "Write" in s["Sid"]:
            assert not any("table/Customers" in r for r in s["Resource"])


def test_refactor_preserves_deny():
    policy = {
        "Version": "2012-10-17",
        "Statement": [
            {"Effect": "Allow", "Action": "dynamodb:GetItem", "Resource": "*"},
            {"Effect": "Deny",  "Action": "dynamodb:DeleteTable", "Resource": "*"},
        ],
    }
    inv = {"account_id": "111122223333", "region": "us-west-2",
           "tables": {"Foo": {}}}
    out, _ = refactor(policy, inv)
    assert any(s["Effect"] == "Deny" for s in out["Statement"])
