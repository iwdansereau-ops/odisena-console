"""Tests for the resource-based policy extensions."""

import json
from pathlib import Path

from ddb_iam_refactor import (
    IDENTITY,
    RESOURCE,
    analyze,
    detect_policy_type,
    refactor,
    refactor_resource_policy,
)
from ddb_iam_refactor.policy_type import condition_scopes_principal

SAMPLES = Path(__file__).parent.parent / "samples"


def test_detect_policy_type_identity():
    p = json.loads((SAMPLES / "realistic.json").read_text())
    assert detect_policy_type(p) == IDENTITY


def test_detect_policy_type_resource():
    p = json.loads((SAMPLES / "resource_policy_risky.json").read_text())
    assert detect_policy_type(p) == RESOURCE


def test_analyze_flags_principal_star_and_notprincipal_and_root():
    p = json.loads((SAMPLES / "resource_policy_risky.json").read_text())
    findings, _ = analyze(p, policy_type=RESOURCE)
    codes = {f.code for f in findings}
    assert "W_PRINCIPAL_STAR" in codes           # Principal: "*" with no scoping condition
    assert "W_PRINCIPAL_ACCOUNT_ROOT" in codes   # arn:aws:iam::...:root
    assert "W_NOTPRINCIPAL" in codes             # NotPrincipal usage
    assert "W_RES_MULTI_TABLE" in codes          # 2 tables referenced
    # Original also has dangerous actions from dynamodb:*
    assert any(f.code == "W_DANGEROUS_ACTION" for f in findings)


def test_analyze_identity_policy_with_principal_is_flagged():
    # Feeding a resource-shaped policy but declaring IDENTITY should trip mismatch.
    p = json.loads((SAMPLES / "resource_policy_risky.json").read_text())
    findings, _ = analyze(p, policy_type=IDENTITY)
    codes = {f.code for f in findings}
    assert "E_TYPE_MISMATCH_ID" in codes


def test_refactor_resource_policy_scopes_to_attached_table():
    p = json.loads((SAMPLES / "resource_policy_risky.json").read_text())
    inv = json.loads((SAMPLES / "resource_inventory.json").read_text())
    new_policy, notes = refactor(p, inv)
    assert new_policy["Version"] == "2012-10-17"
    assert new_policy["Statement"], "expected at least one statement"

    # Every Allow statement must reference only the attached table.
    for s in new_policy["Statement"]:
        if s.get("Effect") != "Allow":
            continue
        resources = s["Resource"] if isinstance(s["Resource"], list) else [s["Resource"]]
        for r in resources:
            assert "table/Orders" in r, f"unexpected resource {r}"
            assert "SomeOtherTable" not in r


def test_refactor_resource_policy_promotes_scoping_conditions():
    p = json.loads((SAMPLES / "resource_policy_risky.json").read_text())
    inv = json.loads((SAMPLES / "resource_inventory.json").read_text())
    new_policy, _ = refactor(p, inv)

    saw_principal_arn = False
    saw_source_account = False
    saw_org_id = False
    saw_vpce = False
    saw_tls = False
    for s in new_policy["Statement"]:
        cond = s.get("Condition") or {}
        assert condition_scopes_principal(cond) or s.get("Effect") == "Deny"
        # Flatten
        flat = {}
        for op, kv in cond.items():
            if isinstance(kv, dict):
                for k, v in kv.items():
                    flat[k] = (op, v)
        saw_principal_arn |= "aws:PrincipalArn" in flat
        saw_source_account |= "aws:SourceAccount" in flat
        saw_org_id |= "aws:PrincipalOrgID" in flat
        saw_vpce |= "aws:SourceVpce" in flat
        saw_tls |= "aws:SecureTransport" in flat
    assert saw_principal_arn
    assert saw_source_account
    assert saw_org_id
    assert saw_vpce
    assert saw_tls


def test_refactor_resource_policy_requires_principal():
    p = json.loads((SAMPLES / "resource_policy_risky.json").read_text())
    inv = json.loads((SAMPLES / "resource_inventory.json").read_text())
    new_policy, _ = refactor(p, inv)
    for s in new_policy["Statement"]:
        if s.get("Effect") == "Allow":
            assert "Principal" in s


def test_refactor_resource_policy_drops_account_scoped_actions():
    # dynamodb:ListTables is account-scoped and should be filtered out
    # when refactoring a resource-based policy.
    policy = {
        "Version": "2012-10-17",
        "Statement": [{
            "Effect": "Allow",
            "Principal": {"AWS": "arn:aws:iam::111122223333:role/App"},
            "Action": ["dynamodb:GetItem", "dynamodb:ListTables"],
            "Resource": "arn:aws:dynamodb:us-east-1:123456789012:table/Orders",
        }],
    }
    inv = {
        "policy_type": "RESOURCE_POLICY",
        "account_id": "123456789012", "region": "us-east-1",
        "attached_table": "Orders", "tables": {"Orders": {}},
    }
    new_policy, notes = refactor_resource_policy(policy, inv)
    all_actions = set()
    for s in new_policy["Statement"]:
        acts = s.get("Action")
        acts = acts if isinstance(acts, list) else [acts]
        all_actions.update(acts)
    assert "dynamodb:GetItem" in all_actions
    assert "dynamodb:ListTables" not in all_actions
    assert any("account-scoped" in n for n in notes)


def test_validator_resource_policy_offline():
    from ddb_iam_refactor import validate_resource_policy
    # No boto3/AWS CLI in the test sandbox - just ensure the shape is correct.
    result = validate_resource_policy({"Version": "2012-10-17", "Statement": []})
    assert result["policy_type"] == "RESOURCE_POLICY"
    assert result["validate_policy_resource_type"] == "AWS::DynamoDB::Table"
    # backend is one of the three; error is set when offline.
    assert result["backend"] in ("boto3", "cli", "offline")
