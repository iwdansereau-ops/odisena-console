// Package gcpressure implements a pprof-based GC pressure monitor for the
// OpenTelemetry Collector. It samples runtime.MemStats on a fixed interval,
// exposes Prometheus metrics (heap alloc rate, GC pause, pdata object velocity),
// and captures heap profiles + goroutine stack traces whenever GC pause duration
// crosses a configurable threshold (default 100ms) or heap churn exceeds a
// configurable rate (default 2 GB / minute).
//
// The monitor is designed to be embedded in a custom OTel Collector extension
// (see extension/gcpressureextension) but is usable standalone.
package gcpressure

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"runtime/debug"
	"runtime/pprof"
	"sync"
	"sync/atomic"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"go.uber.org/zap"
)

// Config controls the GC pressure monitor.
type Config struct {
	// SampleInterval is how often runtime.MemStats is polled.
	SampleInterval time.Duration
	// PauseThreshold triggers a pprof capture when a single GC pause exceeds it.
	PauseThreshold time.Duration
	// ChurnBytesPerMinuteThreshold triggers alerting / capture when the rolling
	// heap allocation rate exceeds this many bytes per minute.
	ChurnBytesPerMinuteThreshold uint64
	// ProfileDir is where heap profiles and stack traces are written.
	ProfileDir string
	// MinCaptureInterval rate-limits pprof captures so a storm of GC events
	// does not fill the disk.
	MinCaptureInterval time.Duration
	// Logger is optional; a no-op logger is used if nil.
	Logger *zap.Logger
}

// DefaultConfig returns the recommended defaults for a busy Collector.
func DefaultConfig() Config {
	return Config{
		SampleInterval:               1 * time.Second,
		PauseThreshold:               100 * time.Millisecond,
		ChurnBytesPerMinuteThreshold: 2 * 1024 * 1024 * 1024, // 2 GB / min
		ProfileDir:                   "/var/lib/otelcol/gcprofiles",
		MinCaptureInterval:           30 * time.Second,
	}
}

// Monitor is the pprof-based GC pressure monitor.
type Monitor struct {
	cfg Config
	log *zap.Logger

	// Prometheus metrics.
	heapAllocBytes       prometheus.Gauge
	heapInuseBytes       prometheus.Gauge
	heapSysBytes         prometheus.Gauge
	heapObjects          prometheus.Gauge
	nextGCBytes          prometheus.Gauge
	allocRateBytes       prometheus.Gauge // instantaneous, bytes/sec
	allocChurnPerMinute  prometheus.Gauge // rolling window, bytes/min
	gcPauseNs            prometheus.Histogram
	gcPauseLastNs        prometheus.Gauge
	gcCountTotal         prometheus.Counter
	gcCPUFraction        prometheus.Gauge
	pdataObjectsCreated  *prometheus.CounterVec // labels: signal, stage
	pdataObjectsVelocity *prometheus.GaugeVec   // labels: signal, stage
	captureTotal         *prometheus.CounterVec // labels: reason
	overThresholdTotal   *prometheus.CounterVec // labels: kind (pause|churn)

	// Sampling state.
	lastMemStats runtime.MemStats
	lastSampleAt time.Time
	lastNumGC    uint32
	// Rolling window of alloc deltas keyed by sample time for a 60s window.
	// We keep it small (max ~60 entries at 1s interval).
	windowMu    sync.Mutex
	windowAlloc []allocSample

	// Capture rate limiter.
	lastCaptureAt atomic.Int64 // unix nano

	// pdata counters (feed pdataObjectsCreated + pdataObjectsVelocity).
	pdataMu       sync.Mutex
	pdataCounters map[pdataKey]*pdataCounter

	// Lifecycle.
	stop chan struct{}
	done chan struct{}
}

type allocSample struct {
	at    time.Time
	bytes uint64 // cumulative TotalAlloc snapshot
}

type pdataKey struct {
	signal string // logs|metrics|traces
	stage  string // receiver|processor:<name>|exporter|batcher|...
}

type pdataCounter struct {
	total   atomic.Uint64
	lastVal uint64
	lastAt  time.Time
}

// NewMonitor constructs a Monitor. Register(reg) must be called before Start.
func NewMonitor(cfg Config) *Monitor {
	if cfg.SampleInterval <= 0 {
		cfg.SampleInterval = time.Second
	}
	if cfg.PauseThreshold <= 0 {
		cfg.PauseThreshold = 100 * time.Millisecond
	}
	if cfg.ChurnBytesPerMinuteThreshold == 0 {
		cfg.ChurnBytesPerMinuteThreshold = 2 * 1024 * 1024 * 1024
	}
	if cfg.MinCaptureInterval <= 0 {
		cfg.MinCaptureInterval = 30 * time.Second
	}
	if cfg.ProfileDir == "" {
		cfg.ProfileDir = "/tmp/otelcol-gcprofiles"
	}
	if cfg.Logger == nil {
		cfg.Logger = zap.NewNop()
	}

	m := &Monitor{
		cfg:           cfg,
		log:           cfg.Logger,
		pdataCounters: make(map[pdataKey]*pdataCounter),
		stop:          make(chan struct{}),
		done:          make(chan struct{}),
	}

	ns := "otelcol_gc"
	m.heapAllocBytes = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: ns, Name: "heap_alloc_bytes",
		Help: "Bytes of allocated heap objects (MemStats.HeapAlloc).",
	})
	m.heapInuseBytes = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: ns, Name: "heap_inuse_bytes",
		Help: "Bytes in in-use spans (MemStats.HeapInuse).",
	})
	m.heapSysBytes = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: ns, Name: "heap_sys_bytes",
		Help: "Bytes of heap memory obtained from the OS (MemStats.HeapSys).",
	})
	m.heapObjects = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: ns, Name: "heap_objects",
		Help: "Number of allocated heap objects (MemStats.HeapObjects).",
	})
	m.nextGCBytes = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: ns, Name: "next_gc_target_bytes",
		Help: "Target heap size for the next GC cycle (MemStats.NextGC).",
	})
	m.allocRateBytes = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: ns, Name: "alloc_rate_bytes_per_second",
		Help: "Instantaneous heap allocation rate in bytes/second.",
	})
	m.allocChurnPerMinute = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: ns, Name: "alloc_churn_bytes_per_minute",
		Help: "Rolling 60s heap allocation churn in bytes/minute.",
	})
	m.gcPauseNs = prometheus.NewHistogram(prometheus.HistogramOpts{
		Namespace: ns, Name: "pause_seconds",
		Help: "Distribution of individual GC pause durations, in seconds.",
		Buckets: []float64{
			0.0001, 0.0005, 0.001, 0.005, 0.01, 0.025, 0.05,
			0.1, 0.2, 0.5, 1.0, 2.0,
		},
	})
	m.gcPauseLastNs = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: ns, Name: "pause_last_seconds",
		Help: "Duration of the most recent GC pause, in seconds.",
	})
	m.gcCountTotal = prometheus.NewCounter(prometheus.CounterOpts{
		Namespace: ns, Name: "cycles_total",
		Help: "Total number of completed GC cycles observed by the monitor.",
	})
	m.gcCPUFraction = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: ns, Name: "cpu_fraction",
		Help: "Fraction of program CPU time used by GC (MemStats.GCCPUFraction).",
	})
	m.pdataObjectsCreated = prometheus.NewCounterVec(prometheus.CounterOpts{
		Namespace: ns, Name: "pdata_objects_created_total",
		Help: "Total pdata objects created, labeled by signal and pipeline stage.",
	}, []string{"signal", "stage"})
	m.pdataObjectsVelocity = prometheus.NewGaugeVec(prometheus.GaugeOpts{
		Namespace: ns, Name: "pdata_objects_per_second",
		Help: "Instantaneous pdata object creation velocity (objects/second).",
	}, []string{"signal", "stage"})
	m.captureTotal = prometheus.NewCounterVec(prometheus.CounterOpts{
		Namespace: ns, Name: "pprof_captures_total",
		Help: "Total pprof captures triggered, labeled by trigger reason.",
	}, []string{"reason"})
	m.overThresholdTotal = prometheus.NewCounterVec(prometheus.CounterOpts{
		Namespace: ns, Name: "threshold_exceeded_total",
		Help: "Total number of threshold breaches observed.",
	}, []string{"kind"})

	return m
}

// Register attaches all Prometheus collectors to reg.
func (m *Monitor) Register(reg prometheus.Registerer) error {
	collectors := []prometheus.Collector{
		m.heapAllocBytes, m.heapInuseBytes, m.heapSysBytes, m.heapObjects,
		m.nextGCBytes, m.allocRateBytes, m.allocChurnPerMinute,
		m.gcPauseNs, m.gcPauseLastNs, m.gcCountTotal, m.gcCPUFraction,
		m.pdataObjectsCreated, m.pdataObjectsVelocity,
		m.captureTotal, m.overThresholdTotal,
	}
	for _, c := range collectors {
		if err := reg.Register(c); err != nil {
			return fmt.Errorf("register collector: %w", err)
		}
	}
	return nil
}

// Start begins background sampling. It returns immediately.
func (m *Monitor) Start(ctx context.Context) error {
	if err := os.MkdirAll(m.cfg.ProfileDir, 0o755); err != nil {
		return fmt.Errorf("create profile dir %q: %w", m.cfg.ProfileDir, err)
	}

	// Prime the sampler.
	runtime.ReadMemStats(&m.lastMemStats)
	m.lastSampleAt = time.Now()
	m.lastNumGC = m.lastMemStats.NumGC

	go m.loop(ctx)
	go m.pdataVelocityLoop(ctx)
	return nil
}

// Stop shuts down the monitor. It blocks until sampling goroutines exit.
func (m *Monitor) Stop() {
	select {
	case <-m.stop:
		// already stopped
	default:
		close(m.stop)
	}
	<-m.done
}

func (m *Monitor) loop(ctx context.Context) {
	defer close(m.done)
	t := time.NewTicker(m.cfg.SampleInterval)
	defer t.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-m.stop:
			return
		case <-t.C:
			m.sample()
		}
	}
}

func (m *Monitor) sample() {
	var ms runtime.MemStats
	runtime.ReadMemStats(&ms)
	now := time.Now()

	dt := now.Sub(m.lastSampleAt).Seconds()
	if dt <= 0 {
		dt = m.cfg.SampleInterval.Seconds()
	}

	// --- basic gauges ---
	m.heapAllocBytes.Set(float64(ms.HeapAlloc))
	m.heapInuseBytes.Set(float64(ms.HeapInuse))
	m.heapSysBytes.Set(float64(ms.HeapSys))
	m.heapObjects.Set(float64(ms.HeapObjects))
	m.nextGCBytes.Set(float64(ms.NextGC))
	m.gcCPUFraction.Set(ms.GCCPUFraction)

	// --- allocation rate ---
	// TotalAlloc is monotonically non-decreasing cumulative bytes allocated.
	var deltaAlloc uint64
	if ms.TotalAlloc >= m.lastMemStats.TotalAlloc {
		deltaAlloc = ms.TotalAlloc - m.lastMemStats.TotalAlloc
	}
	instRate := float64(deltaAlloc) / dt
	m.allocRateBytes.Set(instRate)

	churn := m.pushAllocSample(now, ms.TotalAlloc)
	m.allocChurnPerMinute.Set(float64(churn))

	// --- GC cycles / pauses ---
	// NumGC wraps very slowly; use unsigned subtraction.
	newGCs := ms.NumGC - m.lastNumGC
	if newGCs > 0 {
		// PauseNs is a 256-entry ring buffer. Iterate the new entries.
		if newGCs > 256 {
			newGCs = 256
		}
		var maxPause uint64
		for i := uint32(0); i < newGCs; i++ {
			idx := (ms.NumGC + 255 - i) % 256
			p := ms.PauseNs[idx]
			m.gcCountTotal.Inc()
			m.gcPauseNs.Observe(float64(p) / 1e9)
			if p > maxPause {
				maxPause = p
			}
		}
		m.gcPauseLastNs.Set(float64(maxPause) / 1e9)

		if maxPause > 0 && time.Duration(maxPause) >= m.cfg.PauseThreshold {
			m.overThresholdTotal.WithLabelValues("pause").Inc()
			m.maybeCapture("gc_pause", map[string]string{
				"pause_ns":  fmt.Sprintf("%d", maxPause),
				"threshold": m.cfg.PauseThreshold.String(),
			})
		}
	}

	// --- churn threshold ---
	if churn >= m.cfg.ChurnBytesPerMinuteThreshold {
		m.overThresholdTotal.WithLabelValues("churn").Inc()
		m.maybeCapture("heap_churn", map[string]string{
			"churn_bytes_per_min": fmt.Sprintf("%d", churn),
			"threshold":           fmt.Sprintf("%d", m.cfg.ChurnBytesPerMinuteThreshold),
		})
	}

	// Advance.
	m.lastMemStats = ms
	m.lastSampleAt = now
	m.lastNumGC = ms.NumGC
}

// pushAllocSample records a cumulative TotalAlloc sample and returns
// current rolling churn expressed as bytes/minute.
func (m *Monitor) pushAllocSample(now time.Time, total uint64) uint64 {
	m.windowMu.Lock()
	defer m.windowMu.Unlock()

	m.windowAlloc = append(m.windowAlloc, allocSample{at: now, bytes: total})
	// Drop anything older than 60s.
	cutoff := now.Add(-60 * time.Second)
	i := 0
	for i < len(m.windowAlloc) && m.windowAlloc[i].at.Before(cutoff) {
		i++
	}
	if i > 0 {
		m.windowAlloc = append(m.windowAlloc[:0], m.windowAlloc[i:]...)
	}
	if len(m.windowAlloc) < 2 {
		return 0
	}
	first := m.windowAlloc[0]
	last := m.windowAlloc[len(m.windowAlloc)-1]
	span := last.at.Sub(first.at).Seconds()
	if span <= 0 {
		return 0
	}
	var delta uint64
	if last.bytes >= first.bytes {
		delta = last.bytes - first.bytes
	}
	// bytes / sec -> bytes / min
	return uint64(float64(delta) / span * 60.0)
}

// maybeCapture writes a heap profile + goroutine stack dump if enough time
// has elapsed since the last capture. The write happens on a dedicated
// goroutine so a stuck disk cannot block the sampling loop.
func (m *Monitor) maybeCapture(reason string, meta map[string]string) {
	nowNs := time.Now().UnixNano()
	lastNs := m.lastCaptureAt.Load()
	if lastNs != 0 && time.Duration(nowNs-lastNs) < m.cfg.MinCaptureInterval {
		return
	}
	if !m.lastCaptureAt.CompareAndSwap(lastNs, nowNs) {
		return
	}

	// Run the capture off the sampling goroutine. Capture cost (STW GC +
	// pprof serialization) is bounded but can be hundreds of milliseconds
	// on large heaps; a stuck disk could block indefinitely. Detaching
	// isolates both risks from metric collection.
	go m.doCapture(reason, meta)
}

func (m *Monitor) doCapture(reason string, meta map[string]string) {
	ts := time.Now().UTC().Format("20060102T150405.000Z")
	base := filepath.Join(m.cfg.ProfileDir, fmt.Sprintf("gc-%s-%s", reason, ts))

	// Heap profile.
	heapPath := base + ".heap.pprof"
	if f, err := os.Create(heapPath); err == nil {
		// Force STW so the heap reflects post-trigger state.
		runtime.GC()
		if err := pprof.Lookup("heap").WriteTo(f, 0); err != nil {
			m.log.Warn("write heap profile", zap.Error(err))
		}
		_ = f.Close()
	} else {
		m.log.Warn("create heap profile", zap.Error(err))
	}

	// Goroutine stack dump (debug=2 prints full stacks).
	stackPath := base + ".stacks.txt"
	if f, err := os.Create(stackPath); err == nil {
		if err := pprof.Lookup("goroutine").WriteTo(f, 2); err != nil {
			m.log.Warn("write goroutine profile", zap.Error(err))
		}
		_ = f.Close()
	} else {
		m.log.Warn("create stacks file", zap.Error(err))
	}

	// Small metadata sidecar so the correlator can align pprof with traces.
	metaPath := base + ".meta.txt"
	if f, err := os.Create(metaPath); err == nil {
		fmt.Fprintf(f, "reason=%s\n", reason)
		fmt.Fprintf(f, "captured_at=%s\n", time.Now().UTC().Format(time.RFC3339Nano))
		bi, _ := debug.ReadBuildInfo()
		if bi != nil {
			fmt.Fprintf(f, "go_version=%s\n", bi.GoVersion)
			fmt.Fprintf(f, "main_module=%s\n", bi.Main.Path)
		}
		for k, v := range meta {
			fmt.Fprintf(f, "%s=%s\n", k, v)
		}
		_ = f.Close()
	}

	m.captureTotal.WithLabelValues(reason).Inc()
	m.log.Warn("captured pprof heap + stacks",
		zap.String("reason", reason),
		zap.String("heap", heapPath),
		zap.String("stacks", stackPath),
		zap.Any("meta", meta),
	)
}

// -----------------------------------------------------------------------------
// pdata object velocity: called by pipeline instrumentation.
// -----------------------------------------------------------------------------

// RecordPdataObjects is invoked by pdata pipeline instrumentation whenever a
// stage produces or forwards objects. signal is "logs"|"metrics"|"traces" and
// stage identifies the pipeline node (e.g. "receiver:otlp", "processor:batch").
func (m *Monitor) RecordPdataObjects(signal, stage string, n int) {
	if n <= 0 {
		return
	}
	m.pdataObjectsCreated.WithLabelValues(signal, stage).Add(float64(n))

	key := pdataKey{signal: signal, stage: stage}
	m.pdataMu.Lock()
	c, ok := m.pdataCounters[key]
	if !ok {
		c = &pdataCounter{}
		c.lastAt = time.Now()
		m.pdataCounters[key] = c
	}
	m.pdataMu.Unlock()
	c.total.Add(uint64(n))
}

// pdataVelocityLoop periodically converts counter deltas into
// objects/second gauges.
func (m *Monitor) pdataVelocityLoop(ctx context.Context) {
	t := time.NewTicker(m.cfg.SampleInterval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-m.stop:
			return
		case now := <-t.C:
			m.pdataMu.Lock()
			for key, c := range m.pdataCounters {
				total := c.total.Load()
				dt := now.Sub(c.lastAt).Seconds()
				var vel float64
				if dt > 0 && total >= c.lastVal {
					vel = float64(total-c.lastVal) / dt
				}
				m.pdataObjectsVelocity.WithLabelValues(key.signal, key.stage).Set(vel)
				c.lastVal = total
				c.lastAt = now
			}
			m.pdataMu.Unlock()
		}
	}
}
