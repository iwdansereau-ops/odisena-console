#!/usr/bin/env bash
# ghz load-test driver for the OTLP/gRPC ingest path. This is the fastest
# way to force GC pressure on a Go collector because the protobuf → pdata
# unmarshal allocates one Go struct per attribute, resource, scope, and record.
#
# Requirements:
#   * ghz >= 0.117 in $PATH  (https://ghz.sh/)
#   * The OTLP protos vendored under loadtest/ghz/proto/ (see fetch-protos.sh)
#   * A running collector with OTLP/gRPC on :4317
#
# Usage:
#   ./run-ghz.sh                              # default (breach profile)
#   PROFILE=hurricane ./run-ghz.sh            # heavier
#   TARGET=collector:4317 ./run-ghz.sh        # remote collector

set -euo pipefail
cd "$(dirname "$0")"

TARGET="${TARGET:-localhost:4317}"
PROFILE="${PROFILE:-breach}"
DURATION="${DURATION:-3m}"
PROTO_ROOT="${PROTO_ROOT:-./proto}"
PAYLOAD="${PAYLOAD:-./payload.breach.json}"

case "$PROFILE" in
  nudge)      CONCURRENCY=25;  RPS=200;   PAYLOAD="./payload.nudge.json" ;;
  breach)     CONCURRENCY=100; RPS=800;   PAYLOAD="./payload.breach.json" ;;
  hurricane)  CONCURRENCY=250; RPS=2000;  PAYLOAD="./payload.hurricane.json" ;;
  *) echo "unknown PROFILE=$PROFILE (nudge|breach|hurricane)"; exit 2 ;;
esac

if [ ! -f "$PAYLOAD" ]; then
  echo "generating $PAYLOAD ..."
  node ./gen-payload.js "$PROFILE" > "$PAYLOAD"
fi

# We invoke opentelemetry.proto.collector.logs.v1.LogsService/Export because
# the logs path exercises the widest attribute-per-record surface.
exec ghz \
  --insecure \
  --async \
  --proto           "${PROTO_ROOT}/opentelemetry/proto/collector/logs/v1/logs_service.proto" \
  --import-paths    "${PROTO_ROOT}" \
  --call            opentelemetry.proto.collector.logs.v1.LogsService.Export \
  --concurrency     "${CONCURRENCY}" \
  --rps             "${RPS}" \
  --duration        "${DURATION}" \
  --data-file       "${PAYLOAD}" \
  --connections     "$(( CONCURRENCY / 25 > 0 ? CONCURRENCY / 25 : 1 ))" \
  --load-schedule   step \
  --load-start      "$(( RPS / 10 ))" \
  --load-step       "$(( RPS / 10 ))" \
  --load-step-duration 5s \
  --load-end        "${RPS}" \
  --format          summary \
  "${TARGET}"
