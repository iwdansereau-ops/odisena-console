#!/usr/bin/env node
// Generates a single ExportLogsServiceRequest JSON payload for ghz to send.
// ghz repeats the same payload each RPC; that's fine — the goal is
// collector-side allocation, not client-side variety.

const profiles = {
  nudge:     { records: 100,  width: 16,  attrBytes: 48  },
  breach:    { records: 500,  width: 64,  attrBytes: 96  },
  hurricane: { records: 1000, width: 128, attrBytes: 128 },
};

const p = profiles[process.argv[2] || 'breach'];
if (!p) { console.error('unknown profile'); process.exit(2); }

function rs(n) {
  const cs = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let s = '';
  for (let i = 0; i < n; i++) s += cs[Math.floor(Math.random() * cs.length)];
  return s;
}

function attrs(n) {
  const out = [];
  for (let i = 0; i < n; i++) {
    switch (i % 5) {
      case 0: out.push({ key: `k${i}`, value: { stringValue: rs(p.attrBytes) } }); break;
      case 1: out.push({ key: `k${i}`, value: { intValue: String(i * 131) } }); break;
      case 2: out.push({ key: `k${i}`, value: { doubleValue: i * 0.001 } }); break;
      case 3: out.push({ key: `k${i}`, value: { boolValue: i % 2 === 0 } }); break;
      case 4: out.push({ key: `k${i}`, value: {
        arrayValue: { values: [
          { stringValue: rs(24) }, { stringValue: rs(24) },
        ]}}}); break;
    }
  }
  return out;
}

const now = String(Date.now()) + '000000';
const records = new Array(p.records).fill(null).map((_, i) => ({
  timeUnixNano: now,
  observedTimeUnixNano: now,
  severityNumber: 9,
  severityText: 'INFO',
  body: { stringValue: `record ${i} ${rs(64)}` },
  attributes: attrs(p.width),
}));

const payload = {
  resourceLogs: [{
    resource: {
      attributes: [
        { key: 'service.name', value: { stringValue: 'ghz-gcload' } },
        ...attrs(8),
      ],
    },
    scopeLogs: [{
      scope: { name: 'ghz.gcload', version: '1.0.0' },
      logRecords: records,
    }],
  }],
};

process.stdout.write(JSON.stringify(payload));
