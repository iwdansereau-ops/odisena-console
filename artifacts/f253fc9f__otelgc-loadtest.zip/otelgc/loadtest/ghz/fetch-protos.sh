#!/usr/bin/env bash
# Vendors the minimal OTLP proto set ghz needs to invoke LogsService/Export.
# Uses a pinned tag so the run is reproducible.

set -euo pipefail
cd "$(dirname "$0")"

TAG="${OTLP_PROTO_TAG:-v1.3.2}"
DEST="./proto"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "fetching opentelemetry-proto $TAG ..."
curl -fsSL "https://github.com/open-telemetry/opentelemetry-proto/archive/refs/tags/${TAG}.tar.gz" \
  | tar -xz -C "$TMP" --strip-components=1

mkdir -p "$DEST"
# Copy only what LogsService/Export transitively needs.
for f in \
  opentelemetry/proto/common/v1/common.proto \
  opentelemetry/proto/resource/v1/resource.proto \
  opentelemetry/proto/logs/v1/logs.proto \
  opentelemetry/proto/collector/logs/v1/logs_service.proto \
  ; do
  install -D "$TMP/$f" "$DEST/$f"
done

echo "protos ready under $DEST"
