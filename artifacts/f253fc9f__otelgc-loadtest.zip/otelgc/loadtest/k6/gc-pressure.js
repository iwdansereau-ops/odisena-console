// k6 load test that drives an OTel Collector's OTLP/HTTP endpoint hard enough
// to force GC pauses above 100 ms.
//
// Strategy
// --------
// The collector's per-signal unmarshal path allocates one Go object per
// resource, scope, record, attribute, and data point. To force a pause of
// >100 ms on a modestly-sized VM, we need the sustained allocation rate of
// live objects to blow past the GC's target (NextGC). Two knobs dominate:
//
//   PAYLOAD_WIDTH   attributes per log record / span / data point
//   VUS             concurrent HTTP virtual users
//
// Defaults below hit ~2-4 GB/min heap churn on a 4-core, 4 GiB collector
// running the sample deploy/otelcol/config.yaml (memory_limiter at 80%).
// Adjust via env vars if your target is bigger or smaller.
//
// Usage
// -----
//   k6 run \
//     -e OTLP_URL=http://localhost:4318 \
//     -e SIGNAL=logs \
//     -e PAYLOAD_WIDTH=64 \
//     -e RECORDS_PER_REQUEST=500 \
//     loadtest/k6/gc-pressure.js
//
// Signals: logs (default, easiest to blow up), traces, metrics.

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Counter, Trend, Gauge } from 'k6/metrics';
import { randomString } from 'https://jslib.k6.io/k6-utils/1.4.0/index.js';

// ---- tunables ---------------------------------------------------------------

const OTLP_URL             = __ENV.OTLP_URL             || 'http://localhost:4318';
const SIGNAL               = (__ENV.SIGNAL              || 'logs').toLowerCase();
const PAYLOAD_WIDTH        = parseInt(__ENV.PAYLOAD_WIDTH        || '64',   10);
const RECORDS_PER_REQUEST  = parseInt(__ENV.RECORDS_PER_REQUEST  || '500',  10);
const RESOURCE_ATTR_COUNT  = parseInt(__ENV.RESOURCE_ATTR_COUNT  || '16',   10);
const STRING_ATTR_BYTES    = parseInt(__ENV.STRING_ATTR_BYTES    || '96',   10);
const RAMP_TARGET_VUS      = parseInt(__ENV.RAMP_TARGET_VUS      || '200',  10);
const RAMP_DURATION        = __ENV.RAMP_DURATION        || '30s';
const SUSTAIN_DURATION     = __ENV.SUSTAIN_DURATION     || '3m';
const COOLDOWN_DURATION    = __ENV.COOLDOWN_DURATION    || '30s';

// ---- k6 options / stages ----------------------------------------------------

export const options = {
  discardResponseBodies: true, // matters: k6 side also allocates less
  scenarios: {
    gc_pressure: {
      executor: 'ramping-vus',
      startVUs: 0,
      gracefulRampDown: '10s',
      gracefulStop: '10s',
      stages: [
        { duration: RAMP_DURATION,    target: RAMP_TARGET_VUS },
        { duration: SUSTAIN_DURATION, target: RAMP_TARGET_VUS },
        { duration: COOLDOWN_DURATION, target: 0 },
      ],
    },
  },
  thresholds: {
    // We do NOT threshold on http_req_failed: some 429/503 from the
    // memory_limiter processor is *expected* under pressure and doesn't mean
    // the test failed. The test's real goal is triggering GC events, verified
    // by scripts/verify-capture.sh, not zero-error load.
    'http_req_duration': ['p(95)<10000'],
  },
};

// ---- custom k6 metrics ------------------------------------------------------

const pdataObjectsSent  = new Counter('pdata_objects_sent_total');
const pdataAttrsSent    = new Counter('pdata_attrs_sent_total');
const collectorLatency  = new Trend('collector_latency_ms', true);
const payloadBytes      = new Gauge('payload_bytes');

// ---- payload builders -------------------------------------------------------
//
// We build the JSON payload once per VU iteration but mutate a few unique
// fields so the collector cannot cheat with any hypothetical interning path.

const HOSTNAME_PREFIX = randomString(8);

function nowNs()      { return `${Date.now()}000000`; }
function traceIdHex() { return randomString(32, '0123456789abcdef'); }
function spanIdHex()  { return randomString(16, '0123456789abcdef'); }

function resourceAttrs() {
  const attrs = [
    { key: 'service.name',       value: { stringValue: `gcload-${HOSTNAME_PREFIX}` } },
    { key: 'service.instance.id', value: { stringValue: randomString(24) } },
    { key: 'host.name',           value: { stringValue: `${HOSTNAME_PREFIX}-${__VU}` } },
    { key: 'deployment.environment', value: { stringValue: 'loadtest' } },
  ];
  for (let i = attrs.length; i < RESOURCE_ATTR_COUNT; i++) {
    attrs.push({
      key: `res.attr.${i}`,
      value: { stringValue: randomString(STRING_ATTR_BYTES) },
    });
  }
  return attrs;
}

function recordAttrs(seed) {
  // Alternate types so pdata's []Value slice contains many distinct object
  // allocations rather than uniform primitives.
  const attrs = [];
  for (let i = 0; i < PAYLOAD_WIDTH; i++) {
    let value;
    switch (i % 5) {
      case 0: value = { stringValue: randomString(STRING_ATTR_BYTES) }; break;
      case 1: value = { intValue: `${seed * 131 + i}` }; break;
      case 2: value = { doubleValue: (seed + i) * 0.001 }; break;
      case 3: value = { boolValue: (seed + i) % 2 === 0 }; break;
      case 4: value = { arrayValue: { values: [
        { stringValue: randomString(24) },
        { intValue: `${i}` },
        { stringValue: randomString(24) },
      ]}}; break;
    }
    attrs.push({ key: `attr.${i}`, value });
  }
  return attrs;
}

function buildLogsPayload() {
  const records = new Array(RECORDS_PER_REQUEST);
  for (let i = 0; i < RECORDS_PER_REQUEST; i++) {
    records[i] = {
      timeUnixNano: nowNs(),
      observedTimeUnixNano: nowNs(),
      severityNumber: 9,
      severityText: 'INFO',
      body: { stringValue: `log line ${__VU}/${__ITER}/${i} ${randomString(64)}` },
      attributes: recordAttrs(i),
      traceId: traceIdHex(),
      spanId:  spanIdHex(),
    };
  }
  return {
    resourceLogs: [{
      resource: { attributes: resourceAttrs() },
      scopeLogs: [{
        scope: { name: 'k6.gcload', version: '1.0.0' },
        logRecords: records,
      }],
    }],
  };
}

function buildTracesPayload() {
  const spans = new Array(RECORDS_PER_REQUEST);
  const traceId = traceIdHex();
  for (let i = 0; i < RECORDS_PER_REQUEST; i++) {
    const start = Date.now() * 1e6 - i * 1e6;
    spans[i] = {
      traceId: traceId,
      spanId:  spanIdHex(),
      parentSpanId: i === 0 ? '' : spanIdHex(),
      name: `op.${i}`,
      kind: 2,
      startTimeUnixNano: `${start}`,
      endTimeUnixNano:   `${start + 5_000_000}`,
      attributes: recordAttrs(i),
      status: { code: 1 },
    };
  }
  return {
    resourceSpans: [{
      resource: { attributes: resourceAttrs() },
      scopeSpans: [{
        scope: { name: 'k6.gcload' },
        spans: spans,
      }],
    }],
  };
}

function buildMetricsPayload() {
  // Metrics-side pressure is best created via many data points per metric —
  // the pdata datapoint slice is where large chunks of allocation happen.
  const dpPerMetric = Math.max(1, Math.floor(RECORDS_PER_REQUEST / 8));
  const metrics = new Array(8);
  const nowStr = nowNs();
  for (let m = 0; m < 8; m++) {
    const dps = new Array(dpPerMetric);
    for (let i = 0; i < dpPerMetric; i++) {
      dps[i] = {
        attributes: recordAttrs(i),
        startTimeUnixNano: nowStr,
        timeUnixNano: nowStr,
        asDouble: Math.random() * 1000,
      };
    }
    metrics[m] = {
      name: `gcload.metric.${m}`,
      unit: 'By',
      gauge: { dataPoints: dps },
    };
  }
  return {
    resourceMetrics: [{
      resource: { attributes: resourceAttrs() },
      scopeMetrics: [{
        scope: { name: 'k6.gcload' },
        metrics: metrics,
      }],
    }],
  };
}

// ---- request loop -----------------------------------------------------------

const PATH_BY_SIGNAL = {
  logs:    '/v1/logs',
  traces:  '/v1/traces',
  metrics: '/v1/metrics',
};

const BUILDER_BY_SIGNAL = {
  logs:    buildLogsPayload,
  traces:  buildTracesPayload,
  metrics: buildMetricsPayload,
};

export default function () {
  const path    = PATH_BY_SIGNAL[SIGNAL];
  const builder = BUILDER_BY_SIGNAL[SIGNAL];
  if (!path) {
    throw new Error(`unsupported SIGNAL=${SIGNAL}; use logs|traces|metrics`);
  }

  const bodyObj = builder();
  const body    = JSON.stringify(bodyObj);
  payloadBytes.add(body.length);

  const started = Date.now();
  const res = http.post(`${OTLP_URL}${path}`, body, {
    headers: { 'Content-Type': 'application/json' },
    timeout: '30s',
    tags:    { signal: SIGNAL },
  });
  collectorLatency.add(Date.now() - started);

  // Under memory_limiter pressure the collector returns 429/503; treat those
  // as "delivered pressure" rather than errors.
  const ok = check(res, {
    'status is 2xx / 429 / 503': (r) => r.status === 200 || r.status === 429 || r.status === 503,
  });
  if (!ok) {
    // Only log unexpected statuses.
    console.error(`unexpected status ${res.status} body=${res.body}`);
  }

  pdataObjectsSent.add(RECORDS_PER_REQUEST, { signal: SIGNAL });
  pdataAttrsSent.add(RECORDS_PER_REQUEST * PAYLOAD_WIDTH, { signal: SIGNAL });

  // No sleep — we want maximum in-flight requests per VU.
}

export function setup() {
  console.log(`gc-pressure load test`);
  console.log(`  target        : ${OTLP_URL}`);
  console.log(`  signal        : ${SIGNAL}`);
  console.log(`  payload_width : ${PAYLOAD_WIDTH} attrs/record`);
  console.log(`  records/req   : ${RECORDS_PER_REQUEST}`);
  console.log(`  ramp target   : ${RAMP_TARGET_VUS} VUs`);
  console.log(`  phases        : ramp ${RAMP_DURATION} -> sustain ${SUSTAIN_DURATION} -> cooldown ${COOLDOWN_DURATION}`);
}
