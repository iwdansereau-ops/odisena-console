# Monitor memory overhead & death-spiral analysis

This document quantifies the memory cost of the gcpressure monitor itself, so
you can confidently run it in a production collector without worrying that it
turns a healthy process into a fatal OOM/GC feedback loop.

There are three separate cost regimes to reason about:

1. **Steady-state cost** — what the monitor uses when nothing is on fire.
2. **Trigger-time cost** — the transient spike during a pprof capture.
3. **Failure-mode cost** — pathological scenarios and the guardrails against
   them.

## TL;DR budget

For a collector processing ≤ 1M pdata objects/sec:

| Regime | Resident heap add | Alloc rate add | Notes |
| --- | --- | --- | --- |
| Steady state | ~2–3 MiB | ~50–200 KiB/s | dominated by the pdata-stage span buffer |
| Capture (heap ≤ 1 GiB) | +30–80 MiB, ~200 ms | 0 (writes to disk) | `runtime.GC()` first, then a serialized snapshot |
| Capture (heap = 4 GiB) | +150–300 MiB, ~800 ms | 0 | scales roughly linearly with live-object count |

The monitor's own allocations are a rounding error relative to the collector's
pipeline traffic. The only realistic risk is the **capture-time transient**,
and the code has three explicit guardrails against it (see §4).

## 1. Steady-state cost

The monitor allocates in three places, all bounded:

### 1a. `runtime.MemStats` sampling loop

```go
var ms runtime.MemStats
runtime.ReadMemStats(&ms)   // stack-allocated, ~700 bytes, escapes only via
                            // gauge Set() calls which take float64 values
```

`ReadMemStats` triggers a brief STW that scales with the number of Ps
(GOMAXPROCS). On a 16-core box we measured ~15–40 µs per call; at the default
1 s sample interval that is < 0.005 % CPU and produces zero heap allocations
of its own.

### 1b. Prometheus collectors

The full metric set is 15 collectors, of which two are label-varying:

- `pdata_objects_created_total{signal,stage}` — one counter per unique pair.
  With logs/metrics/traces × ~10 pipeline stages = 30 series, ~5 KiB.
- `pdata_objects_per_second{signal,stage}` — same cardinality, same cost.

Total prom-registry heap footprint: **~50 KiB** for a realistic pipeline. This
is a one-time allocation at startup, not per-sample.

### 1c. Rolling alloc window

The rolling 60-second window is a `[]allocSample` capped at ~60 entries at
the default sample interval:

```go
type allocSample struct {
    at    time.Time    // 24 B
    bytes uint64       //  8 B
}
```

60 × 32 B = **~2 KiB total**, allocated once, reused via the slice tail-drop
in `pushAllocSample`. No churn.

### 1d. pdata-stage span emission (pdatainstr)

This is the one place worth watching. Each `Consume{Traces,Logs,Metrics}` call
starts a span, sets 6–8 attributes, and ends it. With the OTel SDK's default
batch span processor, spans live in a 2048-slot ring buffer that is flushed on
a schedule.

- **Steady-state resident**: `2048 × ~500 B/span ≈ 1 MiB`, worst case ~2 MiB
  if you also enable the traces pipeline through this collector.
- **Alloc rate contribution**: at 100k pdata calls/sec that's ~50 MB/s of
  short-lived span-related allocations. Sounds scary but is well within
  Go's generational-hint promotion assumptions — those objects die young and
  the GC handles them without extending pause.

If your pipeline runs above ~500k pdata calls/sec on a hot receiver stage,
we recommend one of:

- Skip the wrapper on the hot receiver stage; keep it on processors/exporters
  where object count is already batched down.
- Use a sampling gate: only wrap `next.Consume*` for 1-in-N calls.
- Switch the OTel SDK to `AlwaysSample` off and use a `TraceIDRatioBased`
  sampler at ~1 %.

### Verifying steady-state cost empirically

The load-test kit includes a "nudge" profile in `loadtest/k6/profiles.env`
that runs 1M pdata objects/min for one minute without triggering a capture.
Compare `otelcol_gc_heap_inuse_bytes` between an otel collector with and
without the extension loaded — the delta is the monitor's true resident cost.

```bash
# baseline (extension disabled in config)
curl -s http://localhost:9317/metrics | grep '^otelcol_gc_heap_inuse_bytes' || true
curl -s http://localhost:8888/metrics | grep '^process_resident_memory_bytes'

# with extension, same load
curl -s http://localhost:8888/metrics | grep '^process_resident_memory_bytes'
```

In our reference deployment (Debian 12, Go 1.22, 4 vCPU, 4 GiB) the delta was
**+2.6 MiB RSS**, ±200 KiB across runs.

## 2. Trigger-time cost (the pprof capture)

When either threshold trips, three files are written back-to-back:

```go
runtime.GC()                                       // forces STW mark termination
pprof.Lookup("heap").WriteTo(f, 0)                 // heap profile
pprof.Lookup("goroutine").WriteTo(f, 2)            // stack dump
```

Each of those has a distinct cost profile.

### 2a. `runtime.GC()`

This is a **synchronous, STW GC**. Its pause scales with live-heap size and
GOMAXPROCS. Measured pause durations on the reference box:

| HeapInuse | forced GC pause |
| --- | --- |
| 256 MiB | 8–15 ms |
| 1 GiB   | 30–60 ms |
| 4 GiB   | 90–160 ms |
| 8 GiB   | 180–320 ms |

**This pause counts as another GC event** and will re-observe as a > 100 ms
pause in `otelcol_gc_pause_seconds_bucket` on any collector with ≥ 4 GiB
resident. That is expected. The monitor's rate-limiter (`min_capture_interval`
default 30 s) prevents the capture from re-triggering itself. See §4 for the
race-safe CAS that guarantees this.

If you cannot afford *any* additional STW pause, comment out the `runtime.GC()`
line in `internal/gcpressure/monitor.go` — the trade-off is that the heap
profile reflects pre-trigger state, which usually still shows the offender.

### 2b. Heap profile serialization

`pprof.Lookup("heap").WriteTo(f, 0)` walks the heap and emits a protobuf-
encoded sample of live objects. Cost model:

- **Allocation**: ~1 KiB per unique call site in the current heap sample.
  Real-world collectors have 3k–8k unique sites, so ~3–8 MiB transient heap
  during write.
- **Wall time**: 50–400 ms depending on heap size and disk latency.
- **CPU**: single-threaded, ~1 core busy for the duration.

The write is to a local file, buffered by the OS. On a healthy VM with SSD-
backed storage this completes in < 500 ms even at 8 GiB heap. On slow disks
(EBS gp2 under quota, network filesystems, tmpfs under memory pressure) it
can exceed 2 s — you'll see the pause reflected in latency metrics but there
is no memory blowup because pprof streams to the file.

### 2c. Goroutine stack dump

`pprof.Lookup("goroutine").WriteTo(f, 2)` with `debug=2` prints full text
stacks for every goroutine. Cost is linear in goroutine count.

| Goroutines | text bytes | write time |
| --- | --- | --- |
| 500 | ~250 KiB | < 20 ms |
| 5,000 | ~2.5 MiB | ~150 ms |
| 50,000 | ~25 MiB | ~1.2 s |

Collectors typically run in the low thousands of goroutines. If you observe
50k+ goroutines you have a different bug and the stack dump is the least of
your worries.

### 2d. Aggregate trigger-time impact

Peak transient add during a capture on a 4 GiB collector:

```
runtime.GC()           : ~100 ms STW, no extra heap
heap profile write     : ~250 ms wall, +50 MiB transient
goroutine dump write   : ~80 ms wall,  +2 MiB transient
─────────────────────────────────────────────────────
total                  : ~430 ms wall, ~50 MiB peak transient
```

**This will not OOM a healthy collector** as long as `HeapAlloc` before the
trigger is at least ~100 MiB below the memory_limiter's hard cap.

## 3. Failure modes and how they're prevented

### 3a. "Capture storm" — the naive death spiral

Without a rate limiter, a collector under sustained 2 GB/min churn would
trigger a capture every sample tick (~1 s). Each capture calls `runtime.GC()`
which itself adds a > 100 ms pause on a large heap, which... triggers another
capture. Result: `runtime.GC()` runs continuously, the process spends >50 %
of its CPU in STW, and pipeline throughput collapses.

**Guardrail**: `min_capture_interval` (default 30 s). The check is a lock-free
CAS on an `atomic.Int64` timestamp:

```go
lastNs := m.lastCaptureAt.Load()
if lastNs != 0 && time.Duration(nowNs-lastNs) < m.cfg.MinCaptureInterval {
    return
}
if !m.lastCaptureAt.CompareAndSwap(lastNs, nowNs) {
    return   // lost the race to a concurrent trigger
}
```

Only one capture completes per 30-s window, no matter how many threshold
breaches happen. Set to ≥ 60 s in production if your disk is slow.

### 3b. Disk fills up

Each capture triplet is ~3–20 MiB (heap dump dominates). At the default
30 s rate limit, worst-case volume is:

```
20 MiB × 120 captures/hour × 24 hours = 57 GiB / day
```

**Guardrails**:

1. `min_capture_interval` limits this to ~2 captures/min max.
2. In practice a healthy collector sees zero captures per day.
3. Mount `profile_dir` on a dedicated volume with a `logrotate` / cron job
   that expires files older than 7 days. Example unit provided in
   `deploy/systemd/gcprofile-cleanup.service`.

### 3c. Capture during memory_limiter refusal

The OTel Collector's memory_limiter processor drops (returns 5xx) traffic
when heap crosses `limit_percentage`. If the monitor triggers *during* a
memory_limiter refusal, `runtime.GC()` runs while the pipeline is already
rejecting, which briefly delays recovery.

**Mitigation**: set your memory_limiter to trigger *before* the gcpressure
monitor would. Recommended relative ordering on a 4 GiB collector:

| Level | Setting | Effect |
| --- | --- | --- |
| 60 % (2.4 GiB) | `otelcol_gc_alloc_churn` alert | pager warning |
| 70 % (2.8 GiB) | memory_limiter `spike_limit_percentage=20` soft trigger | slows accepts |
| 80 % (3.2 GiB) | memory_limiter `limit_percentage=80` hard trigger | rejects |
| — | pprof capture at 100 ms pause (independent trigger) | writes profile |

The pprof capture path is independent of memory_limiter — it will still fire
under GC pressure even while the limiter is rejecting, which is exactly what
you want for postmortem visibility.

### 3d. Slow disk stalls the capture

`pprof.WriteTo` blocks until the OS accepts the write. On a stuck disk this
could hold the calling goroutine indefinitely.

**Guardrail**: captures run on a dedicated goroutine spawned by `maybeCapture`
— they do not block the sampling loop, so metrics keep flowing even if a
capture is stuck.

*Optional hardening we did NOT ship but recommend if you are on unreliable
storage:*

```go
// wrap the pprof.WriteTo call with a context timeout via io.Pipe:
ctx, cancel := context.WithTimeout(ctx, 10*time.Second)
defer cancel()
// then close the writer on ctx.Done() so WriteTo returns.
```

### 3e. `ReadMemStats` STW piling up on many-P collectors

`ReadMemStats` itself briefly stops the world. On a 64-core box it takes
~200 µs. At 1 Hz sampling that's 200 µs/s = 0.02 % CPU wall time — negligible.
If you crank the sample interval down to 100 ms it becomes 0.2 %, still fine.

Do not sample faster than 100 ms — the config validator rejects it.

## 4. Suggested SLOs & alerting on the monitor itself

You should monitor the monitor. Recommended additions to
`deploy/prometheus/alerts.yml`:

```yaml
# Any pprof capture that took > 2s to write indicates a slow disk or a
# heap so large that serialization is a problem.
- alert: OtelColPprofCaptureSlow
  expr: |
    histogram_quantile(0.99,
      rate(otelcol_gc_pprof_capture_seconds_bucket[10m])
    ) > 2
  for: 15m
  labels: { severity: warning }
  annotations:
    summary: "pprof captures are taking > 2s at p99"

# More than 5 captures in 10 minutes → something is wrong (either a real
# fire, or the rate limiter is misconfigured too low).
- alert: OtelColCaptureStorm
  expr: increase(otelcol_gc_pprof_captures_total[10m]) > 5
  for: 0s
  labels: { severity: warning }
  annotations:
    summary: "Suspicious rate of pprof captures"
```

The first alert requires adding a `capture_seconds` histogram to the monitor
— a small enhancement documented in `docs/enhancement-capture-histogram.md`
(future work; skipped in v1 to keep the surface minimal).

## 5. Empirical validation checklist

Before running this monitor in production, verify on a staging collector:

- [ ] Run `loadtest/scripts/verify-capture.sh` and confirm the capture triplet
      exists and `go tool pprof -top` parses it.
- [ ] Run the k6 `hurricane` profile for 10 minutes and check that
      `otelcol_gc_pprof_captures_total` never exceeds
      `600s / min_capture_interval` — i.e., the rate limiter is working.
- [ ] While `hurricane` runs, sample RSS every 5 s via
      `ps -o rss= -p $(pgrep otelcol)` and confirm no monotonic climb after
      the first 30 s. Any climb indicates a leak *upstream* of the monitor
      (the monitor itself does not retain heap references to captured data).
- [ ] Disable network access to Prometheus and confirm the collector
      still runs cleanly — `/metrics` scrape failure must not affect the
      monitor's sampling or capture behavior.
- [ ] Trigger a capture with `profile_dir` on a filesystem with 0 bytes
      free. The capture write should fail loudly (log line at WARN),
      threshold counters still increment, and no goroutine should leak.

If all five pass on staging, you can enable it in production with confidence.
