# GC Pressure Load Test Kit

Purpose: prove, in staging or a dev container, that the gcpressure monitor
actually triggers under sustained load and that its captured artifacts are
usable — without leaving room for "it looked fine in the unit tests."

```
loadtest/
├── k6/
│   ├── gc-pressure.js      main k6 load driver (OTLP/HTTP)
│   └── profiles.env        nudge / breach / hurricane presets
├── ghz/
│   ├── run-ghz.sh          gRPC alternative (uses ghz)
│   ├── fetch-protos.sh     vendors OTLP protos
│   └── gen-payload.js      builds a single ExportLogsServiceRequest
├── scripts/
│   └── verify-capture.sh   end-to-end trigger + assertion
└── docs/
    └── memory-overhead.md  monitor cost analysis + death-spiral guardrails
```

## Quick start

Assumes the docker-compose stack from `deploy/` is running and the
`gcpressure` extension is enabled with `profile_dir: /var/lib/otelcol/gcprofiles`.

```bash
# 1. Install k6 (any recent version)
brew install k6                    # or:  go install go.k6.io/k6@latest

# 2. Make the profile dir readable from your host
docker compose -f deploy/docker-compose.yaml exec otelcol \
  chmod -R a+rX /var/lib/otelcol/gcprofiles

# 3. Run end-to-end verification
PROFILE_DIR=$(docker volume inspect deploy_otelcol-profiles \
                --format '{{ .Mountpoint }}')/gcprofiles \
  ./loadtest/scripts/verify-capture.sh
```

Expected output (~90 s):

```
▶ preflight
  metrics endpoint  : reachable
  profile directory : /var/lib/docker/volumes/…/gcprofiles
  load tool         : k6
  pprof validator   : go tool pprof
▶ capturing baseline
▶ driving load (k6)
▶ waiting for a capture (max 240s)
  [ 62s] captures=1 files=1 churn_bpm=2374127616 pause_last=0.121
▶ verifying capture triplet
  meta reason=heap_churn
  heap magic bytes  : OK (0x1f 0x8b)
  go tool pprof     : parsed (57 lines of -top output)
  stacks content    : OK (found runtime/pdata frames)
▶ verifying Prometheus counters advanced
  pprof_captures_total       : 0 -> 1
  threshold_exceeded{pause}  : 0 -> 3
  threshold_exceeded{churn}  : 0 -> 8
▶ SUCCESS
```

## Design: why these knobs force GC pauses over 100 ms

The Go GC's pause time is essentially the time it takes to scan the goroutine
stacks and finish the mark termination STW phase. Both grow with:

1. **Live-object count** — more objects = more pointers to scan.
2. **Allocation rate during marking** — a runaway allocator forces the GC
   to shorten its mark budget, which means longer mark-assist stalls and
   eventually a hard STW.

The k6 script maximizes both by design:

- **`PAYLOAD_WIDTH=64`**: each log record contains 64 attributes. When the
  collector's protobuf/JSON unmarshaller processes the request, it allocates
  one `pcommon.Value` struct per attribute plus the underlying string bytes.
  A 500-record request thus creates ~32,000 Go objects for the attribute
  slice alone, plus ~500 record structs, plus resource/scope objects.
- **`RECORDS_PER_REQUEST=500`**: keeps request framing overhead low, so almost
  all wall time is spent in unmarshal + processors.
- **200 VUs, no sleep**: sustains 100–300 in-flight requests per collector
  core, keeping the allocator continuously hot.

Together this yields ~2–4 GB/min heap churn on a 4-vCPU / 4-GiB Debian VM,
which reliably drives at least one > 100 ms GC pause per minute during the
sustain phase.

## Profiles

| Profile | RECORDS/req | attrs | VUs | Expected churn | Expected max pause |
| --- | ---: | ---: | ---: | ---: | ---: |
| `nudge` | 100 | 16 | 50 | 300–600 MB/min | < 40 ms |
| `breach` (default) | 500 | 64 | 200 | 2–4 GB/min | 100–250 ms |
| `hurricane` | 1000 | 128 | 400 | 6–10 GB/min | 250–700 ms |

The `nudge` profile is deliberately below the trigger — use it to verify
that steady-state metrics work without the noise of captures. `hurricane` will
usually cause `memory_limiter` to reject a chunk of traffic; that's fine, the
receiver-side allocation already happened.

## ghz variant

If you want to isolate to OTLP/gRPC (higher allocation density per byte
because protobuf → pdata is stricter than JSON → pdata):

```bash
./loadtest/ghz/fetch-protos.sh
./loadtest/ghz/run-ghz.sh                       # breach profile
PROFILE=hurricane ./loadtest/ghz/run-ghz.sh
```

Then run the verifier with `LOAD_TOOL=ghz`:

```bash
LOAD_TOOL=ghz PROFILE_DIR=/path/to/dir ./loadtest/scripts/verify-capture.sh
```

## Reading the results

After a successful run:

```bash
# Open the captured heap in the interactive pprof web UI
go tool pprof -http :0 /path/to/gcprofiles/gc-heap_churn-<timestamp>.heap.pprof

# Correlate with pipeline spans (see main README)
go run ./cmd/gccorrelate \
  --profile-dir /path/to/gcprofiles \
  --spans       /var/lib/otelcol/spans.jsonl \
  --prom-url    http://localhost:9090 \
  --window      30s
```

The Grafana dashboard shows the pprof-capture events as vertical annotations
so you can eyeball the load-test timeline against churn and pause history.

## Production safety

Read `docs/memory-overhead.md` before enabling the monitor in production.
Summary: **~2–3 MiB steady-state overhead, +30–150 MiB transient per capture,
guarded by a 30 s rate limiter and off-loop capture goroutine.**
