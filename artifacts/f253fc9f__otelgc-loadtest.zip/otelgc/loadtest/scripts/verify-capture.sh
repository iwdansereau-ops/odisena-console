#!/usr/bin/env bash
# End-to-end verification that the gcpressure monitor:
#   1. Fires its 100ms-pause AND 2GB/min-churn triggers under sustained load.
#   2. Writes a heap pprof + goroutine stack + meta triplet to $PROFILE_DIR.
#   3. Produces well-formed pprof output (readable by `go tool pprof`).
#   4. Increments the Prometheus threshold_exceeded_total counter.
#
# Exits 0 on success, non-zero and prints diagnostics otherwise.
#
# Environment (all optional):
#   OTLP_URL         default http://localhost:4318
#   COLLECTOR_METRICS default http://localhost:9317/metrics
#   PROFILE_DIR      default /var/lib/otelcol/gcprofiles
#                    (must be readable from wherever this script runs;
#                     for docker-compose use `docker compose cp` or a bind mount)
#   LOAD_TOOL        k6 (default) | ghz
#   K6_SCRIPT        default $REPO/loadtest/k6/gc-pressure.js
#   MAX_WAIT_SEC     default 240 (how long to wait for a capture after ramp)
#
# Example:
#   PROFILE_DIR=/tmp/otelcol-gcprofiles ./verify-capture.sh

set -euo pipefail

# ---- config -----------------------------------------------------------------

OTLP_URL="${OTLP_URL:-http://localhost:4318}"
COLLECTOR_METRICS="${COLLECTOR_METRICS:-http://localhost:9317/metrics}"
PROFILE_DIR="${PROFILE_DIR:-/var/lib/otelcol/gcprofiles}"
LOAD_TOOL="${LOAD_TOOL:-k6}"
K6_SCRIPT="${K6_SCRIPT:-$(cd "$(dirname "$0")/.." && pwd)/k6/gc-pressure.js}"
K6_PROFILES_ENV="${K6_PROFILES_ENV:-$(cd "$(dirname "$0")/.." && pwd)/k6/profiles.env}"
MAX_WAIT_SEC="${MAX_WAIT_SEC:-240}"

# ---- helpers ----------------------------------------------------------------

_red()   { printf '\033[31m%s\033[0m\n' "$*" >&2; }
_green() { printf '\033[32m%s\033[0m\n' "$*"; }
_yellow(){ printf '\033[33m%s\033[0m\n' "$*"; }
_step()  { printf '\n\033[1m▶ %s\033[0m\n' "$*"; }

_fail() { _red "FAIL: $*"; exit 1; }

_require() {
  command -v "$1" >/dev/null 2>&1 || _fail "required tool not found: $1"
}

_metric() {
  # Fetch a single Prometheus metric line's value (sum across labels).
  local name="$1"
  curl -fsS "$COLLECTOR_METRICS" \
    | awk -v n="$name" '
        $0 !~ /^#/ && index($1, n) == 1 { s += $2 }
        END { printf "%.0f", s+0 }
      '
}

# ---- 0. preflight -----------------------------------------------------------

_step "preflight"

_require curl
_require awk
case "$LOAD_TOOL" in
  k6)  _require k6  ;;
  ghz) _require ghz ;;
  *)   _fail "unknown LOAD_TOOL=$LOAD_TOOL (k6|ghz)" ;;
esac

# The pprof CLI (go tool pprof) is optional but strongly preferred for
# validating the binary format. We fall back to a magic-bytes check.
HAVE_PPROF=0
if command -v go >/dev/null 2>&1 && go tool pprof -h >/dev/null 2>&1; then
  HAVE_PPROF=1
fi

if ! curl -fsS "$COLLECTOR_METRICS" >/dev/null; then
  _fail "collector /metrics not reachable at $COLLECTOR_METRICS"
fi

if [ ! -d "$PROFILE_DIR" ]; then
  _fail "PROFILE_DIR=$PROFILE_DIR does not exist (or is not readable from here)"
fi

_green "  metrics endpoint  : reachable"
_green "  profile directory : $PROFILE_DIR"
_green "  load tool         : $LOAD_TOOL"
[ "$HAVE_PPROF" = 1 ] && _green "  pprof validator   : go tool pprof" \
                     || _yellow "  pprof validator   : magic-bytes fallback (install Go for stricter check)"

# ---- 1. baseline snapshot ---------------------------------------------------

_step "capturing baseline"

BASELINE_PAUSE=$(_metric otelcol_gc_threshold_exceeded_total{kind=\"pause\"} || echo 0)
BASELINE_CHURN=$(_metric otelcol_gc_threshold_exceeded_total{kind=\"churn\"} || echo 0)
BASELINE_CAPS=$(_metric otelcol_gc_pprof_captures_total || echo 0)
BASELINE_HEAP=$(_metric otelcol_gc_heap_alloc_bytes || echo 0)

BASELINE_FILES=$(find "$PROFILE_DIR" -maxdepth 1 -name 'gc-*.meta.txt' 2>/dev/null | wc -l | tr -d ' ')

echo "  threshold_exceeded{pause} = $BASELINE_PAUSE"
echo "  threshold_exceeded{churn} = $BASELINE_CHURN"
echo "  pprof_captures_total      = $BASELINE_CAPS"
echo "  heap_alloc_bytes          = $BASELINE_HEAP"
echo "  existing capture files    = $BASELINE_FILES"

# ---- 2. drive load ----------------------------------------------------------

_step "driving load ($LOAD_TOOL)"

LOAD_LOG="$(mktemp)"
if [ "$LOAD_TOOL" = "k6" ]; then
  # Read the 'breach' profile from profiles.env, ignoring commented lines.
  ENV_ARGS=()
  while IFS= read -r line; do
    case "$line" in
      ''|'#'*) ;;
      *) ENV_ARGS+=("-e" "$line") ;;
    esac
  done < "$K6_PROFILES_ENV"
  # Override OTLP_URL from the environment if the caller set one.
  ENV_ARGS+=("-e" "OTLP_URL=$OTLP_URL")
  ( set -x; k6 run "${ENV_ARGS[@]}" "$K6_SCRIPT" ) >"$LOAD_LOG" 2>&1 &
else
  ( cd "$(dirname "$0")/../ghz" && TARGET="${OTLP_URL/http:\/\//}" ./run-ghz.sh ) >"$LOAD_LOG" 2>&1 &
fi
LOAD_PID=$!

# ---- 3. poll for capture ----------------------------------------------------

_step "waiting for a capture (max ${MAX_WAIT_SEC}s)"

CAPTURED=0
START=$(date +%s)
while :; do
  NOW=$(date +%s)
  ELAPSED=$(( NOW - START ))
  if [ "$ELAPSED" -ge "$MAX_WAIT_SEC" ]; then
    break
  fi

  CURRENT_CAPS=$(_metric otelcol_gc_pprof_captures_total || echo 0)
  CURRENT_FILES=$(find "$PROFILE_DIR" -maxdepth 1 -name 'gc-*.meta.txt' 2>/dev/null | wc -l | tr -d ' ')

  if [ "$CURRENT_CAPS" -gt "$BASELINE_CAPS" ] && [ "$CURRENT_FILES" -gt "$BASELINE_FILES" ]; then
    CAPTURED=1
    break
  fi

  printf '\r  [%3ds] captures=%s files=%s churn_bpm=%s pause_last=%s   ' \
    "$ELAPSED" "$CURRENT_CAPS" "$CURRENT_FILES" \
    "$(_metric otelcol_gc_alloc_churn_bytes_per_minute || echo 0)" \
    "$(_metric otelcol_gc_pause_last_seconds || echo 0)"
  sleep 2
done
echo

# Stop the load generator (but let k6's own cooldown run if it's already there).
if kill -0 "$LOAD_PID" 2>/dev/null; then
  kill "$LOAD_PID" 2>/dev/null || true
  wait "$LOAD_PID" 2>/dev/null || true
fi

if [ "$CAPTURED" -ne 1 ]; then
  _yellow "load generator output (tail):"
  tail -n 40 "$LOAD_LOG" >&2 || true
  _fail "no new capture appeared within ${MAX_WAIT_SEC}s. Investigate: collector may have too much headroom, or memory_limiter is rejecting before allocations happen."
fi

# ---- 4. verify capture triplet ---------------------------------------------

_step "verifying capture triplet"

# Pick the newest meta file.
NEWEST_META=$(find "$PROFILE_DIR" -maxdepth 1 -name 'gc-*.meta.txt' -printf '%T@ %p\n' 2>/dev/null \
              | sort -nr | head -1 | awk '{print $2}')
[ -n "$NEWEST_META" ] || _fail "could not locate newest gc-*.meta.txt"

BASE="${NEWEST_META%.meta.txt}"
HEAP_FILE="${BASE}.heap.pprof"
STACK_FILE="${BASE}.stacks.txt"

echo "  meta   : $NEWEST_META"
echo "  heap   : $HEAP_FILE"
echo "  stacks : $STACK_FILE"

for f in "$NEWEST_META" "$HEAP_FILE" "$STACK_FILE"; do
  [ -f "$f" ] || _fail "missing companion file: $f"
  [ -s "$f" ] || _fail "empty file: $f"
done

# 4a. Meta file must contain reason=... and captured_at=...
grep -q '^reason='       "$NEWEST_META" || _fail "meta missing reason="
grep -q '^captured_at='  "$NEWEST_META" || _fail "meta missing captured_at="
REASON=$(awk -F= '/^reason=/{print $2; exit}' "$NEWEST_META")
_green "  meta reason=$REASON"

# 4b. Heap pprof must be a valid gzip'd protobuf (pprof format is gzipped).
#     First two bytes should be 0x1f 0x8b.
MAGIC=$(head -c2 "$HEAP_FILE" | od -An -tx1 | tr -d ' \n')
if [ "$MAGIC" != "1f8b" ]; then
  _fail "heap file $HEAP_FILE does not start with gzip magic (got $MAGIC)"
fi
_green "  heap magic bytes  : OK (0x1f 0x8b)"

# 4c. If we have go tool pprof, run a real parse.
if [ "$HAVE_PPROF" = 1 ]; then
  if go tool pprof -top -sample_index=inuse_space -unit=b "$HEAP_FILE" >/tmp/pprof-top.$$ 2>/dev/null; then
    LINES=$(wc -l </tmp/pprof-top.$$)
    _green "  go tool pprof     : parsed ($LINES lines of -top output)"
    rm -f /tmp/pprof-top.$$
  else
    _fail "go tool pprof failed to parse $HEAP_FILE"
  fi
fi

# 4d. Stack file should mention runtime GC frames or pdata frames — this
#     validates the goroutine dump captured what we expect at the moment of
#     the trigger. We are lenient: any of a handful of substrings is fine.
if grep -Eq 'runtime\.(gc|GC|mallocgc)|pdata|unmarshal|otelcol' "$STACK_FILE"; then
  _green "  stacks content    : OK (found runtime/pdata frames)"
else
  _yellow "  stacks content    : did not match expected substrings; keeping the file for manual review"
fi

# ---- 5. verify Prometheus counters advanced --------------------------------

_step "verifying Prometheus counters advanced"

FINAL_CAPS=$(_metric otelcol_gc_pprof_captures_total)
FINAL_PAUSE=$(_metric otelcol_gc_threshold_exceeded_total{kind=\"pause\"} || echo 0)
FINAL_CHURN=$(_metric otelcol_gc_threshold_exceeded_total{kind=\"churn\"} || echo 0)

echo "  pprof_captures_total       : $BASELINE_CAPS -> $FINAL_CAPS"
echo "  threshold_exceeded{pause}  : $BASELINE_PAUSE -> $FINAL_PAUSE"
echo "  threshold_exceeded{churn}  : $BASELINE_CHURN -> $FINAL_CHURN"

[ "$FINAL_CAPS" -gt "$BASELINE_CAPS" ] || _fail "pprof_captures_total did not advance"

if [ "$FINAL_PAUSE" -eq "$BASELINE_PAUSE" ] && [ "$FINAL_CHURN" -eq "$BASELINE_CHURN" ]; then
  _fail "neither pause nor churn threshold_exceeded counter advanced (capture reason: $REASON)"
fi

# ---- 6. summary -------------------------------------------------------------

_step "SUCCESS"
cat <<EOF
Captured artifact set:
  $NEWEST_META
  $HEAP_FILE
  $STACK_FILE

Reason              : $REASON
Load generator log  : $LOAD_LOG
Next step           : inspect the heap with
                        go tool pprof -http :0 $HEAP_FILE
                      and correlate with pipeline spans:
                        gccorrelate --profile-dir $PROFILE_DIR --spans /path/to/spans.jsonl
EOF
