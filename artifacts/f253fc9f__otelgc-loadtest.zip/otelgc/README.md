# OTel Collector · GC Pressure Monitor

A drop-in pprof-based GC pressure monitor for the OpenTelemetry Collector,
plus a Prometheus/Grafana dashboard, alerting, and a side-by-side correlation
tool that lines up heap allocation spikes with specific pdata pipeline stages.

## What it does

1. **Samples `runtime.MemStats` every second** and exports Prometheus metrics:
   - `otelcol_gc_heap_alloc_bytes`, `heap_inuse_bytes`, `heap_sys_bytes`,
     `heap_objects`, `next_gc_target_bytes`
   - `otelcol_gc_alloc_rate_bytes_per_second` (instantaneous)
   - `otelcol_gc_alloc_churn_bytes_per_minute` (rolling 60s window)
   - `otelcol_gc_pause_seconds` (histogram), `pause_last_seconds`
   - `otelcol_gc_cycles_total`, `cpu_fraction`
   - `otelcol_gc_pdata_objects_created_total{signal,stage}`
   - `otelcol_gc_pdata_objects_per_second{signal,stage}`
   - `otelcol_gc_pprof_captures_total{reason}`,
     `otelcol_gc_threshold_exceeded_total{kind}`
2. **Auto-captures pprof + goroutine stack traces** to `profile_dir`
   whenever:
   - A single GC pause ≥ **100 ms**, or
   - Rolling 60s heap churn ≥ **2 GB/min**
   Captures are rate-limited (default 30s) so a storm cannot fill the disk.
3. **Ships a Grafana dashboard** covering all of the above with capture
   events overlaid as annotations.
4. **Alerts** on 2 GB/min churn, ≥100 ms pauses, elevated p99 pause, and
   pdata velocity spikes (Prometheus alerting rules).
5. **Correlates pprof captures with pdata pipeline spans** so you can see
   which processors/exporters were active at the moment of a spike.

## Repo layout

```
internal/gcpressure/          the sampling + pprof-capture library
internal/pdatainstr/          consumer wrappers that annotate spans
extension/gcpressureextension/ OTel Collector extension wrapping the library
cmd/gcmon/                    standalone binary (dev / sidecar)
cmd/gccorrelate/              side-by-side correlation CLI
deploy/otelcol/               example config + `ocb` builder manifest
deploy/prometheus/            scrape config + alerts.yml
deploy/grafana/               provisioned datasource + dashboard JSON
deploy/docker-compose.yaml    local stack (collector + prom + grafana)
loadtest/                     k6 + ghz load drivers + verify-capture.sh
loadtest/docs/memory-overhead.md   production-safety analysis (read before rollout)
```

## Building the Collector

The extension is meant to be linked into a custom Collector distribution built
with the OpenTelemetry Collector Builder (`ocb`):

```bash
go install go.opentelemetry.io/collector/cmd/builder@latest
builder --config deploy/otelcol/builder-manifest.yaml
./bin/otelcol-gcpressure --config deploy/otelcol/config.yaml
```

Or run the standalone monitor:

```bash
go run ./cmd/gcmon \
  --listen :9317 \
  --pause-threshold 100ms \
  --churn-bytes-per-min $((2*1024*1024*1024)) \
  --profile-dir /var/lib/otelcol/gcprofiles
```

## Local dev stack

```bash
cd deploy
docker compose up -d
# Grafana:      http://localhost:3000  (admin / admin)
# Prometheus:   http://localhost:9090
# Collector:    OTLP :4317 (gRPC) / :4318 (HTTP), metrics :9317
```

The **OTel Collector · GC Pressure** dashboard is provisioned automatically.

## Wiring pdata instrumentation into pipelines

The `pdatainstr` package exposes `WrapTraces` / `WrapLogs` / `WrapMetrics`
functions that decorate a `consumer.T` with:

- pdata object velocity counters (fed to the Prometheus gauges), and
- per-stage OTel spans annotated with
  `otelcol.pdata.stage`, `otelcol.pdata.signal`,
  `otelcol.pdata.objects`, `otelcol.pdata.data_points`,
  `otelcol.pdata.alloc_delta_bytes`,
  `otelcol.pdata.heap_before_bytes`, `otelcol.pdata.heap_after_bytes`,
  `otelcol.pdata.numgc_delta`

Inside a custom processor factory:

```go
mon := gcpressureextension.Lookup()
tr  := otel.Tracer("otelcol.pdatainstr")
next = pdatainstr.WrapMetrics(next, "processor:batch", mon, tr)
```

Export the resulting spans to a file (see `file/spans` in the sample config)
or to any tracing backend that supports OTLP JSON export.

## Alerts

`deploy/prometheus/alerts.yml` defines four rules; the flagship one is:

```yaml
- alert: OtelColHeapChurnHigh
  expr: otelcol_gc_alloc_churn_bytes_per_minute > 2 * 1024 * 1024 * 1024
  for: 1m
  labels: { severity: critical }
```

The rule fires once churn has been above 2 GB/min for a full minute. By that
point the monitor has already written a heap profile + stack dump into
`profile_dir` — the runbook link should point at the correlator command
below.

## Side-by-side correlation

```bash
go run ./cmd/gccorrelate \
  --profile-dir /var/lib/otelcol/gcprofiles \
  --spans       /var/lib/otelcol/spans.jsonl \
  --prom-url    http://prometheus:9090 \
  --window      30s
```

For every capture in `profile_dir` it prints:

- Capture metadata (reason, timestamp, thresholds, pprof paths)
- A two-column timeline: allocation rate (from Prometheus) on the left,
  overlapping pipeline-stage spans on the right
- A "top allocating stages" table summarizing which
  signal:stage combinations were doing the most allocation inside the
  correlation window
- The exact `go tool pprof` command to open the captured heap profile

Sample output:

```
 pprof capture: gc-heap_churn-20260702T051318.120Z.meta.txt
   reason         : heap_churn
   captured_at    : 2026-07-02T05:13:18.120Z
   heap profile   : …/gc-heap_churn-20260702T051318.120Z.heap.pprof
   churn_bytes_per_min : 2374127616
   threshold      : 2147483648
   window         : ±30s

 alloc rate (bytes/sec)         │ concurrent pdata pipeline stages
 ────────────────────────────── │ ────────────────────────────────────────────
 05:13:12.000    41.0 MiB/s     │
                                │ 05:13:12.310  metrics:receiver:otlp     obj=8192   Δalloc=6.1 MiB dur=4ms
 05:13:13.000   187.0 MiB/s     │
                                │ 05:13:13.104  metrics:processor:attribu obj=8192   Δalloc=94.2 MiB dur=32ms gc+1
 05:13:14.000    62.0 MiB/s     │

 ── top 5 allocating stages (spans overlapping capture window) ──
 signal:stage                        spans          Δalloc   obj/span    gc/span
 metrics:processor:attributes           14         1.4 GiB     8192.0       0.71
 metrics:processor:batch                 3       248.0 MiB     8192.0       0.00
 metrics:exporter:otlphttp               2       120.0 MiB    12288.0       0.00
```

## Tuning

All thresholds are configurable per-extension:

| Field | Default | Notes |
| --- | --- | --- |
| `sample_interval` | 1s | must be ≥ 100 ms |
| `pause_threshold` | 100 ms | triggers pprof capture |
| `churn_bytes_per_minute` | 2 GiB | triggers pprof capture and Prom alert |
| `min_capture_interval` | 30s | rate-limits pprof captures |
| `profile_dir` | `/var/lib/otelcol/gcprofiles` | mount a volume with enough headroom |

## Notes / gotchas

- `runtime.MemStats` is cheap but not free; the pdata wrappers call
  `ReadMemStats` twice per stage invocation. At very high signal rates
  (>100k/s per stage) consider disabling wrappers on the hot receiver stage
  and rely on the aggregate MemStats sampler.
- `runtime.GC()` is called immediately before a capture so the heap profile
  reflects post-trigger state. Skip this line in
  `internal/gcpressure/monitor.go` if you want the pre-GC heap.
- Prometheus's `annotations.list[].tagKeys` field in the dashboard JSON
  requires Grafana 10.4+. Downgrade to `tags` array if you need older
  Grafana.
