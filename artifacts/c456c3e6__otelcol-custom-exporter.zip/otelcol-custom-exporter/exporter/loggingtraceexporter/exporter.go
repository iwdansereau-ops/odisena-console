package loggingtraceexporter

import (
	"context"
	"fmt"
	"strings"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/exporter"
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"go.uber.org/zap"
)

// tracesExporter is the concrete implementation. It holds config and a
// logger derived from the Collector's shared logger, so log lines flow into
// the same sink as the rest of the Collector.
type tracesExporter struct {
	cfg    *Config
	logger *zap.Logger
}

func newTracesExporter(cfg *Config, set exporter.Settings) (*tracesExporter, error) {
	return &tracesExporter{
		cfg:    cfg,
		logger: set.Logger,
	}, nil
}

// Capabilities tells the pipeline whether this exporter mutates the data.
// We only read, so MutatesData is false — this lets the Collector fan out
// the same pdata to multiple exporters without cloning.
func (e *tracesExporter) Capabilities() consumer.Capabilities {
	return consumer.Capabilities{MutatesData: false}
}

// start is called once when the Collector pipeline is starting.
func (e *tracesExporter) start(_ context.Context, _ component.Host) error {
	e.logger.Info("loggingtrace exporter started",
		zap.String("verbosity", e.cfg.Verbosity),
		zap.String("prefix", e.cfg.Prefix),
	)
	return nil
}

// shutdown is called during Collector shutdown; flush anything that needs
// flushing here. We hold no state so there's nothing to do.
func (e *tracesExporter) shutdown(_ context.Context) error {
	e.logger.Info("loggingtrace exporter shutting down")
	return nil
}

// pushTraces is the hot path — called by exporterhelper for every batch of
// spans that survives the queue/retry pipeline. We iterate resource → scope
// → span and log a summary line per batch, plus per-span detail when the
// user asks for it via `verbosity: detailed`.
func (e *tracesExporter) pushTraces(ctx context.Context, td ptrace.Traces) error {
	rss := td.ResourceSpans()

	summary := fmt.Sprintf(
		"%s received traces: resource_spans=%d spans=%d",
		e.cfg.Prefix, rss.Len(), td.SpanCount(),
	)
	e.logger.Info(summary)

	if e.cfg.Verbosity != "detailed" {
		return nil
	}

	for i := 0; i < rss.Len(); i++ {
		rs := rss.At(i)
		resAttrs := attrsToString(rs.Resource().Attributes())

		sss := rs.ScopeSpans()
		for j := 0; j < sss.Len(); j++ {
			ss := sss.At(j)
			scope := ss.Scope()

			spans := ss.Spans()
			for k := 0; k < spans.Len(); k++ {
				sp := spans.At(k)
				e.logger.Info(e.cfg.Prefix+" span",
					zap.String("trace_id", sp.TraceID().String()),
					zap.String("span_id", sp.SpanID().String()),
					zap.String("parent_span_id", sp.ParentSpanID().String()),
					zap.String("name", sp.Name()),
					zap.String("kind", sp.Kind().String()),
					zap.String("status", sp.Status().Code().String()),
					zap.Time("start", sp.StartTimestamp().AsTime()),
					zap.Time("end", sp.EndTimestamp().AsTime()),
					zap.String("scope", fmt.Sprintf("%s@%s", scope.Name(), scope.Version())),
					zap.String("resource_attrs", resAttrs),
					zap.String("span_attrs", attrsToString(sp.Attributes())),
				)
			}
		}
	}
	if e.pushOverride != nil {
		return e.pushOverride(ctx, td)
	}
	return nil
}

// attrsToString renders a pcommon.Map as a compact k=v string. Good enough
// for a debug-style exporter; use a proper marshaler if you need machine
// readability.
func attrsToString(m pcommon.Map) string {
	if m.Len() == 0 {
		return ""
	}
	parts := make([]string, 0, m.Len())
	m.Range(func(k string, v pcommon.Value) bool {
		parts = append(parts, fmt.Sprintf("%s=%s", k, v.AsString()))
		return true
	})
	return strings.Join(parts, ",")
}
