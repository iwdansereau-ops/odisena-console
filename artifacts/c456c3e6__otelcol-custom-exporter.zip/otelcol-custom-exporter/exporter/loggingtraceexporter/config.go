// Package loggingtraceexporter implements a custom OpenTelemetry Collector
// exporter that logs received OTLP traces to stdout via the Collector logger.
package loggingtraceexporter

import (
	"fmt"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/config/configretry"
	"go.opentelemetry.io/collector/exporter/exporterhelper"
)

// Config defines the configuration for the loggingtrace exporter.
// Fields here are surfaced to users in the Collector's config.yaml under
// this exporter's key (e.g. `loggingtrace:`).
type Config struct {
	// Verbosity controls how much detail is logged for each span batch.
	// Allowed values: "basic" (default), "detailed".
	Verbosity string `mapstructure:"verbosity"`

	// Prefix is prepended to every log line emitted by the exporter.
	// Useful when you have multiple instances of this exporter running.
	Prefix string `mapstructure:"prefix"`

	// Standard helper settings — these give the exporter batching, retry,
	// timeout, and queue behavior for free via exporterhelper.
	TimeoutSettings exporterhelper.TimeoutConfig    `mapstructure:",squash"`
	QueueSettings   exporterhelper.QueueBatchConfig `mapstructure:"sending_queue"`
	BackOffConfig   configretry.BackOffConfig       `mapstructure:"retry_on_failure"`
}

// Validate checks that the config is well-formed. It is called automatically
// by the Collector during startup.
func (c *Config) Validate() error {
	switch c.Verbosity {
	case "", "basic", "detailed":
		// ok
	default:
		return fmt.Errorf("invalid verbosity %q: must be \"basic\" or \"detailed\"", c.Verbosity)
	}
	return nil
}

// Ensure Config satisfies the component.Config interface.
var _ component.Config = (*Config)(nil)
