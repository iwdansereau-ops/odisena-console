module github.com/example/otelcol-custom-exporter/exporter/loggingtraceexporter

go 1.23.0

require (
	github.com/stretchr/testify v1.10.0
	go.opentelemetry.io/collector/component v0.116.0
	go.opentelemetry.io/collector/component/componenttest v0.116.0
	go.opentelemetry.io/collector/config/configretry v1.22.0
	go.opentelemetry.io/collector/consumer v1.22.0
	go.opentelemetry.io/collector/consumer/consumererror v0.116.0
	go.opentelemetry.io/collector/exporter v0.116.0
	go.opentelemetry.io/collector/exporter/exporterhelper v0.116.0
	go.opentelemetry.io/collector/exporter/exportertest v0.116.0
	go.opentelemetry.io/collector/pdata v1.22.0
	go.uber.org/zap v1.27.0
)
