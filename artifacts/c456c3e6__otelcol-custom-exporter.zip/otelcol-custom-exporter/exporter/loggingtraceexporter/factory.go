package loggingtraceexporter

import (
	"context"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/config/configretry"
	"go.opentelemetry.io/collector/exporter"
	"go.opentelemetry.io/collector/exporter/exporterhelper"
)

// Metadata describing this component. The type string is what users write
// in their Collector config under the `exporters:` section.
var (
	componentType = component.MustNewType("loggingtrace")
)

const (
	// stability is reported to the Collector so it can warn users if they
	// enable an alpha component. Bump this as the component matures.
	stability = component.StabilityLevelAlpha
)

// NewFactory returns a factory for the loggingtrace exporter. This is the
// symbol referenced from the OCB manifest.yaml (`gomod: ... loggingtraceexporter`).
func NewFactory() exporter.Factory {
	return exporter.NewFactory(
		componentType,
		createDefaultConfig,
		exporter.WithTraces(createTracesExporter, stability),
	)
}

// createDefaultConfig returns the default Config for this exporter. Users
// override any of these values from their config.yaml.
func createDefaultConfig() component.Config {
	return &Config{
		Verbosity:       "basic",
		Prefix:          "[loggingtrace]",
		TimeoutSettings: exporterhelper.NewDefaultTimeoutConfig(),
		QueueSettings:   exporterhelper.NewDefaultQueueConfig(),
		BackOffConfig:   configretry.NewDefaultBackOffConfig(),
	}
}

// createTracesExporter wires the concrete exporter implementation up with
// the standard exporterhelper features (timeout, retry, queue, shutdown).
// This is what makes the exporter behave like a first-class Collector
// component rather than just an ad-hoc goroutine.
func createTracesExporter(
	ctx context.Context,
	set exporter.Settings,
	cfg component.Config,
) (exporter.Traces, error) {
	c := cfg.(*Config)

	exp, err := newTracesExporter(c, set)
	if err != nil {
		return nil, err
	}

	return exporterhelper.NewTraces(
		ctx,
		set,
		cfg,
		exp.pushTraces,
		exporterhelper.WithCapabilities(exp.Capabilities()),
		exporterhelper.WithStart(exp.start),
		exporterhelper.WithShutdown(exp.shutdown),
		exporterhelper.WithTimeout(c.TimeoutSettings),
		exporterhelper.WithRetry(c.BackOffConfig),
		exporterhelper.WithQueue(c.QueueSettings),
	)
}
