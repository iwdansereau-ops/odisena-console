# otlp-http-testsuite

A Go integration-test suite that validates OTLP/HTTP trace pipelines end-to-end
against a local test collector, using the official OpenTelemetry Protobuf
definitions from `go.opentelemetry.io/proto/otlp/collector/trace/v1`.

Both wire formats defined by the OTLP/HTTP specification are supported:

| Payload type | Content-Type              | Encoder                    |
| ------------ | ------------------------- | -------------------------- |
| `protobuf`   | `application/x-protobuf`  | `google.golang.org/protobuf/proto` |
| `json`       | `application/json`        | `google.golang.org/protobuf/encoding/protojson` |

## Layout

```
harness/    generator, encoder/decoder, HTTP client, schema validators
server/     in-process OTLP/HTTP test collector on /v1/traces
tests/      integration tests with a -payload-type flag
deploy/     docker-compose runner for real OTel Collector compliance testing
Makefile    convenience targets: test, test-compliance, up, down, logs
```

## Running

### Fast local run (in-process mock collector)

```
make test
# or
go test ./tests/...
go test ./tests/... -payload-type=protobuf
go test ./tests/... -payload-type=json
```

The env var `OTLP_TEST_PAYLOAD` is honored as a fallback for CI.

### Real-collector compliance run (docker-compose)

```
make test-compliance
```

This boots the pinned official `opentelemetry-collector-contrib` image,
waits for its health-check to pass, runs the **entire** `./tests/...`
suite (including a dedicated `compliance_test.go` file) against the real
collector at `http://127.0.0.1:4318/v1/traces`, then tears the container
down. Exit code matches `go test`. See `deploy/README.md` for details.

## Test coverage

- **Round-trip export** — encode → POST → decode → validate for each payload type.
- **Content-type selection** — asserts the exact header value required by the OTLP/HTTP spec.
- **Partial success** — collector echoes `ExportTracePartialSuccess`; validator surfaces the rejection.
- **Server error** — non-2xx responses are surfaced with the raw body for inspection.
- **Flag aliases** — `-payload-type` accepts `protobuf`, `proto`, `pb`, `binary`, `json`.
- **Retry on 503** — client retries until success, honoring `Retry-After`.
- **Retry on 429** — delta-seconds and HTTP-date `Retry-After` forms are parsed and respected; clamped by `MaxRetryAfter`.
- **Max-retries exhaustion** — client stops after N retries and surfaces the last status + body.
- **Non-retryable status** — 400 bypasses the retry loop.
- **Mixed instability** — 503 → 429 → 502 → 200 recovery sequence.
- **Response delay + context timeout** — server-side delay interacts correctly with client deadlines.
- **Cancellation during backoff** — context deadline aborts a long `Retry-After` wait promptly.
- **Transport-level retries** — connection refused is retried when the retry policy is enabled.

## Simulating network instability

The test collector exposes three knobs for chaos-style testing:

```go
tc.SetResponseDelay(150 * time.Millisecond)      // artificial latency on every response
tc.SetResponseCode(503, "2")                     // return 503 + Retry-After: 2 for every request
tc.ScriptResponses(                              // one-shot scripted sequence, consumed FIFO
    server.ScriptedResponse{StatusCode: 503, RetryAfter: "1"},
    server.ScriptedResponse{StatusCode: 429, RetryAfter: "1"},
    server.ScriptedResponse{StatusCode: 200},
)
```

## Retrying client

Enable retries with `WithRetry`:

```go
client := harness.NewClient(url, harness.PayloadProtobuf).
    WithRetry(harness.DefaultRetryConfig())
```

`DefaultRetryConfig` retries on 429/502/503/504 with exponential backoff
(100ms → 5s), respects `Retry-After` (both delta-seconds and HTTP-date),
caps server-supplied waits with `MaxRetryAfter`, and honors `context`
cancellation during backoff. `Response.RetryHistory` captures the status
code and wait applied to each attempt for observability.

## Property-based edge-case testing

`harness/property.go` and `tests/property_test.go` add property-based
testing on top of Go's stdlib `testing/quick`. Every property test
generates thousands of pseudo-random `ExportTraceServiceRequest` payloads
covering shapes that hand-written fixtures typically miss:

- **Oversized attributes** — 1-16 KiB strings, thousands of KVs per span.
- **Extreme timestamps** — zero, `MaxUint64`, near-overflow, `end < start`.
- **Empty resource fields** — nil Resource, empty attribute slices, empty scopes.
- **Malformed instrumentation scopes** — empty names, control chars, huge names.
- **Odd trace/span IDs** — all-zero (spec-illegal), wrong-length (0/4/32 bytes).
- **Attribute value chaos** — NaN/Inf floats, non-UTF-8 bytes, nested ArrayValue/KvList.

Invariants asserted:

1. Encoding never panics in either codec.
2. Round-trip (encode → decode) preserves semantic equality (`proto.Equal`).
3. The mock server never returns 5xx or panics on any generated payload.
4. Spec-valid payloads always get 200 + a schema-valid response.
5. Against a real collector (when `OTLP_HTTP_ENDPOINT` is set), no 5xx on
   any input — spec violators may be rejected as 4xx but must not crash.

### Running

```
go test ./tests/... -run Property                       # default: 1000 iters/property
go test ./tests/... -run Property -property-iters=5000  # ~2 minutes
go test ./tests/... -run Property -property-seed=42     # reproduce a failing run
OTLP_PROPERTY_ITERS=100 go test ./tests/... -run Property  # env override for CI
```

Every run logs its seed at the top so failures can be reproduced:

```
property config: iterations=1000 seed=7297965761258807283
```

Against the real collector via `./deploy/run.sh`, iteration count auto-lowers
to 200 unless overridden — network overhead per request makes higher counts
impractical without a dedicated CI budget.

## Real-collector compliance suite

`tests/compliance_test.go` runs against a real OTel Collector when
`OTLP_HTTP_ENDPOINT` is set (skips cleanly otherwise). It asserts:

- Well-formed generator payloads are accepted (both protobuf and JSON).
- Large batches (150 spans across nested resource/scope) are accepted.
- Response Content-Type matches request Content-Type.
- Response bodies decode against the official OTLP proto schema.
- Protobuf body labeled as `application/json` is rejected (no silent corruption).
- Unknown content-types (e.g. `application/xml`) are rejected.
- Malformed payloads return 4xx (never 5xx).
- Empty ExportTraceServiceRequest is accepted (per spec).

A failure here means the generator has drifted from what the production
collector considers well-formed — the whole point of the suite.

## Extending

- To exercise a real collector, point `harness.NewClient` at your collector's
  `/v1/traces` endpoint instead of the in-process `server.TestCollector`.
- To fuzz the generator, tweak `harness.GenerateOpts` (span counts, scope
  metadata, service name) or extend `newSpan` with events/links.
- To assert additional schema rules, add checks to `harness.ValidateResponse`
  and `harness.ValidateRequest`.
