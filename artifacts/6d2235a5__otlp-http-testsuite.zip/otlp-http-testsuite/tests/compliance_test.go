package tests

// The tests in this file target a REAL OpenTelemetry Collector rather than
// the in-process mock in ../server. They are the source of truth for
// "does my harness produce payloads the production collector accepts?".
//
// They are gated on the OTLP_HTTP_ENDPOINT env var (or -otlp-endpoint flag).
// When that is not set the tests skip cleanly so `go test ./tests/...`
// keeps working in local mock-only mode. The docker-compose runner in
// ./deploy/run.sh sets OTLP_HTTP_ENDPOINT for you.
//
// What "compliance" means here — every assertion is directly derived from
// the OTLP/HTTP specification:
//
//   1. The receiver MUST accept both application/x-protobuf and
//      application/json content-types on /v1/traces.
//   2. On success the receiver MUST return 200 OK with an
//      ExportTraceServiceResponse body in the same content-type.
//   3. The response body MUST parse against the official
//      go.opentelemetry.io/proto/otlp/collector/trace/v1 schema.
//   4. If any spans were rejected, PartialSuccess.RejectedSpans MUST be > 0
//      and ErrorMessage MUST be populated.
//   5. Well-formed payloads MUST NOT be rejected — a partial-success block
//      with RejectedSpans > 0 on a valid payload is a compliance failure.

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"strings"
	"testing"
	"time"

	"github.com/example/otlp-http-testsuite/harness"
	collectortracepb "go.opentelemetry.io/proto/otlp/collector/trace/v1"
)

// requireExternalCollector returns the endpoint URL and skips the test if
// none is configured. Every compliance test starts with this call.
func requireExternalCollector(t *testing.T) string {
	t.Helper()
	ep := externalEndpoint()
	if ep == "" {
		t.Skip("OTLP_HTTP_ENDPOINT not set — skipping real-collector compliance test. " +
			"Run via ./deploy/run.sh, or set OTLP_HTTP_ENDPOINT=http://host:4318/v1/traces.")
	}
	return ep
}

// TestCompliance_RoundTrip is the anchor test: for each supported payload
// type, generate a valid TraceServiceRequest, POST it to the real
// collector, and assert that:
//   - the collector returns 200 OK,
//   - the response Content-Type matches the request Content-Type,
//   - the body decodes cleanly against the OTLP proto schema,
//   - no spans are rejected.
//
// A failure here means our generator has drifted from what the production
// collector considers well-formed.
func TestCompliance_RoundTrip(t *testing.T) {
	endpoint := requireExternalCollector(t)

	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			req, err := harness.NewTraceServiceRequest(harness.Defaults())
			if err != nil {
				t.Fatalf("generate: %v", err)
			}
			if err := harness.ValidateRequest(req); err != nil {
				t.Fatalf("generator produced an invalid request: %v", err)
			}

			client := harness.NewClient(endpoint, pt)
			client.Timeout = 15 * time.Second

			ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
			defer cancel()

			resp, err := client.Export(ctx, req)
			if err != nil {
				t.Fatalf("real collector rejected payload: %v (status=%d body=%q)",
					err, respStatusOr0(resp), respBodyOr(resp))
			}
			if resp.StatusCode != http.StatusOK {
				t.Fatalf("compliance: got status %d, want 200 OK (body=%q)",
					resp.StatusCode, string(resp.RawBody))
			}
			if !matchesContentType(resp.ContentType, pt.ContentType()) {
				t.Fatalf("compliance: response Content-Type %q does not match request %q",
					resp.ContentType, pt.ContentType())
			}
			if err := harness.ValidateResponse(resp.Decoded); err != nil {
				t.Fatalf("compliance: real collector response failed schema validation: %v", err)
			}
			if ps := resp.Decoded.GetPartialSuccess(); ps != nil && ps.GetRejectedSpans() > 0 {
				t.Fatalf("compliance: real collector rejected %d spans from a valid payload: %s",
					ps.GetRejectedSpans(), ps.GetErrorMessage())
			}
		})
	}
}

// TestCompliance_LargeBatch checks the collector accepts a realistic
// multi-span, multi-scope, multi-resource batch. This exercises the
// generator's nested loops (ResourceSpans → ScopeSpans → Spans) against
// the production decoder.
func TestCompliance_LargeBatch(t *testing.T) {
	endpoint := requireExternalCollector(t)

	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			req, err := harness.NewTraceServiceRequest(harness.GenerateOpts{
				NumResourceSpans: 3,
				NumScopeSpans:    2,
				NumSpans:         25,
				ServiceName:      "compliance-large-batch",
				ScopeName:        "github.com/example/otlp-http-testsuite/compliance",
				ScopeVersion:     "0.1.0",
			})
			if err != nil {
				t.Fatalf("generate: %v", err)
			}
			if got, want := harness.CountSpans(req), 3*2*25; got != want {
				t.Fatalf("generator span count: got %d want %d", got, want)
			}

			client := harness.NewClient(endpoint, pt)
			client.Timeout = 20 * time.Second
			ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
			defer cancel()

			resp, err := client.Export(ctx, req)
			if err != nil {
				t.Fatalf("large batch rejected: %v (status=%d body=%q)",
					err, respStatusOr0(resp), respBodyOr(resp))
			}
			if resp.StatusCode != http.StatusOK {
				t.Fatalf("large batch: got status %d, want 200", resp.StatusCode)
			}
			if err := harness.ValidateResponse(resp.Decoded); err != nil {
				t.Fatalf("large batch response failed validation: %v", err)
			}
		})
	}
}

// TestCompliance_ContentTypeHeaders asserts that the real collector honors
// each of the two content-types prescribed by the OTLP/HTTP spec, and that
// it rejects an obviously wrong content-type (protobuf body labeled as JSON).
func TestCompliance_ContentTypeHeaders(t *testing.T) {
	endpoint := requireExternalCollector(t)

	// Positive path: correct content-types are accepted.
	t.Run("correct/protobuf", func(t *testing.T) {
		if err := postAndExpectOK(t, endpoint, harness.PayloadProtobuf, harness.PayloadProtobuf); err != nil {
			t.Fatal(err)
		}
	})
	t.Run("correct/json", func(t *testing.T) {
		if err := postAndExpectOK(t, endpoint, harness.PayloadJSON, harness.PayloadJSON); err != nil {
			t.Fatal(err)
		}
	})

	// Negative path: send a protobuf body but label it as application/json.
	// The collector MUST NOT return 200 OK — that would silently corrupt
	// telemetry. Any 4xx is acceptable evidence of compliant rejection.
	t.Run("mismatch/protobuf-body-as-json", func(t *testing.T) {
		req, err := harness.NewTraceServiceRequest(harness.Defaults())
		if err != nil {
			t.Fatalf("generate: %v", err)
		}
		body, err := harness.EncodeRequest(req, harness.PayloadProtobuf)
		if err != nil {
			t.Fatalf("encode: %v", err)
		}
		status, _, respBody, err := rawPost(endpoint, "application/json", body)
		if err != nil {
			t.Fatalf("POST: %v", err)
		}
		if status >= 200 && status < 300 {
			t.Fatalf("compliance violation: collector accepted protobuf body under "+
				"application/json content-type (status=%d body=%q)", status, string(respBody))
		}
	})
}

// TestCompliance_UnsupportedMediaTypeRejected asserts the collector
// rejects an unknown Content-Type outright. Per the OTLP/HTTP spec, only
// application/x-protobuf and application/json are defined; any other
// content-type SHOULD be rejected with 415 (Unsupported Media Type).
func TestCompliance_UnsupportedMediaTypeRejected(t *testing.T) {
	endpoint := requireExternalCollector(t)

	req, err := harness.NewTraceServiceRequest(harness.Defaults())
	if err != nil {
		t.Fatalf("generate: %v", err)
	}
	body, err := harness.EncodeRequest(req, harness.PayloadProtobuf)
	if err != nil {
		t.Fatalf("encode: %v", err)
	}
	status, _, respBody, err := rawPost(endpoint, "application/xml", body)
	if err != nil {
		t.Fatalf("POST: %v", err)
	}
	// Any non-2xx is compliant; 415 is the ideal answer.
	if status >= 200 && status < 300 {
		t.Fatalf("compliance violation: collector accepted application/xml (status=%d body=%q)",
			status, string(respBody))
	}
	if status != http.StatusUnsupportedMediaType {
		t.Logf("note: collector rejected application/xml with %d (415 is the "+
			"canonical response but any 4xx satisfies the spec)", status)
	}
}

// TestCompliance_MalformedPayloadRejected asserts that garbage bytes are
// rejected without a 5xx (which would suggest a collector bug rather than
// a rejection). The OTLP/HTTP spec categorizes malformed payloads as 4xx.
func TestCompliance_MalformedPayloadRejected(t *testing.T) {
	endpoint := requireExternalCollector(t)

	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			junk := []byte{0xff, 0xfe, 0xfd, 0x00, 0x01, 0x02, 0x03, 0x04}
			if pt == harness.PayloadJSON {
				junk = []byte(`{"resourceSpans": "this should be an array"}`)
			}
			status, _, respBody, err := rawPost(endpoint, pt.ContentType(), junk)
			if err != nil {
				t.Fatalf("POST: %v", err)
			}
			if status >= 200 && status < 300 {
				t.Fatalf("compliance violation: collector accepted malformed %s payload "+
					"(status=%d body=%q)", pt, status, string(respBody))
			}
			if status >= 500 {
				t.Fatalf("compliance violation: collector 5xx'd on malformed %s payload — "+
					"should be 4xx (status=%d body=%q)", pt, status, string(respBody))
			}
		})
	}
}

// TestCompliance_EmptyBatchAccepted checks that an ExportTraceServiceRequest
// with zero resource_spans is accepted (per the spec, an empty export is
// legal — clients may batch even when no spans are ready).
func TestCompliance_EmptyBatchAccepted(t *testing.T) {
	endpoint := requireExternalCollector(t)

	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			empty := &collectortracepb.ExportTraceServiceRequest{}
			client := harness.NewClient(endpoint, pt)
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
			defer cancel()

			resp, err := client.Export(ctx, empty)
			if err != nil {
				t.Fatalf("empty batch rejected: %v (status=%d body=%q)",
					err, respStatusOr0(resp), respBodyOr(resp))
			}
			if resp.StatusCode != http.StatusOK {
				t.Fatalf("empty batch: got status %d, want 200", resp.StatusCode)
			}
			if err := harness.ValidateResponse(resp.Decoded); err != nil {
				t.Fatalf("empty batch response failed validation: %v", err)
			}
		})
	}
}

// --- helpers ---------------------------------------------------------------

func postAndExpectOK(t *testing.T, endpoint string, generatePT, wirePT harness.PayloadType) error {
	t.Helper()
	req, err := harness.NewTraceServiceRequest(harness.Defaults())
	if err != nil {
		return fmt.Errorf("generate: %w", err)
	}
	body, err := harness.EncodeRequest(req, generatePT)
	if err != nil {
		return fmt.Errorf("encode: %w", err)
	}
	status, ct, respBody, err := rawPost(endpoint, wirePT.ContentType(), body)
	if err != nil {
		return fmt.Errorf("POST: %w", err)
	}
	if status != http.StatusOK {
		return fmt.Errorf("status=%d ct=%q body=%q", status, ct, string(respBody))
	}
	// Decode using the request-side content-type since compliant collectors
	// echo it back.
	if _, err := harness.DecodeResponse(respBody, ct); err != nil {
		return fmt.Errorf("decode response (ct=%q): %w", ct, err)
	}
	return nil
}

// rawPost is a minimal HTTP POST that bypasses harness.Client so tests can
// exercise deliberately-malformed requests (mismatched content-types,
// garbage bodies, etc.).
func rawPost(endpoint, contentType string, body []byte) (int, string, []byte, error) {
	httpReq, err := http.NewRequest(http.MethodPost, endpoint, bytes.NewReader(body))
	if err != nil {
		return 0, "", nil, err
	}
	httpReq.Header.Set("Content-Type", contentType)
	client := &http.Client{Timeout: 15 * time.Second}
	resp, err := client.Do(httpReq)
	if err != nil {
		return 0, "", nil, err
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		return resp.StatusCode, resp.Header.Get("Content-Type"), nil, err
	}
	return resp.StatusCode, resp.Header.Get("Content-Type"), raw, nil
}

// matchesContentType returns true when the observed header equals the
// expected media type, ignoring any parameters (e.g. "; charset=utf-8").
func matchesContentType(observed, expected string) bool {
	obs := observed
	if i := strings.IndexByte(obs, ';'); i >= 0 {
		obs = obs[:i]
	}
	return strings.EqualFold(strings.TrimSpace(obs), expected)
}

func respStatusOr0(r *harness.Response) int {
	if r == nil {
		return 0
	}
	return r.StatusCode
}

func respBodyOr(r *harness.Response) string {
	if r == nil {
		return ""
	}
	return string(r.RawBody)
}
