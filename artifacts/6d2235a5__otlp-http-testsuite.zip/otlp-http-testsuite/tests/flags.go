package tests

import (
	"flag"
	"os"
	"strings"

	"github.com/example/otlp-http-testsuite/harness"
)

// payloadFlag is the value provided by `-payload-type` (or the
// OTLP_TEST_PAYLOAD env var). Recognized values: "protobuf", "json", "both".
var payloadFlag string

// endpointFlag is provided by `-otlp-endpoint` (or the OTLP_HTTP_ENDPOINT
// env var). When set, compliance tests target this URL instead of the
// in-process mock collector.
var endpointFlag string

func init() {
	flag.StringVar(&payloadFlag, "payload-type", "",
		`OTLP/HTTP payload encoding for integration tests: "protobuf", "json", or "both". `+
			`Falls back to the OTLP_TEST_PAYLOAD environment variable, then defaults to "both".`)
	flag.StringVar(&endpointFlag, "otlp-endpoint", "",
		`Full URL of an external OTLP/HTTP /v1/traces endpoint. When set, `+
			`compliance tests run against this endpoint (typically a real `+
			`OpenTelemetry Collector) instead of the in-process mock server. `+
			`Falls back to the OTLP_HTTP_ENDPOINT environment variable.`)
}

// selectedPayloads returns the list of payload types to exercise for the
// current test run. The order is deterministic: protobuf first, then JSON.
func selectedPayloads() []harness.PayloadType {
	v := payloadFlag
	if v == "" {
		v = os.Getenv("OTLP_TEST_PAYLOAD")
	}
	switch strings.ToLower(strings.TrimSpace(v)) {
	case "", "both", "all":
		return []harness.PayloadType{harness.PayloadProtobuf, harness.PayloadJSON}
	case "protobuf", "proto", "binary", "pb":
		return []harness.PayloadType{harness.PayloadProtobuf}
	case "json":
		return []harness.PayloadType{harness.PayloadJSON}
	default:
		// Unknown value: fall back to both so tests still run.
		return []harness.PayloadType{harness.PayloadProtobuf, harness.PayloadJSON}
	}
}

// externalEndpoint returns the configured external OTLP/HTTP endpoint URL
// (from -otlp-endpoint or OTLP_HTTP_ENDPOINT), or the empty string if none
// is set. When empty, tests requiring a real collector are expected to
// skip themselves rather than fail.
func externalEndpoint() string {
	if endpointFlag != "" {
		return endpointFlag
	}
	return os.Getenv("OTLP_HTTP_ENDPOINT")
}
