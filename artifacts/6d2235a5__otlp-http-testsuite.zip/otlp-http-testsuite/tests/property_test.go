package tests

// Property-based edge-case tests for the OTLP/HTTP pipeline.
//
// These tests generate thousands of pseudo-random ExportTraceServiceRequest
// values covering shapes that hand-written fixtures typically miss:
//
//   * oversized attributes (64 KiB strings, thousands of KVs)
//   * extreme timestamps (0, MaxUint64, end < start)
//   * empty resource/scope/spans fields
//   * malformed instrumentation scopes (empty name, control chars)
//   * odd trace/span IDs (all-zero, wrong length)
//   * NaN/Inf floats, non-UTF-8 bytes attributes
//   * deeply nested KvList / ArrayValue attribute types
//
// Each property is checked in BOTH payload encodings (protobuf & JSON)
// unless a payload-type filter is active. Iteration count is configurable
// via -property-iters (default 1000) or the OTLP_PROPERTY_ITERS env var.
// The PRNG seed is deterministic once set; failing runs log the seed so
// you can reproduce with `-property-seed=<value>`.
//
// The primary invariants asserted here are:
//
//   INVARIANT 1: Encoding a generated request MUST NOT panic in either
//     protobuf or JSON codec.
//   INVARIANT 2: The mock server MUST NOT panic on any generated payload;
//     it must respond with either a 2xx (well-formed) or a 4xx
//     (spec-violating) — never a 5xx or hung connection.
//   INVARIANT 3: When encoded successfully, a payload decoded by the same
//     codec must round-trip (proto.Equal or JSON-normalized equality).
//   INVARIANT 4: For payloads that pass harness.ValidateRequest, the mock
//     server MUST respond 200 OK and the response MUST pass
//     harness.ValidateResponse.
//
// A separate optional test (TestProperty_RealCollectorFuzz) exercises the
// same generator against a real OTel collector when OTLP_HTTP_ENDPOINT is
// set. It asserts INVARIANT 5: the real collector must not 5xx on any
// generated payload — spec violators may be rejected as 4xx but must not
// crash the collector or hang the connection.

import (
	"context"
	"flag"
	"fmt"
	"net/http"
	"testing"
	"testing/quick"
	"time"

	"github.com/example/otlp-http-testsuite/harness"
	"github.com/example/otlp-http-testsuite/server"
	collectortracepb "go.opentelemetry.io/proto/otlp/collector/trace/v1"
	"google.golang.org/protobuf/proto"
)

// Register property-test-specific flags. They live here rather than in
// flags.go because they're only meaningful to property tests.
var (
	propertyItersFlag string
	propertySeedFlag  string
)

func init() {
	flag.StringVar(&propertyItersFlag, "property-iters", "",
		"Number of property-based iterations per test (default 1000). "+
			"Overrides OTLP_PROPERTY_ITERS.")
	flag.StringVar(&propertySeedFlag, "property-seed", "",
		"PRNG seed for property-based tests (default: random). Set this to "+
			"a value printed by a failing run to reproduce it deterministically.")
}

// TestProperty_EncodeDecodeRoundTrip asserts INVARIANT 1 and INVARIANT 3:
// every generated request encodes without panicking, and successfully
// encoded payloads round-trip through the paired decoder.
func TestProperty_EncodeDecodeRoundTrip(t *testing.T) {
	opts := harness.PropertyOptionsFromFlags()
	cfg := opts.QuickConfig()
	t.Logf("property config: iterations=%d seed=%d", opts.Iterations, opts.Seed)

	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			property := func(rtr harness.RandomTraceRequest) bool {
				if rtr.Request == nil {
					return true
				}
				body, err := encodeSafe(rtr.Request, pt)
				if err != nil {
					// JSON codec is allowed to reject NaN/Inf floats; that's
					// documented protojson behavior and NOT a bug in the
					// harness. Only fail on unexpected error types.
					if pt == harness.PayloadJSON && isJSONFloatError(err) {
						return true
					}
					t.Logf("encode(%s) refused input: %v", pt, err)
					return true // encode error is acceptable — no panic
				}

				// Round-trip: decode back and compare with the encoder's own decoder.
				// For protobuf we can use proto.Equal directly. For JSON we
				// re-encode the decoded value and byte-compare, which handles
				// map/enum canonicalization.
				decoded, err := harness.DecodeResponseAsRequest(body, pt.ContentType())
				if err != nil {
					t.Errorf("decode(%s) failed on our own encoded output "+
						"(seed=%d): %v; body prefix=%q",
						pt, opts.Seed, err, truncate(body, 200))
					return false
				}
				switch pt {
				case harness.PayloadProtobuf:
					if !proto.Equal(rtr.Request, decoded) {
						t.Errorf("protobuf roundtrip mismatch (seed=%d): "+
							"top-level rs=%d vs %d", opts.Seed,
							len(rtr.Request.ResourceSpans),
							len(decoded.ResourceSpans))
						return false
					}
				case harness.PayloadJSON:
					// protojson is not guaranteed to preserve byte-identical
					// output on re-encode (map ordering, default suppression),
					// so we assert semantic equality via proto.Equal.
					if !proto.Equal(rtr.Request, decoded) {
						t.Errorf("json roundtrip semantic mismatch (seed=%d)", opts.Seed)
						return false
					}
				}
				return true
			}

			if err := quick.Check(property, cfg); err != nil {
				t.Fatalf("property failed: %v", err)
			}
		})
	}
}

// TestProperty_MockServerNoPanic asserts INVARIANT 2 & 4: every generated
// payload gets a well-defined HTTP response from the mock server (no
// panics, no 5xx, no hangs).
func TestProperty_MockServerNoPanic(t *testing.T) {
	opts := harness.PropertyOptionsFromFlags()
	cfg := opts.QuickConfig()
	t.Logf("property config: iterations=%d seed=%d", opts.Iterations, opts.Seed)

	tc := server.New()
	defer tc.Close()

	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			property := func(rtr harness.RandomTraceRequest) bool {
				if rtr.Request == nil {
					return true
				}
				client := harness.NewClient(tc.TracesURL(), pt)
				client.Timeout = 5 * time.Second

				ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
				defer cancel()

				// Encode-refusal (e.g. NaN under protojson) is fine — the
				// server never sees such payloads in practice.
				resp, err := clientExportSafe(ctx, client, rtr.Request)
				if err != nil {
					if isEncodeRefusal(err, pt) {
						return true
					}
					// A transport error might still be OK if the server
					// returned a well-formed non-2xx (harness surfaces
					// non-2xx as error). Inspect the response.
					if resp == nil {
						t.Errorf("transport error with no response (seed=%d, pt=%s): %v",
							opts.Seed, pt, err)
						return false
					}
				}
				if resp == nil {
					t.Errorf("nil response with nil error (seed=%d, pt=%s)",
						opts.Seed, pt)
					return false
				}

				// INVARIANT 2: no 5xx from the mock server.
				if resp.StatusCode >= 500 {
					t.Errorf("mock server returned 5xx (seed=%d, pt=%s, status=%d, body=%q)",
						opts.Seed, pt, resp.StatusCode, truncate(resp.RawBody, 200))
					return false
				}

				// INVARIANT 4: valid generated requests get 200 + valid response.
				if err := harness.ValidateRequest(rtr.Request); err == nil {
					// Request is spec-valid — server MUST 200.
					if resp.StatusCode != http.StatusOK {
						t.Errorf("valid request got non-200 (seed=%d, pt=%s, status=%d)",
							opts.Seed, pt, resp.StatusCode)
						return false
					}
					if verr := harness.ValidateResponse(resp.Decoded); verr != nil {
						t.Errorf("valid request got invalid response (seed=%d, pt=%s): %v",
							opts.Seed, pt, verr)
						return false
					}
				}
				return true
			}
			if err := quick.Check(property, cfg); err != nil {
				t.Fatalf("property failed: %v", err)
			}
		})
	}
}

// TestProperty_RealCollectorFuzz asserts INVARIANT 5 against a real OTel
// collector when OTLP_HTTP_ENDPOINT is configured. Skipped otherwise.
//
// Iteration count defaults to a lower value here because each request
// crosses a real network / container boundary. Override with
// -property-iters=... when running via ./deploy/run.sh.
func TestProperty_RealCollectorFuzz(t *testing.T) {
	endpoint := externalEndpoint()
	if endpoint == "" {
		t.Skip("OTLP_HTTP_ENDPOINT not set — skipping real-collector fuzz")
	}

	opts := harness.PropertyOptionsFromFlags()
	if opts.Iterations > 200 && opts.Iterations == harness.DefaultPropertyOptions().Iterations {
		// Auto-lower the default when hitting a real collector; explicit
		// -property-iters overrides this.
		opts.Iterations = 200
	}
	cfg := opts.QuickConfig()
	t.Logf("property config (real collector): iterations=%d seed=%d endpoint=%s",
		opts.Iterations, opts.Seed, endpoint)

	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			property := func(rtr harness.RandomTraceRequest) bool {
				if rtr.Request == nil {
					return true
				}
				client := harness.NewClient(endpoint, pt)
				client.Timeout = 10 * time.Second
				ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
				defer cancel()

				resp, err := clientExportSafe(ctx, client, rtr.Request)
				if err != nil && isEncodeRefusal(err, pt) {
					return true
				}
				if resp == nil {
					t.Errorf("real collector: nil response (seed=%d, pt=%s, err=%v)",
						opts.Seed, pt, err)
					return false
				}
				// The real collector must never 5xx on fuzz input. It may
				// 4xx (spec violation) or 200 (accepted, possibly partial).
				if resp.StatusCode >= 500 {
					t.Errorf("real collector 5xx (seed=%d, pt=%s, status=%d, body=%q)",
						opts.Seed, pt, resp.StatusCode, truncate(resp.RawBody, 200))
					return false
				}
				return true
			}
			if err := quick.Check(property, cfg); err != nil {
				t.Fatalf("property failed: %v", err)
			}
		})
	}
}

// --- helpers ---------------------------------------------------------------

// encodeSafe wraps harness.EncodeRequest with a recover so we can classify
// panics vs errors distinctly. Returns nil body + error on either outcome.
func encodeSafe(req *collectortracepb.ExportTraceServiceRequest, pt harness.PayloadType) (out []byte, err error) {
	defer func() {
		if p := recover(); p != nil {
			err = fmt.Errorf("PANIC in EncodeRequest(%s): %v", pt, p)
			out = nil
		}
	}()
	return harness.EncodeRequest(req, pt)
}

// clientExportSafe wraps Client.Export with a recover.
func clientExportSafe(ctx context.Context, c *harness.Client, req *collectortracepb.ExportTraceServiceRequest) (resp *harness.Response, err error) {
	defer func() {
		if p := recover(); p != nil {
			err = fmt.Errorf("PANIC in Client.Export: %v", p)
		}
	}()
	return c.Export(ctx, req)
}

// isEncodeRefusal returns true when err represents a documented refusal
// by the JSON codec (e.g. NaN/Inf under protojson) rather than a real bug.
func isEncodeRefusal(err error, pt harness.PayloadType) bool {
	if err == nil || pt != harness.PayloadJSON {
		return false
	}
	return isJSONFloatError(err)
}

func isJSONFloatError(err error) bool {
	if err == nil {
		return false
	}
	s := err.Error()
	// protojson error strings for special floats.
	return contains(s, "NaN") || contains(s, "Infinity") ||
		contains(s, "not finite") || contains(s, "invalid value")
}

func contains(hay, needle string) bool {
	if len(needle) == 0 {
		return true
	}
	for i := 0; i+len(needle) <= len(hay); i++ {
		if hay[i:i+len(needle)] == needle {
			return true
		}
	}
	return false
}

func truncate(b []byte, n int) []byte {
	if len(b) <= n {
		return b
	}
	return b[:n]
}
