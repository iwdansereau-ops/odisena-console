package tests

import (
	"context"
	"net/http"
	"testing"
	"time"

	"github.com/example/otlp-http-testsuite/harness"
	"github.com/example/otlp-http-testsuite/server"
)

// TestExport_RoundTrip verifies a full OTLP/HTTP export cycle for each
// selected payload type: encode → POST → decode → schema-validate.
func TestExport_RoundTrip(t *testing.T) {
	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			tc := server.New()
			defer tc.Close()

			req, err := harness.NewTraceServiceRequest(harness.Defaults())
			if err != nil {
				t.Fatalf("generate: %v", err)
			}
			if err := harness.ValidateRequest(req); err != nil {
				t.Fatalf("generated request invalid: %v", err)
			}

			client := harness.NewClient(tc.TracesURL(), pt)
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()

			resp, err := client.Export(ctx, req)
			if err != nil {
				t.Fatalf("export: %v (status=%d, body=%q)", err, respStatus(resp), respBody(resp))
			}
			if resp.StatusCode != http.StatusOK {
				t.Fatalf("unexpected status: got %d want 200", resp.StatusCode)
			}
			if resp.ContentType == "" {
				t.Fatalf("missing response content-type")
			}
			if err := harness.ValidateResponse(resp.Decoded); err != nil {
				t.Fatalf("response schema invalid: %v", err)
			}

			// Round-trip integrity: the collector should have observed
			// exactly the same span count we sent.
			got := tc.Received()
			if len(got) != 1 {
				t.Fatalf("received %d requests, want 1", len(got))
			}
			if harness.CountSpans(got[0]) != harness.CountSpans(req) {
				t.Fatalf("span count mismatch: server=%d client=%d",
					harness.CountSpans(got[0]), harness.CountSpans(req))
			}
		})
	}
}

// TestExport_ContentTypeSelection asserts the client sends the correct
// Content-Type header for each payload type — the header value is prescribed
// by the OTLP/HTTP spec.
func TestExport_ContentTypeSelection(t *testing.T) {
	cases := map[harness.PayloadType]string{
		harness.PayloadProtobuf: "application/x-protobuf",
		harness.PayloadJSON:     "application/json",
	}
	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			if got := pt.ContentType(); got != cases[pt] {
				t.Fatalf("content-type: got %q want %q", got, cases[pt])
			}
		})
	}
}

// TestExport_PartialSuccess exercises the OTLP/HTTP partial-success schema:
// the collector is configured to reject 1 span, and the validator must
// surface that as an error even though the HTTP status is 200.
func TestExport_PartialSuccess(t *testing.T) {
	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			tc := server.New()
			defer tc.Close()
			tc.SetPartialSuccess(1, "invalid span attribute")

			req, err := harness.NewTraceServiceRequest(harness.Defaults())
			if err != nil {
				t.Fatalf("generate: %v", err)
			}

			client := harness.NewClient(tc.TracesURL(), pt)
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()

			resp, err := client.Export(ctx, req)
			if err != nil {
				t.Fatalf("export: %v", err)
			}
			if err := harness.ValidateResponse(resp.Decoded); err == nil {
				t.Fatalf("expected validation error for partial success, got nil")
			}
			if resp.Decoded.GetPartialSuccess().GetRejectedSpans() != 1 {
				t.Fatalf("rejected_spans: got %d want 1",
					resp.Decoded.GetPartialSuccess().GetRejectedSpans())
			}
		})
	}
}

// TestExport_ServerError verifies non-2xx paths: the client must surface
// an error but still expose the raw body and status code to callers.
func TestExport_ServerError(t *testing.T) {
	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			tc := server.New()
			defer tc.Close()
			tc.SetForceStatus(http.StatusInternalServerError)

			req, err := harness.NewTraceServiceRequest(harness.Defaults())
			if err != nil {
				t.Fatalf("generate: %v", err)
			}
			client := harness.NewClient(tc.TracesURL(), pt)
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()

			resp, err := client.Export(ctx, req)
			if err == nil {
				t.Fatalf("expected error on 500 response")
			}
			if resp == nil || resp.StatusCode != http.StatusInternalServerError {
				t.Fatalf("status: got %+v want 500", resp)
			}
		})
	}
}

// TestParsePayloadType_Aliases ensures the flag parser accepts the aliases
// commonly used by CI systems.
func TestParsePayloadType_Aliases(t *testing.T) {
	cases := map[string]harness.PayloadType{
		"protobuf": harness.PayloadProtobuf,
		"proto":    harness.PayloadProtobuf,
		"binary":   harness.PayloadProtobuf,
		"pb":       harness.PayloadProtobuf,
		"JSON":     harness.PayloadJSON,
		"json":     harness.PayloadJSON,
	}
	for in, want := range cases {
		got, err := harness.ParsePayloadType(in)
		if err != nil {
			t.Errorf("ParsePayloadType(%q) error: %v", in, err)
			continue
		}
		if got != want {
			t.Errorf("ParsePayloadType(%q) = %q, want %q", in, got, want)
		}
	}
}

func respStatus(r *harness.Response) int {
	if r == nil {
		return 0
	}
	return r.StatusCode
}

func respBody(r *harness.Response) string {
	if r == nil {
		return ""
	}
	return string(r.RawBody)
}
