package tests

import (
	"context"
	"net/http"
	"sync/atomic"
	"testing"
	"time"

	"github.com/example/otlp-http-testsuite/harness"
	"github.com/example/otlp-http-testsuite/server"
)

// fastRetryConfig returns a retry policy tuned for tests: quick backoff, a
// captured sleep function so we can assert what the client waited for, and
// a low MaxRetryAfter so accidental large values don't hang CI.
func fastRetryConfig(t *testing.T) (harness.RetryConfig, *[]time.Duration) {
	t.Helper()
	var waits []time.Duration
	rc := harness.DefaultRetryConfig()
	rc.MaxRetries = 4
	rc.InitialBackoff = 5 * time.Millisecond
	rc.MaxBackoff = 50 * time.Millisecond
	rc.MaxRetryAfter = 500 * time.Millisecond
	rc.Sleep = func(ctx context.Context, d time.Duration) error {
		waits = append(waits, d)
		// Still respect context cancellation so timeout tests work.
		select {
		case <-time.After(d):
			return nil
		case <-ctx.Done():
			return ctx.Err()
		}
	}
	return rc, &waits
}

// TestRetry_503_ThenSuccess verifies the client retries a 503 Service
// Unavailable response until the server returns 200. The Retry-After header
// (delta-seconds) MUST be honored for the retry delay.
func TestRetry_503_ThenSuccess(t *testing.T) {
	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			tc := server.New()
			defer tc.Close()

			// Script: 503 → 503 → 200.
			tc.ScriptResponses(
				server.ScriptedResponse{StatusCode: http.StatusServiceUnavailable, RetryAfter: "0"},
				server.ScriptedResponse{StatusCode: http.StatusServiceUnavailable, RetryAfter: "0"},
				server.ScriptedResponse{StatusCode: http.StatusOK},
			)

			rc, waits := fastRetryConfig(t)
			client := harness.NewClient(tc.TracesURL(), pt).WithRetry(rc)

			req, err := harness.NewTraceServiceRequest(harness.Defaults())
			if err != nil {
				t.Fatalf("generate: %v", err)
			}

			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			resp, err := client.Export(ctx, req)
			if err != nil {
				t.Fatalf("export: %v (attempts=%d)", err, resp.Attempts)
			}
			if resp.StatusCode != http.StatusOK {
				t.Fatalf("final status: got %d want 200", resp.StatusCode)
			}
			if resp.Attempts != 3 {
				t.Fatalf("attempts: got %d want 3", resp.Attempts)
			}
			if tc.CallCount() != 3 {
				t.Fatalf("collector call count: got %d want 3", tc.CallCount())
			}
			// Two retries → two sleeps recorded.
			if len(*waits) != 2 {
				t.Fatalf("sleep count: got %d want 2", len(*waits))
			}
			if err := harness.ValidateResponse(resp.Decoded); err != nil {
				t.Fatalf("validate: %v", err)
			}
		})
	}
}

// TestRetry_429_HonorsRetryAfterSeconds verifies the client uses the
// Retry-After delta-seconds value (not its own backoff schedule) after a
// 429 Too Many Requests response.
func TestRetry_429_HonorsRetryAfterSeconds(t *testing.T) {
	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			tc := server.New()
			defer tc.Close()

			// A concrete Retry-After of 0.05s (50ms) — expressed via the
			// server-side scripted response by using MaxRetryAfter to clamp
			// a "1"-second Retry-After down to 50ms in the retry config.
			tc.ScriptResponses(
				server.ScriptedResponse{StatusCode: http.StatusTooManyRequests, RetryAfter: "1"},
				server.ScriptedResponse{StatusCode: http.StatusOK},
			)

			rc, waits := fastRetryConfig(t)
			rc.MaxRetryAfter = 50 * time.Millisecond // clamp Retry-After: 1s → 50ms
			client := harness.NewClient(tc.TracesURL(), pt).WithRetry(rc)

			req, err := harness.NewTraceServiceRequest(harness.Defaults())
			if err != nil {
				t.Fatalf("generate: %v", err)
			}
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()

			resp, err := client.Export(ctx, req)
			if err != nil {
				t.Fatalf("export: %v", err)
			}
			if resp.StatusCode != http.StatusOK {
				t.Fatalf("final status: got %d want 200", resp.StatusCode)
			}
			if resp.Attempts != 2 {
				t.Fatalf("attempts: got %d want 2", resp.Attempts)
			}
			// Exactly one sleep, clamped to MaxRetryAfter (50ms).
			if len(*waits) != 1 {
				t.Fatalf("sleep count: got %d want 1", len(*waits))
			}
			if got := (*waits)[0]; got != 50*time.Millisecond {
				t.Fatalf("clamped wait: got %v want 50ms", got)
			}
			// RetryHistory reflects the observed Retry-After from attempt #1.
			if len(resp.RetryHistory) != 2 {
				t.Fatalf("retry history len: got %d want 2", len(resp.RetryHistory))
			}
			if resp.RetryHistory[0].StatusCode != http.StatusTooManyRequests {
				t.Fatalf("attempt#1 status: got %d want 429", resp.RetryHistory[0].StatusCode)
			}
			if resp.RetryHistory[0].RetryAfter != time.Second {
				t.Fatalf("attempt#1 retry-after: got %v want 1s",
					resp.RetryHistory[0].RetryAfter)
			}
		})
	}
}

// TestRetry_429_HonorsRetryAfterHTTPDate verifies the RFC 1123 HTTP-date
// form of Retry-After is parsed and honored.
func TestRetry_429_HonorsRetryAfterHTTPDate(t *testing.T) {
	tc := server.New()
	defer tc.Close()

	// A Retry-After ~30ms in the future, encoded as an HTTP-date.
	// http.ParseTime rounds to whole seconds, so we set the header to a
	// timestamp 1 second in the future and clamp with MaxRetryAfter.
	future := time.Now().Add(1 * time.Second).UTC().Format(http.TimeFormat)
	tc.ScriptResponses(
		server.ScriptedResponse{StatusCode: http.StatusTooManyRequests, RetryAfter: future},
		server.ScriptedResponse{StatusCode: http.StatusOK},
	)

	rc, waits := fastRetryConfig(t)
	rc.MaxRetryAfter = 30 * time.Millisecond
	client := harness.NewClient(tc.TracesURL(), harness.PayloadProtobuf).WithRetry(rc)

	req, err := harness.NewTraceServiceRequest(harness.Defaults())
	if err != nil {
		t.Fatalf("generate: %v", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	resp, err := client.Export(ctx, req)
	if err != nil {
		t.Fatalf("export: %v", err)
	}
	if resp.Attempts != 2 {
		t.Fatalf("attempts: got %d want 2", resp.Attempts)
	}
	if len(*waits) != 1 || (*waits)[0] != 30*time.Millisecond {
		t.Fatalf("clamped HTTP-date wait: got %v want 30ms", *waits)
	}
}

// TestRetry_MaxRetriesExhausted asserts the client stops after MaxRetries
// additional attempts and surfaces the last observed status/body to the
// caller.
func TestRetry_MaxRetriesExhausted(t *testing.T) {
	for _, pt := range selectedPayloads() {
		pt := pt
		t.Run(string(pt), func(t *testing.T) {
			tc := server.New()
			defer tc.Close()

			// Persistent 503 — never succeeds.
			tc.SetResponseCode(http.StatusServiceUnavailable, "0")

			rc, waits := fastRetryConfig(t)
			rc.MaxRetries = 3 // → 4 total attempts
			client := harness.NewClient(tc.TracesURL(), pt).WithRetry(rc)

			req, err := harness.NewTraceServiceRequest(harness.Defaults())
			if err != nil {
				t.Fatalf("generate: %v", err)
			}
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()

			resp, err := client.Export(ctx, req)
			if err == nil {
				t.Fatalf("expected error after exhausting retries")
			}
			if resp == nil {
				t.Fatalf("response should be non-nil on exhaustion")
			}
			if resp.StatusCode != http.StatusServiceUnavailable {
				t.Fatalf("final status: got %d want 503", resp.StatusCode)
			}
			if resp.Attempts != 4 {
				t.Fatalf("attempts: got %d want 4", resp.Attempts)
			}
			if tc.CallCount() != 4 {
				t.Fatalf("collector calls: got %d want 4", tc.CallCount())
			}
			// 3 retries → 3 sleeps recorded.
			if len(*waits) != 3 {
				t.Fatalf("sleep count: got %d want 3", len(*waits))
			}
		})
	}
}

// TestRetry_NonRetryableStatus verifies that non-retryable codes (e.g. 400)
// bypass the retry loop entirely.
func TestRetry_NonRetryableStatus(t *testing.T) {
	tc := server.New()
	defer tc.Close()
	tc.SetResponseCode(http.StatusBadRequest, "")

	rc, waits := fastRetryConfig(t)
	client := harness.NewClient(tc.TracesURL(), harness.PayloadProtobuf).WithRetry(rc)

	req, err := harness.NewTraceServiceRequest(harness.Defaults())
	if err != nil {
		t.Fatalf("generate: %v", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()

	resp, err := client.Export(ctx, req)
	if err == nil {
		t.Fatalf("expected error for 400")
	}
	if resp.StatusCode != http.StatusBadRequest {
		t.Fatalf("status: got %d want 400", resp.StatusCode)
	}
	if resp.Attempts != 1 {
		t.Fatalf("attempts: got %d want 1", resp.Attempts)
	}
	if len(*waits) != 0 {
		t.Fatalf("waits: got %v want none", *waits)
	}
	if tc.CallCount() != 1 {
		t.Fatalf("collector calls: got %d want 1", tc.CallCount())
	}
}

// TestRetry_MixedStatusesRecover exercises a realistic instability sequence:
// 503 → 429 → 502 → 200. Each transient failure is retried with the
// server-supplied Retry-After.
func TestRetry_MixedStatusesRecover(t *testing.T) {
	tc := server.New()
	defer tc.Close()
	tc.ScriptResponses(
		server.ScriptedResponse{StatusCode: http.StatusServiceUnavailable, RetryAfter: "0"},
		server.ScriptedResponse{StatusCode: http.StatusTooManyRequests, RetryAfter: "0"},
		server.ScriptedResponse{StatusCode: http.StatusBadGateway},
		server.ScriptedResponse{StatusCode: http.StatusOK},
	)

	rc, _ := fastRetryConfig(t)
	rc.MaxRetries = 5
	client := harness.NewClient(tc.TracesURL(), harness.PayloadJSON).WithRetry(rc)

	req, err := harness.NewTraceServiceRequest(harness.Defaults())
	if err != nil {
		t.Fatalf("generate: %v", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	resp, err := client.Export(ctx, req)
	if err != nil {
		t.Fatalf("export: %v", err)
	}
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("final status: got %d want 200", resp.StatusCode)
	}
	if resp.Attempts != 4 {
		t.Fatalf("attempts: got %d want 4", resp.Attempts)
	}
	wantSequence := []int{503, 429, 502, 200}
	if len(resp.RetryHistory) != len(wantSequence) {
		t.Fatalf("retry history len: got %d want %d",
			len(resp.RetryHistory), len(wantSequence))
	}
	for i, want := range wantSequence {
		if resp.RetryHistory[i].StatusCode != want {
			t.Fatalf("attempt %d status: got %d want %d",
				i+1, resp.RetryHistory[i].StatusCode, want)
		}
	}
}

// TestRetry_ResponseDelayRespectsContext verifies that SetResponseDelay
// interacts correctly with client-side context timeouts: a long delay must
// cause the request to time out rather than hang.
func TestRetry_ResponseDelayRespectsContext(t *testing.T) {
	tc := server.New()
	defer tc.Close()
	tc.SetResponseDelay(2 * time.Second)

	// No retries — we're purely testing that the delay is applied and
	// context cancellation fires.
	client := harness.NewClient(tc.TracesURL(), harness.PayloadProtobuf)
	client.Timeout = 100 * time.Millisecond

	req, err := harness.NewTraceServiceRequest(harness.Defaults())
	if err != nil {
		t.Fatalf("generate: %v", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 300*time.Millisecond)
	defer cancel()

	start := time.Now()
	_, err = client.Export(ctx, req)
	elapsed := time.Since(start)
	if err == nil {
		t.Fatalf("expected timeout error given 2s server delay + 100ms client timeout")
	}
	if elapsed > 500*time.Millisecond {
		t.Fatalf("timeout took too long: %v", elapsed)
	}
}

// TestRetry_ContextCancellationDuringBackoff verifies that a context
// canceled while the client is waiting between retries aborts the retry
// loop promptly.
func TestRetry_ContextCancellationDuringBackoff(t *testing.T) {
	tc := server.New()
	defer tc.Close()
	tc.SetResponseCode(http.StatusServiceUnavailable, "3600") // 1-hour Retry-After

	rc := harness.DefaultRetryConfig()
	rc.MaxRetries = 5
	rc.MaxRetryAfter = time.Hour // don't clamp
	rc.RespectRetryAfter = true
	client := harness.NewClient(tc.TracesURL(), harness.PayloadProtobuf).WithRetry(rc)

	req, err := harness.NewTraceServiceRequest(harness.Defaults())
	if err != nil {
		t.Fatalf("generate: %v", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 50*time.Millisecond)
	defer cancel()

	start := time.Now()
	resp, err := client.Export(ctx, req)
	elapsed := time.Since(start)
	if err == nil {
		t.Fatalf("expected context deadline error")
	}
	if elapsed > 500*time.Millisecond {
		t.Fatalf("cancellation was not prompt: %v", elapsed)
	}
	// At least one attempt should have been made before the deadline.
	if resp == nil || resp.Attempts < 1 {
		t.Fatalf("expected at least 1 attempt, got %+v", resp)
	}
}

// TestRetry_TransportErrorRetries verifies that transport-level failures
// (server not listening) are retried when the retry policy is enabled.
func TestRetry_TransportErrorRetries(t *testing.T) {
	// Start and immediately stop a server so we know the address is dead.
	tc := server.New()
	url := tc.TracesURL()
	tc.Close()

	var counter atomic.Int32
	rc, _ := fastRetryConfig(t)
	rc.MaxRetries = 2
	rc.Sleep = func(ctx context.Context, d time.Duration) error {
		counter.Add(1)
		return nil // don't actually wait
	}
	client := harness.NewClient(url, harness.PayloadProtobuf).WithRetry(rc)

	req, err := harness.NewTraceServiceRequest(harness.Defaults())
	if err != nil {
		t.Fatalf("generate: %v", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	resp, err := client.Export(ctx, req)
	if err == nil {
		t.Fatalf("expected transport error against closed server")
	}
	if resp == nil || resp.Attempts != 3 {
		t.Fatalf("attempts: got %+v want 3", resp)
	}
	if got := counter.Load(); got != 2 {
		t.Fatalf("sleep count: got %d want 2", got)
	}
}

// TestParseRetryAfter_UnitTest exercises the server-side ParseRetryAfter
// helper for delta-seconds, HTTP-dates, and malformed inputs.
func TestParseRetryAfter_UnitTest(t *testing.T) {
	now := time.Date(2026, 7, 2, 6, 30, 0, 0, time.UTC)
	cases := []struct {
		name    string
		in      string
		wantD   time.Duration
		wantOK  bool
	}{
		{"empty", "", 0, false},
		{"zero seconds", "0", 0, true},
		{"positive seconds", "5", 5 * time.Second, true},
		{"negative seconds rejected", "-3", 0, false},
		{"http-date future", now.Add(10 * time.Second).Format(http.TimeFormat), 10 * time.Second, true},
		{"http-date past clamps to zero", now.Add(-time.Hour).Format(http.TimeFormat), 0, true},
		{"garbage", "later", 0, false},
	}
	for _, c := range cases {
		c := c
		t.Run(c.name, func(t *testing.T) {
			got, ok := server.ParseRetryAfter(c.in, now)
			if ok != c.wantOK {
				t.Fatalf("ok: got %v want %v (input=%q)", ok, c.wantOK, c.in)
			}
			if got != c.wantD {
				t.Fatalf("duration: got %v want %v (input=%q)", got, c.wantD, c.in)
			}
		})
	}
}
