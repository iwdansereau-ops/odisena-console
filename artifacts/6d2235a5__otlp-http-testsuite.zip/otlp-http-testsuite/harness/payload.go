// Package harness provides utilities for building, encoding, transmitting,
// and validating OTLP/HTTP trace payloads against a test collector.
//
// OTLP/HTTP is defined in the OpenTelemetry specification:
//   https://github.com/open-telemetry/opentelemetry-specification/blob/main/specification/protocol/otlp.md#otlphttp
//
// The two supported content-types are:
//   - application/x-protobuf : binary-serialized proto messages
//   - application/json       : proto3 JSON mapping (protojson)
package harness

import (
	"errors"
	"fmt"
	"strings"
)

// PayloadType selects the OTLP/HTTP wire format.
type PayloadType string

const (
	// PayloadProtobuf is the binary protobuf encoding.
	// Content-Type: application/x-protobuf
	PayloadProtobuf PayloadType = "protobuf"

	// PayloadJSON is the proto3-JSON encoding.
	// Content-Type: application/json
	PayloadJSON PayloadType = "json"
)

// ContentType returns the OTLP/HTTP-compliant HTTP Content-Type header value
// for the payload type. These values are prescribed by the OTLP spec.
func (p PayloadType) ContentType() string {
	switch p {
	case PayloadProtobuf:
		return "application/x-protobuf"
	case PayloadJSON:
		return "application/json"
	default:
		return ""
	}
}

// Validate returns an error if the payload type is not recognized.
func (p PayloadType) Validate() error {
	switch p {
	case PayloadProtobuf, PayloadJSON:
		return nil
	default:
		return fmt.Errorf("harness: unknown payload type %q (want %q or %q)",
			p, PayloadProtobuf, PayloadJSON)
	}
}

// ParsePayloadType is a case-insensitive parser convenient for CLI flags.
// Accepts: "protobuf", "proto", "binary", "pb", "json".
func ParsePayloadType(s string) (PayloadType, error) {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "protobuf", "proto", "binary", "pb", "x-protobuf":
		return PayloadProtobuf, nil
	case "json":
		return PayloadJSON, nil
	case "":
		return "", errors.New("harness: empty payload type")
	default:
		return "", fmt.Errorf("harness: unknown payload type %q", s)
	}
}
