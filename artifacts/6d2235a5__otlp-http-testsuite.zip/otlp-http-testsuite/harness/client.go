package harness

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"time"

	collectortracepb "go.opentelemetry.io/proto/otlp/collector/trace/v1"
)

// RetryConfig controls the retry behavior of Client.Export.
//
// The client retries on the set of HTTP status codes considered
// retryable by the OTLP/HTTP specification and on transport-level errors
// (connection refused, DNS failure, TLS handshake, request timeout, etc.).
//
// When the server returns a Retry-After header, its value overrides the
// computed backoff for that attempt. Retry-After may be either a
// non-negative integer number of seconds or an RFC 1123 HTTP-date, as
// prescribed by RFC 7231 §7.1.3.
type RetryConfig struct {
	// MaxRetries is the maximum number of RETRIES (not attempts) beyond the
	// initial request. A MaxRetries of 3 therefore permits up to 4 total
	// HTTP requests. Zero disables retry entirely.
	MaxRetries int

	// InitialBackoff is the wait applied before the first retry when no
	// Retry-After header is present.
	InitialBackoff time.Duration

	// MaxBackoff caps the exponential backoff between attempts.
	MaxBackoff time.Duration

	// BackoffMultiplier is the exponent base applied per attempt. A value of
	// 2.0 doubles the backoff each retry. Values <= 1 disable growth.
	BackoffMultiplier float64

	// RetryableStatusCodes is the allowlist of HTTP status codes that
	// trigger a retry. Defaults are supplied by DefaultRetryConfig.
	RetryableStatusCodes map[int]struct{}

	// RespectRetryAfter, when true (the default), honors the Retry-After
	// header. When false, the exponential-backoff schedule is used even
	// for 429/503 responses.
	RespectRetryAfter bool

	// MaxRetryAfter caps how long the client is willing to wait on a
	// server-supplied Retry-After value. Zero means "no cap".
	MaxRetryAfter time.Duration

	// Sleep is an override for the sleep function; production code uses
	// time.Sleep-equivalent semantics via context. Test code may inject
	// a fake to make time deterministic. When nil, a context-aware sleep
	// backed by time.After is used.
	Sleep func(ctx context.Context, d time.Duration) error
}

// DefaultRetryConfig returns a RetryConfig with values suitable for
// integration tests and light production use.
//
// The retryable set matches the OTLP/HTTP specification's list of
// transient failures:
//
//	429 Too Many Requests
//	502 Bad Gateway
//	503 Service Unavailable
//	504 Gateway Timeout
//
// The OTLP spec explicitly calls out that 429 and 503 SHOULD include a
// Retry-After header, and clients SHOULD honor it.
func DefaultRetryConfig() RetryConfig {
	return RetryConfig{
		MaxRetries:        3,
		InitialBackoff:    100 * time.Millisecond,
		MaxBackoff:        5 * time.Second,
		BackoffMultiplier: 2.0,
		RetryableStatusCodes: map[int]struct{}{
			http.StatusTooManyRequests:     {}, // 429
			http.StatusBadGateway:          {}, // 502
			http.StatusServiceUnavailable:  {}, // 503
			http.StatusGatewayTimeout:      {}, // 504
		},
		RespectRetryAfter: true,
		MaxRetryAfter:     30 * time.Second,
	}
}

// isRetryable reports whether the given status code is in the retryable set.
func (rc RetryConfig) isRetryable(code int) bool {
	if rc.RetryableStatusCodes == nil {
		return false
	}
	_, ok := rc.RetryableStatusCodes[code]
	return ok
}

// Client is an OTLP/HTTP trace exporter with a configurable payload type
// and retry policy.
//
// The default OTLP/HTTP path for traces is /v1/traces; callers may override
// this via Endpoint (full URL).
type Client struct {
	// Endpoint is the full URL to POST to, e.g. http://127.0.0.1:4318/v1/traces
	Endpoint string
	// PayloadType selects protobuf-binary or JSON serialization.
	PayloadType PayloadType
	// HTTPClient may be overridden; a default one is used when nil.
	HTTPClient *http.Client
	// Timeout applied to each request if HTTPClient is nil.
	Timeout time.Duration
	// Retry, when non-nil, enables retry behavior with the given policy.
	// Use DefaultRetryConfig for a reasonable starting point.
	Retry *RetryConfig
}

// NewClient constructs a Client with sane defaults. Retry is disabled by
// default; call WithRetry or set Client.Retry to enable it.
func NewClient(endpoint string, pt PayloadType) *Client {
	return &Client{
		Endpoint:    endpoint,
		PayloadType: pt,
		Timeout:     10 * time.Second,
	}
}

// WithRetry returns c with the supplied RetryConfig installed. It mutates
// and returns the receiver for fluent construction.
func (c *Client) WithRetry(rc RetryConfig) *Client {
	c.Retry = &rc
	return c
}

// Response is the parsed result of an OTLP/HTTP export call.
//
// On a fully successful export, Decoded is populated and Attempts is 1 plus
// the number of retries actually performed.
type Response struct {
	StatusCode  int
	ContentType string
	RawBody     []byte
	Decoded     *collectortracepb.ExportTraceServiceResponse
	// Attempts records how many HTTP requests were made in total (>= 1).
	Attempts int
	// RetryHistory records the outcome of each attempt for observability.
	RetryHistory []AttemptResult
}

// AttemptResult captures the outcome of a single request attempt.
type AttemptResult struct {
	// StatusCode is 0 when the attempt failed at the transport layer
	// (e.g. connection refused) before receiving an HTTP response.
	StatusCode int
	// Err is the transport-level error, if any.
	Err error
	// WaitedBefore is the delay applied BEFORE this attempt (0 for the
	// first attempt).
	WaitedBefore time.Duration
	// RetryAfter is the parsed Retry-After header value from this attempt's
	// response, when present.
	RetryAfter time.Duration
}

// Export sends the given request and returns the collector's parsed response.
//
// Retry behavior:
//
//   - When Client.Retry is nil, a single attempt is made and any non-2xx is
//     surfaced as a non-nil error with the raw body still populated.
//   - When Client.Retry is set, transport errors and retryable status codes
//     (per RetryConfig.RetryableStatusCodes) cause the request to be retried
//     up to Retry.MaxRetries additional times. A Retry-After response header
//     overrides the exponential backoff schedule for the following attempt.
//   - Retry-After caps: values larger than RetryConfig.MaxRetryAfter are
//     clamped when MaxRetryAfter > 0.
//   - The request body is fully buffered so it is safe to replay across
//     retries without a body-reset callback.
//   - ctx cancellation aborts any pending sleep and returns immediately.
func (c *Client) Export(ctx context.Context, req *collectortracepb.ExportTraceServiceRequest) (*Response, error) {
	if err := c.PayloadType.Validate(); err != nil {
		return nil, err
	}
	body, err := EncodeRequest(req, c.PayloadType)
	if err != nil {
		return nil, err
	}

	client := c.HTTPClient
	if client == nil {
		client = &http.Client{Timeout: c.Timeout}
	}

	rc := c.Retry
	maxRetries := 0
	if rc != nil {
		maxRetries = rc.MaxRetries
	}

	out := &Response{}
	var (
		lastResp *Response
		lastErr  error
		wait     time.Duration
	)

	for attempt := 0; attempt <= maxRetries; attempt++ {
		if attempt > 0 {
			// Wait before retrying. A canceled context aborts immediately.
			if err := doSleep(ctx, wait, rc); err != nil {
				if lastResp != nil {
					lastResp.Attempts = attempt
				}
				return lastResp, err
			}
		}

		respRec, retryAfter, doErr := c.doOnce(ctx, client, body)
		out.Attempts = attempt + 1
		out.RetryHistory = append(out.RetryHistory, AttemptResult{
			StatusCode:   respRec.StatusCode,
			Err:          doErr,
			WaitedBefore: wait,
			RetryAfter:   retryAfter,
		})

		// Preserve the latest observed response fields so callers can
		// inspect the final failed attempt.
		out.StatusCode = respRec.StatusCode
		out.ContentType = respRec.ContentType
		out.RawBody = respRec.RawBody
		out.Decoded = respRec.Decoded
		lastResp = out

		// Transport error path.
		if doErr != nil {
			lastErr = doErr
			if rc == nil || !isRetryableTransportError(doErr) || attempt == maxRetries {
				return out, doErr
			}
			wait = computeBackoff(rc, attempt, 0)
			continue
		}

		// HTTP response path.
		if respRec.StatusCode >= 200 && respRec.StatusCode < 300 {
			return out, nil
		}

		// Retryable status: schedule another attempt if budget remains.
		if rc != nil && rc.isRetryable(respRec.StatusCode) && attempt < maxRetries {
			wait = computeBackoff(rc, attempt, retryAfter)
			lastErr = fmt.Errorf("harness: retryable status %d from %s", respRec.StatusCode, c.Endpoint)
			continue
		}

		// Non-retryable failure or retries exhausted: surface the error.
		return out, fmt.Errorf("harness: non-2xx status %d from %s (attempt %d/%d)",
			respRec.StatusCode, c.Endpoint, attempt+1, maxRetries+1)
	}

	// Unreachable in practice; loop always returns.
	if lastErr == nil {
		lastErr = errors.New("harness: retries exhausted")
	}
	return lastResp, lastErr
}

// doOnce performs a single HTTP POST attempt. It returns the observed
// response fields, the parsed Retry-After delay (0 if absent), and any
// transport-level error.
func (c *Client) doOnce(ctx context.Context, client *http.Client, body []byte) (*Response, time.Duration, error) {
	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, c.Endpoint, bytes.NewReader(body))
	if err != nil {
		return &Response{}, 0, fmt.Errorf("harness: build http request: %w", err)
	}
	httpReq.Header.Set("Content-Type", c.PayloadType.ContentType())
	httpReq.Header.Set("Accept", c.PayloadType.ContentType())

	httpResp, err := client.Do(httpReq)
	if err != nil {
		return &Response{}, 0, fmt.Errorf("harness: POST %s: %w", c.Endpoint, err)
	}
	defer httpResp.Body.Close()

	raw, err := io.ReadAll(httpResp.Body)
	if err != nil {
		return &Response{StatusCode: httpResp.StatusCode}, 0,
			fmt.Errorf("harness: read response body: %w", err)
	}

	out := &Response{
		StatusCode:  httpResp.StatusCode,
		ContentType: httpResp.Header.Get("Content-Type"),
		RawBody:     raw,
	}

	retryAfter, _ := parseRetryAfterHeader(httpResp.Header.Get("Retry-After"), time.Now())

	// Only decode success bodies. Non-2xx is left raw for the caller to
	// inspect (it may carry a google.rpc.Status per the OTLP failure rules).
	if httpResp.StatusCode >= 200 && httpResp.StatusCode < 300 {
		decoded, derr := DecodeResponse(raw, out.ContentType)
		if derr != nil {
			return out, retryAfter, derr
		}
		out.Decoded = decoded
	}
	return out, retryAfter, nil
}

// computeBackoff picks the wait duration before the next attempt. When a
// server-supplied Retry-After is honored and non-zero, it takes precedence;
// otherwise an exponential schedule capped at MaxBackoff is used.
func computeBackoff(rc *RetryConfig, attempt int, retryAfter time.Duration) time.Duration {
	if rc == nil {
		return 0
	}
	if rc.RespectRetryAfter && retryAfter > 0 {
		if rc.MaxRetryAfter > 0 && retryAfter > rc.MaxRetryAfter {
			return rc.MaxRetryAfter
		}
		return retryAfter
	}
	base := rc.InitialBackoff
	if base <= 0 {
		base = 100 * time.Millisecond
	}
	mult := rc.BackoffMultiplier
	if mult <= 1 {
		return capBackoff(base, rc.MaxBackoff)
	}
	d := float64(base)
	for i := 0; i < attempt; i++ {
		d *= mult
		if rc.MaxBackoff > 0 && time.Duration(d) >= rc.MaxBackoff {
			return rc.MaxBackoff
		}
	}
	return capBackoff(time.Duration(d), rc.MaxBackoff)
}

func capBackoff(d, max time.Duration) time.Duration {
	if max > 0 && d > max {
		return max
	}
	return d
}

// doSleep sleeps for d, respecting context cancellation. If RetryConfig
// installs a custom Sleep func, that is used instead.
func doSleep(ctx context.Context, d time.Duration, rc *RetryConfig) error {
	if d <= 0 {
		return ctx.Err()
	}
	if rc != nil && rc.Sleep != nil {
		return rc.Sleep(ctx, d)
	}
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-t.C:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

// parseRetryAfterHeader parses a Retry-After header value per RFC 7231 §7.1.3.
// Both delta-seconds (non-negative integer) and HTTP-date formats are
// recognized. Malformed values return (0, false).
func parseRetryAfterHeader(header string, now time.Time) (time.Duration, bool) {
	header = trimSpace(header)
	if header == "" {
		return 0, false
	}
	if n, err := strconv.Atoi(header); err == nil {
		if n < 0 {
			return 0, false
		}
		return time.Duration(n) * time.Second, true
	}
	if t, err := http.ParseTime(header); err == nil {
		d := t.Sub(now)
		if d < 0 {
			return 0, true
		}
		return d, true
	}
	return 0, false
}

// isRetryableTransportError reports whether a transport-level error should
// trigger a retry. Context-cancellation and context-deadline errors are NOT
// retryable — they indicate the caller has given up.
func isRetryableTransportError(err error) bool {
	if err == nil {
		return false
	}
	if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
		return false
	}
	return true
}
