package harness

import (
	"crypto/rand"
	"fmt"
	"time"

	commonpb "go.opentelemetry.io/proto/otlp/common/v1"
	resourcepb "go.opentelemetry.io/proto/otlp/resource/v1"
	tracepb "go.opentelemetry.io/proto/otlp/trace/v1"
	collectortracepb "go.opentelemetry.io/proto/otlp/collector/trace/v1"
)

// GenerateOpts controls synthetic trace generation.
type GenerateOpts struct {
	// NumResourceSpans is the number of ResourceSpans entries to create.
	NumResourceSpans int
	// NumScopeSpans is the number of ScopeSpans per ResourceSpans.
	NumScopeSpans int
	// NumSpans is the number of Spans per ScopeSpans.
	NumSpans int
	// ServiceName is written as a resource attribute `service.name`.
	ServiceName string
	// ScopeName is the instrumentation scope name (e.g. library name).
	ScopeName string
	// ScopeVersion is the instrumentation scope version.
	ScopeVersion string
}

// Defaults returns a small but complete GenerateOpts useful for a single test.
func Defaults() GenerateOpts {
	return GenerateOpts{
		NumResourceSpans: 1,
		NumScopeSpans:    1,
		NumSpans:         2,
		ServiceName:      "otlp-http-testsuite",
		ScopeName:        "github.com/example/otlp-http-testsuite/harness",
		ScopeVersion:     "0.1.0",
	}
}

// NewTraceServiceRequest builds a valid ExportTraceServiceRequest per the
// OTLP proto definitions in go.opentelemetry.io/proto/otlp/collector/trace/v1.
//
// The returned message is guaranteed to contain well-formed 16-byte trace IDs
// and 8-byte span IDs, non-zero start/end timestamps, and required
// instrumentation-scope fields.
func NewTraceServiceRequest(opts GenerateOpts) (*collectortracepb.ExportTraceServiceRequest, error) {
	if opts.NumResourceSpans <= 0 {
		opts.NumResourceSpans = 1
	}
	if opts.NumScopeSpans <= 0 {
		opts.NumScopeSpans = 1
	}
	if opts.NumSpans <= 0 {
		opts.NumSpans = 1
	}

	now := time.Now()
	rs := make([]*tracepb.ResourceSpans, 0, opts.NumResourceSpans)
	for i := 0; i < opts.NumResourceSpans; i++ {
		scopeSpans := make([]*tracepb.ScopeSpans, 0, opts.NumScopeSpans)
		for j := 0; j < opts.NumScopeSpans; j++ {
			spans := make([]*tracepb.Span, 0, opts.NumSpans)
			for k := 0; k < opts.NumSpans; k++ {
				sp, err := newSpan(fmt.Sprintf("span-%d-%d-%d", i, j, k), now)
				if err != nil {
					return nil, err
				}
				spans = append(spans, sp)
			}
			scopeSpans = append(scopeSpans, &tracepb.ScopeSpans{
				Scope: &commonpb.InstrumentationScope{
					Name:    opts.ScopeName,
					Version: opts.ScopeVersion,
				},
				Spans:     spans,
				SchemaUrl: "https://opentelemetry.io/schemas/1.20.0",
			})
		}

		rs = append(rs, &tracepb.ResourceSpans{
			Resource: &resourcepb.Resource{
				Attributes: []*commonpb.KeyValue{
					stringAttr("service.name", opts.ServiceName),
					stringAttr("service.instance.id", fmt.Sprintf("instance-%d", i)),
					stringAttr("telemetry.sdk.language", "go"),
					stringAttr("telemetry.sdk.name", "otlp-http-testsuite"),
				},
			},
			ScopeSpans: scopeSpans,
			SchemaUrl:  "https://opentelemetry.io/schemas/1.20.0",
		})
	}

	return &collectortracepb.ExportTraceServiceRequest{
		ResourceSpans: rs,
	}, nil
}

func newSpan(name string, base time.Time) (*tracepb.Span, error) {
	traceID := make([]byte, 16)
	if _, err := rand.Read(traceID); err != nil {
		return nil, fmt.Errorf("trace id: %w", err)
	}
	spanID := make([]byte, 8)
	if _, err := rand.Read(spanID); err != nil {
		return nil, fmt.Errorf("span id: %w", err)
	}

	start := base
	end := base.Add(15 * time.Millisecond)

	return &tracepb.Span{
		TraceId:           traceID,
		SpanId:            spanID,
		Name:              name,
		Kind:              tracepb.Span_SPAN_KIND_INTERNAL,
		StartTimeUnixNano: uint64(start.UnixNano()),
		EndTimeUnixNano:   uint64(end.UnixNano()),
		Attributes: []*commonpb.KeyValue{
			stringAttr("component", "test-harness"),
			intAttr("http.status_code", 200),
		},
		Status: &tracepb.Status{
			Code:    tracepb.Status_STATUS_CODE_OK,
			Message: "ok",
		},
	}, nil
}

func stringAttr(k, v string) *commonpb.KeyValue {
	return &commonpb.KeyValue{
		Key:   k,
		Value: &commonpb.AnyValue{Value: &commonpb.AnyValue_StringValue{StringValue: v}},
	}
}

func intAttr(k string, v int64) *commonpb.KeyValue {
	return &commonpb.KeyValue{
		Key:   k,
		Value: &commonpb.AnyValue{Value: &commonpb.AnyValue_IntValue{IntValue: v}},
	}
}
