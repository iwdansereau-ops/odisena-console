package harness

// Property-based generators for OTLP TraceServiceRequest edge-cases.
//
// The generators here produce ExportTraceServiceRequest values that
// exercise corners of the OTLP proto schema which are easy to miss with
// hand-written test fixtures:
//
//   - **Oversized attributes**: very long string/bytes values and huge
//     key/value counts, which stress the collector's memory limits and
//     protojson's UTF-8 handling.
//   - **Extreme timestamps**: zero, max-uint64, and near-overflow values
//     that catch off-by-one errors in downstream aggregators.
//   - **Empty resource fields**: nil Resource, empty attributes slice,
//     empty ScopeSpans, and empty Spans lists.
//   - **Malformed instrumentation scopes**: empty names, huge names,
//     non-UTF-8 attempts (via bytes attrs), unusual version strings.
//   - **Odd trace/span IDs**: all-zero IDs (spec-illegal but common in
//     buggy instrumentations), oversized IDs, and short IDs.
//   - **Attribute value chaos**: nested arrays, deeply-nested KVLists,
//     mixed types under the same key, boolean/int/double/string flips.
//
// The generators integrate with Go's stdlib property-testing framework
// testing/quick via the Generate(rand, size) method on RandomTraceRequest.
// A wrapper Property helper is provided so tests can share configuration
// (iteration count, seed, size hint) across files.

import (
	"flag"
	"fmt"
	"math"
	"math/rand"
	"os"
	"reflect"
	"strconv"
	"strings"
	"testing/quick"

	commonpb "go.opentelemetry.io/proto/otlp/common/v1"
	resourcepb "go.opentelemetry.io/proto/otlp/resource/v1"
	tracepb "go.opentelemetry.io/proto/otlp/trace/v1"
	collectortracepb "go.opentelemetry.io/proto/otlp/collector/trace/v1"
)

// PropertyOptions controls property-based test runs.
type PropertyOptions struct {
	// Iterations is the number of random inputs to generate per property.
	Iterations int
	// Seed is the PRNG seed. Zero uses a time-based default (recorded on
	// first Generate call so failures can be reproduced from the log).
	Seed int64
	// MaxSize bounds the recursion/list-length hint passed to quick.
	MaxSize int
	// AllowSpecViolations, when true, generates payloads that deliberately
	// violate the OTLP spec (empty trace IDs, huge attributes, etc.) so
	// tests can verify graceful rejection rather than crashes.
	AllowSpecViolations bool
}

// DefaultPropertyOptions returns a well-balanced configuration.
func DefaultPropertyOptions() PropertyOptions {
	return PropertyOptions{
		Iterations:          1000,
		Seed:                0,
		MaxSize:             25,
		AllowSpecViolations: true,
	}
}

// PropertyOptionsFromFlags reads iteration count and seed from flags/env.
// Precedence: -property-iters flag > OTLP_PROPERTY_ITERS env > default.
// The seed flag / env is honored likewise via -property-seed / OTLP_PROPERTY_SEED.
func PropertyOptionsFromFlags() PropertyOptions {
	opts := DefaultPropertyOptions()
	if f := flag.Lookup("property-iters"); f != nil {
		if v, err := strconv.Atoi(f.Value.String()); err == nil && v > 0 {
			opts.Iterations = v
		}
	}
	if v := os.Getenv("OTLP_PROPERTY_ITERS"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			opts.Iterations = n
		}
	}
	if f := flag.Lookup("property-seed"); f != nil {
		if v, err := strconv.ParseInt(f.Value.String(), 10, 64); err == nil && v != 0 {
			opts.Seed = v
		}
	}
	if v := os.Getenv("OTLP_PROPERTY_SEED"); v != "" {
		if n, err := strconv.ParseInt(v, 10, 64); err == nil && n != 0 {
			opts.Seed = n
		}
	}
	return opts
}

// QuickConfig returns a *quick.Config wired for these options. If Seed is
// zero, a random seed is picked and stored back on the receiver so it can
// be logged for reproducibility.
func (o *PropertyOptions) QuickConfig() *quick.Config {
	if o.Seed == 0 {
		o.Seed = rand.Int63() //nolint:gosec // reproducibility, not crypto
	}
	src := rand.New(rand.NewSource(o.Seed))
	return &quick.Config{
		MaxCount: o.Iterations,
		Rand:     src,
		Values: func(args []reflect.Value, r *rand.Rand) {
			// Called by quick.Check when the property function's parameter
			// type doesn't implement quick.Generator directly. We generate
			// a RandomTraceRequest for the single expected argument.
			for i := range args {
				rtr := RandomTraceRequest{opts: *o}
				val := rtr.Generate(r, o.MaxSize)
				args[i] = val
			}
		},
	}
}

// RandomTraceRequest wraps an ExportTraceServiceRequest so we can attach
// a Generate method (satisfying testing/quick.Generator) without polluting
// the proto type.
type RandomTraceRequest struct {
	Request *collectortracepb.ExportTraceServiceRequest
	// opts records the generation policy so shrinking / logging can inspect it.
	opts PropertyOptions
}

// Generate implements testing/quick.Generator. It produces a
// RandomTraceRequest whose Request field contains one of many edge-case
// shapes chosen uniformly from the shape table.
//
// The `size` argument is a hint from testing/quick; we clamp it hard so
// worst-case payloads stay in the low-MB range. Otherwise the Cartesian
// product of ResourceSpans × ScopeSpans × Spans × Attributes with the
// 256 KiB oversized-string branch can produce multi-GB requests that
// take seconds each to encode and defeat the point of high-iteration
// property testing.
func (RandomTraceRequest) Generate(r *rand.Rand, size int) reflect.Value {
	if size <= 0 {
		size = 3
	}
	if size > 8 {
		size = 8
	}

	req := &collectortracepb.ExportTraceServiceRequest{
		ResourceSpans: randomResourceSpansList(r, size),
	}
	return reflect.ValueOf(RandomTraceRequest{Request: req})
}

// randomResourceSpansList generates 0..size ResourceSpans entries. Zero is
// intentionally allowed to exercise the empty-batch path.
func randomResourceSpansList(r *rand.Rand, size int) []*tracepb.ResourceSpans {
	n := r.Intn(size + 1)
	out := make([]*tracepb.ResourceSpans, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, randomResourceSpans(r, size))
	}
	return out
}

func randomResourceSpans(r *rand.Rand, size int) *tracepb.ResourceSpans {
	rs := &tracepb.ResourceSpans{
		SchemaUrl: pickSchemaURL(r),
	}
	// Resource has ~4 shape variants including nil.
	switch r.Intn(5) {
	case 0:
		rs.Resource = nil // spec-illegal per some strict readers
	case 1:
		rs.Resource = &resourcepb.Resource{} // empty attributes
	case 2:
		rs.Resource = &resourcepb.Resource{
			Attributes:             randomAttrList(r, size),
			DroppedAttributesCount: r.Uint32() % 1000,
		}
	case 3:
		rs.Resource = &resourcepb.Resource{
			Attributes: []*commonpb.KeyValue{
				// Oversized single attribute — 4-16 KiB. Large enough to
				// exercise the oversized path, small enough that a single
				// property iteration stays sub-millisecond.
				stringKV("bulk.data", randomOversizedString(r, 4*1024, 16*1024)),
			},
		}
	default:
		// Many small attributes: up to size*4 pairs.
		attrs := make([]*commonpb.KeyValue, 0, size*4)
		for i := 0; i < r.Intn(size*4+1); i++ {
			attrs = append(attrs, randomAttr(r))
		}
		rs.Resource = &resourcepb.Resource{Attributes: attrs}
	}
	rs.ScopeSpans = randomScopeSpansList(r, size)
	return rs
}

func randomScopeSpansList(r *rand.Rand, size int) []*tracepb.ScopeSpans {
	n := r.Intn(size + 1)
	out := make([]*tracepb.ScopeSpans, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, randomScopeSpans(r, size))
	}
	return out
}

func randomScopeSpans(r *rand.Rand, size int) *tracepb.ScopeSpans {
	ss := &tracepb.ScopeSpans{
		SchemaUrl: pickSchemaURL(r),
	}
	// Malformed / edge-case instrumentation scopes.
	switch r.Intn(6) {
	case 0:
		ss.Scope = nil // some collectors treat this as valid, some not
	case 1:
		ss.Scope = &commonpb.InstrumentationScope{} // empty everything
	case 2:
		ss.Scope = &commonpb.InstrumentationScope{
			Name:    "",
			Version: "malformed-no-name",
		}
	case 3:
		ss.Scope = &commonpb.InstrumentationScope{
			Name:                   randomOversizedString(r, 2*1024, 8*1024),
			Version:                "9999.9999.9999-alpha+build.longmetadata",
			Attributes:             randomAttrList(r, size),
			DroppedAttributesCount: r.Uint32(),
		}
	case 4:
		ss.Scope = &commonpb.InstrumentationScope{
			Name:    "scope/with\x00null\x01control\x1fchars",
			Version: "\t\n\r",
		}
	default:
		ss.Scope = &commonpb.InstrumentationScope{
			Name:       randomShortIdentifier(r),
			Version:    randomShortIdentifier(r),
			Attributes: randomAttrList(r, size/2+1),
		}
	}
	ss.Spans = randomSpanList(r, size)
	return ss
}

func randomSpanList(r *rand.Rand, size int) []*tracepb.Span {
	n := r.Intn(size + 1)
	out := make([]*tracepb.Span, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, randomSpan(r, size))
	}
	return out
}

func randomSpan(r *rand.Rand, size int) *tracepb.Span {
	sp := &tracepb.Span{
		Name: pickSpanName(r),
		Kind: tracepb.Span_SpanKind(r.Intn(6)), // valid range [0..5]
	}

	// Trace/Span IDs — cover legal (16/8 bytes), spec-illegal (all-zero),
	// and outright wrong (short/long) shapes.
	sp.TraceId = pickIDBytes(r, 16)
	sp.SpanId = pickIDBytes(r, 8)
	// ParentSpanId is optional (0 bytes) or 8 bytes.
	if r.Intn(2) == 0 {
		sp.ParentSpanId = pickIDBytes(r, 8)
	}

	// Extreme timestamps: zero, max-uint64, near-overflow, past, future,
	// and normal.
	sp.StartTimeUnixNano, sp.EndTimeUnixNano = pickTimestamps(r)

	// TraceState: usually empty, sometimes long.
	if r.Intn(4) == 0 {
		sp.TraceState = strings.Repeat("k=v,", 1+r.Intn(16))
	}

	sp.Attributes = randomAttrList(r, size)
	sp.DroppedAttributesCount = r.Uint32()

	// Events: sometimes many, sometimes none.
	if r.Intn(3) == 0 {
		nEvents := r.Intn(size + 1)
		sp.Events = make([]*tracepb.Span_Event, 0, nEvents)
		for i := 0; i < nEvents; i++ {
			sp.Events = append(sp.Events, &tracepb.Span_Event{
				TimeUnixNano:           uint64(r.Int63()),
				Name:                   pickSpanName(r),
				Attributes:             randomAttrList(r, size/2+1),
				DroppedAttributesCount: r.Uint32(),
			})
		}
	}

	// Links: rare.
	if r.Intn(6) == 0 {
		nLinks := r.Intn(3)
		sp.Links = make([]*tracepb.Span_Link, 0, nLinks)
		for i := 0; i < nLinks; i++ {
			sp.Links = append(sp.Links, &tracepb.Span_Link{
				TraceId:                pickIDBytes(r, 16),
				SpanId:                 pickIDBytes(r, 8),
				TraceState:             "",
				Attributes:             randomAttrList(r, 2),
				DroppedAttributesCount: r.Uint32(),
			})
		}
	}

	sp.Status = &tracepb.Status{
		Code:    tracepb.Status_StatusCode(r.Intn(3)), // 0/1/2 legal range
		Message: pickSpanName(r),
	}
	return sp
}

// pickIDBytes returns bytes for a Trace/Span ID. With 3% chance returns
// wrong-length bytes (0, 4, 32) to stress validation paths. With 4% chance
// returns all-zero of the correct length (spec-illegal but common).
func pickIDBytes(r *rand.Rand, want int) []byte {
	roll := r.Intn(100)
	switch {
	case roll < 3:
		// Wrong length — pick from {0, 4, 32}.
		wrong := []int{0, 4, 32}[r.Intn(3)]
		b := make([]byte, wrong)
		_, _ = r.Read(b)
		return b
	case roll < 7:
		// All-zero of correct length.
		return make([]byte, want)
	default:
		b := make([]byte, want)
		_, _ = r.Read(b)
		return b
	}
}

// pickTimestamps returns (start, end) unix-nano timestamps chosen to
// exercise extreme boundary conditions.
func pickTimestamps(r *rand.Rand) (uint64, uint64) {
	switch r.Intn(8) {
	case 0:
		return 0, 0 // both zero
	case 1:
		return 0, math.MaxUint64 // huge range
	case 2:
		return math.MaxUint64 - 1, math.MaxUint64 // near-overflow
	case 3:
		return math.MaxUint64, 0 // end < start (spec-illegal)
	case 4:
		t := uint64(r.Int63())
		return t, t // instantaneous (end == start)
	case 5:
		// Reasonable "now-ish" timestamps ~2020-2030 in ns.
		base := uint64(1577836800_000_000_000) + uint64(r.Int63n(315_360_000_000_000_000))
		return base, base + uint64(r.Int63n(1_000_000_000))
	case 6:
		return 1, 2 // tiny nonzero
	default:
		// Random 64-bit pair; may or may not be ordered.
		return uint64(r.Int63()), uint64(r.Int63())
	}
}

// randomAttrList produces a slice of KeyValue attributes with mixed types.
func randomAttrList(r *rand.Rand, size int) []*commonpb.KeyValue {
	if size <= 0 {
		return nil
	}
	n := r.Intn(size + 1)
	out := make([]*commonpb.KeyValue, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, randomAttr(r))
	}
	return out
}

// randomAttr generates one KeyValue with any of the AnyValue variants.
// Includes oversized-string and empty-key cases.
func randomAttr(r *rand.Rand) *commonpb.KeyValue {
	key := pickAttrKey(r)
	kv := &commonpb.KeyValue{Key: key}
	switch r.Intn(9) {
	case 0:
		kv.Value = &commonpb.AnyValue{Value: &commonpb.AnyValue_StringValue{
			StringValue: randomShortString(r),
		}}
	case 1:
		// Oversized string: 1 KiB - 8 KiB. Keeps per-iteration cost low
		// while still stressing the oversized-attribute code path.
		kv.Value = &commonpb.AnyValue{Value: &commonpb.AnyValue_StringValue{
			StringValue: randomOversizedString(r, 1024, 8*1024),
		}}
	case 2:
		kv.Value = &commonpb.AnyValue{Value: &commonpb.AnyValue_IntValue{
			IntValue: r.Int63() - r.Int63(),
		}}
	case 3:
		kv.Value = &commonpb.AnyValue{Value: &commonpb.AnyValue_DoubleValue{
			DoubleValue: pickExtremeFloat(r),
		}}
	case 4:
		kv.Value = &commonpb.AnyValue{Value: &commonpb.AnyValue_BoolValue{
			BoolValue: r.Intn(2) == 0,
		}}
	case 5:
		// Bytes — arbitrary content including non-UTF-8.
		size := r.Intn(1024)
		b := make([]byte, size)
		_, _ = r.Read(b)
		kv.Value = &commonpb.AnyValue{Value: &commonpb.AnyValue_BytesValue{BytesValue: b}}
	case 6:
		// Nested array.
		n := r.Intn(6)
		arr := make([]*commonpb.AnyValue, 0, n)
		for i := 0; i < n; i++ {
			arr = append(arr, &commonpb.AnyValue{Value: &commonpb.AnyValue_StringValue{
				StringValue: randomShortString(r),
			}})
		}
		kv.Value = &commonpb.AnyValue{Value: &commonpb.AnyValue_ArrayValue{
			ArrayValue: &commonpb.ArrayValue{Values: arr},
		}}
	case 7:
		// KvList (nested map).
		n := r.Intn(4)
		inner := make([]*commonpb.KeyValue, 0, n)
		for i := 0; i < n; i++ {
			inner = append(inner, &commonpb.KeyValue{
				Key: fmt.Sprintf("inner.%d", i),
				Value: &commonpb.AnyValue{Value: &commonpb.AnyValue_IntValue{
					IntValue: r.Int63(),
				}},
			})
		}
		kv.Value = &commonpb.AnyValue{Value: &commonpb.AnyValue_KvlistValue{
			KvlistValue: &commonpb.KeyValueList{Values: inner},
		}}
	default:
		// nil Value — protojson usually renders as {} and proto marshals fine.
		kv.Value = nil
	}
	return kv
}

func pickAttrKey(r *rand.Rand) string {
	switch r.Intn(20) {
	case 0:
		return "" // empty key — spec-illegal but proto-legal
	case 1:
		return randomOversizedString(r, 256, 1024)
	case 2:
		return "http.status_code"
	case 3:
		return "service.name"
	case 4:
		return "db.statement"
	default:
		return fmt.Sprintf("attr.%d.%d", r.Intn(1000), r.Intn(1000))
	}
}

func randomShortString(r *rand.Rand) string {
	n := r.Intn(64)
	b := make([]byte, n)
	for i := range b {
		b[i] = byte(32 + r.Intn(95)) // printable ASCII
	}
	return string(b)
}

func randomOversizedString(r *rand.Rand, min, max int) string {
	if max <= min {
		max = min + 1
	}
	n := min + r.Intn(max-min)
	b := make([]byte, n)
	for i := range b {
		b[i] = byte(32 + r.Intn(95))
	}
	return string(b)
}

func randomShortIdentifier(r *rand.Rand) string {
	parts := []string{"lib", "instrumentation", "otel", "test", "harness"}
	return fmt.Sprintf("%s.%s.%d", parts[r.Intn(len(parts))], parts[r.Intn(len(parts))], r.Intn(1000))
}

func pickSchemaURL(r *rand.Rand) string {
	switch r.Intn(4) {
	case 0:
		return ""
	case 1:
		return "https://opentelemetry.io/schemas/1.20.0"
	case 2:
		return "https://opentelemetry.io/schemas/1.9.0"
	default:
		return "not-a-url-" + randomShortIdentifier(r)
	}
}

func pickSpanName(r *rand.Rand) string {
	switch r.Intn(8) {
	case 0:
		return ""
	case 1:
		return randomOversizedString(r, 512, 2*1024)
	case 2:
		return "GET /api/v1/users"
	case 3:
		return "SELECT * FROM orders"
	case 4:
		return "\x00\x01\x02null-bytes"
	default:
		return fmt.Sprintf("op-%d", r.Int31())
	}
}

func pickExtremeFloat(r *rand.Rand) float64 {
	switch r.Intn(8) {
	case 0:
		return math.Inf(1)
	case 1:
		return math.Inf(-1)
	case 2:
		return math.NaN()
	case 3:
		return math.MaxFloat64
	case 4:
		return -math.MaxFloat64
	case 5:
		return math.SmallestNonzeroFloat64
	case 6:
		return 0
	default:
		return r.NormFloat64()
	}
}

// stringKV is a convenience helper used above.
func stringKV(k, v string) *commonpb.KeyValue {
	return &commonpb.KeyValue{
		Key:   k,
		Value: &commonpb.AnyValue{Value: &commonpb.AnyValue_StringValue{StringValue: v}},
	}
}
