package harness

import (
	"fmt"

	collectortracepb "go.opentelemetry.io/proto/otlp/collector/trace/v1"
	tracepb "go.opentelemetry.io/proto/otlp/trace/v1"
)

// ValidateResponse checks that an ExportTraceServiceResponse conforms to
// the schema expected by the OpenTelemetry Collector's otlpreceiver.
//
// The rules enforced here follow the OTLP/HTTP spec for successful export:
//   - The response message is non-nil.
//   - If PartialSuccess is present, RejectedSpans must be >= 0.
//   - If any spans are rejected, ErrorMessage must be non-empty
//     (per the OTLP spec's "partial success" semantics).
//
// A nil error means the response is a valid full success or valid partial
// success. Full-reject responses (RejectedSpans > 0) are surfaced as errors
// so that integration tests fail loudly.
func ValidateResponse(resp *collectortracepb.ExportTraceServiceResponse) error {
	if resp == nil {
		return fmt.Errorf("validate: nil response")
	}
	ps := resp.GetPartialSuccess()
	if ps == nil {
		return nil // full success
	}
	if ps.GetRejectedSpans() < 0 {
		return fmt.Errorf("validate: negative rejected_spans=%d", ps.GetRejectedSpans())
	}
	if ps.GetRejectedSpans() > 0 && ps.GetErrorMessage() == "" {
		return fmt.Errorf("validate: partial success reports %d rejected spans with empty error_message",
			ps.GetRejectedSpans())
	}
	if ps.GetRejectedSpans() > 0 {
		return fmt.Errorf("validate: collector rejected %d spans: %s",
			ps.GetRejectedSpans(), ps.GetErrorMessage())
	}
	return nil
}

// ValidateRequest verifies that a generated ExportTraceServiceRequest is
// well-formed per the OTLP trace proto schema. Useful as a self-check on
// the generator before sending it over the wire.
func ValidateRequest(req *collectortracepb.ExportTraceServiceRequest) error {
	if req == nil {
		return fmt.Errorf("validate: nil ExportTraceServiceRequest")
	}
	if len(req.ResourceSpans) == 0 {
		return fmt.Errorf("validate: no resource_spans")
	}
	for i, rs := range req.ResourceSpans {
		if rs.Resource == nil {
			return fmt.Errorf("validate: resource_spans[%d].resource is nil", i)
		}
		if len(rs.ScopeSpans) == 0 {
			return fmt.Errorf("validate: resource_spans[%d].scope_spans is empty", i)
		}
		for j, ss := range rs.ScopeSpans {
			if ss.Scope == nil || ss.Scope.Name == "" {
				return fmt.Errorf("validate: resource_spans[%d].scope_spans[%d].scope.name is empty", i, j)
			}
			if len(ss.Spans) == 0 {
				return fmt.Errorf("validate: resource_spans[%d].scope_spans[%d].spans is empty", i, j)
			}
			for k, sp := range ss.Spans {
				if err := validateSpan(sp); err != nil {
					return fmt.Errorf("resource_spans[%d].scope_spans[%d].spans[%d]: %w", i, j, k, err)
				}
			}
		}
	}
	return nil
}

func validateSpan(sp *tracepb.Span) error {
	if sp == nil {
		return fmt.Errorf("nil span")
	}
	if len(sp.TraceId) != 16 {
		return fmt.Errorf("trace_id must be 16 bytes, got %d", len(sp.TraceId))
	}
	if len(sp.SpanId) != 8 {
		return fmt.Errorf("span_id must be 8 bytes, got %d", len(sp.SpanId))
	}
	if sp.Name == "" {
		return fmt.Errorf("span name is empty")
	}
	if sp.StartTimeUnixNano == 0 {
		return fmt.Errorf("start_time_unix_nano is 0")
	}
	if sp.EndTimeUnixNano < sp.StartTimeUnixNano {
		return fmt.Errorf("end_time_unix_nano (%d) < start_time_unix_nano (%d)",
			sp.EndTimeUnixNano, sp.StartTimeUnixNano)
	}
	return nil
}

// CountSpans returns the total number of spans across all resource/scope
// entries. Convenient for asserting round-trip fidelity in tests.
func CountSpans(req *collectortracepb.ExportTraceServiceRequest) int {
	if req == nil {
		return 0
	}
	n := 0
	for _, rs := range req.ResourceSpans {
		for _, ss := range rs.ScopeSpans {
			n += len(ss.Spans)
		}
	}
	return n
}
