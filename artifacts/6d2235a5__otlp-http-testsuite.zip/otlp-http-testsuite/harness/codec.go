package harness

import (
	"fmt"

	collectortracepb "go.opentelemetry.io/proto/otlp/collector/trace/v1"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

// EncodeRequest serializes an ExportTraceServiceRequest according to the
// content-type rules defined by the OTLP/HTTP specification.
//
// For PayloadProtobuf, the standard binary protobuf wire format is used.
// For PayloadJSON, the proto3 JSON mapping is used via protojson so that
// bytes fields (TraceId, SpanId) are hex-encoded and enums are rendered as
// their canonical string names — matching what the OpenTelemetry Collector's
// otlpreceiver expects.
func EncodeRequest(req *collectortracepb.ExportTraceServiceRequest, pt PayloadType) ([]byte, error) {
	if req == nil {
		return nil, fmt.Errorf("harness: nil ExportTraceServiceRequest")
	}
	switch pt {
	case PayloadProtobuf:
		return proto.Marshal(req)
	case PayloadJSON:
		m := protojson.MarshalOptions{
			UseProtoNames:   false, // camelCase field names, per OTLP/HTTP spec
			EmitUnpopulated: false,
		}
		return m.Marshal(req)
	default:
		return nil, fmt.Errorf("harness: unsupported payload type %q", pt)
	}
}

// DecodeResponse parses an OTLP/HTTP ExportTraceServiceResponse from body
// bytes. It respects the response Content-Type: an application/json body is
// decoded via protojson, application/x-protobuf via proto.Unmarshal.
//
// The OpenTelemetry Collector may reply with an empty body (0 bytes) on
// success; in that case a zero-value ExportTraceServiceResponse is returned.
func DecodeResponse(body []byte, contentType string) (*collectortracepb.ExportTraceServiceResponse, error) {
	resp := &collectortracepb.ExportTraceServiceResponse{}
	if len(body) == 0 {
		return resp, nil
	}
	ct := normalizeContentType(contentType)
	switch ct {
	case "application/x-protobuf":
		if err := proto.Unmarshal(body, resp); err != nil {
			return nil, fmt.Errorf("harness: decode protobuf response: %w", err)
		}
	case "application/json":
		if err := (protojson.UnmarshalOptions{DiscardUnknown: true}).Unmarshal(body, resp); err != nil {
			return nil, fmt.Errorf("harness: decode json response: %w", err)
		}
	default:
		return nil, fmt.Errorf("harness: unsupported response content-type %q", contentType)
	}
	return resp, nil
}

// DecodeResponseAsRequest decodes body bytes into an
// ExportTraceServiceRequest. It is the request-side counterpart of
// DecodeResponse and is primarily used by property-based tests that
// need to round-trip an encoded request through the paired decoder.
func DecodeResponseAsRequest(body []byte, contentType string) (*collectortracepb.ExportTraceServiceRequest, error) {
	req := &collectortracepb.ExportTraceServiceRequest{}
	if len(body) == 0 {
		return req, nil
	}
	ct := normalizeContentType(contentType)
	switch ct {
	case "application/x-protobuf":
		if err := proto.Unmarshal(body, req); err != nil {
			return nil, fmt.Errorf("harness: decode protobuf request: %w", err)
		}
	case "application/json":
		if err := (protojson.UnmarshalOptions{DiscardUnknown: true}).Unmarshal(body, req); err != nil {
			return nil, fmt.Errorf("harness: decode json request: %w", err)
		}
	default:
		return nil, fmt.Errorf("harness: unsupported request content-type %q", contentType)
	}
	return req, nil
}

// normalizeContentType strips parameters such as "; charset=utf-8".
func normalizeContentType(ct string) string {
	for i := 0; i < len(ct); i++ {
		if ct[i] == ';' {
			return trimSpace(ct[:i])
		}
	}
	return trimSpace(ct)
}

func trimSpace(s string) string {
	start, end := 0, len(s)
	for start < end && (s[start] == ' ' || s[start] == '\t') {
		start++
	}
	for end > start && (s[end-1] == ' ' || s[end-1] == '\t') {
		end--
	}
	return s[start:end]
}
