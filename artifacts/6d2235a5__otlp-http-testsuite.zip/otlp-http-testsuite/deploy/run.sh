#!/usr/bin/env bash
# run.sh — one-shot docker-compose test runner.
#
# Boots the pinned OpenTelemetry Collector, waits for its health-check
# extension to report ready, then runs `go test ./tests/...` against the
# real collector (via OTLP_HTTP_ENDPOINT). The compose stack is torn down
# on exit regardless of test outcome. The script's exit code matches
# `go test` so it slots cleanly into CI.
#
# Environment overrides (all optional):
#   COLLECTOR_TAG      collector image tag (default: 0.136.0)
#   OTLP_HTTP_PORT     host port bound to the collector's 4318 (default: 4318)
#   OTLP_HEALTH_PORT   host port bound to health_check (default: 13133)
#   OTLP_TEST_PAYLOAD  passed through to the Go tests (protobuf|json|both)
#   TEST_TIMEOUT       -timeout value passed to `go test` (default: 60s)
#   KEEP_UP            if set to "1", leaves the collector running on exit
#
# Usage:
#   ./deploy/run.sh                       # full run, both payload types
#   OTLP_TEST_PAYLOAD=json ./deploy/run.sh
#   KEEP_UP=1 ./deploy/run.sh             # for interactive debugging

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

COMPOSE_FILE="${SCRIPT_DIR}/docker-compose.yaml"
OTLP_HTTP_PORT="${OTLP_HTTP_PORT:-4318}"
OTLP_HEALTH_PORT="${OTLP_HEALTH_PORT:-13133}"
TEST_TIMEOUT="${TEST_TIMEOUT:-60s}"

# Pick `docker compose` (v2) or fall back to legacy `docker-compose`.
if docker compose version >/dev/null 2>&1; then
  DC=(docker compose -f "${COMPOSE_FILE}")
elif command -v docker-compose >/dev/null 2>&1; then
  DC=(docker-compose -f "${COMPOSE_FILE}")
else
  echo "ERROR: neither 'docker compose' nor 'docker-compose' is installed" >&2
  exit 127
fi

teardown() {
  if [[ "${KEEP_UP:-0}" == "1" ]]; then
    echo "KEEP_UP=1 — leaving collector running. Tear down manually with:"
    echo "    ${DC[*]} down -v"
    return
  fi
  echo "→ Tearing down collector"
  "${DC[@]}" down -v --remove-orphans >/dev/null 2>&1 || true
}
trap teardown EXIT

echo "→ Booting collector (tag=${COLLECTOR_TAG:-0.136.0}, http=${OTLP_HTTP_PORT}, health=${OTLP_HEALTH_PORT})"
"${DC[@]}" up -d --pull always --wait --wait-timeout 60 || {
  echo "ERROR: collector failed to become healthy" >&2
  "${DC[@]}" logs otel-collector | tail -80 >&2 || true
  exit 1
}

# Belt-and-suspenders: even after `--wait`, poll /v1/traces with a tiny
# empty request to confirm the OTLP receiver (not just the health-check
# extension) is actually accepting requests.
echo "→ Probing OTLP/HTTP receiver at http://127.0.0.1:${OTLP_HTTP_PORT}/v1/traces"
for i in $(seq 1 20); do
  code=$(curl -s -o /dev/null -w '%{http_code}' \
    -X POST "http://127.0.0.1:${OTLP_HTTP_PORT}/v1/traces" \
    -H 'Content-Type: application/x-protobuf' --data-binary '') || code=000
  # Empty body → the OTLP receiver responds 4xx (typically 400) but the
  # port is up. Anything non-000 proves the listener is live.
  if [[ "${code}" != "000" ]]; then
    echo "  receiver responding (HTTP ${code})"
    break
  fi
  sleep 0.5
  if [[ "${i}" == "20" ]]; then
    echo "ERROR: OTLP/HTTP receiver never responded" >&2
    "${DC[@]}" logs otel-collector | tail -80 >&2 || true
    exit 1
  fi
done

# Run the full test suite against the real collector. Setting
# OTLP_HTTP_ENDPOINT switches tests that opt-in to a real collector
# (see tests/compliance_test.go) away from the in-process mock server.
export OTLP_HTTP_ENDPOINT="http://127.0.0.1:${OTLP_HTTP_PORT}/v1/traces"
export OTLP_TEST_PAYLOAD="${OTLP_TEST_PAYLOAD:-both}"

echo "→ Running Go test suite against ${OTLP_HTTP_ENDPOINT}"
cd "${REPO_ROOT}"
go test ./tests/... -timeout "${TEST_TIMEOUT}" -v "$@"
rc=$?

if [[ $rc -ne 0 ]]; then
  echo "→ Test run failed — collector logs follow:"
  "${DC[@]}" logs otel-collector | tail -120 || true
fi

exit $rc
