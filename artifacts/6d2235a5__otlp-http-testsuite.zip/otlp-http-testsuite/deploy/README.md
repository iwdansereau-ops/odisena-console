# deploy/

Docker-compose test runner that boots the **real** OpenTelemetry Collector
(contrib distribution) and runs the full `./tests/...` suite against it.

## What this validates

The mock in `../server` is convenient but it can drift from the real
collector's implementation. This directory pins a real released collector,
gives it a minimal OTLP/HTTP receiver + debug exporter pipeline, and runs
`tests/compliance_test.go` against it to confirm:

- The generator produces payloads the production collector accepts.
- Content-Type handling matches the OTLP/HTTP spec on both directions.
- Partial-success responses conform to the OTLP proto schema.
- Well-formed batches are never spuriously rejected.
- Malformed payloads are rejected as 4xx (not 5xx).
- Unsupported media types are rejected.

## Files

- `docker-compose.yaml` — pinned collector image + port bindings + health-check.
- `collector/config.yaml` — receivers/exporters/pipelines for the test run.
- `run.sh` — the one-shot runner. Boots, waits for readiness, runs
  `go test`, tears down. Exit code = `go test` exit code.

## Quick start

```
# Fastest path — from the repo root:
make test-compliance

# Or invoke the runner directly:
./deploy/run.sh

# Interactive: leave the collector running for repeated `go test` invocations.
KEEP_UP=1 ./deploy/run.sh
OTLP_HTTP_ENDPOINT=http://127.0.0.1:4318/v1/traces go test ./tests/... -run Compliance -v
```

## Environment overrides

| Variable            | Default   | Purpose                                              |
| ------------------- | --------- | ---------------------------------------------------- |
| `COLLECTOR_TAG`     | `0.136.0` | Image tag for `opentelemetry-collector-contrib`.     |
| `OTLP_HTTP_PORT`    | `4318`    | Host port bound to the collector's OTLP/HTTP port.   |
| `OTLP_HEALTH_PORT`  | `13133`   | Host port bound to `health_check` extension.        |
| `OTLP_TEST_PAYLOAD` | `both`    | Passed to Go tests (`protobuf`, `json`, or `both`).  |
| `TEST_TIMEOUT`      | `60s`     | `-timeout` value for `go test`.                      |
| `KEEP_UP`           | unset     | `1` = leave the collector running on exit.           |

## Image source

The collector image is pulled from GHCR at
`ghcr.io/open-telemetry/opentelemetry-collector-releases/opentelemetry-collector-contrib`.
Newer collector releases (v0.123.1 onwards) publish there rather than to
DockerHub. If you need an older tag that only exists on DockerHub, edit
`docker-compose.yaml` and swap the `image:` line to
`otel/opentelemetry-collector-contrib:<tag>`.

## Debugging a failing compliance run

`run.sh` prints the last 120 lines of collector logs when `go test` fails.
For deeper debugging:

```
KEEP_UP=1 ./deploy/run.sh -run TestCompliance_RoundTrip -v
docker compose -f deploy/docker-compose.yaml logs -f otel-collector

# In another shell, replay a single test against the still-running collector:
OTLP_HTTP_ENDPOINT=http://127.0.0.1:4318/v1/traces \
  go test ./tests/... -run TestCompliance_RoundTrip/protobuf -v
```

The debug exporter is configured with `verbosity: detailed`, so the
collector logs every span it received — perfect for diffing against what
the generator sent.
