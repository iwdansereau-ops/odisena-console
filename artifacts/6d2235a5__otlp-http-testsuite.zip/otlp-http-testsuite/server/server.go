// Package server implements a minimal local OTLP/HTTP test collector that
// accepts trace exports on /v1/traces. It mirrors the content-type handling
// performed by the OpenTelemetry Collector's otlpreceiver so integration
// tests can validate both binary-protobuf and JSON pipelines end-to-end.
package server

import (
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strconv"
	"sync"
	"time"

	collectortracepb "go.opentelemetry.io/proto/otlp/collector/trace/v1"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

// ScriptedResponse describes a single scripted reply used to simulate network
// instability. When the collector's script is non-empty, each incoming request
// consumes one entry from the front of the script; once the script is
// exhausted the collector falls back to its default success behavior.
//
// Fields:
//   - StatusCode: HTTP status returned for this call. Zero means 200 OK.
//   - Delay: artificial latency applied before writing the response.
//   - RetryAfter: value written into the Retry-After header. May be a
//     numeric string ("2") for delta-seconds or an RFC 1123 HTTP-date.
//     Empty means no header is sent.
type ScriptedResponse struct {
	StatusCode int
	Delay      time.Duration
	RetryAfter string
}

// TestCollector is a lightweight in-process OTLP/HTTP receiver used by
// integration tests. It records every received ExportTraceServiceRequest
// and replies with an empty ExportTraceServiceResponse encoded using the
// same content-type as the request.
type TestCollector struct {
	server *httptest.Server

	mu       sync.Mutex
	received []*collectortracepb.ExportTraceServiceRequest
	// partialSuccess, when non-nil, is echoed on every response so tests can
	// exercise the partial-success validation path.
	partialSuccess *collectortracepb.ExportTracePartialSuccess
	// forceStatus, when non-zero, overrides the success status code for
	// EVERY request (unlike script which only applies to one call).
	forceStatus int
	// defaultDelay is applied to every request. Set via SetResponseDelay.
	defaultDelay time.Duration
	// defaultStatus, when non-zero, is applied to every request. Set via
	// SetResponseCode.
	defaultStatus int
	// defaultRetryAfter is echoed on every response when non-empty.
	defaultRetryAfter string
	// script is a queue of one-shot responses consumed FIFO. It always takes
	// precedence over the default* fields for the call it applies to.
	script []ScriptedResponse
	// callCount is the number of requests received (regardless of outcome).
	callCount int
}

// New starts a new TestCollector on a random loopback port.
func New() *TestCollector {
	tc := &TestCollector{}
	mux := http.NewServeMux()
	mux.HandleFunc("/v1/traces", tc.handleTraces)
	tc.server = httptest.NewServer(mux)
	return tc
}

// URL returns the base URL, e.g. http://127.0.0.1:PORT.
func (tc *TestCollector) URL() string { return tc.server.URL }

// TracesURL returns the full /v1/traces endpoint URL.
func (tc *TestCollector) TracesURL() string { return tc.server.URL + "/v1/traces" }

// Close shuts the server down.
func (tc *TestCollector) Close() { tc.server.Close() }

// Received returns a snapshot of all requests observed so far.
func (tc *TestCollector) Received() []*collectortracepb.ExportTraceServiceRequest {
	tc.mu.Lock()
	defer tc.mu.Unlock()
	out := make([]*collectortracepb.ExportTraceServiceRequest, len(tc.received))
	copy(out, tc.received)
	return out
}

// CallCount returns the total number of HTTP requests the collector has
// received on /v1/traces. Useful for asserting retry behavior.
func (tc *TestCollector) CallCount() int {
	tc.mu.Lock()
	defer tc.mu.Unlock()
	return tc.callCount
}

// Reset clears the received-requests log, call counter, and any scripted
// responses. Default status/delay/retry-after are preserved.
func (tc *TestCollector) Reset() {
	tc.mu.Lock()
	defer tc.mu.Unlock()
	tc.received = nil
	tc.callCount = 0
	tc.script = nil
}

// SetPartialSuccess configures the collector to echo a PartialSuccess block.
func (tc *TestCollector) SetPartialSuccess(rejected int64, msg string) {
	tc.mu.Lock()
	defer tc.mu.Unlock()
	tc.partialSuccess = &collectortracepb.ExportTracePartialSuccess{
		RejectedSpans: rejected,
		ErrorMessage:  msg,
	}
}

// SetForceStatus makes the collector reply with the given HTTP status code
// (with an empty body) for every request. Useful for exercising client
// error paths.
//
// Deprecated: prefer SetResponseCode which is symmetrical with
// SetResponseDelay and interacts cleanly with the scripted-response system.
// This function is retained for compatibility with existing tests.
func (tc *TestCollector) SetForceStatus(code int) {
	tc.mu.Lock()
	defer tc.mu.Unlock()
	tc.forceStatus = code
}

// SetResponseDelay sets an artificial latency applied to every response.
// Pass 0 to disable. Delay is applied before the status line is written,
// so client-side context/timeout deadlines fire as expected.
func (tc *TestCollector) SetResponseDelay(d time.Duration) {
	tc.mu.Lock()
	defer tc.mu.Unlock()
	tc.defaultDelay = d
}

// SetResponseCode configures the default HTTP status code the collector
// returns for every request. Pass 0 to restore normal 200 OK behavior.
//
// The most common values for simulating network instability are:
//   - 429 Too Many Requests (rate-limited)
//   - 502 Bad Gateway
//   - 503 Service Unavailable
//   - 504 Gateway Timeout
//
// All of these are considered retryable by the OTLP/HTTP specification.
// When retryAfter is non-empty it is written as the "Retry-After" response
// header. Per RFC 7231 the value may be either a non-negative integer
// number of delta-seconds or an HTTP-date.
func (tc *TestCollector) SetResponseCode(code int, retryAfter string) {
	tc.mu.Lock()
	defer tc.mu.Unlock()
	tc.defaultStatus = code
	tc.defaultRetryAfter = retryAfter
}

// ScriptResponses appends one or more scripted responses to the queue. Each
// incoming request consumes the head of the queue. When the queue empties,
// the collector falls back to its default behavior (200 OK unless
// SetResponseCode / SetForceStatus is active).
//
// A common pattern for retry tests is:
//
//	tc.ScriptResponses(
//	    server.ScriptedResponse{StatusCode: 503, RetryAfter: "1"},
//	    server.ScriptedResponse{StatusCode: 429, RetryAfter: "1"},
//	    server.ScriptedResponse{StatusCode: 200},
//	)
func (tc *TestCollector) ScriptResponses(responses ...ScriptedResponse) {
	tc.mu.Lock()
	defer tc.mu.Unlock()
	tc.script = append(tc.script, responses...)
}

// nextScripted pops the next scripted response, if any.
func (tc *TestCollector) nextScripted() (ScriptedResponse, bool) {
	tc.mu.Lock()
	defer tc.mu.Unlock()
	if len(tc.script) == 0 {
		return ScriptedResponse{}, false
	}
	r := tc.script[0]
	tc.script = tc.script[1:]
	return r, true
}

func (tc *TestCollector) handleTraces(w http.ResponseWriter, r *http.Request) {
	tc.mu.Lock()
	tc.callCount++
	tc.mu.Unlock()

	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	ct := normalizeContentType(r.Header.Get("Content-Type"))
	if ct != "application/x-protobuf" && ct != "application/json" {
		http.Error(w, "unsupported content-type: "+r.Header.Get("Content-Type"),
			http.StatusUnsupportedMediaType)
		return
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "read body: "+err.Error(), http.StatusBadRequest)
		return
	}

	req := &collectortracepb.ExportTraceServiceRequest{}
	if err := decodeRequest(body, ct, req); err != nil {
		http.Error(w, "decode: "+err.Error(), http.StatusBadRequest)
		return
	}

	tc.mu.Lock()
	tc.received = append(tc.received, req)
	forceStatus := tc.forceStatus
	defaultStatus := tc.defaultStatus
	defaultDelay := tc.defaultDelay
	defaultRetryAfter := tc.defaultRetryAfter
	ps := tc.partialSuccess
	tc.mu.Unlock()

	// Resolve the effective response: scripted entry wins over defaults,
	// defaults win over the plain 200 OK success path. forceStatus is
	// preserved for backward compatibility with existing tests.
	resp := ScriptedResponse{}
	if scripted, ok := tc.nextScripted(); ok {
		resp = scripted
	} else {
		resp.StatusCode = defaultStatus
		resp.Delay = defaultDelay
		resp.RetryAfter = defaultRetryAfter
		if forceStatus != 0 && resp.StatusCode == 0 {
			resp.StatusCode = forceStatus
		}
	}

	// Apply latency BEFORE writing the response so client deadlines are
	// honored naturally.
	if resp.Delay > 0 {
		select {
		case <-time.After(resp.Delay):
		case <-r.Context().Done():
			return
		}
	}

	if resp.RetryAfter != "" {
		w.Header().Set("Retry-After", resp.RetryAfter)
	}

	// Non-2xx path: write status with an empty body. This matches how the
	// upstream otlpreceiver reports transient failures without a body.
	if resp.StatusCode != 0 && (resp.StatusCode < 200 || resp.StatusCode >= 300) {
		w.WriteHeader(resp.StatusCode)
		return
	}

	// Success path: build and encode the OTLP response.
	otlpResp := &collectortracepb.ExportTraceServiceResponse{}
	if ps != nil {
		otlpResp.PartialSuccess = ps
	}
	respBytes, err := encodeResponse(otlpResp, ct)
	if err != nil {
		http.Error(w, "encode: "+err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", ct)
	if resp.StatusCode == 0 {
		w.WriteHeader(http.StatusOK)
	} else {
		w.WriteHeader(resp.StatusCode)
	}
	_, _ = w.Write(respBytes)
}

// ParseRetryAfter parses a Retry-After header value per RFC 7231, returning
// the wait duration relative to `now`. Returns (0, false) when the header
// is empty or malformed. Delta-seconds and HTTP-dates are both supported.
func ParseRetryAfter(header string, now time.Time) (time.Duration, bool) {
	header = trimSpace(header)
	if header == "" {
		return 0, false
	}
	if n, err := strconv.Atoi(header); err == nil {
		if n < 0 {
			return 0, false
		}
		return time.Duration(n) * time.Second, true
	}
	if t, err := http.ParseTime(header); err == nil {
		d := t.Sub(now)
		if d < 0 {
			return 0, true
		}
		return d, true
	}
	return 0, false
}

func decodeRequest(body []byte, ct string, req *collectortracepb.ExportTraceServiceRequest) error {
	switch ct {
	case "application/x-protobuf":
		return proto.Unmarshal(body, req)
	case "application/json":
		return (protojson.UnmarshalOptions{DiscardUnknown: true}).Unmarshal(body, req)
	}
	return errors.New("unsupported content-type")
}

func encodeResponse(resp *collectortracepb.ExportTraceServiceResponse, ct string) ([]byte, error) {
	switch ct {
	case "application/x-protobuf":
		return proto.Marshal(resp)
	case "application/json":
		return protojson.MarshalOptions{}.Marshal(resp)
	}
	return nil, fmt.Errorf("unsupported content-type %q", ct)
}

func normalizeContentType(ct string) string {
	for i := 0; i < len(ct); i++ {
		if ct[i] == ';' {
			return trimSpace(ct[:i])
		}
	}
	return trimSpace(ct)
}

func trimSpace(s string) string {
	start, end := 0, len(s)
	for start < end && (s[start] == ' ' || s[start] == '\t') {
		start++
	}
	for end > start && (s[end-1] == ' ' || s[end-1] == '\t') {
		end--
	}
	return s[start:end]
}
