// Package gentest builds synthetic pmetric.Metrics payloads for tests and
// benchmarks. Isolated in its own package so benchmarks can import it
// without dragging in test-only helpers. Named `gentest` rather than
// `testdata` because Go's toolchain skips directories named `testdata`.
package gentest

import (
	"strconv"
	"time"

	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/pmetric"
)

// Options configures a synthetic batch.
type Options struct {
	Resources        int    // number of ResourceMetrics
	ScopesPerRes     int    // number of ScopeMetrics per resource
	MetricsPerScope  int    // number of Metric entries per scope
	SeriesPerMetric  int    // number of distinct (attr set) data points per metric
	IncludeGauge     bool   // add one Gauge metric per scope (exercises passthrough)
	MonotonicSum     bool
	Temporality      pmetric.AggregationTemporality
	MetricNamePrefix string
}

// Default returns a mid-size batch: ~10k series.
func Default() Options {
	return Options{
		Resources:        4,
		ScopesPerRes:     4,
		MetricsPerScope:  4,
		SeriesPerMetric:  160,
		MonotonicSum:     true,
		Temporality:      pmetric.AggregationTemporalityCumulative,
		MetricNamePrefix: "svc.requests",
	}
}

// Build produces a pmetric.Metrics matching opts. Attribute values are
// deterministic and span-based so benchmarks can vary cardinality by
// changing SeriesPerMetric.
func Build(opts Options) pmetric.Metrics {
	md := pmetric.NewMetrics()
	now := pcommon.NewTimestampFromTime(time.Unix(1_700_000_000, 0))
	start := pcommon.NewTimestampFromTime(time.Unix(1_699_999_900, 0))

	for r := 0; r < opts.Resources; r++ {
		rm := md.ResourceMetrics().AppendEmpty()
		rm.Resource().Attributes().PutStr("service.name", "svc-"+strconv.Itoa(r))
		rm.Resource().Attributes().PutStr("deployment.env", "prod")
		for s := 0; s < opts.ScopesPerRes; s++ {
			sm := rm.ScopeMetrics().AppendEmpty()
			sm.Scope().SetName("scope-" + strconv.Itoa(s))
			sm.Scope().SetVersion("1.0.0")
			for m := 0; m < opts.MetricsPerScope; m++ {
				metric := sm.Metrics().AppendEmpty()
				metric.SetName(opts.MetricNamePrefix + "." + strconv.Itoa(m))
				metric.SetUnit("1")
				sum := metric.SetEmptySum()
				sum.SetAggregationTemporality(opts.Temporality)
				sum.SetIsMonotonic(opts.MonotonicSum)
				dps := sum.DataPoints()
				dps.EnsureCapacity(opts.SeriesPerMetric)
				for i := 0; i < opts.SeriesPerMetric; i++ {
					dp := dps.AppendEmpty()
					dp.SetStartTimestamp(start)
					dp.SetTimestamp(now)
					dp.SetIntValue(int64(i + 1))
					attrs := dp.Attributes()
					attrs.PutStr("http.method", methodFor(i))
					attrs.PutStr("http.route", "/route/"+strconv.Itoa(i%64))
					attrs.PutInt("http.status_code", int64(200+(i%5)))
					attrs.PutStr("customer_id", "cust-"+strconv.Itoa(i))
				}
				if opts.IncludeGauge {
					g := sm.Metrics().AppendEmpty()
					g.SetName(opts.MetricNamePrefix + ".gauge." + strconv.Itoa(m))
					gg := g.SetEmptyGauge()
					gdps := gg.DataPoints()
					dp := gdps.AppendEmpty()
					dp.SetTimestamp(now)
					dp.SetDoubleValue(42.0)
				}
			}
		}
	}
	return md
}

func methodFor(i int) string {
	switch i % 4 {
	case 0:
		return "GET"
	case 1:
		return "POST"
	case 2:
		return "PUT"
	default:
		return "DELETE"
	}
}
