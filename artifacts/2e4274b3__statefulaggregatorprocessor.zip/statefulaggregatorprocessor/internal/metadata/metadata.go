package metadata

import "go.opentelemetry.io/collector/component"

// Type is the component type for this processor.
var Type = component.MustNewType("statefulaggregator")

const (
	MetricsStability = component.StabilityLevelAlpha
)
