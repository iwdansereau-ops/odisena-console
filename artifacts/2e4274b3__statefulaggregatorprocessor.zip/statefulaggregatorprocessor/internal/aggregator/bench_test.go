package aggregator_test

import (
	"testing"
	"time"

	"go.opentelemetry.io/collector/pdata/pmetric"

	"github.com/example/statefulaggregatorprocessor/internal/aggregator"
	"github.com/example/statefulaggregatorprocessor/internal/gentest"
)

// The benchmark suite measures CPU and memory overhead under three regimes:
//
//   - Fingerprint      : cost of the hashing path in isolation.
//   - IngestHighCard   : end-to-end folding of ~250k unique series per op.
//   - FlushHighCard    : cost of draining a populated state to pdata.
//
// Run with:
//
//	go test -bench=. -benchmem -benchtime=3s ./internal/aggregator/...
//
// To capture profiles:
//
//	go test -bench=BenchmarkIngestHighCard -benchmem \
//	    -cpuprofile cpu.out -memprofile mem.out ./internal/aggregator/...

func BenchmarkFingerprint(b *testing.B) {
	md := gentest.Build(gentest.Options{
		Resources: 1, ScopesPerRes: 1, MetricsPerScope: 1, SeriesPerMetric: 1_000,
		MonotonicSum: true, Temporality: pmetric.AggregationTemporalityCumulative,
		MetricNamePrefix: "m",
	})
	rm := md.ResourceMetrics().At(0)
	resAttrs := rm.Resource().Attributes()
	sm := rm.ScopeMetrics().At(0)
	scope := sm.Scope().Name()
	metric := sm.Metrics().At(0)
	name := metric.Name()
	dps := metric.Sum().DataPoints()

	builder := aggregator.NewBuilder()
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		dp := dps.At(i % dps.Len())
		_ = builder.Compute(resAttrs, scope, name, dp.Attributes())
	}
}

func BenchmarkIngestHighCard(b *testing.B) {
	// ~256k unique series per batch: 4 res * 4 scopes * 4 metrics * 4k series.
	opts := gentest.Options{
		Resources: 4, ScopesPerRes: 4, MetricsPerScope: 4, SeriesPerMetric: 4_000,
		MonotonicSum: true, Temporality: pmetric.AggregationTemporalityCumulative,
		MetricNamePrefix: "svc.req",
	}
	md := gentest.Build(opts)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		mgr := aggregator.NewManager(64, 0)
		if dropped := aggregator.Ingest(mgr, md, nil); dropped != 0 {
			b.Fatalf("unexpected drops: %d", dropped)
		}
	}
}

func BenchmarkIngestHighCardReuseState(b *testing.B) {
	// Measures the steady-state fold cost when series already exist.
	opts := gentest.Options{
		Resources: 4, ScopesPerRes: 4, MetricsPerScope: 4, SeriesPerMetric: 4_000,
		MonotonicSum: true, Temporality: pmetric.AggregationTemporalityCumulative,
		MetricNamePrefix: "svc.req",
	}
	md := gentest.Build(opts)
	mgr := aggregator.NewManager(64, 0)
	aggregator.Ingest(mgr, md, nil) // prime

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if dropped := aggregator.Ingest(mgr, md, nil); dropped != 0 {
			b.Fatalf("unexpected drops: %d", dropped)
		}
	}
}

func BenchmarkFlushHighCard(b *testing.B) {
	opts := gentest.Options{
		Resources: 4, ScopesPerRes: 4, MetricsPerScope: 4, SeriesPerMetric: 4_000,
		MonotonicSum: true, Temporality: pmetric.AggregationTemporalityCumulative,
		MetricNamePrefix: "svc.req",
	}
	md := gentest.Build(opts)

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		b.StopTimer()
		mgr := aggregator.NewManager(64, 0)
		aggregator.Ingest(mgr, md, nil)
		b.StartTimer()
		_ = mgr.Flush(time.Now())
	}
}
