package aggregator

import "unsafe"

// unsafePointer is a tiny indirection so fingerprint.go can float64->uint64
// reinterpret without pulling in math (keeps the hot path allocation-free
// and inlineable). Isolated in this file so the unsafe usage is auditable.
func unsafePointer(p *float64) unsafe.Pointer { return unsafe.Pointer(p) }
