package aggregator

import (
	"sync"
	"sync/atomic"
	"time"

	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/pmetric"
)

// Series is the running aggregate for one time series. It stores enough
// identity metadata to reconstruct a pmetric.NumberDataPoint on flush.
type Series struct {
	// Identity (immutable after first insert).
	ResourceAttrs pcommon.Map
	ScopeName     string
	ScopeVersion  string
	MetricName    string
	MetricUnit    string
	MetricDesc    string
	Temporality   pmetric.AggregationTemporality
	IsMonotonic   bool
	DPAttrs       pcommon.Map

	// Aggregated payload — protected by the enclosing shard's lock.
	StartTime pcommon.Timestamp
	Time      pcommon.Timestamp

	// One of intSum / doubleSum is used depending on the first observed point.
	IsDouble  bool
	IntSum    int64
	DoubleSum float64

	// Point count — useful for downstream QoS / debug metrics.
	Points uint64
}

// shard is a single lock-protected partition of the state table.
type shard struct {
	mu   sync.Mutex
	data map[Fingerprint]*Series
}

// Manager holds the aggregation state for all in-flight series. It is safe
// for concurrent Ingest calls and for a background flusher goroutine.
//
// Design notes:
//   - Sharded by the low bits of the fingerprint to spread lock contention.
//   - MaxSeries is a soft cap enforced with an atomic counter to avoid taking
//     every shard lock on every insert.
//   - Each series stores its own identity so Flush can materialise a
//     pmetric.Metrics without walking any external index.
type Manager struct {
	shards     []*shard
	shardMask  uint64
	seriesLen  atomic.Int64
	maxSeries  int64
	builderPool sync.Pool
}

// NewManager constructs a Manager with shardCount partitions (must be a power
// of two) and an optional MaxSeries cap (0 = unbounded).
func NewManager(shardCount, maxSeries int) *Manager {
	if shardCount <= 0 {
		shardCount = 64
	}
	if shardCount&(shardCount-1) != 0 {
		panic("shardCount must be a power of two")
	}
	m := &Manager{
		shards:    make([]*shard, shardCount),
		shardMask: uint64(shardCount - 1),
		maxSeries: int64(maxSeries),
	}
	for i := range m.shards {
		m.shards[i] = &shard{data: make(map[Fingerprint]*Series, 1024)}
	}
	m.builderPool.New = func() any { return NewBuilder() }
	return m
}

// BorrowBuilder returns a pooled fingerprint builder. Callers must Return it.
func (m *Manager) BorrowBuilder() *Builder {
	return m.builderPool.Get().(*Builder)
}

// ReturnBuilder gives a builder back to the pool.
func (m *Manager) ReturnBuilder(b *Builder) {
	m.builderPool.Put(b)
}

// Len returns the current number of tracked series (approximate under
// concurrent load).
func (m *Manager) Len() int { return int(m.seriesLen.Load()) }

// IngestPoint folds a single Sum data point into state. `identity` is used
// only when a new Series is being created; existing entries reuse their
// stored identity. Returns false if the series was rejected due to MaxSeries.
func (m *Manager) IngestPoint(
	fp Fingerprint,
	dp pmetric.NumberDataPoint,
	identity func() *Series,
) bool {
	sh := m.shards[uint64(fp)&m.shardMask]
	sh.mu.Lock()
	defer sh.mu.Unlock()

	s, ok := sh.data[fp]
	if !ok {
		if m.maxSeries > 0 && m.seriesLen.Load() >= m.maxSeries {
			return false
		}
		s = identity()
		sh.data[fp] = s
		m.seriesLen.Add(1)
	}

	// Merge timestamps: keep the earliest StartTime, latest Time.
	if s.StartTime == 0 || (dp.StartTimestamp() != 0 && dp.StartTimestamp() < s.StartTime) {
		s.StartTime = dp.StartTimestamp()
	}
	if dp.Timestamp() > s.Time {
		s.Time = dp.Timestamp()
	}

	switch dp.ValueType() {
	case pmetric.NumberDataPointValueTypeInt:
		if s.Points == 0 {
			s.IsDouble = false
		}
		if s.IsDouble {
			s.DoubleSum += float64(dp.IntValue())
		} else {
			s.IntSum += dp.IntValue()
		}
	case pmetric.NumberDataPointValueTypeDouble:
		if s.Points == 0 {
			s.IsDouble = true
		}
		if s.IsDouble {
			s.DoubleSum += dp.DoubleValue()
		} else {
			// Upgrade the accumulator to double on first double observation.
			s.DoubleSum = float64(s.IntSum) + dp.DoubleValue()
			s.IntSum = 0
			s.IsDouble = true
		}
	}
	s.Points++
	return true
}

// Flush drains state into a fresh pmetric.Metrics payload. Series identity
// is preserved; each unique (resource, scope, metric) tuple becomes one
// ScopeMetrics + Metric with one data point per fingerprint.
//
// Flush takes every shard lock in order — callers should invoke it from a
// single goroutine (e.g. the periodic flusher), not concurrently.
func (m *Manager) Flush(now time.Time) pmetric.Metrics {
	out := pmetric.NewMetrics()
	// Group series by (resourceKey, scopeName, metricName) as we drain shards.
	type metricKey struct {
		resKey, scope, name string
	}
	groups := make(map[metricKey][]*Series, 1024)

	for _, sh := range m.shards {
		sh.mu.Lock()
		for fp, s := range sh.data {
			k := metricKey{
				resKey: attrsKey(s.ResourceAttrs),
				scope:  s.ScopeName,
				name:   s.MetricName,
			}
			groups[k] = append(groups[k], s)
			delete(sh.data, fp)
			m.seriesLen.Add(-1)
		}
		sh.mu.Unlock()
	}

	// Emit. We rebuild ResourceMetrics per unique resource-attrs key. In a
	// production build you'd want to intern resource maps; this scaffold
	// keeps it simple.
	type resBucket struct {
		rm     pmetric.ResourceMetrics
		scopes map[string]pmetric.ScopeMetrics
	}
	resIdx := make(map[string]*resBucket)

	flushTs := pcommon.NewTimestampFromTime(now)

	for k, series := range groups {
		rb, ok := resIdx[k.resKey]
		if !ok {
			rm := out.ResourceMetrics().AppendEmpty()
			series[0].ResourceAttrs.CopyTo(rm.Resource().Attributes())
			rb = &resBucket{rm: rm, scopes: map[string]pmetric.ScopeMetrics{}}
			resIdx[k.resKey] = rb
		}
		sm, ok := rb.scopes[k.scope]
		if !ok {
			sm = rb.rm.ScopeMetrics().AppendEmpty()
			sm.Scope().SetName(series[0].ScopeName)
			sm.Scope().SetVersion(series[0].ScopeVersion)
			rb.scopes[k.scope] = sm
		}
		mt := sm.Metrics().AppendEmpty()
		mt.SetName(series[0].MetricName)
		mt.SetUnit(series[0].MetricUnit)
		mt.SetDescription(series[0].MetricDesc)
		sum := mt.SetEmptySum()
		sum.SetAggregationTemporality(series[0].Temporality)
		sum.SetIsMonotonic(series[0].IsMonotonic)
		dps := sum.DataPoints()
		dps.EnsureCapacity(len(series))
		for _, s := range series {
			dp := dps.AppendEmpty()
			s.DPAttrs.CopyTo(dp.Attributes())
			if s.StartTime != 0 {
				dp.SetStartTimestamp(s.StartTime)
			}
			if s.Time != 0 {
				dp.SetTimestamp(s.Time)
			} else {
				dp.SetTimestamp(flushTs)
			}
			if s.IsDouble {
				dp.SetDoubleValue(s.DoubleSum)
			} else {
				dp.SetIntValue(s.IntSum)
			}
		}
	}
	return out
}

// attrsKey produces a stable string key for a resource attribute set. Only
// used at flush time (not on the ingest hot path), so allocation cost is
// acceptable.
func attrsKey(m pcommon.Map) string {
	// Fast path: empty.
	if m.Len() == 0 {
		return ""
	}
	b := NewBuilder()
	b.writeMap(m)
	// Reinterpret the internal hasher's sum as a 16-byte string. This is a
	// hash-collision-tolerant identity — production code should intern the
	// actual attribute map instead.
	var buf [8]byte
	sum := b.h.Sum64()
	for i := 0; i < 8; i++ {
		buf[i] = byte(sum >> (i * 8))
	}
	return string(buf[:])
}
