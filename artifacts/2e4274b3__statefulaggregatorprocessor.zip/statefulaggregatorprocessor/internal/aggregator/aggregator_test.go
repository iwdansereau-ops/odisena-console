package aggregator_test

import (
	"testing"
	"time"

	"go.opentelemetry.io/collector/pdata/pmetric"

	"github.com/example/statefulaggregatorprocessor/internal/aggregator"
	"github.com/example/statefulaggregatorprocessor/internal/gentest"
)

func TestIngestFoldsMatchingSeries(t *testing.T) {
	mgr := aggregator.NewManager(8, 0)

	// Two identical batches — every point should fold into the same series.
	md := gentest.Build(gentest.Options{
		Resources: 1, ScopesPerRes: 1, MetricsPerScope: 1, SeriesPerMetric: 10,
		Temporality: pmetric.AggregationTemporalityCumulative, MonotonicSum: true,
		MetricNamePrefix: "m",
	})
	if dropped := aggregator.Ingest(mgr, md, nil); dropped != 0 {
		t.Fatalf("unexpected drops: %d", dropped)
	}
	if dropped := aggregator.Ingest(mgr, md, nil); dropped != 0 {
		t.Fatalf("unexpected drops on second ingest: %d", dropped)
	}

	if got := mgr.Len(); got != 10 {
		t.Fatalf("expected 10 series, got %d", got)
	}
	out := mgr.Flush(time.Now())
	if got := out.MetricCount(); got != 1 {
		t.Fatalf("expected 1 metric emitted, got %d", got)
	}
	dps := out.ResourceMetrics().At(0).ScopeMetrics().At(0).Metrics().At(0).Sum().DataPoints()
	if dps.Len() != 10 {
		t.Fatalf("expected 10 dps, got %d", dps.Len())
	}
	// Each series ingested twice with values 1..10 — sum per series is 2*(i+1).
	seen := map[int64]bool{}
	for i := 0; i < dps.Len(); i++ {
		seen[dps.At(i).IntValue()] = true
	}
	for i := 1; i <= 10; i++ {
		if !seen[int64(2*i)] {
			t.Fatalf("missing folded value %d", 2*i)
		}
	}
}

func TestMaxSeriesCap(t *testing.T) {
	mgr := aggregator.NewManager(8, 5)
	md := gentest.Build(gentest.Options{
		Resources: 1, ScopesPerRes: 1, MetricsPerScope: 1, SeriesPerMetric: 20,
		MonotonicSum: true, Temporality: pmetric.AggregationTemporalityCumulative,
		MetricNamePrefix: "m",
	})
	dropped := aggregator.Ingest(mgr, md, nil)
	if dropped != 15 {
		t.Fatalf("expected 15 drops, got %d", dropped)
	}
	if mgr.Len() != 5 {
		t.Fatalf("expected 5 series retained, got %d", mgr.Len())
	}
}

func TestFilterExcludesMetrics(t *testing.T) {
	mgr := aggregator.NewManager(8, 0)
	md := gentest.Build(gentest.Options{
		Resources: 1, ScopesPerRes: 1, MetricsPerScope: 3, SeriesPerMetric: 2,
		MonotonicSum: true, Temporality: pmetric.AggregationTemporalityCumulative,
		MetricNamePrefix: "m",
	})
	filter := func(name string) bool { return name == "m.1" }
	_ = aggregator.Ingest(mgr, md, filter)
	if mgr.Len() != 2 {
		t.Fatalf("expected only 2 series (one metric x 2 dps), got %d", mgr.Len())
	}
}
