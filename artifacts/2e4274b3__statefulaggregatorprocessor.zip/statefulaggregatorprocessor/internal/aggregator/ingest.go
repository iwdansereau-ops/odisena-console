package aggregator

import (
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/pmetric"
)

// Filter reports whether a metric name should be aggregated. A nil Filter
// accepts every Sum.
type Filter func(name string) bool

// Ingest walks a pmetric.Metrics payload and folds every eligible Sum data
// point into the manager. Non-Sum metrics (Gauge, Histogram, Summary,
// ExponentialHistogram) are ignored — callers that also need to pass those
// through should use the copy-on-write helper alongside this call.
//
// Iteration is deliberately structured to avoid re-fetching parents inside
// inner loops and to keep zero allocations on the hot path aside from the
// pooled builder (borrowed once per call).
//
// Returns the number of points that were rejected because MaxSeries was
// reached — surface this as a processor metric in production.
func Ingest(m *Manager, md pmetric.Metrics, filter Filter) (dropped int) {
	b := m.BorrowBuilder()
	defer m.ReturnBuilder(b)

	rms := md.ResourceMetrics()
	for i := 0; i < rms.Len(); i++ {
		rm := rms.At(i)
		resAttrs := rm.Resource().Attributes()
		sms := rm.ScopeMetrics()
		for j := 0; j < sms.Len(); j++ {
			sm := sms.At(j)
			scope := sm.Scope()
			scopeName := scope.Name()
			scopeVer := scope.Version()
			metrics := sm.Metrics()
			for k := 0; k < metrics.Len(); k++ {
				metric := metrics.At(k)
				if metric.Type() != pmetric.MetricTypeSum {
					continue
				}
				name := metric.Name()
				if filter != nil && !filter(name) {
					continue
				}
				sum := metric.Sum()
				temporality := sum.AggregationTemporality()
				isMonotonic := sum.IsMonotonic()
				unit := metric.Unit()
				desc := metric.Description()
				dps := sum.DataPoints()
				for l := 0; l < dps.Len(); l++ {
					dp := dps.At(l)
					fp := b.Compute(resAttrs, scopeName, name, dp.Attributes())
					ok := m.IngestPoint(fp, dp, func() *Series {
						s := &Series{
							ScopeName:    scopeName,
							ScopeVersion: scopeVer,
							MetricName:   name,
							MetricUnit:   unit,
							MetricDesc:   desc,
							Temporality:  temporality,
							IsMonotonic:  isMonotonic,
						}
						// Clone identity maps — the incoming pdata may be
						// mutated or returned to a pool by an upstream stage.
						s.ResourceAttrs = pcommon.NewMap()
						resAttrs.CopyTo(s.ResourceAttrs)
						s.DPAttrs = pcommon.NewMap()
						dp.Attributes().CopyTo(s.DPAttrs)
						return s
					})
					if !ok {
						dropped++
					}
				}
			}
		}
	}
	return dropped
}

// HasAggregatableSum reports whether md contains at least one Sum metric that
// the filter accepts. Used by the copy-on-write fast path to decide whether
// to bypass state entirely.
func HasAggregatableSum(md pmetric.Metrics, filter Filter) bool {
	rms := md.ResourceMetrics()
	for i := 0; i < rms.Len(); i++ {
		sms := rms.At(i).ScopeMetrics()
		for j := 0; j < sms.Len(); j++ {
			metrics := sms.At(j).Metrics()
			for k := 0; k < metrics.Len(); k++ {
				metric := metrics.At(k)
				if metric.Type() != pmetric.MetricTypeSum {
					continue
				}
				if filter == nil || filter(metric.Name()) {
					return true
				}
			}
		}
	}
	return false
}
