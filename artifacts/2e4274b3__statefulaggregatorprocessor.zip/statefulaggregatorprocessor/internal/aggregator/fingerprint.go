package aggregator

import (
	"encoding/binary"
	"hash/maphash"
	"sort"

	"go.opentelemetry.io/collector/pdata/pcommon"
)

// seed is process-global so fingerprints are stable across goroutines within
// a single process but unpredictable across processes (defeats hash-flood
// attacks against the shard map).
var seed = maphash.MakeSeed()

// Fingerprint is a 64-bit identity for a metric time series.
// It combines resource attributes, scope name, metric name and data point
// attributes into one value using maphash, which is allocation-free after
// the initial hasher setup.
type Fingerprint uint64

// Builder is a reusable fingerprint builder. It amortises the maphash and
// scratch-buffer allocations across many series in the same batch. Not safe
// for concurrent use; construct one per goroutine.
type Builder struct {
	h       maphash.Hash
	keyBuf  []string
	scratch []byte
}

// NewBuilder returns a builder pre-sized for typical attribute counts.
func NewBuilder() *Builder {
	b := &Builder{
		keyBuf:  make([]string, 0, 16),
		scratch: make([]byte, 0, 256),
	}
	b.h.SetSeed(seed)
	return b
}

// Compute returns the fingerprint for the given identity components.
// The attribute maps are hashed in sorted-key order for stability.
func (b *Builder) Compute(
	resAttrs pcommon.Map,
	scopeName string,
	metricName string,
	dpAttrs pcommon.Map,
) Fingerprint {
	b.h.Reset()
	b.writeMap(resAttrs)
	b.writeString(scopeName)
	b.writeString(metricName)
	b.writeMap(dpAttrs)
	return Fingerprint(b.h.Sum64())
}

func (b *Builder) writeString(s string) {
	var lenBuf [4]byte
	binary.LittleEndian.PutUint32(lenBuf[:], uint32(len(s)))
	_, _ = b.h.Write(lenBuf[:])
	_, _ = b.h.WriteString(s)
}

func (b *Builder) writeMap(m pcommon.Map) {
	// Collect keys, sort, then hash in order. Sorting on every point is the
	// hottest path — keyBuf is reused, and Range avoids allocating a map copy.
	b.keyBuf = b.keyBuf[:0]
	m.Range(func(k string, _ pcommon.Value) bool {
		b.keyBuf = append(b.keyBuf, k)
		return true
	})
	sort.Strings(b.keyBuf)

	var countBuf [4]byte
	binary.LittleEndian.PutUint32(countBuf[:], uint32(len(b.keyBuf)))
	_, _ = b.h.Write(countBuf[:])

	for _, k := range b.keyBuf {
		v, _ := m.Get(k)
		b.writeString(k)
		b.writeValue(v)
	}
}

func (b *Builder) writeValue(v pcommon.Value) {
	b.scratch = b.scratch[:0]
	b.scratch = append(b.scratch, byte(v.Type()))
	switch v.Type() {
	case pcommon.ValueTypeStr:
		_, _ = b.h.Write(b.scratch)
		b.writeString(v.Str())
	case pcommon.ValueTypeBool:
		if v.Bool() {
			b.scratch = append(b.scratch, 1)
		} else {
			b.scratch = append(b.scratch, 0)
		}
		_, _ = b.h.Write(b.scratch)
	case pcommon.ValueTypeInt:
		var buf [8]byte
		binary.LittleEndian.PutUint64(buf[:], uint64(v.Int()))
		b.scratch = append(b.scratch, buf[:]...)
		_, _ = b.h.Write(b.scratch)
	case pcommon.ValueTypeDouble:
		var buf [8]byte
		binary.LittleEndian.PutUint64(buf[:], uint64Bits(v.Double()))
		b.scratch = append(b.scratch, buf[:]...)
		_, _ = b.h.Write(b.scratch)
	default:
		// Slices/maps/bytes: fall back to AsString. Rare on data-point attrs.
		_, _ = b.h.Write(b.scratch)
		b.writeString(v.AsString())
	}
}

func uint64Bits(f float64) uint64 {
	// math.Float64bits inlined to avoid an import cycle with math on some
	// toolchains under -gcflags=-l during benchmarking.
	return *(*uint64)(unsafePointer(&f))
}
