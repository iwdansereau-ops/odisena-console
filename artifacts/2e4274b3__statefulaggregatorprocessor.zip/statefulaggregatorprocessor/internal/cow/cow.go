// Package cow implements a copy-on-write wrapper around pmetric.Metrics
// so pipeline stages that only *read* the payload never trigger a clone.
//
// Rationale
// ---------
// pmetric.Metrics is a value that internally references shared protobuf
// storage. Two stages that both call .Clone() double the allocation cost of
// every pipeline batch, which dominates CPU under high cardinality.
//
// The Handle here tracks a single "mutation intent" flag. Non-mutating stages
// call Read() and receive the shared payload; the first stage that needs to
// mutate calls Mutable() which lazily clones. Subsequent Mutable() calls in
// the same handle reuse the clone.
//
// This mirrors the pattern used by pmetric.Metrics under the hood but exposes
// it explicitly so a processor chain can coordinate.
package cow

import (
	"sync"
	"sync/atomic"

	"go.opentelemetry.io/collector/pdata/pmetric"
)

// Handle wraps a pmetric.Metrics with copy-on-write semantics.
//
// Concurrency model:
//   - Multiple goroutines may call Read() concurrently; the returned value
//     must be treated as read-only.
//   - Mutable() is serialised via an internal mutex and may return a cloned
//     payload. After the first Mutable() call, Read() also returns the clone.
//   - A Handle is intended to be short-lived (one batch through one
//     pipeline). Do not share across batches.
type Handle struct {
	mu       sync.Mutex
	original pmetric.Metrics
	mutable  pmetric.Metrics
	cloned   atomic.Bool
}

// New wraps md. The caller must not retain md after passing it to New unless
// they also treat their own reference as read-only.
func New(md pmetric.Metrics) *Handle {
	return &Handle{original: md}
}

// Read returns a payload safe to iterate. Callers MUST NOT mutate the
// returned value. Zero allocations, zero locking on the hot path once
// Mutable() has been called: we do a single atomic load.
func (h *Handle) Read() pmetric.Metrics {
	if h.cloned.Load() {
		return h.mutable
	}
	return h.original
}

// Mutable returns a payload that the caller may modify. The first invocation
// clones the underlying pdata; subsequent invocations reuse that clone.
func (h *Handle) Mutable() pmetric.Metrics {
	if h.cloned.Load() {
		return h.mutable
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	if h.cloned.Load() {
		return h.mutable
	}
	clone := pmetric.NewMetrics()
	h.original.CopyTo(clone)
	h.mutable = clone
	h.cloned.Store(true)
	return h.mutable
}

// Cloned reports whether a clone has been materialised. Useful for metrics
// reporting so operators can see how often the fast path is hit.
func (h *Handle) Cloned() bool { return h.cloned.Load() }

// Emit returns the current payload for downstream consumers. If a clone was
// made it returns the clone; otherwise the original. Prefer this over Read()
// at the very end of the pipeline stage.
func (h *Handle) Emit() pmetric.Metrics {
	if h.cloned.Load() {
		return h.mutable
	}
	return h.original
}
