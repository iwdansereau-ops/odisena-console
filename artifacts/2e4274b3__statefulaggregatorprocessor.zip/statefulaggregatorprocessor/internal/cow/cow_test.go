package cow_test

import (
	"sync"
	"testing"

	"github.com/example/statefulaggregatorprocessor/internal/cow"
	"github.com/example/statefulaggregatorprocessor/internal/gentest"
)

func TestReadDoesNotClone(t *testing.T) {
	md := gentest.Build(gentest.Default())
	h := cow.New(md)
	for i := 0; i < 100; i++ {
		_ = h.Read()
	}
	if h.Cloned() {
		t.Fatal("expected no clone after read-only usage")
	}
}

func TestMutableClonesOnce(t *testing.T) {
	md := gentest.Build(gentest.Default())
	h := cow.New(md)
	first := h.Mutable()
	second := h.Mutable()
	if !h.Cloned() {
		t.Fatal("expected clone flag set")
	}
	// Same underlying pdata handle after the first clone.
	if first.MetricCount() != second.MetricCount() {
		t.Fatal("clones diverged")
	}
}

func TestConcurrentReadersDuringMutable(t *testing.T) {
	md := gentest.Build(gentest.Default())
	h := cow.New(md)

	var wg sync.WaitGroup
	for i := 0; i < 32; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 100; j++ {
				_ = h.Read()
			}
		}()
	}
	// Trigger a single mutation concurrently with readers.
	wg.Add(1)
	go func() {
		defer wg.Done()
		_ = h.Mutable()
	}()
	wg.Wait()
	if !h.Cloned() {
		t.Fatal("expected clone flag set")
	}
}

func BenchmarkReadFastPath(b *testing.B) {
	md := gentest.Build(gentest.Default())
	h := cow.New(md)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = h.Read()
	}
}

func BenchmarkMutableClone(b *testing.B) {
	md := gentest.Build(gentest.Default())
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		h := cow.New(md) // fresh handle each iter so we measure the clone
		_ = h.Mutable()
	}
}
