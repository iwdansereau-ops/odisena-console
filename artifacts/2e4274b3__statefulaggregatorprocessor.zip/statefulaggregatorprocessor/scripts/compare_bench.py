#!/usr/bin/env python3
"""
compare_bench.py — compare `go test -bench` output against a stored baseline.

Reads a raw `go test -bench=. -benchmem -count=N` transcript from stdin (or
--input), computes the median ns/op, B/op, and allocs/op for each benchmark,
compares against .github/benchmarks/baseline.json, and:

  - writes a GitHub-flavoured Markdown report to --output (or stdout),
  - writes machine-readable results JSON to --json-output,
  - exits with code 0 on pass, 1 on regression, 2 on missing/invalid input.

Regression rule:
    metric_pr > metric_baseline * (1 + threshold)  ==> FAIL

Thresholds are pulled from baseline.thresholds.per_benchmark[name] with a
fallback to baseline.thresholds.default. A benchmark that appears in the run
but NOT in the baseline is reported as "NEW" (warn, not fail). A benchmark
that appears in the baseline but is missing from the run is a FAIL — silent
regressions from renamed / disabled benchmarks would otherwise slip through.

No third-party dependencies; only Python 3.9+ stdlib.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import statistics
import sys
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional


# `go test -bench` output lines look like:
#   BenchmarkIngestHighCard-4  	      12	  188_432_101 ns/op	 55_812_400 B/op	   781_234 allocs/op
# The count column, the trailing "-N" GOMAXPROCS suffix, and the underscore
# thousands separators (Go 1.21+) all need to be handled.
BENCH_LINE = re.compile(
    r"^(?P<name>Benchmark[A-Za-z0-9_/]+?)(?:-\d+)?\s+"
    r"(?P<iters>[\d_]+)\s+"
    r"(?P<ns>[\d_.]+)\s+ns/op"
    r"(?:\s+(?P<bytes>[\d_.]+)\s+B/op)?"
    r"(?:\s+(?P<allocs>[\d_.]+)\s+allocs/op)?"
)

# `go test -bench` prints one `pkg: <import path>` header per package before
# the benchmark lines for that package. We track the most recently seen pkg
# so each benchmark result can be attributed back to its Go package — this
# lets the pprof collector target `go test -bench=^Name$ <pkg>` precisely
# instead of re-running the whole suite.
PKG_LINE = re.compile(r"^pkg:\s+(?P<pkg>\S+)\s*$")


def _num(raw: Optional[str]) -> Optional[float]:
    if raw is None:
        return None
    return float(raw.replace("_", ""))


@dataclass
class RunSample:
    ns_op: float
    b_op: float
    allocs_op: float


@dataclass
class BenchResult:
    name: str
    ns_op: float
    b_op: float
    allocs_op: float
    samples: int
    pkg: str = ""


@dataclass
class Comparison:
    name: str
    status: str  # "PASS", "FAIL", "NEW", "MISSING"
    pr: Optional[BenchResult]
    baseline: Optional[Dict[str, float]]
    thresholds: Dict[str, float]
    deltas: Dict[str, float] = field(default_factory=dict)  # fractional deltas
    failed_metrics: List[str] = field(default_factory=list)


class _SamplesDict(dict):
    """A dict subclass that lets us attach the per-benchmark package map
    without a second return value. Behaves identically to a plain dict for
    every existing caller."""
    pass


def parse_bench_output(text: str) -> Dict[str, List[RunSample]]:
    """Group every parsed line by benchmark name; multiple entries per name
    come from `-count=N`."""
    samples: _SamplesDict = _SamplesDict()
    _pkgs_by_bench: Dict[str, str] = {}
    current_pkg = ""
    for line in text.splitlines():
        stripped = line.strip()
        pm = PKG_LINE.match(stripped)
        if pm:
            current_pkg = pm.group("pkg")
            continue
        m = BENCH_LINE.match(stripped)
        if not m:
            continue
        name = m.group("name")
        ns = _num(m.group("ns")) or 0.0
        b = _num(m.group("bytes")) or 0.0
        allocs = _num(m.group("allocs")) or 0.0
        samples.setdefault(name, []).append(RunSample(ns, b, allocs))
        # Stash the package attribution as an attribute on the list — it's
        # not per-sample data so we don't want it in RunSample.
        if current_pkg and name not in _pkgs_by_bench:
            _pkgs_by_bench[name] = current_pkg
    # Attach package map to the returned dict via a well-known key. Callers
    # that need it use bench_packages(); parse_bench_output remains a plain
    # dict for backwards compatibility.
    setattr(samples, "_pkgs", _pkgs_by_bench)
    return samples


def bench_packages(samples: Dict[str, List[RunSample]]) -> Dict[str, str]:
    """Return the {benchmark_name: package_import_path} map derived from the
    `pkg:` headers in the parsed output. Returns {} if none were seen (e.g.
    when the input came from a hand-authored transcript)."""
    return getattr(samples, "_pkgs", {})


def median_of(samples: List[RunSample]) -> BenchResult:
    return BenchResult(
        name="",
        ns_op=statistics.median(s.ns_op for s in samples),
        b_op=statistics.median(s.b_op for s in samples),
        allocs_op=statistics.median(s.allocs_op for s in samples),
        samples=len(samples),
    )


def thresholds_for(baseline: dict, name: str) -> Dict[str, float]:
    per = baseline.get("thresholds", {}).get("per_benchmark", {}).get(name)
    default = baseline.get("thresholds", {}).get("default", {})
    if per is None:
        return dict(default)
    merged = dict(default)
    merged.update(per)
    return merged


def _profiles_for(c: "Comparison") -> List[str]:
    """Decide which pprof profiles to capture for a regressed benchmark.

    Rules:
      - ns_op regression   -> cpu (find where the CPU is going)
      - b_op regression    -> mem (heap allocations)
      - allocs_op regression -> mem (allocation count, same profile)

    We always include `cpu` for any FAIL because a memory regression often
    shows up as a CPU regression once the GC starts working harder — and CPU
    profiles are cheap relative to the whole benchmark rerun cost.
    """
    profs = {"cpu"}
    if "b_op" in c.failed_metrics or "allocs_op" in c.failed_metrics:
        profs.add("mem")
    return sorted(profs)


def compute_delta(pr_val: float, base_val: float) -> float:
    """Fractional delta with a small-baseline guard.

    For counter-style metrics the baseline can legitimately be 0 (e.g. an
    allocation-free hot path). In that case ANY non-zero PR value is treated
    as a regression, expressed as +infinity so it always breaches the
    threshold.
    """
    if base_val == 0:
        return float("inf") if pr_val > 0 else 0.0
    return (pr_val - base_val) / base_val


def compare(pr_medians: Dict[str, BenchResult], baseline: dict) -> List[Comparison]:
    baseline_benches = baseline.get("benchmarks", {})
    seen = set()
    out: List[Comparison] = []

    for name, pr in pr_medians.items():
        seen.add(name)
        pr.name = name
        base = baseline_benches.get(name)
        th = thresholds_for(baseline, name)
        if base is None:
            out.append(Comparison(name=name, status="NEW", pr=pr, baseline=None, thresholds=th))
            continue

        deltas = {
            "ns_op": compute_delta(pr.ns_op, base["ns_op"]),
            "b_op": compute_delta(pr.b_op, base["b_op"]),
            "allocs_op": compute_delta(pr.allocs_op, base["allocs_op"]),
        }
        failed = [m for m, d in deltas.items() if d > th.get(m, 0.0)]
        out.append(
            Comparison(
                name=name,
                status="FAIL" if failed else "PASS",
                pr=pr,
                baseline=base,
                thresholds=th,
                deltas=deltas,
                failed_metrics=failed,
            )
        )

    # Anything in the baseline that we DIDN'T see is a hard fail.
    for name, base in baseline_benches.items():
        if name in seen:
            continue
        out.append(
            Comparison(
                name=name,
                status="MISSING",
                pr=None,
                baseline=base,
                thresholds=thresholds_for(baseline, name),
            )
        )

    out.sort(key=lambda c: (c.status != "FAIL", c.status != "MISSING", c.name))
    return out


# --------------------------------------------------------------------------- #
# Formatting                                                                  #
# --------------------------------------------------------------------------- #

STATUS_EMOJI = {"PASS": "✅", "FAIL": "❌", "NEW": "🆕", "MISSING": "⚠️"}


def _fmt_ns(v: float) -> str:
    if v >= 1_000_000:
        return f"{v / 1_000_000:.2f} ms"
    if v >= 1_000:
        return f"{v / 1_000:.2f} µs"
    return f"{v:.1f} ns"


def _fmt_bytes(v: float) -> str:
    if v >= 1 << 20:
        return f"{v / (1 << 20):.2f} MiB"
    if v >= 1 << 10:
        return f"{v / (1 << 10):.2f} KiB"
    return f"{int(v)} B"


def _fmt_pct(delta: float) -> str:
    if delta == float("inf"):
        return "＋∞%"
    sign = "+" if delta >= 0 else ""
    return f"{sign}{delta * 100:.1f}%"


def render_markdown(
    comparisons: List[Comparison],
    baseline: dict,
    meta: dict,
) -> str:
    total = len(comparisons)
    failing = sum(1 for c in comparisons if c.status in ("FAIL", "MISSING"))
    new_ct = sum(1 for c in comparisons if c.status == "NEW")
    passing = sum(1 for c in comparisons if c.status == "PASS")

    overall = "✅ **PASS**" if failing == 0 else "❌ **FAIL**"

    lines: List[str] = []
    lines.append(f"## Benchmark results — {overall}")
    lines.append("")
    lines.append(
        f"{passing} passing · {failing} regressed · {new_ct} new · "
        f"baseline captured {baseline.get('captured_at', 'unknown')} "
        f"@ `{baseline.get('captured_commit', 'unknown')[:12]}`"
    )
    lines.append("")
    lines.append(
        f"Runner: `{meta.get('runner', '?')}` · Go: `{meta.get('go_version', '?')}` · "
        f"`-benchtime={baseline.get('benchtime', '?')}` · "
        f"`-count={baseline.get('count', '?')}`"
    )
    if meta.get("report_url"):
        lines.append("")
        lines.append(f"📊 [Full benchmark report + raw logs]({meta['report_url']})")
    lines.append("")
    lines.append(
        "| Status | Benchmark | ns/op (Δ) | B/op (Δ) | allocs/op (Δ) |"
    )
    lines.append("| :----: | :-------- | --------: | -------: | -------------: |")

    for c in comparisons:
        emoji = STATUS_EMOJI[c.status]
        if c.status == "MISSING":
            lines.append(
                f"| {emoji} MISSING | `{c.name}` | — | — | benchmark disappeared |"
            )
            continue
        if c.status == "NEW":
            assert c.pr is not None
            lines.append(
                f"| {emoji} NEW | `{c.name}` | "
                f"{_fmt_ns(c.pr.ns_op)} | {_fmt_bytes(c.pr.b_op)} | {int(c.pr.allocs_op)} |"
            )
            continue

        assert c.pr is not None and c.baseline is not None

        def cell(metric: str, pr_val: float, fmt) -> str:
            base_val = c.baseline[metric]
            delta = c.deltas[metric]
            thr = c.thresholds.get(metric, 0.0)
            marker = "❌" if metric in c.failed_metrics else ""
            return (
                f"{fmt(pr_val)} vs {fmt(base_val)} "
                f"({_fmt_pct(delta)} / thr {int(thr * 100)}%) {marker}".strip()
            )

        lines.append(
            f"| {emoji} {c.status} | `{c.name}` | "
            f"{cell('ns_op', c.pr.ns_op, _fmt_ns)} | "
            f"{cell('b_op', c.pr.b_op, _fmt_bytes)} | "
            f"{cell('allocs_op', c.pr.allocs_op, lambda v: str(int(v)))} |"
        )

    lines.append("")
    if failing:
        lines.append("### Regressions")
        for c in comparisons:
            if c.status == "FAIL":
                metrics = ", ".join(c.failed_metrics)
                lines.append(f"- **`{c.name}`** exceeded thresholds on: {metrics}")
            elif c.status == "MISSING":
                lines.append(
                    f"- **`{c.name}`** was in the baseline but not in this run — "
                    "renamed or disabled? Update the baseline if intentional."
                )
        lines.append("")
        lines.append(
            "To accept a new baseline (e.g. after an intentional perf change), "
            "run the `benchmark-baseline` workflow from `main` or open a PR "
            "editing `.github/benchmarks/baseline.json`."
        )
    lines.append("")
    lines.append(
        "<sub>Report generated by "
        "[`scripts/compare_bench.py`](../blob/main/scripts/compare_bench.py).</sub>"
    )
    # Marker is intentionally emitted on its own line at the very end.
    # The workflow may append pprof content *after* the last line of this
    # report; the marker is used by the PR-comment upsert logic via
    # substring match, so its position is not important — keeping it last
    # here just means it lives at the boundary between the bench table
    # and any appended pprof section, which is easy to eyeball in diffs.
    lines.append("<!-- statefulagg-bench-report -->")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# CLI                                                                         #
# --------------------------------------------------------------------------- #


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", help="raw `go test -bench` output; defaults to stdin")
    ap.add_argument("--baseline", required=True, help="path to baseline.json")
    ap.add_argument("--output", required=True, help="path to write Markdown report")
    ap.add_argument("--json-output", required=True, help="path to write results JSON")
    ap.add_argument("--runner", default=os.environ.get("RUNNER_LABEL", "unknown"))
    ap.add_argument("--go-version", default=os.environ.get("GO_VERSION", "unknown"))
    ap.add_argument("--report-url", default=os.environ.get("REPORT_URL", ""))
    ap.add_argument(
        "--soft",
        action="store_true",
        help="Do not exit non-zero on regressions; still writes report.",
    )
    args = ap.parse_args()

    try:
        with open(args.baseline, "r", encoding="utf-8") as fh:
            baseline = json.load(fh)
    except (OSError, json.JSONDecodeError) as e:
        print(f"failed to load baseline: {e}", file=sys.stderr)
        return 2

    if args.input:
        with open(args.input, "r", encoding="utf-8") as fh:
            raw = fh.read()
    else:
        raw = sys.stdin.read()

    if not raw.strip():
        print("no benchmark output on stdin/--input", file=sys.stderr)
        return 2

    grouped = parse_bench_output(raw)
    if not grouped:
        print(
            "parsed 0 benchmarks from input — check `go test -bench` succeeded",
            file=sys.stderr,
        )
        return 2

    pkgs = bench_packages(grouped)
    pr_medians = {name: median_of(samples) for name, samples in grouped.items()}
    for name, res in pr_medians.items():
        res.pkg = pkgs.get(name, "")
    comparisons = compare(pr_medians, baseline)

    meta = {
        "runner": args.runner,
        "go_version": args.go_version,
        "report_url": args.report_url,
    }
    md = render_markdown(comparisons, baseline, meta)

    with open(args.output, "w", encoding="utf-8") as fh:
        fh.write(md)

    # Regressions summary — consumed by collect_pprofs.py to decide which
    # benchmarks to re-run under a profiler. We emit this even on PASS (as
    # an empty list) so downstream tooling can rely on the key existing.
    regressions = [
        {
            "name": c.name,
            "pkg": c.pr.pkg if c.pr else "",
            "failed_metrics": c.failed_metrics,
            # Which profile types to collect. cpu is always useful for a
            # regression; allocation-heavy regressions get -memprofile too.
            "profiles": _profiles_for(c),
        }
        for c in comparisons
        if c.status == "FAIL" and c.pr is not None and c.pr.pkg
    ]

    payload = {
        "overall_status": "fail"
        if any(c.status in ("FAIL", "MISSING") for c in comparisons)
        else "pass",
        "baseline_commit": baseline.get("captured_commit"),
        "runner": args.runner,
        "regressions": regressions,
        "results": [
            {
                "name": c.name,
                "status": c.status,
                "pr": asdict(c.pr) if c.pr else None,
                "baseline": c.baseline,
                "thresholds": c.thresholds,
                "deltas": c.deltas,
                "failed_metrics": c.failed_metrics,
            }
            for c in comparisons
        ],
    }
    with open(args.json_output, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)

    if payload["overall_status"] == "fail" and not args.soft:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
