#!/usr/bin/env python3
"""
weekly_report.py — week-over-week benchmark trend analysis.

Reads a rolling history file of weekly benchmark snapshots and compares the
newest snapshot (the current run) against the immediately preceding one.
Flags any benchmark whose ns/op, B/op, or allocs/op degraded by more than
--threshold (default 5%). Also flags large improvements (>10%) so they show
up on the dashboard, but they don't count as "alerts".

History format: JSONL, one snapshot per line. Each line looks like:

    {
      "captured_at": "2026-07-06T14:00:00Z",
      "commit": "abc123...",
      "runner": "ubuntu-latest",
      "go_version": "1.22.5",
      "benchtime": "3s",
      "count": 5,
      "benchmarks": {
        "BenchmarkIngestHighCard": {"ns_op": 185000000, "b_op": 55000000, "allocs_op": 780000, "pkg": "..."},
        ...
      }
    }

Outputs:
  --report-md    Markdown summary suitable for job summary / Slack
  --report-json  Machine-readable payload for downstream tools
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional

# Reuse the parser from compare_bench.py so history entries are built with
# the same rules as the PR gate.
sys.path.insert(0, str(Path(__file__).parent))
from compare_bench import (  # type: ignore
    parse_bench_output,
    median_of,
    bench_packages,
    compute_delta,
)

METRICS = ("ns_op", "b_op", "allocs_op")


@dataclass
class BenchDelta:
    name: str
    pkg: str
    status: str  # "REGRESSION", "IMPROVEMENT", "STABLE", "NEW", "REMOVED"
    current: Optional[Dict[str, float]]
    previous: Optional[Dict[str, float]]
    deltas: Dict[str, float] = field(default_factory=dict)
    breaches: List[str] = field(default_factory=list)  # metrics over threshold


def load_history(path: Path) -> List[dict]:
    if not path.exists():
        return []
    entries = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        entries.append(json.loads(line))
    # Sort by captured_at so "newest" is always the last element regardless
    # of how the file was written.
    entries.sort(key=lambda e: e.get("captured_at", ""))
    return entries


def build_snapshot(bench_output_path: Path, commit: str, runner: str,
                   go_version: str, benchtime: str, count: int,
                   captured_at: str) -> dict:
    """Parse a `go test -bench -v` transcript into a history snapshot."""
    raw = bench_output_path.read_text()
    grouped = parse_bench_output(raw)
    pkgs = bench_packages(grouped)
    benchmarks = {}
    for name, samples in grouped.items():
        med = median_of(samples)
        benchmarks[name] = {
            "ns_op": round(med.ns_op, 2),
            "b_op": int(med.b_op),
            "allocs_op": int(med.allocs_op),
            "pkg": pkgs.get(name, ""),
        }
    return {
        "captured_at": captured_at,
        "commit": commit,
        "runner": runner,
        "go_version": go_version,
        "benchtime": benchtime,
        "count": count,
        "benchmarks": benchmarks,
    }


def compare_snapshots(current: dict, previous: Optional[dict],
                      regression_threshold: float,
                      improvement_threshold: float) -> List[BenchDelta]:
    cur_benches: Dict[str, dict] = current.get("benchmarks", {})
    prev_benches: Dict[str, dict] = (previous or {}).get("benchmarks", {})

    out: List[BenchDelta] = []
    seen = set()
    for name, cur in cur_benches.items():
        seen.add(name)
        prev = prev_benches.get(name)
        if prev is None:
            out.append(BenchDelta(
                name=name, pkg=cur.get("pkg", ""),
                status="NEW", current=cur, previous=None,
            ))
            continue
        deltas = {m: compute_delta(cur[m], prev[m]) for m in METRICS}
        breaches = [m for m, d in deltas.items() if d > regression_threshold]
        status = "STABLE"
        if breaches:
            status = "REGRESSION"
        else:
            # Only mark as IMPROVEMENT if ALL metrics moved in a good direction
            # and at least one crossed the improvement threshold. This avoids
            # calling a benchmark "improved" when ns/op dropped 12% but allocs
            # doubled.
            improved = all(deltas[m] <= 0 for m in METRICS) and any(
                deltas[m] < -improvement_threshold for m in METRICS
            )
            if improved:
                status = "IMPROVEMENT"
        out.append(BenchDelta(
            name=name, pkg=cur.get("pkg", ""),
            status=status, current=cur, previous=prev,
            deltas=deltas, breaches=breaches,
        ))

    for name, prev in prev_benches.items():
        if name in seen:
            continue
        out.append(BenchDelta(
            name=name, pkg=prev.get("pkg", ""),
            status="REMOVED", current=None, previous=prev,
        ))

    # Regressions first, then removed, then improvements, then stable, then new.
    order = {"REGRESSION": 0, "REMOVED": 1, "IMPROVEMENT": 2, "STABLE": 3, "NEW": 4}
    out.sort(key=lambda d: (order[d.status], d.name))
    return out


# --------------------------------------------------------------------------- #
# Rendering                                                                   #
# --------------------------------------------------------------------------- #

STATUS_EMOJI = {
    "REGRESSION": "🔴",
    "REMOVED": "⚠️",
    "IMPROVEMENT": "🟢",
    "STABLE": "⚪",
    "NEW": "🆕",
}


def _fmt_ns(v: float) -> str:
    if v >= 1_000_000:
        return f"{v / 1_000_000:.2f} ms"
    if v >= 1_000:
        return f"{v / 1_000:.2f} µs"
    return f"{v:.1f} ns"


def _fmt_bytes(v: float) -> str:
    if v >= 1 << 20:
        return f"{v / (1 << 20):.2f} MiB"
    if v >= 1 << 10:
        return f"{v / (1 << 10):.2f} KiB"
    return f"{int(v)} B"


def _fmt_pct(delta: float) -> str:
    if delta == float("inf"):
        return "＋∞%"
    sign = "+" if delta >= 0 else ""
    return f"{sign}{delta * 100:.1f}%"


def render_markdown(deltas: List[BenchDelta], current: dict,
                    previous: Optional[dict], threshold: float,
                    dashboard_url: str = "",
                    slack_alert_url: str = "") -> str:
    regressions = [d for d in deltas if d.status == "REGRESSION"]
    removed = [d for d in deltas if d.status == "REMOVED"]
    improvements = [d for d in deltas if d.status == "IMPROVEMENT"]
    new_ct = sum(1 for d in deltas if d.status == "NEW")

    lines: List[str] = []
    lines.append(f"# Weekly benchmark trend — {current['captured_at'][:10]}")
    lines.append("")
    if previous is None:
        lines.append("_First recorded snapshot — nothing to compare against yet._")
        lines.append("")
    else:
        lines.append(
            f"Comparing **{current['captured_at'][:10]}** "
            f"(`{current['commit'][:12]}`) vs "
            f"**{previous['captured_at'][:10]}** "
            f"(`{previous['commit'][:12]}`) "
            f"— regression threshold **{int(threshold * 100)}%**."
        )
        lines.append("")

    overall = "🔴 **Regressions detected**" if regressions or removed else "🟢 **No regressions**"
    lines.append(f"## Summary — {overall}")
    lines.append("")
    lines.append(
        f"- {len(regressions)} regressed · {len(improvements)} improved · "
        f"{new_ct} new · {len(removed)} removed"
    )
    if dashboard_url:
        lines.append(f"- 📈 [Trend dashboard]({dashboard_url})")
    if slack_alert_url:
        lines.append(f"- 💬 [Slack alert]({slack_alert_url})")
    lines.append("")

    if regressions:
        lines.append("## Regressions (>{}% degradation)".format(int(threshold * 100)))
        lines.append("")
        lines.append("| Benchmark | Metric | Previous | Current | Δ |")
        lines.append("| :-- | :-: | --: | --: | --: |")
        for d in regressions:
            assert d.current is not None and d.previous is not None
            for m in d.breaches:
                fmt = _fmt_ns if m == "ns_op" else (_fmt_bytes if m == "b_op" else lambda v: str(int(v)))
                lines.append(
                    f"| `{d.name}` | {m} | "
                    f"{fmt(d.previous[m])} | {fmt(d.current[m])} | "
                    f"**{_fmt_pct(d.deltas[m])}** |"
                )
        lines.append("")

    if removed:
        lines.append("## Removed benchmarks")
        for d in removed:
            lines.append(f"- `{d.name}` (was in `{d.pkg}`) — renamed or deleted?")
        lines.append("")

    if improvements:
        lines.append("## Improvements")
        lines.append("")
        lines.append("| Benchmark | ns/op | B/op | allocs/op |")
        lines.append("| :-- | --: | --: | --: |")
        for d in improvements:
            lines.append(
                f"| `{d.name}` | {_fmt_pct(d.deltas['ns_op'])} | "
                f"{_fmt_pct(d.deltas['b_op'])} | {_fmt_pct(d.deltas['allocs_op'])} |"
            )
        lines.append("")

    lines.append("<sub>Marker: `<!-- statefulagg-weekly-trend -->`</sub>")
    lines.append("<!-- statefulagg-weekly-trend -->")
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_snap = sub.add_parser("snapshot", help="Append a snapshot to the history file")
    p_snap.add_argument("--bench-output", required=True, help="Raw `go test -bench -v` transcript")
    p_snap.add_argument("--history", required=True, help="Path to history.jsonl")
    p_snap.add_argument("--commit", required=True)
    p_snap.add_argument("--runner", required=True)
    p_snap.add_argument("--go-version", required=True)
    p_snap.add_argument("--benchtime", required=True)
    p_snap.add_argument("--count", type=int, required=True)
    p_snap.add_argument("--captured-at", required=True,
                        help="ISO-8601 UTC timestamp for this snapshot")

    p_cmp = sub.add_parser("compare", help="Compare newest vs previous snapshot")
    p_cmp.add_argument("--history", required=True)
    p_cmp.add_argument("--report-md", required=True)
    p_cmp.add_argument("--report-json", required=True)
    p_cmp.add_argument("--threshold", type=float, default=0.05,
                       help="Regression threshold as a fraction (default 0.05 = 5%%)")
    p_cmp.add_argument("--improvement-threshold", type=float, default=0.10)
    p_cmp.add_argument("--dashboard-url", default="")
    p_cmp.add_argument("--slack-alert-url", default="")

    args = ap.parse_args()

    if args.cmd == "snapshot":
        snap = build_snapshot(
            Path(args.bench_output), args.commit, args.runner,
            args.go_version, args.benchtime, args.count, args.captured_at,
        )
        if not snap["benchmarks"]:
            print("no benchmarks parsed — refusing to write empty snapshot", file=sys.stderr)
            return 2
        hist_path = Path(args.history)
        hist_path.parent.mkdir(parents=True, exist_ok=True)
        with hist_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(snap) + "\n")
        print(f"appended snapshot ({len(snap['benchmarks'])} benchmarks) to {hist_path}")
        return 0

    if args.cmd == "compare":
        entries = load_history(Path(args.history))
        if not entries:
            print("history is empty — nothing to compare", file=sys.stderr)
            return 2
        current = entries[-1]
        previous = entries[-2] if len(entries) >= 2 else None
        deltas = compare_snapshots(current, previous,
                                   args.threshold, args.improvement_threshold)

        md = render_markdown(
            deltas, current, previous, args.threshold,
            dashboard_url=args.dashboard_url,
            slack_alert_url=args.slack_alert_url,
        )
        Path(args.report_md).write_text(md)

        payload = {
            "captured_at": current["captured_at"],
            "current_commit": current["commit"],
            "previous_commit": previous["commit"] if previous else None,
            "threshold": args.threshold,
            "has_regressions": any(d.status == "REGRESSION" for d in deltas),
            "regression_count": sum(1 for d in deltas if d.status == "REGRESSION"),
            "improvement_count": sum(1 for d in deltas if d.status == "IMPROVEMENT"),
            "removed_count": sum(1 for d in deltas if d.status == "REMOVED"),
            "new_count": sum(1 for d in deltas if d.status == "NEW"),
            "deltas": [asdict(d) for d in deltas],
        }
        Path(args.report_json).write_text(json.dumps(payload, indent=2))

        print(f"regressions={payload['regression_count']} "
              f"improvements={payload['improvement_count']} "
              f"removed={payload['removed_count']}")
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
