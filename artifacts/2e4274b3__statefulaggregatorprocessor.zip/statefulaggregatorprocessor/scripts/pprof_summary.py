#!/usr/bin/env python3
"""
pprof_summary.py — turn collected pprof profiles into Markdown snippets
suitable for embedding in a PR comment.

For each profile in the manifest:
  - run `go tool pprof -top -unit=... -nodecount=N <binary> <profile>`
  - parse the `flat  flat%  sum%  cum  cum%  name` table
  - emit a compact Markdown table with the top functions

The summariser is intentionally read-only: it does NOT rerun benchmarks or
mutate any pprof file. Everything it produces is derived from artifacts
already on disk.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

# `go tool pprof -top` output looks like:
#
#   Showing nodes accounting for 3s, 88.24% of 3.40s total
#   Dropped 20 nodes (cum <= 0.02s)
#         flat  flat%   sum%        cum   cum%
#      1200ms 35.29% 35.29%     1400ms 41.18%  runtime.mallocgc
#       500ms 14.71% 50.00%      500ms 14.71%  runtime.memclrNoHeapPointers
#       ...
TOP_ROW = re.compile(
    r"^\s*(?P<flat>[\d.]+\S*)\s+(?P<flat_pct>[\d.]+%)\s+(?P<sum_pct>[\d.]+%)"
    r"\s+(?P<cum>[\d.]+\S*)\s+(?P<cum_pct>[\d.]+%)\s+(?P<name>\S.*)$"
)
HEADER_LINE = re.compile(r"^\s*flat\s+flat%\s+sum%\s+cum\s+cum%")


def run_pprof_top(binary: Path, profile: Path, node_count: int, sample_index: str,
                   go_bin: str = "go") -> str:
    """Invoke `go tool pprof -top` and return raw stdout."""
    cmd = [
        go_bin, "tool", "pprof",
        "-top", "-nodecount", str(node_count),
        "-sample_index", sample_index,
        str(binary), str(profile),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=120)
    if proc.returncode != 0:
        return f"ERROR: pprof returned {proc.returncode}\n{proc.stderr}"
    return proc.stdout


def parse_top(pprof_output: str) -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    in_table = False
    for line in pprof_output.splitlines():
        if HEADER_LINE.match(line):
            in_table = True
            continue
        if not in_table:
            continue
        if not line.strip():
            # Blank line ends the table body.
            if rows:
                break
            continue
        m = TOP_ROW.match(line)
        if m:
            rows.append(m.groupdict())
    return rows


# For each profile type we care about the two sample dimensions that best
# match the metric that regressed. `mem` profiles have two sample indices:
#   alloc_space  \u2014 total bytes allocated (matches B/op)
#   alloc_objects \u2014 total allocations   (matches allocs/op)
MEM_INDICES = ("alloc_space", "alloc_objects")


def _short_name(fn: str) -> str:
    """Trim the noisy runtime prefix so the PR comment stays readable."""
    if len(fn) > 90:
        return fn[:87] + "\u2026"
    return fn


def render_entry(entry: dict, artifacts_root: Path, node_count: int,
                 artifact_base_url: str = "") -> str:
    name = entry["name"]
    pkg = entry.get("pkg", "?")
    md: List[str] = []
    md.append(f"<details><summary><b>\U0001f50e {name}</b>  <sub>({pkg})</sub></summary>")
    md.append("")

    profiles = entry.get("profiles") or {}
    errors = entry.get("errors") or []
    if errors and not profiles:
        md.append("> \u26a0\ufe0f Profile collection failed:")
        for e in errors:
            md.append(f"> - {e}")
        md.append("")
        md.append("</details>")
        return "\n".join(md)

    binary_rel = entry.get("binary")
    if not binary_rel:
        md.append("> No compiled test binary recorded \u2014 cannot symbolise.")
        md.append("</details>")
        return "\n".join(md)
    binary_path = artifacts_root / name / binary_rel

    for prof_type, prof_meta in profiles.items():
        prof_path = artifacts_root / prof_meta["file"]
        md.append(f"#### `{prof_type}` profile")
        if prof_type == "cpu":
            indices = [("samples", "CPU time")]
        elif prof_type == "mem":
            indices = [("alloc_space", "bytes allocated"), ("alloc_objects", "allocation count")]
        else:
            indices = [("samples", prof_type)]

        for sample_index, label in indices:
            raw = run_pprof_top(binary_path, prof_path, node_count, sample_index)
            rows = parse_top(raw)
            if not rows:
                md.append(f"_No `{label}` samples parsed from `{prof_path.name}`._")
                md.append("")
                continue
            md.append(f"**Top {min(node_count, len(rows))} by {label}**")
            md.append("")
            md.append("| flat | flat% | cum | cum% | function |")
            md.append("| ---: | ---: | ---: | ---: | :--- |")
            for row in rows[:node_count]:
                md.append(
                    f"| {row['flat']} | {row['flat_pct']} | {row['cum']} | "
                    f"{row['cum_pct']} | `{_short_name(row['name'])}` |"
                )
            md.append("")

        # Direct download link if we know the artifact base URL. GitHub
        # doesn't expose per-file URLs for artifact zips, so we point at
        # the artifact bundle and describe the internal path.
        if artifact_base_url:
            md.append(
                f"\u2192 Raw profile in the `pprof-profiles` artifact at "
                f"`{prof_meta['file']}` \u2014 download with "
                f"`gh run download {os.environ.get('GITHUB_RUN_ID', '<run-id>')} "
                f"-n pprof-profiles`, then explore with:"
            )
        else:
            md.append(
                f"\u2192 Raw profile: `{prof_meta['file']}`. Explore with:"
            )
        md.append("")
        md.append("```bash")
        md.append(
            f"go tool pprof -http=: {name}/{binary_rel} {prof_meta['file']}"
        )
        md.append("```")
        md.append("")

    md.append("</details>")
    return "\n".join(md)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--artifacts-dir", required=True)
    ap.add_argument("--output", required=True,
                    help="Markdown fragment to append to the PR comment")
    ap.add_argument("--nodecount", type=int, default=10)
    ap.add_argument("--artifact-base-url", default=os.environ.get("ARTIFACT_URL", ""))
    args = ap.parse_args()

    with open(args.manifest, "r", encoding="utf-8") as fh:
        manifest = json.load(fh)

    entries = manifest.get("entries", [])
    skipped = manifest.get("skipped", [])
    artifacts_root = Path(args.artifacts_dir).resolve()

    if not entries and not skipped:
        Path(args.output).write_text("")
        print("no pprof entries \u2014 nothing to summarise")
        return 0

    md: List[str] = []
    md.append("### \U0001f50d pprof profiles for regressed benchmarks")
    md.append("")
    md.append(
        f"Collected {manifest.get('captured_count', 0)} profile(s) with "
        f"`-benchtime={manifest.get('benchtime', '?')}`."
    )
    if args.artifact_base_url:
        md.append("")
        md.append(
            f"\U0001f4e6 Download the full profile set from "
            f"[the `pprof-profiles` workflow artifact]({args.artifact_base_url})."
        )
    md.append("")

    for entry in entries:
        md.append(render_entry(entry, artifacts_root, args.nodecount, args.artifact_base_url))
        md.append("")

    if skipped:
        md.append(
            f"<sub>\u23ed\ufe0f {len(skipped)} additional regressed benchmark(s) "
            f"skipped to keep profiling runtime bounded: "
            f"{', '.join(f'`{n}`' for n in skipped)}.</sub>"
        )
        md.append("")

    Path(args.output).write_text("\n".join(md))
    print(f"wrote pprof summary ({len(entries)} entries) to {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
