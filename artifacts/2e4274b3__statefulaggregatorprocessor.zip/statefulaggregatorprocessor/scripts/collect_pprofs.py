#!/usr/bin/env python3
"""
collect_pprofs.py — capture pprof profiles for benchmarks that regressed.

Reads the `regressions` array produced by compare_bench.py, invokes
`go test -bench=^<name>$ -run=^$ -benchtime=... -count=1 -cpuprofile=... [-memprofile=...] <pkg>`
for each entry, and writes the resulting `.pprof` files (plus the compiled
test binary that pprof needs for symbolisation) into an output directory
laid out as:

    <output_dir>/
      manifest.json                   # index consumed by pprof_summary.py
      <BenchmarkName>/
        cpu.pprof
        mem.pprof                     # only when allocations regressed
        <BenchmarkName>.test          # compiled binary (needed for symbols)
        run.log                       # captured stdout/stderr

The compiled test binary is preserved because `go tool pprof` needs both the
binary and the profile to resolve function names. `go test -c` builds the
binary; we then invoke it directly with `-test.bench=...` so we know exactly
which binary matches which profile.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional


def _run(cmd: List[str], cwd: Optional[Path] = None, log_to: Optional[Path] = None,
         timeout: int = 900) -> int:
    """Run a subprocess, tee its output to log_to if provided, and return
    the exit code. Never raises \u2014 caller decides how to handle failure."""
    print(f"$ {' '.join(cmd)}", flush=True)
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as e:
        if log_to:
            log_to.write_text(f"TIMEOUT after {timeout}s\n{e.stdout or ''}\n{e.stderr or ''}\n")
        print(f"TIMEOUT after {timeout}s", file=sys.stderr)
        return 124
    combined = (proc.stdout or "") + (proc.stderr or "")
    if log_to:
        log_to.write_text(combined)
    if proc.returncode != 0:
        print(combined, file=sys.stderr)
    return proc.returncode


def collect_one(
    bench: dict,
    profile_benchtime: str,
    output_dir: Path,
    repo_root: Path,
) -> dict:
    """Rebuild the test binary for the benchmark's package, then invoke it
    with the requested profilers. Returns a manifest entry describing what
    was produced."""
    name = bench["name"]
    pkg = bench["pkg"]
    profiles: List[str] = bench.get("profiles") or ["cpu"]

    workdir = output_dir / name
    workdir.mkdir(parents=True, exist_ok=True)

    entry: Dict[str, object] = {
        "name": name,
        "pkg": pkg,
        "failed_metrics": bench.get("failed_metrics", []),
        "profiles": {},
        "errors": [],
    }

    # 1. Compile the test binary. Doing this separately from the profiling
    #    run means the compilation cost isn't counted against the profile,
    #    and it gives us a symbolisable binary to archive alongside the
    #    .pprof files.
    binary_name = f"{name}.test"
    binary_path = workdir / binary_name
    compile_log = workdir / "compile.log"
    rc = _run(
        ["go", "test", "-c", "-o", str(binary_path), pkg],
        cwd=repo_root,
        log_to=compile_log,
    )
    if rc != 0:
        entry["errors"].append(f"go test -c failed (rc={rc}); see compile.log")
        return entry
    entry["binary"] = binary_name

    # 2. Invoke the compiled binary with each requested profiler. We use one
    #    invocation per profile type rather than combining flags \u2014 the CPU
    #    profile sampler and the memory profile behave differently under
    #    -benchtime, and mixing them muddies the results.
    for prof in profiles:
        prof_file = workdir / f"{prof}.pprof"
        run_log = workdir / f"{prof}.run.log"
        flag = {
            "cpu": "-test.cpuprofile",
            "mem": "-test.memprofile",
            "block": "-test.blockprofile",
            "mutex": "-test.mutexprofile",
        }.get(prof)
        if flag is None:
            entry["errors"].append(f"unknown profile type: {prof}")
            continue

        cmd = [
            str(binary_path),
            f"-test.bench=^{name}$",
            "-test.run=^$",
            f"-test.benchtime={profile_benchtime}",
            "-test.count=1",
            "-test.benchmem",
            f"{flag}={prof_file}",
        ]
        # For mem profiles, ask the runtime for a comprehensive sample rate.
        # The default `MemProfileRate` (512 KiB) can miss small hot allocs
        # in short-running benchmarks; 1 = record every alloc, at the cost
        # of some overhead.  Only applied to mem to avoid perturbing CPU.
        env = os.environ.copy()
        if prof == "mem":
            env["GODEBUG"] = env.get("GODEBUG", "") + ",memprofilerate=4096"

        t0 = time.time()
        proc = subprocess.run(
            cmd, cwd=str(repo_root), capture_output=True, text=True,
            env=env, timeout=900, check=False,
        )
        elapsed = time.time() - t0
        run_log.write_text((proc.stdout or "") + (proc.stderr or ""))

        if proc.returncode != 0 or not prof_file.exists() or prof_file.stat().st_size == 0:
            entry["errors"].append(
                f"{prof} profile collection failed (rc={proc.returncode}); see {prof}.run.log"
            )
            continue

        entry["profiles"][prof] = {
            "file": f"{name}/{prof}.pprof",
            "size_bytes": prof_file.stat().st_size,
            "elapsed_sec": round(elapsed, 2),
        }

    return entry


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--regressions-json", required=True,
                    help="Path to compare_bench.py's --json-output file")
    ap.add_argument("--output-dir", required=True,
                    help="Directory to write pprof artifacts into")
    ap.add_argument("--repo-root", default=".",
                    help="Path passed as `go test` working directory")
    ap.add_argument("--benchtime", default="2s",
                    help="`-benchtime` for profile runs. Shorter than the "
                         "main benchmark run \u2014 we only need enough samples "
                         "to identify hot functions.")
    ap.add_argument("--max-benches", type=int, default=6,
                    help="Cap the number of benchmarks profiled to keep "
                         "runtime bounded. If more regressed, only the "
                         "first N (as ordered by compare_bench.py) are "
                         "profiled; the rest are recorded as skipped.")
    args = ap.parse_args()

    with open(args.regressions_json, "r", encoding="utf-8") as fh:
        report = json.load(fh)

    regressions: List[dict] = report.get("regressions", [])
    if not regressions:
        print("no regressions to profile; exiting cleanly")
        # Still emit an empty manifest so downstream steps can be
        # unconditional about reading it.
        out = Path(args.output_dir)
        out.mkdir(parents=True, exist_ok=True)
        (out / "manifest.json").write_text(json.dumps({"entries": [], "skipped": []}))
        return 0

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    repo_root = Path(args.repo_root).resolve()

    to_profile = regressions[: args.max_benches]
    skipped = [r["name"] for r in regressions[args.max_benches:]]

    entries = []
    for bench in to_profile:
        if not bench.get("pkg"):
            entries.append({
                "name": bench["name"],
                "pkg": "",
                "errors": ["no package attribution \u2014 rerun benchmarks with -v to capture `pkg:` headers"],
                "profiles": {},
            })
            continue
        entries.append(collect_one(bench, args.benchtime, output_dir, repo_root))

    manifest = {
        "benchtime": args.benchtime,
        "captured_count": sum(1 for e in entries if e.get("profiles")),
        "entries": entries,
        "skipped": skipped,
    }
    (output_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))
    print(f"wrote manifest with {len(entries)} entries to {output_dir}/manifest.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
