#!/usr/bin/env python3
"""
build_baseline.py — write a new baseline.json from a fresh benchmark run.

Reuses the parser in compare_bench.py so the exact same rules apply for
parsing `go test -bench` output. Preserves the `thresholds` and `$comment`
blocks from any existing baseline file so operator-tuned tolerances survive
automated refreshes.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
from pathlib import Path

# Reuse the parser from the sibling script.
sys.path.insert(0, str(Path(__file__).parent))
from compare_bench import parse_bench_output, median_of  # type: ignore


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--existing", required=True, help="current baseline path (for thresholds carry-over)")
    ap.add_argument("--output", required=True)
    ap.add_argument("--runner", required=True)
    ap.add_argument("--go-version", required=True)
    ap.add_argument("--benchtime", required=True)
    ap.add_argument("--count", required=True, type=int)
    ap.add_argument("--commit", required=True)
    args = ap.parse_args()

    with open(args.input, "r", encoding="utf-8") as fh:
        raw = fh.read()
    grouped = parse_bench_output(raw)
    if not grouped:
        print("no benchmarks parsed — refusing to overwrite baseline", file=sys.stderr)
        return 2

    # Carry over thresholds + comment block if the file already exists.
    existing = {}
    if os.path.exists(args.existing):
        try:
            with open(args.existing, "r", encoding="utf-8") as fh:
                existing = json.load(fh)
        except json.JSONDecodeError:
            print("existing baseline is not valid JSON — starting fresh", file=sys.stderr)

    benchmarks = {}
    for name, samples in sorted(grouped.items()):
        med = median_of(samples)
        benchmarks[name] = {
            "ns_op": round(med.ns_op, 2),
            # B/op and allocs/op are reported as integers by `go test` even
            # though the parser holds them as floats.
            "b_op": int(med.b_op),
            "allocs_op": int(med.allocs_op),
        }

    out = {
        "$comment": existing.get("$comment", [
            "Performance baseline. Refresh via the benchmark-baseline workflow.",
        ]),
        "runner": args.runner,
        "go_version": args.go_version,
        "captured_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "captured_commit": args.commit,
        "benchtime": args.benchtime,
        "count": args.count,
        "thresholds": existing.get("thresholds", {
            "default": {"ns_op": 0.10, "b_op": 0.10, "allocs_op": 0.05},
            "per_benchmark": {},
        }),
        "benchmarks": benchmarks,
    }

    with open(args.output, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=2)
        fh.write("\n")
    print(f"wrote {len(benchmarks)} benchmarks to {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
