module github.com/example/statefulaggregatorprocessor

go 1.22

require (
	go.opentelemetry.io/collector/component v0.106.1
	go.opentelemetry.io/collector/consumer v0.106.1
	go.opentelemetry.io/collector/pdata v1.12.0
	go.opentelemetry.io/collector/processor v0.106.1
	go.uber.org/zap v1.27.0
)
