package statefulaggregatorprocessor

import (
	"errors"
	"time"
)

// Config drives the stateful aggregation processor.
//
// The processor buckets pmetric.Sum data points by a stable fingerprint of
// (resource attributes, scope, metric name, data point attributes) and folds
// incoming points into a running aggregate that is flushed on FlushInterval.
type Config struct {
	// FlushInterval controls how often aggregated state is emitted downstream.
	// A zero or negative value disables periodic flushes; state is emitted
	// synchronously with each incoming batch instead.
	FlushInterval time.Duration `mapstructure:"flush_interval"`

	// MaxSeries caps the number of distinct series held in state to protect
	// against runaway cardinality. Zero means unbounded (not recommended).
	MaxSeries int `mapstructure:"max_series"`

	// ShardCount controls the number of state shards used to reduce lock
	// contention. Must be a power of two; defaults to 64.
	ShardCount int `mapstructure:"shard_count"`

	// CopyOnWrite enables the COW wrapper for the non-mutating fast path.
	// When true and the incoming pmetric.Metrics contains no Sum points that
	// require aggregation, the processor forwards the original payload without
	// cloning.
	CopyOnWrite bool `mapstructure:"copy_on_write"`

	// IncludeMetricNames optionally restricts aggregation to specific metric
	// names. An empty list means "aggregate every cumulative or delta Sum".
	IncludeMetricNames []string `mapstructure:"include_metric_names"`
}

// Validate implements component.Config.
func (c *Config) Validate() error {
	if c.ShardCount != 0 && (c.ShardCount&(c.ShardCount-1)) != 0 {
		return errors.New("shard_count must be a power of two")
	}
	if c.MaxSeries < 0 {
		return errors.New("max_series must be >= 0")
	}
	return nil
}

func createDefaultConfig() *Config {
	return &Config{
		FlushInterval: 15 * time.Second,
		MaxSeries:     1_000_000,
		ShardCount:    64,
		CopyOnWrite:   true,
	}
}
