package statefulaggregatorprocessor

import (
	"context"
	"sync"
	"testing"

	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.uber.org/zap"

	"github.com/example/statefulaggregatorprocessor/internal/gentest"
)

// sinkConsumer discards downstream traffic without allocating; the goal is
// to isolate the processor's own cost from any receiver overhead.
type sinkConsumer struct {
	mu    sync.Mutex
	calls int
	dps   int
}

func (s *sinkConsumer) Capabilities() consumer.Capabilities {
	return consumer.Capabilities{MutatesData: false}
}

func (s *sinkConsumer) ConsumeMetrics(_ context.Context, md pmetric.Metrics) error {
	s.mu.Lock()
	s.calls++
	s.dps += md.DataPointCount()
	s.mu.Unlock()
	return nil
}

// BenchmarkConsumePassthrough measures the COW fast path — the input has no
// Sum metrics the processor cares about, so it should forward without any
// clone. Watch B/op: it should be near-zero.
func BenchmarkConsumePassthrough(b *testing.B) {
	cfg := createDefaultConfig()
	cfg.IncludeMetricNames = []string{"nothing.matches"}
	cfg.FlushInterval = 0
	p := newProcessor(cfg, zap.NewNop(), &sinkConsumer{})
	md := gentest.Build(gentest.Default())

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if err := p.ConsumeMetrics(context.Background(), md); err != nil {
			b.Fatal(err)
		}
	}
}

// BenchmarkConsumeAggregate measures the mutating path — every batch folds
// into state and inline-flushes (FlushInterval=0). Compare B/op and ns/op
// against BenchmarkConsumePassthrough to see the aggregation overhead.
func BenchmarkConsumeAggregate(b *testing.B) {
	cfg := createDefaultConfig()
	cfg.FlushInterval = 0
	p := newProcessor(cfg, zap.NewNop(), &sinkConsumer{})
	md := gentest.Build(gentest.Options{
		Resources: 4, ScopesPerRes: 2, MetricsPerScope: 4, SeriesPerMetric: 2_000,
		MonotonicSum:     true,
		Temporality:      pmetric.AggregationTemporalityCumulative,
		MetricNamePrefix: "svc.req",
	})

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if err := p.ConsumeMetrics(context.Background(), md); err != nil {
			b.Fatal(err)
		}
	}
}
