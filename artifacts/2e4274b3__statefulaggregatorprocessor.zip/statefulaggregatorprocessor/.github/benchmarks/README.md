# Benchmark CI

Three workflows keep the processor's performance from drifting:

| Workflow | Trigger | Purpose |
| --- | --- | --- |
| `benchmark-pr.yml` | Every PR against `main` (paths filter on `**.go`, `go.mod`, workflow itself) | Run full bench suite, compare to baseline, comment on PR, gate merge |
| `benchmark-baseline.yml` | Manual (`workflow_dispatch`) | Rebuild `baseline.json` from `main` and open a PR |
| `benchmark-weekly.yml` | Cron (Mondays 13:00 UTC) + manual | Run full bench suite on `main`, record week-over-week snapshot, flag regressions >5%, post Slack alert, feed the trend dashboard |

## How the gate works

1. `go test -bench=. -benchmem -v -benchtime=3s -count=5 -run='^$' ./...` runs on `ubuntu-latest`. `-v` is required so `pkg:` headers are emitted for every package — the compare script uses them to attribute each benchmark to its Go import path.
2. `scripts/compare_bench.py` parses the transcript, takes the median across the `-count` samples, and compares each benchmark's `ns/op`, `B/op`, and `allocs/op` against `baseline.json`.
3. A benchmark fails when `metric_pr > metric_baseline × (1 + threshold)`.
4. **On regression only:** `scripts/collect_pprofs.py` reruns each failing benchmark under `-cpuprofile` (always) and `-memprofile` (when `B/op` or `allocs/op` regressed) with `-benchtime=2s`, using the compiled test binary so pprof can symbolise the results. Profiles are uploaded as a `pprof-profiles-<pr>-<run>` artifact.
5. `scripts/pprof_summary.py` runs `go tool pprof -top` against each captured profile and appends a top-10 function table (plus a `go tool pprof -http=:` invocation and an artifact-download link) to the PR comment.
6. The Markdown report is:
   - posted (or updated in place) as a PR comment,
   - written to the job summary,
   - uploaded as an artifact with a link back in the comment.
7. If any benchmark fails or is missing, the final workflow step exits non-zero — the check turns red and blocks merge if branch protection requires it.

## Investigating a failed PR

When the gate turns red, the PR comment includes a `🔍 pprof profiles for regressed benchmarks` section with a top-N table per profile. If that's enough to spot the culprit, great. Otherwise, download the full profile bundle:

```bash
gh run download <RUN_ID> -n pprof-profiles-<PR>-<RUN_ID>
cd pprof-profiles-<PR>-<RUN_ID>/BenchmarkIngestHighCard
go tool pprof -http=: BenchmarkIngestHighCard.test cpu.pprof
```

Each benchmark's directory contains its `.test` binary alongside the `.pprof` files so pprof can symbolise the profile without needing your local checkout to compile.

**What each profile type answers:**

| Profile | Sample dimensions | Best for |
| --- | --- | --- |
| `cpu.pprof` | `samples` (CPU time) | `ns/op` regressions — shows where the CPU is going. Always captured for any FAIL. |
| `mem.pprof` | `alloc_space` (bytes) / `alloc_objects` (count) | `B/op` and `allocs/op` regressions. Captured with `GODEBUG=memprofilerate=4096` for finer resolution on short runs. |

**Caps and skips:** at most 6 benchmarks are profiled per run to keep CI time bounded. If more regressed, only the first 6 (ordered by the compare script) are profiled and the rest are listed as skipped in the comment.

## Thresholds

`baseline.json.thresholds` has two layers:

```jsonc
"thresholds": {
  "default": { "ns_op": 0.10, "b_op": 0.10, "allocs_op": 0.05 },
  "per_benchmark": {
    "BenchmarkConsumePassthrough": { "ns_op": 0.15, "b_op": 0.00, "allocs_op": 0.00 }
  }
}
```

- Values are **fractions** (`0.10 == 10%`).
- `per_benchmark` overrides `default` metric-by-metric.
- A `0.00` threshold means "any regression fails" — appropriate for allocation-free hot paths where any allocation is a real regression.
- Tightening `allocs_op` first tends to catch regressions earliest; `ns/op` is inherently noisier on shared runners.

## Refreshing the baseline

**After an intentional performance change:**

1. Merge the change to `main`.
2. Actions tab → `benchmark-baseline` → **Run workflow** → provide a reason.
3. The workflow opens a PR editing `baseline.json`. Review the diff (especially any `ns_op` numbers that moved by >20% — occasional runner noise can slip through even at `-count=5`) and merge.

**Locally (for debugging):**

```bash
go test -bench=. -benchmem -benchtime=3s -count=5 -run='^$' ./... > /tmp/bench.txt
python3 scripts/build_baseline.py \
  --input /tmp/bench.txt \
  --existing .github/benchmarks/baseline.json \
  --output .github/benchmarks/baseline.json \
  --runner ubuntu-latest \
  --go-version 1.22.x \
  --benchtime 3s --count 5 \
  --commit "$(git rev-parse HEAD)"
```

## Runner discipline

Baseline comparisons only make sense when the PR and baseline ran on the **same runner label**. The PR workflow refuses to run if `baseline.json.runner` doesn't match `ubuntu-latest`. If you migrate to a self-hosted runner (recommended for stable numbers) update both the workflow `runs-on:` and `baseline.json.runner`, and rerun the baseline workflow.

## Skipping benchmarks

Add `[skip bench]` to the PR title. Note: this only prevents the workflow from running; if the check is a required status check in branch protection, the PR will still be blocked from merging.

## Weekly trend monitoring

`benchmark-weekly.yml` runs the same suite as the PR gate against `main` every Monday at 13:00 UTC (09:00 America/New_York in EDT, 08:00 in EST). Each run:

1. Executes `go test -bench=. -benchmem -v -benchtime=3s -count=5 -run='^$' ./...` on `ubuntu-latest`.
2. Appends a snapshot to `.github/benchmarks/history.jsonl` via `scripts/weekly_report.py snapshot` — one JSON object per line with `captured_at`, `commit`, `benchmarks{name: {ns_op, b_op, allocs_op, pkg}}`.
3. Runs `scripts/weekly_report.py compare` against the previous snapshot. Any benchmark whose `ns/op`, `B/op`, or `allocs/op` degraded by more than **5%** is flagged as a regression; movements better than 10% show up as improvements.
4. Commits the updated `history.jsonl` back to `main` (`[skip ci]`) so the trend dashboard picks it up.
5. If regressions were found, posts a Block Kit alert to Slack via the `PERF_ALERTS_SLACK_WEBHOOK` secret (channel taken from the `PERF_ALERTS_SLACK_CHANNEL` repo variable, or the webhook default). The Slack message links back to the workflow run and the dashboard.
6. Uploads `weekly-report.md` + `weekly-report.json` + the raw bench transcript as a `weekly-benchmark-<timestamp>` artifact (90-day retention). The Perplexity Monday-morning email digest reads the latest JSON payload from this artifact.

The weekly job does **not** fail on regression — the point is to keep capturing points even when things get worse. Slack + email are the human-facing signals.

### Trend dashboard

A static dashboard lives at `docs/dashboard/index.html` and is published to GitHub Pages by `.github/workflows/pages.yml` on every push that touches the dashboard files or `history.jsonl`. Enable it under **Settings → Pages → Source: GitHub Actions**. The published URL is `https://<owner>.github.io/<repo>/dashboard/`.

The dashboard fetches `history.jsonl` at page-load time and renders per-benchmark `ns/op`, `B/op`, and `allocs/op` time series using Chart.js. Deep links preserve the selected benchmark, range, and Y-scale via the URL hash — e.g. `#bench=BenchmarkIngestHighCard&range=13&scale=logarithmic`.

### Repository configuration

| Setting | Where | Purpose |
| --- | --- | --- |
| `PERF_ALERTS_SLACK_WEBHOOK` | Actions secret | Incoming webhook URL for the perf alerts channel. Without this, the Slack step is skipped (the weekly run still succeeds). |
| `PERF_ALERTS_SLACK_CHANNEL` | Actions variable (optional) | Overrides the webhook's default channel — useful when the webhook is app-scoped. |
| GitHub Pages | Settings → Pages → Source: GitHub Actions | Serves the trend dashboard. |
| Branch protection: allow bot pushes | Settings → Branches → Protection rules for `main` | The weekly workflow uses `GITHUB_TOKEN` to push `history.jsonl` back to `main`. If `main` requires PRs for all changes, either exempt `github-actions[bot]` or switch the workflow to open a PR instead of pushing. |

### Investigating a weekly regression

1. Open the workflow run linked from the Slack alert; the job summary contains the same table as the email.
2. Download the `weekly-benchmark-<timestamp>` artifact for the raw bench transcript.
3. Open the trend dashboard and filter to the regressed benchmark to see whether this is a one-week jump or a slow drift.
4. If the change is intentional and expected to stick, rerun `benchmark-baseline` after the underlying commit landed so the PR gate stops complaining about it.

## Seed values disclaimer

The values initially checked into `baseline.json` are **estimates**. The first real baseline should be captured by running `benchmark-baseline` after the first green build on `main`. Until then, expect the PR gate to produce noisy pass/fail results.
