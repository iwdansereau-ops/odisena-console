# statefulaggregatorprocessor

A scaffold for a custom OpenTelemetry Collector processor that performs
stateful aggregation of `pmetric.Sum` data points, keyed by a stable
fingerprint of `(resource attributes, scope, metric name, data point
attributes)`.

The scaffold is deliberately self-contained: it does not depend on the
contrib repo's factory helpers so you can drop it into any Collector
distribution.

## Layout

```
statefulaggregatorprocessor/
├── config.go                     # Config + defaults + Validate
├── factory.go                    # processor.Factory wiring
├── processor.go                  # ConsumeMetrics hot path + flusher
├── processor_test.go             # Passthrough + inline-flush tests
├── processor_bench_test.go       # End-to-end benchmarks
├── internal/
│   ├── aggregator/
│   │   ├── fingerprint.go        # maphash-based series identity
│   │   ├── state.go              # Sharded, thread-safe state manager
│   │   ├── ingest.go             # pdata iteration + Sum merging
│   │   ├── aggregator_test.go
│   │   └── bench_test.go         # High-cardinality micro-benchmarks
│   ├── cow/
│   │   ├── cow.go                # Copy-on-write handle
│   │   └── cow_test.go
│   └── metadata/metadata.go
└── internal/gentest/generator.go # Synthetic pmetric.Metrics builder
                                  # (named gentest — Go skips `testdata/`)
```

## Design highlights

### Thread-safe aggregation state manager
`internal/aggregator.Manager` shards state across `ShardCount` maps
(power-of-two) chosen by the low bits of the fingerprint. Each shard has its
own `sync.Mutex`, so ingest scales roughly linearly with core count on
high-cardinality workloads. `MaxSeries` is enforced with a single
`atomic.Int64` to avoid taking every shard lock on every insert.

### Efficient pdata iteration
`aggregator.Ingest` uses classic index-based `for i := 0; i < X.Len(); i++`
loops over `pmetric.ResourceMetrics`, `ScopeMetrics`, `MetricSlice`, and
`NumberDataPointSlice`. Parents are hoisted out of inner loops, the
fingerprint builder is pooled per manager, and identity `pcommon.Map`s are
only cloned the first time a fingerprint is seen (not on every merge).

### Sum merging
`Manager.IngestPoint` folds int and double Sums independently and upgrades
the accumulator to double the first time a double point is observed for a
series. Timestamps merge as `min(StartTime), max(Time)` so cumulative and
delta temporalities both round-trip cleanly.

### Copy-on-write for non-mutating stages
`internal/cow.Handle` wraps a `pmetric.Metrics` and exposes:

- `Read()` — atomic-load fast path, no clone, safe for concurrent readers.
- `Mutable()` — clones lazily under a mutex; every subsequent `Read()` and
  `Mutable()` reuses the clone.
- `Emit()` — returns the clone if one exists, otherwise the original.

`processor.ConsumeMetrics` checks `HasAggregatableSum` before touching state.
When no Sum matches the filter, the payload is forwarded via `Emit()` with
zero allocations.

## Configuration

```yaml
processors:
  statefulaggregator:
    flush_interval: 15s        # 0 disables the background flusher (inline emit)
    max_series: 1000000        # 0 = unbounded
    shard_count: 64            # power of two
    copy_on_write: true
    include_metric_names:      # empty = every Sum
      - http.server.request.count
      - db.client.operation.count
```

## Running tests + benchmarks

```bash
go test ./...
go test -bench=. -benchmem -benchtime=3s ./...
```

Suggested comparisons:

| Benchmark | What it measures |
|---|---|
| `BenchmarkFingerprint` | Hash cost per point (should be ~150–300 ns, 0 allocs/op) |
| `BenchmarkIngestHighCard` | Cold ingest of ~256k series (dominated by map growth + identity clones) |
| `BenchmarkIngestHighCardReuseState` | Steady-state fold cost (should be ~2× fingerprint cost) |
| `BenchmarkFlushHighCard` | Drain cost per series |
| `BenchmarkConsumePassthrough` | COW fast path — expect near-zero B/op |
| `BenchmarkConsumeAggregate` | End-to-end aggregate + inline flush |

Capture profiles for tuning:

```bash
go test -bench=BenchmarkIngestHighCard -benchmem \
    -cpuprofile cpu.out -memprofile mem.out \
    ./internal/aggregator/...
go tool pprof -http=: cpu.out
```

## Next steps to production-harden

- Intern resource attribute maps at ingest so identical resources across
  shards share storage.
- Replace `attrsKey`'s hash-only identity with a real intern table to
  eliminate the residual collision risk during `Flush`.
- Add histogram + exponential histogram aggregation paths mirroring the Sum
  implementation.
- Emit internal telemetry (`otelcol_processor_statefulaggregator_series`,
  `_dropped_series_total`, `_cow_clones_total`).
- Wire `Capabilities.MutatesData` off the config: if `CopyOnWrite=false`,
  advertise `MutatesData=true` so upstream can skip its own defensive clone.
