package statefulaggregatorprocessor

import (
	"context"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/processor"

	"github.com/example/statefulaggregatorprocessor/internal/metadata"
)

// NewFactory returns a processor factory for the stateful aggregator.
func NewFactory() processor.Factory {
	return processor.NewFactory(
		metadata.Type,
		func() component.Config { return createDefaultConfig() },
		processor.WithMetrics(createMetricsProcessor, metadata.MetricsStability),
	)
}

func createMetricsProcessor(
	_ context.Context,
	set processor.Settings,
	cfg component.Config,
	next consumer.Metrics,
) (processor.Metrics, error) {
	pcfg := cfg.(*Config)
	return newProcessor(pcfg, set.Logger, next), nil
}
