package statefulaggregatorprocessor

import (
	"context"
	"sync"
	"time"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.uber.org/zap"

	"github.com/example/statefulaggregatorprocessor/internal/aggregator"
	"github.com/example/statefulaggregatorprocessor/internal/cow"
)

type statefulAggregatorProcessor struct {
	cfg      *Config
	logger   *zap.Logger
	next     consumer.Metrics
	manager  *aggregator.Manager
	filter   aggregator.Filter

	// Flusher state.
	flushDone chan struct{}
	wg        sync.WaitGroup
}

func newProcessor(cfg *Config, logger *zap.Logger, next consumer.Metrics) *statefulAggregatorProcessor {
	shard := cfg.ShardCount
	if shard == 0 {
		shard = 64
	}
	p := &statefulAggregatorProcessor{
		cfg:       cfg,
		logger:    logger,
		next:      next,
		manager:   aggregator.NewManager(shard, cfg.MaxSeries),
		flushDone: make(chan struct{}),
	}
	if len(cfg.IncludeMetricNames) > 0 {
		allow := make(map[string]struct{}, len(cfg.IncludeMetricNames))
		for _, n := range cfg.IncludeMetricNames {
			allow[n] = struct{}{}
		}
		p.filter = func(name string) bool {
			_, ok := allow[name]
			return ok
		}
	}
	return p
}

// Capabilities implements processor.Metrics. We do NOT mutate incoming data
// when the COW fast path applies; when we do aggregate we emit a fresh
// payload downstream, so upstream data is untouched either way.
func (p *statefulAggregatorProcessor) Capabilities() consumer.Capabilities {
	return consumer.Capabilities{MutatesData: false}
}

func (p *statefulAggregatorProcessor) Start(ctx context.Context, _ component.Host) error {
	if p.cfg.FlushInterval > 0 {
		p.wg.Add(1)
		go p.runFlusher(ctx)
	}
	return nil
}

func (p *statefulAggregatorProcessor) Shutdown(ctx context.Context) error {
	close(p.flushDone)
	p.wg.Wait()
	// Drain remaining state on shutdown.
	return p.emit(ctx, p.manager.Flush(time.Now()))
}

// ConsumeMetrics is the hot path.
//
// Flow:
//  1. Wrap incoming payload in a copy-on-write Handle.
//  2. If no aggregatable Sum is present, forward the original via COW (no
//     clone, no state touched) — this is the pure passthrough fast path.
//  3. Otherwise, iterate and fold Sum points into state. Non-Sum metrics
//     from the original batch are still forwarded verbatim (again, no clone)
//     so gauges/histograms flow through unaffected.
//  4. When FlushInterval == 0 we also emit accumulated Sum state inline;
//     otherwise the background flusher owns emission.
func (p *statefulAggregatorProcessor) ConsumeMetrics(ctx context.Context, md pmetric.Metrics) error {
	h := cow.New(md)

	if p.cfg.CopyOnWrite && !aggregator.HasAggregatableSum(h.Read(), p.filter) {
		// Nothing to aggregate — pure passthrough with zero clone.
		return p.next.ConsumeMetrics(ctx, h.Emit())
	}

	// Aggregate Sums.
	if dropped := aggregator.Ingest(p.manager, h.Read(), p.filter); dropped > 0 {
		p.logger.Warn("dropped points due to max_series cap", zap.Int("dropped", dropped))
	}

	// Forward the non-Sum portion of the batch downstream. We build a stripped
	// view lazily — only clone when we actually have to remove Sums.
	stripped := stripSums(h.Read(), p.filter)
	if stripped.MetricCount() > 0 {
		if err := p.next.ConsumeMetrics(ctx, stripped); err != nil {
			return err
		}
	}

	// Inline flush when no background flusher is configured.
	if p.cfg.FlushInterval <= 0 {
		return p.emit(ctx, p.manager.Flush(time.Now()))
	}
	return nil
}

func (p *statefulAggregatorProcessor) runFlusher(ctx context.Context) {
	defer p.wg.Done()
	t := time.NewTicker(p.cfg.FlushInterval)
	defer t.Stop()
	for {
		select {
		case <-p.flushDone:
			return
		case now := <-t.C:
			out := p.manager.Flush(now)
			if out.MetricCount() == 0 {
				continue
			}
			if err := p.emit(ctx, out); err != nil {
				p.logger.Error("flush emit failed", zap.Error(err))
			}
		}
	}
}

func (p *statefulAggregatorProcessor) emit(ctx context.Context, md pmetric.Metrics) error {
	if md.MetricCount() == 0 {
		return nil
	}
	return p.next.ConsumeMetrics(ctx, md)
}

// stripSums returns a payload that contains everything except the Sums the
// filter accepts. When there are no such Sums it returns md unchanged (no
// allocation). Otherwise it clones — this is the "mutation" branch that
// justifies COW being off the hot path when passthrough is possible.
func stripSums(md pmetric.Metrics, filter aggregator.Filter) pmetric.Metrics {
	// First scan: do we need to strip anything?
	needStrip := false
	rms := md.ResourceMetrics()
	for i := 0; i < rms.Len() && !needStrip; i++ {
		sms := rms.At(i).ScopeMetrics()
		for j := 0; j < sms.Len() && !needStrip; j++ {
			ms := sms.At(j).Metrics()
			for k := 0; k < ms.Len(); k++ {
				m := ms.At(k)
				if m.Type() == pmetric.MetricTypeSum && (filter == nil || filter(m.Name())) {
					needStrip = true
					break
				}
			}
		}
	}
	if !needStrip {
		return md
	}

	out := pmetric.NewMetrics()
	rmsOut := out.ResourceMetrics()
	for i := 0; i < rms.Len(); i++ {
		rmIn := rms.At(i)
		var rmOut pmetric.ResourceMetrics
		haveRm := false
		sms := rmIn.ScopeMetrics()
		for j := 0; j < sms.Len(); j++ {
			smIn := sms.At(j)
			var smOut pmetric.ScopeMetrics
			haveSm := false
			ms := smIn.Metrics()
			for k := 0; k < ms.Len(); k++ {
				m := ms.At(k)
				if m.Type() == pmetric.MetricTypeSum && (filter == nil || filter(m.Name())) {
					continue
				}
				if !haveRm {
					rmOut = rmsOut.AppendEmpty()
					rmIn.Resource().CopyTo(rmOut.Resource())
					rmOut.SetSchemaUrl(rmIn.SchemaUrl())
					haveRm = true
				}
				if !haveSm {
					smOut = rmOut.ScopeMetrics().AppendEmpty()
					smIn.Scope().CopyTo(smOut.Scope())
					smOut.SetSchemaUrl(smIn.SchemaUrl())
					haveSm = true
				}
				m.CopyTo(smOut.Metrics().AppendEmpty())
			}
		}
	}
	return out
}
