package statefulaggregatorprocessor

import (
	"context"
	"testing"

	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.uber.org/zap"

	"github.com/example/statefulaggregatorprocessor/internal/gentest"
)

func TestConsumePassthroughDoesNotAllocate(t *testing.T) {
	cfg := createDefaultConfig()
	cfg.IncludeMetricNames = []string{"nothing.matches"}
	cfg.FlushInterval = 0
	sink := &sinkConsumer{}
	p := newProcessor(cfg, zap.NewNop(), sink)
	md := gentest.Build(gentest.Default())

	if err := p.ConsumeMetrics(context.Background(), md); err != nil {
		t.Fatal(err)
	}
	if sink.calls != 1 {
		t.Fatalf("expected 1 downstream call, got %d", sink.calls)
	}
	if sink.dps != md.DataPointCount() {
		t.Fatalf("expected %d dps forwarded, got %d", md.DataPointCount(), sink.dps)
	}
	if p.manager.Len() != 0 {
		t.Fatalf("expected empty state, got %d", p.manager.Len())
	}
}

func TestConsumeInlineFlush(t *testing.T) {
	cfg := createDefaultConfig()
	cfg.FlushInterval = 0
	sink := &sinkConsumer{}
	p := newProcessor(cfg, zap.NewNop(), sink)
	md := gentest.Build(gentest.Options{
		Resources: 1, ScopesPerRes: 1, MetricsPerScope: 1, SeriesPerMetric: 4,
		MonotonicSum:     true,
		Temporality:      pmetric.AggregationTemporalityCumulative,
		MetricNamePrefix: "m",
	})
	if err := p.ConsumeMetrics(context.Background(), md); err != nil {
		t.Fatal(err)
	}
	// With FlushInterval=0 the aggregated view is emitted inline; the input
	// contained only Sum metrics, so stripSums yields an empty batch and
	// downstream should only see the flushed aggregate.
	if sink.calls != 1 {
		t.Fatalf("expected 1 downstream call, got %d", sink.calls)
	}
	if sink.dps != 4 {
		t.Fatalf("expected 4 aggregated dps, got %d", sink.dps)
	}
}
