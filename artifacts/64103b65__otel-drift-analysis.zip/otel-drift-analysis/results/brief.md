# OTel Perf — 30-day Structural Efficiency Risk Brief

> **SYNTHETIC TEMPLATE.** This brief was produced from a synthetic 30-run dataset with deliberately injected slow drift. Replace the input files in `runs/` with real scorecard exports from your GitHub Actions artifact history and re-run `analyze_trend.py` to regenerate against production data.

## Method

- **Data:** 30 nightly runs × 10 iterations, trimmed-median per run.
- **Baseline per run:** rolling 7 previous runs.
- **Trend statistics per metric:** Theil–Sen slope (robust to outliers), Mann-Kendall τ with normal-approx p-value (monotonicity test), projected drift at day 30 as % of first-7-run anchor.
- **Ranking:** signed % of fail-threshold budget consumed by the fitted trend, filtered to metrics that (a) have NOT already tripped the gate, (b) show statistically significant monotonic drift (|τ|≥0.3, p<0.10), and (c) are moving toward failure.

## Top 3 Structural Risks

### 1. `exporter_send_latency_p99_ms` — 36.2% of fail budget consumed

- Direction: `increase_is_bad` · Fail threshold: `+15.0%` per-run vs baseline
- Anchor (first 7 runs): **141.6** → final run: **146.2**
- Projected 30-day drift toward failure: **+5.42%**
- Monotonicity: Kendall τ = **+0.49**, p = **0.000**
- Theil–Sen slope: **+0.2648** per run

**Interpretation:** Tail export latency is drifting up. Likely causes: exporter batch size and flush interval no longer matched to downstream throughput, growing payload size per batch, or TCP/TLS handshake churn if connection pooling regressed. Check batch processor tuning and exporter connection reuse.

### 2. `cpu_ns_per_span` — 36.0% of fail budget consumed

- Direction: `increase_is_bad` · Fail threshold: `+10.0%` per-run vs baseline
- Anchor (first 7 runs): **1.234e+04** → final run: **1.266e+04**
- Projected 30-day drift toward failure: **+3.60%**
- Monotonicity: Kendall τ = **+0.45**, p = **0.001**
- Theil–Sen slope: **+15.32** per run

**Interpretation:** CPU cost per span is climbing monotonically. This usually indicates growing per-span work — a new processor stage, an attribute enrichment path added recently, or a regression in span-processor hot loops. Investigate recent processor-chain changes and profile the collector under load to identify the added path.

### 3. `heap_bytes_per_span` — 24.9% of fail budget consumed

- Direction: `increase_is_bad` · Fail threshold: `+15.0%` per-run vs baseline
- Anchor (first 7 runs): **3189** → final run: **3171**
- Projected 30-day drift toward failure: **+3.73%**
- Monotonicity: Kendall τ = **+0.38**, p = **0.003**
- Theil–Sen slope: **+4.105** per run

**Interpretation:** Heap footprint per span is growing. Prime suspects: attribute cardinality creeping up (new high-cardinality labels), string-interning regressions, or a processor retaining references longer than it should. Compare a heap profile from run 1 vs run 30 and look for growth in map/slice types owned by processors.

## Caveats

- **Near-zero metrics look noisy in the heatmap.** `dropped_spans_ratio` and `retry_ratio` are anchored near zero; any tiny fluctuation shows as a large percentage swing. These metrics are ranked by the same statistical test as everything else, so they only appear in the risk brief if the drift is both large *and* monotonic. Trust the brief, not the color intensity, for these rows.
- **Ranking is preemptive.** The brief filters out any metric that has already tripped the gate — those are the gate's job. This brief is only about slow-drift risks that are still below the fail line.
- **The Mann-Kendall filter (|τ|≥0.3, p<0.10) will hide short-lived regressions.** A sudden step-change on day 25 that persists for 5 runs may fail the monotonicity test even though it's clearly a regression. Pair this brief with the nightly gate — they answer different questions.

## How to swap this template for real data

1. In `otel-perf-nightly.yml`, artifacts named `otel-perf-scorecard-<run_id>` are uploaded with 90-day retention on every run. Once you have ≥30 successful `main` runs, batch-download them:
   ```bash
   gh run list --workflow otel-perf-nightly.yml --branch main --status success \
     --limit 30 --json databaseId --jq '.[].databaseId' \
     | xargs -I{} gh run download {} -n otel-perf-scorecard-{} -D runs/{}
   ```
2. Convert each `scorecard.json` into the `{iterations: [...]}` shape expected by `analyze_trend.py`. If you emit raw iteration data alongside the scorecard (add a `--raw-out` flag to `run-bench.sh`), skip this step and point the analyzer directly at those files.
3. Delete `runs/*.json` from this workspace, drop your real files in, and re-run:
   ```bash
   python scripts/analyze_trend.py
   ```
4. Review `results/heatmap.png` and `results/brief.md`. Metrics ranked in the brief are the ones to address BEFORE they trip the gate.

## Files produced

- `results/per_run_scorecards.json` — full evaluator output for every (run, metric) pair
- `results/trend_summary.csv` — one row per metric with all trend statistics
- `results/heatmap.png` — 17 metrics × 30 runs drift heatmap
- `results/brief.md` — this document