#!/usr/bin/env python3
"""Build a self-contained static HTML dashboard from trend analysis outputs.

Reads:
  results/trend_summary.csv       (per-metric trend stats)
  results/per_run_scorecards.json (per-run per-metric evaluator output)
  results/heatmap.png             (pre-rendered image, base64-embedded)
  results/brief.md                (top-3 risk narrative)

Writes:
  dashboard/site/index.html       (single self-contained page)
  dashboard/site/data.json        (raw payload for anyone who wants it)

No external CSS or JS is loaded at runtime — the page renders offline.
Inline SVG sparklines per metric, no chart libraries.
"""
from __future__ import annotations

import base64
import csv
import html
import json
import statistics
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"
SITE = ROOT / "dashboard" / "site"
SITE.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------- #
# Load inputs                                                                 #
# --------------------------------------------------------------------------- #
def load_trend_rows() -> list[dict]:
    with open(RESULTS / "trend_summary.csv") as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            # cast numeric fields
            for k, v in row.items():
                if k in ("metric", "direction"):
                    continue
                if v == "" or v is None:
                    row[k] = None
                else:
                    try:
                        row[k] = float(v)
                    except ValueError:
                        pass
            rows.append(row)
        return rows


def load_scorecards() -> list[list[dict]]:
    return json.loads((RESULTS / "per_run_scorecards.json").read_text())


def load_brief() -> str:
    p = RESULTS / "brief.md"
    return p.read_text() if p.exists() else ""


def embed_heatmap() -> str | None:
    p = RESULTS / "heatmap.png"
    if not p.exists():
        return None
    b64 = base64.b64encode(p.read_bytes()).decode("ascii")
    return f"data:image/png;base64,{b64}"


# --------------------------------------------------------------------------- #
# Sparkline SVG                                                               #
# --------------------------------------------------------------------------- #
def sparkline_svg(values: list[float], direction: str, width: int = 200, height: int = 36) -> str:
    """Minimal inline SVG sparkline. Red = trending toward failure, blue = away."""
    if not values or all(v is None for v in values):
        return ""
    ys = [v for v in values if v is not None]
    if len(ys) < 2:
        return ""
    lo, hi = min(ys), max(ys)
    rng = hi - lo if hi > lo else 1.0
    pad_y = 3
    def px(i): return round(i / (len(values) - 1) * (width - 2) + 1, 2)
    def py(v): return round(height - pad_y - (v - lo) / rng * (height - 2 * pad_y), 2)
    pts = " ".join(f"{px(i)},{py(v)}" for i, v in enumerate(values))
    # Slope-based color: last-third mean vs first-third mean
    third = max(1, len(ys) // 3)
    early = statistics.mean(ys[:third])
    late = statistics.mean(ys[-third:])
    trending_bad = (late > early) if direction == "increase_is_bad" else (late < early)
    stroke = "#c0392b" if trending_bad else "#2c7fb8"
    end_dot = f'<circle cx="{px(len(values)-1)}" cy="{py(ys[-1])}" r="2.4" fill="{stroke}" />'
    return (
        f'<svg viewBox="0 0 {width} {height}" width="{width}" height="{height}" '
        f'preserveAspectRatio="none" role="img" aria-label="sparkline">'
        f'<polyline fill="none" stroke="{stroke}" stroke-width="1.6" points="{pts}" />'
        f'{end_dot}</svg>'
    )


# --------------------------------------------------------------------------- #
# HTML rendering                                                              #
# --------------------------------------------------------------------------- #
CSS = """
:root { --bg:#0e1116; --panel:#161b22; --border:#30363d; --text:#e6edf3;
        --muted:#8b949e; --ok:#2ea043; --warn:#d29922; --fail:#f85149;
        --link:#58a6ff; }
* { box-sizing:border-box; }
body { margin:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
       background:var(--bg); color:var(--text); line-height:1.5; }
header { padding:20px 32px; border-bottom:1px solid var(--border);
         display:flex; justify-content:space-between; align-items:baseline;
         flex-wrap:wrap; gap:12px; }
h1 { margin:0; font-size:20px; font-weight:600; }
.meta { color:var(--muted); font-size:13px; }
main { max-width:1400px; margin:0 auto; padding:24px 32px 48px; }
section { background:var(--panel); border:1px solid var(--border); border-radius:8px;
          padding:20px 24px; margin-bottom:24px; }
section h2 { margin:0 0 14px; font-size:15px; font-weight:600; color:var(--muted);
             text-transform:uppercase; letter-spacing:.05em; }
.kpis { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
        gap:14px; }
.kpi { background:#0d1117; border:1px solid var(--border); border-radius:6px;
       padding:12px 14px; }
.kpi .label { color:var(--muted); font-size:12px; margin-bottom:4px; }
.kpi .value { font-size:22px; font-weight:600; }
.kpi .value.ok { color:var(--ok); }
.kpi .value.warn { color:var(--warn); }
.kpi .value.fail { color:var(--fail); }
table { width:100%; border-collapse:collapse; font-size:13px; }
th, td { text-align:left; padding:8px 10px; border-bottom:1px solid var(--border); }
th { color:var(--muted); font-weight:500; font-size:12px; text-transform:uppercase; letter-spacing:.04em; }
td.num { text-align:right; font-variant-numeric:tabular-nums; }
td.spark { width:210px; padding:4px 10px; }
.badge { display:inline-block; padding:2px 8px; border-radius:10px; font-size:11px;
         font-weight:600; text-transform:uppercase; letter-spacing:.03em; }
.badge.pass { background:rgba(46,160,67,.15); color:var(--ok); }
.badge.warn { background:rgba(210,153,34,.15); color:var(--warn); }
.badge.fail { background:rgba(248,81,73,.15); color:var(--fail); }
.badge.abstain { background:rgba(139,148,158,.15); color:var(--muted); }
.heatmap { text-align:center; }
.heatmap img { max-width:100%; border-radius:6px; background:white; padding:4px; }
.brief { white-space:pre-wrap; font-family:ui-monospace,"SF Mono",Menlo,monospace;
         font-size:12.5px; background:#0d1117; border:1px solid var(--border);
         border-radius:6px; padding:16px; overflow-x:auto; }
a { color:var(--link); text-decoration:none; }
a:hover { text-decoration:underline; }
footer { color:var(--muted); font-size:12px; text-align:center; padding:24px; }
.risk-list li { margin-bottom:6px; }
"""


def status_class(v: float | None, direction: str, warn: float | None, fail: float | None) -> str:
    if v is None or warn is None or fail is None:
        return "ok"
    v_signed = v if direction == "increase_is_bad" else -v
    warn_signed = warn if direction == "increase_is_bad" else -warn
    fail_signed = fail if direction == "increase_is_bad" else -fail
    if v_signed >= fail_signed:
        return "fail"
    if v_signed >= warn_signed:
        return "warn"
    return "ok"


def render(trend_rows: list[dict], scorecards: list[list[dict]], brief_md: str,
           heatmap_data_uri: str | None) -> str:
    n_runs = len(scorecards)
    latest = scorecards[-1] if scorecards else []
    n_fail = sum(1 for m in latest if m["status"] == "fail")
    n_warn = sum(1 for m in latest if m["status"] == "warn")
    n_pass = sum(1 for m in latest if m["status"] == "pass")
    n_abstain = sum(1 for m in latest if m["status"] == "abstain")

    # Monotonic drift alerts: metrics with |tau|>=0.3 and p<0.10 AND moving bad
    drift_alerts = []
    for r in trend_rows:
        tau = r.get("mann_kendall_tau") or 0
        p = r.get("mk_p_value")
        signed = r.get("signed_drift_pct_30d_bad_positive") or 0
        if p is not None and abs(tau) >= 0.3 and p < 0.10 and signed > 0:
            drift_alerts.append(r)
    drift_alerts.sort(key=lambda r: r.get("pct_of_fail_budget_consumed") or 0, reverse=True)

    # Per-metric time series for sparklines
    series_by_metric: dict[str, list[float]] = {}
    for run_score in scorecards:
        for m in run_score:
            series_by_metric.setdefault(m["name"], []).append(m["current"])

    generated = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    rows_html = []
    for r in trend_rows:
        name = r["metric"]
        direction = r["direction"]
        series = series_by_metric.get(name, [])
        tau = r.get("mann_kendall_tau")
        p = r.get("mk_p_value")
        consumed = r.get("pct_of_fail_budget_consumed")
        drift = r.get("signed_drift_pct_30d_bad_positive")

        # Alert badge on the row
        if p is not None and tau is not None and abs(tau) >= 0.3 and p < 0.10 and (drift or 0) > 0:
            badge = '<span class="badge fail">drifting</span>'
        elif p is not None and abs(tau or 0) >= 0.3 and p < 0.20 and (drift or 0) > 0:
            badge = '<span class="badge warn">watch</span>'
        else:
            badge = '<span class="badge pass">stable</span>'

        consumed_str = f"{consumed:.1f}%" if consumed is not None else "—"
        drift_str = f"{drift:+.2f}%" if drift is not None else "—"
        tau_str = f"{tau:+.2f}" if tau is not None else "—"
        p_str = f"{p:.3f}" if p is not None else "—"
        current = series[-1] if series else float("nan")
        rows_html.append(f"""
          <tr>
            <td><code>{html.escape(name)}</code></td>
            <td>{badge}</td>
            <td class="num">{current:.4g}</td>
            <td class="spark">{sparkline_svg(series, direction)}</td>
            <td class="num">{drift_str}</td>
            <td class="num">{consumed_str}</td>
            <td class="num">{tau_str}</td>
            <td class="num">{p_str}</td>
          </tr>""")

    heatmap_html = (
        f'<div class="heatmap"><img src="{heatmap_data_uri}" alt="30-day drift heatmap"/></div>'
        if heatmap_data_uri else '<p class="muted">Heatmap not available.</p>'
    )

    alert_items = "".join(
        f"<li><code>{html.escape(a['metric'])}</code> — "
        f"{(a.get('pct_of_fail_budget_consumed') or 0):.1f}% of fail budget consumed, "
        f"τ={a.get('mann_kendall_tau'):+.2f}, p={a.get('mk_p_value'):.3f}</li>"
        for a in drift_alerts[:5]
    ) or "<li>No metrics currently exhibit statistically significant monotonic drift.</li>"

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>OTel Perf Dashboard</title>
<style>{CSS}</style>
</head>
<body>
<header>
  <div>
    <h1>OTel Pipeline Performance Dashboard</h1>
    <div class="meta">Last {n_runs} runs · Generated {generated}</div>
  </div>
  <div class="meta">Refresh: daily via GitHub Actions</div>
</header>
<main>

  <section>
    <h2>Latest run</h2>
    <div class="kpis">
      <div class="kpi"><div class="label">Pass</div><div class="value ok">{n_pass}</div></div>
      <div class="kpi"><div class="label">Warn</div><div class="value warn">{n_warn}</div></div>
      <div class="kpi"><div class="label">Fail</div><div class="value fail">{n_fail}</div></div>
      <div class="kpi"><div class="label">Abstain</div><div class="value">{n_abstain}</div></div>
      <div class="kpi"><div class="label">Monotonic-drift alerts</div>
        <div class="value {'fail' if drift_alerts else 'ok'}">{len(drift_alerts)}</div></div>
    </div>
  </section>

  <section>
    <h2>Drift alerts (30-day, statistically significant)</h2>
    <ul class="risk-list">{alert_items}</ul>
  </section>

  <section>
    <h2>Metric table</h2>
    <table>
      <thead><tr>
        <th>Metric</th><th>State</th><th>Latest</th><th>30-day sparkline</th>
        <th>30d drift</th><th>Fail budget</th><th>Kendall τ</th><th>MK p</th>
      </tr></thead>
      <tbody>{''.join(rows_html)}</tbody>
    </table>
  </section>

  <section>
    <h2>Heatmap (17 metrics × 30 runs)</h2>
    {heatmap_html}
  </section>

  <section>
    <h2>Risk brief</h2>
    <div class="brief">{html.escape(brief_md)}</div>
  </section>

</main>
<footer>
  OTel perf dashboard · <a href="data.json">raw data</a> ·
  built by <code>build_dashboard.py</code>
</footer>
</body>
</html>
"""


def main() -> None:
    trend_rows = load_trend_rows()
    scorecards = load_scorecards()
    brief_md = load_brief()
    heatmap = embed_heatmap()

    html_out = render(trend_rows, scorecards, brief_md, heatmap)
    (SITE / "index.html").write_text(html_out)

    # Also emit raw JSON so consumers (Notion mirror, digest job) can reuse it
    (SITE / "data.json").write_text(json.dumps({
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "trend_rows": trend_rows,
        "scorecards": scorecards,
    }, indent=2, default=str))
    print(f"Dashboard written: {SITE / 'index.html'} ({(SITE / 'index.html').stat().st_size} bytes)")


if __name__ == "__main__":
    main()
