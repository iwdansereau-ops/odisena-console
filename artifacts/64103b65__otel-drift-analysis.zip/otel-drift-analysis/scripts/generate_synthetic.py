#!/usr/bin/env python3
"""Generate 30 synthetic nightly runs (10 iterations each) for the 17 metrics.

Design:
  - Anchor value per metric is chosen inside its absolute budget with headroom.
  - Iteration noise ~ Gaussian with metric-specific CV (2-8% typical).
  - Some metrics inject SLOW MONOTONIC DRIFT: linear trend over 30 days that
    accumulates to ~2-3% total, well below the +10% fail threshold.
  - Reproducible via fixed RNG seed.
"""
from __future__ import annotations
import json
import random
from pathlib import Path
import numpy as np

SEED = 20260702
RUNS = 30
ITERS = 10
OUT_DIR = Path("/home/user/workspace/otel-drift-analysis/runs")
OUT_DIR.mkdir(parents=True, exist_ok=True)

# (anchor value, iteration CV, direction, total drift over 30 days as fraction)
# direction: +1 means "increases over time is bad", -1 means "decreases over time is bad"
# drift fraction is signed in the "bad" direction; 0 = stationary.
METRICS = {
    # LATENCY -- 200ms budget, anchor 142ms; slow +2.8% drift => still < 10%
    "exporter_send_latency_p50_ms":        (18.0,   0.04, +1, 0.010),  # slight drift
    "exporter_send_latency_p95_ms":        (55.0,   0.05, +1, 0.015),
    "exporter_send_latency_p99_ms":        (142.0,  0.06, +1, 0.028),  # DRIFTING ← risk
    "processor_batch_send_latency_p99_ms": (38.0,   0.05, +1, 0.008),
    "queue_wait_time_p99_ms":              (70.0,   0.08, +1, 0.000),  # stationary
    # THROUGHPUT (drift is negative in "bad" direction)
    "spans_per_second":                    (11800., 0.03, -1, -0.005),
    "metric_points_per_second":            (58000., 0.03, -1, 0.000),
    "logs_per_second":                     (23000., 0.04, -1, 0.000),
    "export_success_ratio":                (0.9995, 0.0005, -1, 0.000),
    # RESOURCE
    "cpu_ns_per_span":                     (12400., 0.04, +1, 0.030),  # DRIFTING ← risk
    "cpu_peak_percent":                    (72.,    0.05, +1, 0.012),
    "heap_bytes_per_span":                 (3200.,  0.05, +1, 0.025),  # DRIFTING ← risk
    "rss_peak_mib":                        (420.,   0.03, +1, 0.020),
    "gc_pause_p99_ms":                     (3.2,    0.10, +1, 0.000),  # noisy but stationary
    # RELIABILITY
    "dropped_spans_ratio":                 (0.00003, 0.30, +1, 0.000),
    "queue_saturation_max":                (0.42,   0.08, +1, 0.015),
    "retry_ratio":                         (0.003,  0.15, +1, 0.000),
}


def main() -> None:
    rng = np.random.default_rng(SEED)
    random.seed(SEED)
    for run_idx in range(RUNS):
        # Fraction of the 30-day drift accumulated by this run
        t = run_idx / (RUNS - 1)  # 0 → 1
        iterations = []
        for _ in range(ITERS):
            row = {}
            for name, (anchor, cv, direction, total_drift) in METRICS.items():
                # Direction is baked into `total_drift` sign already
                drift_factor = 1.0 + total_drift * t
                mean = anchor * drift_factor
                std = mean * cv
                # Gaussian noise, then clamp to non-negative
                val = float(rng.normal(mean, std))
                # dropped_spans_ratio and retry_ratio can be near-zero; keep >= 0
                if name in ("dropped_spans_ratio", "retry_ratio", "export_success_ratio"):
                    val = max(0.0, val)
                if name == "export_success_ratio":
                    val = min(1.0, val)
                row[name] = val
            iterations.append(row)
        tag = f"run-{run_idx:02d}"
        (OUT_DIR / f"{tag}.json").write_text(json.dumps(
            {"run_index": run_idx, "iterations": iterations}, indent=2
        ))
    print(f"Wrote {RUNS} synthetic run files to {OUT_DIR}")


if __name__ == "__main__":
    main()
