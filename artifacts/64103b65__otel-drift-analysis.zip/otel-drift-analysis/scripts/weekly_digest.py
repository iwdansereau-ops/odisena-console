#!/usr/bin/env python3
"""Weekly digest: email if any metric shows statistically significant
monotonic increase in resource consumption over the last 30 days.

Reads results/trend_summary.csv. Decides whether to send an email
(exit 0 = sent or none needed; nonzero = failure).

Delivery via SendGrid (SENDGRID_API_KEY) or SMTP (SMTP_HOST/USER/PASS).
Falls back to writing digest.md and exit 0 with 'skipped' if no creds set,
so the workflow can conditionally attach it to an issue/artifact instead.
"""
from __future__ import annotations

import csv
import json
import os
import smtplib
import ssl
import sys
from email.message import EmailMessage
from pathlib import Path
from urllib import request as urlrequest

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"

# --------------------------------------------------------------------------- #
# Criteria for alerting                                                       #
# --------------------------------------------------------------------------- #
# Only these metrics count as "resource consumption" for the digest.
# Latency drifts and throughput regressions are visible on the dashboard but
# do not trigger this specific weekly alert (per the user's request).
RESOURCE_METRICS = {
    "cpu_ns_per_span",
    "cpu_peak_percent",
    "heap_bytes_per_span",
    "rss_peak_mib",
    "gc_pause_p99_ms",
    "queue_saturation_max",
}

TAU_MIN = 0.30       # Kendall's tau minimum magnitude
P_MAX = 0.05         # Mann-Kendall p-value maximum (stricter than dashboard)
BUDGET_MIN = 15.0    # % of fail budget consumed minimum


def load_rows() -> list[dict]:
    with open(RESULTS / "trend_summary.csv") as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            for k, v in row.items():
                if k in ("metric", "direction"):
                    continue
                if v == "" or v is None:
                    row[k] = None
                else:
                    try:
                        row[k] = float(v)
                    except ValueError:
                        pass
            rows.append(row)
        return rows


def find_alerts(rows: list[dict]) -> list[dict]:
    alerts = []
    for r in rows:
        if r["metric"] not in RESOURCE_METRICS:
            continue
        if r["direction"] != "increase_is_bad":
            continue
        tau = r.get("mann_kendall_tau") or 0
        p = r.get("mk_p_value")
        consumed = r.get("pct_of_fail_budget_consumed") or 0
        signed_drift = r.get("signed_drift_pct_30d_bad_positive") or 0
        if p is None:
            continue
        if tau >= TAU_MIN and p <= P_MAX and consumed >= BUDGET_MIN and signed_drift > 0:
            alerts.append(r)
    alerts.sort(key=lambda r: r["pct_of_fail_budget_consumed"], reverse=True)
    return alerts


# --------------------------------------------------------------------------- #
# Rendering                                                                   #
# --------------------------------------------------------------------------- #
def render_html(alerts: list[dict], dashboard_url: str) -> str:
    rows_html = "".join(f"""
        <tr>
          <td><code>{a['metric']}</code></td>
          <td style="text-align:right">{a['pct_of_fail_budget_consumed']:.1f}%</td>
          <td style="text-align:right">{a['signed_drift_pct_30d_bad_positive']:+.2f}%</td>
          <td style="text-align:right">{a['mann_kendall_tau']:+.2f}</td>
          <td style="text-align:right">{a['mk_p_value']:.4f}</td>
        </tr>""" for a in alerts)
    return f"""<!doctype html><html><body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#24292f;max-width:640px;margin:0 auto">
<h2 style="margin-bottom:4px">OTel perf — weekly drift digest</h2>
<p style="color:#57606a;margin-top:0">
{len(alerts)} resource metric{'s' if len(alerts)!=1 else ''} showing
statistically significant monotonic increase over the last 30 days.
</p>
<table style="width:100%;border-collapse:collapse;font-size:14px;margin:16px 0">
  <thead>
    <tr style="background:#f6f8fa">
      <th style="text-align:left;padding:8px;border-bottom:1px solid #d0d7de">Metric</th>
      <th style="text-align:right;padding:8px;border-bottom:1px solid #d0d7de">Fail budget</th>
      <th style="text-align:right;padding:8px;border-bottom:1px solid #d0d7de">30d drift</th>
      <th style="text-align:right;padding:8px;border-bottom:1px solid #d0d7de">Kendall τ</th>
      <th style="text-align:right;padding:8px;border-bottom:1px solid #d0d7de">MK p</th>
    </tr>
  </thead>
  <tbody>{rows_html}</tbody>
</table>
<p><a href="{dashboard_url}" style="background:#0969da;color:white;padding:8px 14px;border-radius:6px;text-decoration:none;display:inline-block">Open dashboard →</a></p>
<p style="color:#57606a;font-size:12px;margin-top:24px">
Criteria: |τ|≥{TAU_MIN}, p≤{P_MAX}, ≥{BUDGET_MIN:.0f}% of fail-threshold budget consumed by fitted trend.
Metric universe: {', '.join(sorted(RESOURCE_METRICS))}.
</p>
</body></html>"""


def render_text(alerts: list[dict], dashboard_url: str) -> str:
    lines = [
        f"OTel perf — weekly drift digest",
        f"{len(alerts)} resource metric(s) drifting toward failure over last 30 days.",
        "",
    ]
    for a in alerts:
        lines.append(
            f"  • {a['metric']}: {a['pct_of_fail_budget_consumed']:.1f}% budget, "
            f"drift {a['signed_drift_pct_30d_bad_positive']:+.2f}%, "
            f"τ={a['mann_kendall_tau']:+.2f}, p={a['mk_p_value']:.4f}"
        )
    lines += ["", f"Dashboard: {dashboard_url}"]
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# Delivery                                                                    #
# --------------------------------------------------------------------------- #
def send_via_sendgrid(to: str, subject: str, html_body: str, text_body: str,
                      api_key: str, sender: str) -> None:
    payload = {
        "personalizations": [{"to": [{"email": to}]}],
        "from": {"email": sender},
        "subject": subject,
        "content": [
            {"type": "text/plain", "value": text_body},
            {"type": "text/html", "value": html_body},
        ],
    }
    req = urlrequest.Request(
        "https://api.sendgrid.com/v3/mail/send",
        data=json.dumps(payload).encode(),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urlrequest.urlopen(req, timeout=30) as resp:
        if resp.status >= 300:
            raise RuntimeError(f"SendGrid HTTP {resp.status}: {resp.read()!r}")


def send_via_smtp(to: str, subject: str, html_body: str, text_body: str,
                  host: str, port: int, user: str, password: str, sender: str) -> None:
    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(text_body)
    msg.add_alternative(html_body, subtype="html")
    ctx = ssl.create_default_context()
    with smtplib.SMTP(host, port, timeout=30) as s:
        s.starttls(context=ctx)
        s.login(user, password)
        s.send_message(msg)


# --------------------------------------------------------------------------- #
# Main                                                                        #
# --------------------------------------------------------------------------- #
def gh_output(name: str, value: str) -> None:
    p = os.environ.get("GITHUB_OUTPUT")
    if p:
        with open(p, "a") as f:
            f.write(f"{name}={value}\n")


def main() -> int:
    rows = load_rows()
    alerts = find_alerts(rows)
    dashboard_url = os.environ.get("DASHBOARD_URL", "https://example.github.io/otel-perf/")
    recipient = os.environ.get("DIGEST_TO", "").strip()

    if not alerts:
        gh_output("sent", "false")
        gh_output("alert_count", "0")
        print("No monotonic-drift alerts this week — no email sent.")
        return 0

    subject = f"[OTel perf] {len(alerts)} resource metric(s) drifting toward failure"
    html_body = render_html(alerts, dashboard_url)
    text_body = render_text(alerts, dashboard_url)

    # Always write local copies (also uploaded as workflow artifact)
    (RESULTS / "digest.html").write_text(html_body)
    (RESULTS / "digest.txt").write_text(text_body)

    if not recipient:
        print("::warning::DIGEST_TO not set — writing digest to artifact only.")
        gh_output("sent", "false")
        gh_output("alert_count", str(len(alerts)))
        return 0

    sender = os.environ.get("DIGEST_FROM", recipient)
    sg_key = os.environ.get("SENDGRID_API_KEY")
    smtp_host = os.environ.get("SMTP_HOST")

    try:
        if sg_key:
            send_via_sendgrid(recipient, subject, html_body, text_body, sg_key, sender)
            print(f"Digest sent via SendGrid to {recipient}.")
        elif smtp_host:
            send_via_smtp(
                recipient, subject, html_body, text_body,
                smtp_host,
                int(os.environ.get("SMTP_PORT", "587")),
                os.environ["SMTP_USER"],
                os.environ["SMTP_PASS"],
                sender,
            )
            print(f"Digest sent via SMTP to {recipient}.")
        else:
            print("::warning::No email credentials configured — digest written to artifact only.")
            gh_output("sent", "false")
            gh_output("alert_count", str(len(alerts)))
            return 0
    except Exception as e:
        print(f"::error::Digest delivery failed: {e}")
        gh_output("sent", "false")
        gh_output("alert_count", str(len(alerts)))
        return 1

    gh_output("sent", "true")
    gh_output("alert_count", str(len(alerts)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
