#!/usr/bin/env python3
"""Trimmed-median summarizer + dual-gate evaluator (subset used for trend analysis).

Reused from the workflow package; only the pieces needed for offline batch
evaluation are kept here for clarity.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any
import numpy as np
import yaml

ABSTAIN_MIN_SAMPLES = 3


@dataclass
class MetricSpec:
    name: str
    direction: str
    absolute_budget_max: float | None = None
    absolute_budget_min: float | None = None
    warn_relative: float | None = None
    fail_relative: float | None = None
    warn_absolute_delta: float | None = None
    fail_absolute_delta: float | None = None


@dataclass
class MetricResult:
    name: str
    current: float
    baseline_mean: float | None
    baseline_std: float | None
    baseline_median: float | None
    baseline_mad: float | None
    n_baseline: int
    relative_drift: float | None
    robust_z: float | None
    status: str
    reasons: list[str] = field(default_factory=list)


def load_config(path: str) -> tuple[dict, list[MetricSpec]]:
    with open(path) as f:
        cfg = yaml.safe_load(f)
    return cfg, [MetricSpec(**m) for m in cfg["metrics"]]


def summarize_run(samples: list[float]) -> float:
    if len(samples) <= 2:
        return float(np.median(samples))
    trimmed = sorted(samples)[1:-1]
    return float(np.median(trimmed))


def robust_stats(current: float, baseline: list[float]):
    if len(baseline) < ABSTAIN_MIN_SAMPLES:
        return None
    arr = np.asarray(baseline, dtype=float)
    mean = float(arr.mean())
    std = float(arr.std(ddof=1)) if len(arr) > 1 else 0.0
    median = float(np.median(arr))
    mad = float(np.median(np.abs(arr - median)))
    if mad == 0.0:
        rz = 0.0 if current == median else float(np.sign(current - median)) * float("inf")
    else:
        rz = 0.6745 * (current - median) / mad
    return mean, std, median, mad, rz


def evaluate_metric(spec: MetricSpec, current: float, baseline_samples: list[float], cfg_gate: dict) -> MetricResult:
    stats = robust_stats(current, baseline_samples)
    reasons: list[str] = []
    if stats is None:
        return MetricResult(spec.name, current, None, None, None, None,
                            len(baseline_samples), None, None, "abstain",
                            [f"insufficient baseline (n={len(baseline_samples)})"])
    mean, std, median, mad, rz = stats
    rel = (current - mean) / mean if mean != 0 else 0.0
    absolute_ok = True
    if spec.absolute_budget_max is not None and current > spec.absolute_budget_max:
        absolute_ok = False
        reasons.append(f"absolute budget breach: {current:.4g} > {spec.absolute_budget_max}")
    if spec.absolute_budget_min is not None and current < spec.absolute_budget_min:
        absolute_ok = False
        reasons.append(f"below floor: {current:.4g} < {spec.absolute_budget_min}")
    warn_hit = fail_hit = False
    if spec.direction == "increase_is_bad":
        if spec.fail_relative is not None and rel > spec.fail_relative: fail_hit = True
        elif spec.warn_relative is not None and rel > spec.warn_relative: warn_hit = True
        if spec.fail_absolute_delta is not None and (current - mean) > spec.fail_absolute_delta: fail_hit = True
        elif spec.warn_absolute_delta is not None and (current - mean) > spec.warn_absolute_delta: warn_hit = True
    else:
        if spec.fail_relative is not None and rel < spec.fail_relative: fail_hit = True
        elif spec.warn_relative is not None and rel < spec.warn_relative: warn_hit = True
        if spec.fail_absolute_delta is not None and (current - mean) < spec.fail_absolute_delta: fail_hit = True
        elif spec.warn_absolute_delta is not None and (current - mean) < spec.warn_absolute_delta: warn_hit = True
    z_thresh = float(cfg_gate.get("zscore_fail_threshold", 3.0))
    signed = 1 if spec.direction == "increase_is_bad" else -1
    zscore_ok = (signed * rz) < z_thresh
    status = "pass"
    if not absolute_ok:
        status = "fail"
    elif cfg_gate.get("require_relative_and_zscore", True):
        if fail_hit and not zscore_ok:
            status = "fail"
            reasons.append(f"drift {rel:+.2%} exceeds fail AND robust_z={rz:+.2f} exceeds {z_thresh}")
        elif fail_hit:
            status = "warn"
            reasons.append(f"drift {rel:+.2%} exceeds fail but robust_z={rz:+.2f} within noise")
        elif warn_hit:
            status = "warn"
            reasons.append(f"drift {rel:+.2%} exceeds warn threshold")
    return MetricResult(spec.name, current, mean, std, median, mad,
                        len(baseline_samples), rel, rz, status, reasons)
