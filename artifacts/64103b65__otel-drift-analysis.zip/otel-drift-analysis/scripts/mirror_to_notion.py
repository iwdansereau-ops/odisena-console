#!/usr/bin/env python3
"""Mirror the dashboard summary to a Notion page.

Requires:
  NOTION_TOKEN   - integration token with edit access to NOTION_PAGE_ID
  NOTION_PAGE_ID - target page (32-char hex or dashed UUID)
  DASHBOARD_URL  - link to the full GitHub Pages dashboard (optional)

Strategy:
  Wipes the target page's existing blocks and re-appends fresh content each
  run so the page is idempotent — always shows the latest snapshot without
  accumulating stale sections.
"""
from __future__ import annotations

import csv
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib import request as urlrequest, error as urlerror

RESULTS = Path(__file__).resolve().parent.parent / "results"
API = "https://api.notion.com/v1"
VERSION = "2022-06-28"


def notion(method: str, path: str, token: str, body: dict | None = None) -> dict:
    data = json.dumps(body).encode() if body is not None else None
    req = urlrequest.Request(
        f"{API}{path}",
        data=data,
        headers={
            "Authorization": f"Bearer {token}",
            "Notion-Version": VERSION,
            "Content-Type": "application/json",
        },
        method=method,
    )
    try:
        with urlrequest.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read())
    except urlerror.HTTPError as e:
        raise RuntimeError(f"Notion {method} {path} → HTTP {e.code}: {e.read()!r}") from e


def load_rows() -> list[dict]:
    with open(RESULTS / "trend_summary.csv") as f:
        reader = csv.DictReader(f)
        rows = []
        for row in reader:
            for k, v in row.items():
                if k in ("metric", "direction"):
                    continue
                if v in ("", None):
                    row[k] = None
                else:
                    try:
                        row[k] = float(v)
                    except ValueError:
                        pass
            rows.append(row)
        return rows


def txt(content: str, bold: bool = False, code: bool = False) -> dict:
    return {
        "type": "text",
        "text": {"content": content},
        "annotations": {"bold": bold, "code": code},
    }


def heading(level: int, content: str) -> dict:
    key = f"heading_{level}"
    return {"object": "block", "type": key, key: {"rich_text": [txt(content)]}}


def paragraph(children: list[dict]) -> dict:
    return {"object": "block", "type": "paragraph",
            "paragraph": {"rich_text": children}}


def bullet(children: list[dict]) -> dict:
    return {"object": "block", "type": "bulleted_list_item",
            "bulleted_list_item": {"rich_text": children}}


def divider() -> dict:
    return {"object": "block", "type": "divider", "divider": {}}


def wipe(page_id: str, token: str) -> None:
    """Delete all child blocks on the page."""
    cursor = None
    while True:
        q = f"?start_cursor={cursor}" if cursor else ""
        page = notion("GET", f"/blocks/{page_id}/children{q}", token)
        for block in page["results"]:
            notion("DELETE", f"/blocks/{block['id']}", token)
        if not page.get("has_more"):
            break
        cursor = page["next_cursor"]


def append(page_id: str, token: str, blocks: list[dict]) -> None:
    # Notion caps at 100 children per call
    for i in range(0, len(blocks), 100):
        notion("PATCH", f"/blocks/{page_id}/children",
               token, {"children": blocks[i:i + 100]})


def build_blocks(rows: list[dict], dashboard_url: str) -> list[dict]:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    alerts = [
        r for r in rows
        if r.get("mann_kendall_tau") is not None
        and abs(r["mann_kendall_tau"]) >= 0.3
        and r.get("mk_p_value") is not None
        and r["mk_p_value"] < 0.10
        and (r.get("signed_drift_pct_30d_bad_positive") or 0) > 0
    ]
    alerts.sort(key=lambda r: r.get("pct_of_fail_budget_consumed") or 0, reverse=True)

    blocks: list[dict] = [
        heading(1, "OTel Pipeline — Perf Dashboard Mirror"),
        paragraph([txt(f"Snapshot generated {now}. ", ),
                   txt("Full interactive dashboard: "),
                   {"type": "text",
                    "text": {"content": dashboard_url or "(not set)",
                             "link": {"url": dashboard_url} if dashboard_url else None}}]),
        divider(),
        heading(2, f"Drift alerts ({len(alerts)})"),
    ]

    if not alerts:
        blocks.append(paragraph([txt("No metric currently shows statistically significant "
                                     "monotonic drift toward failure.")]))
    else:
        for a in alerts[:10]:
            blocks.append(bullet([
                txt(a["metric"], code=True),
                txt(f" — {a['pct_of_fail_budget_consumed']:.1f}% of fail budget, "
                    f"drift {a['signed_drift_pct_30d_bad_positive']:+.2f}%, "
                    f"τ={a['mann_kendall_tau']:+.2f}, p={a['mk_p_value']:.3f}"),
            ]))

    blocks += [
        divider(),
        heading(2, "All metrics"),
    ]
    for r in rows:
        drift = r.get("signed_drift_pct_30d_bad_positive")
        consumed = r.get("pct_of_fail_budget_consumed")
        tau = r.get("mann_kendall_tau")
        p = r.get("mk_p_value")
        drift_s = f"{drift:+.2f}%" if drift is not None else "—"
        consumed_s = f"{consumed:.1f}%" if consumed is not None else "—"
        tau_s = f"{tau:+.2f}" if tau is not None else "—"
        p_s = f"{p:.3f}" if p is not None else "—"
        blocks.append(bullet([
            txt(r["metric"], code=True),
            txt(f" · 30d drift {drift_s} · budget {consumed_s} · τ {tau_s} · p {p_s}"),
        ]))
    return blocks


def main() -> int:
    token = os.environ.get("NOTION_TOKEN")
    page_id = os.environ.get("NOTION_PAGE_ID")
    dashboard_url = os.environ.get("DASHBOARD_URL", "")
    if not token or not page_id:
        print("NOTION_TOKEN / NOTION_PAGE_ID not set — skipping Notion mirror.")
        return 0

    rows = load_rows()
    blocks = build_blocks(rows, dashboard_url)
    wipe(page_id, token)
    append(page_id, token, blocks)
    print(f"Mirrored {len(blocks)} blocks to Notion page {page_id}.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
