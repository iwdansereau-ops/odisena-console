#!/usr/bin/env python3
"""Sweep 30 synthetic runs through the evaluator, then run trend analysis.

Outputs:
  results/per_run_scorecards.json   - flat per-metric-per-run records
  results/trend_summary.csv         - per-metric slope, tau, budget-consumed %
  results/heatmap.png               - 17 × 30 drift heatmap
  results/brief.md                  - top-3 risk brief (template)
"""
from __future__ import annotations
import json
import sys
from pathlib import Path
from dataclasses import asdict

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm

sys.path.insert(0, str(Path(__file__).parent))
from evaluate_budget import (  # noqa: E402
    load_config, summarize_run, evaluate_metric, MetricSpec,
)

ROOT = Path("/home/user/workspace/otel-drift-analysis")
RUNS = ROOT / "runs"
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)
BASELINE_WINDOW = 7


def load_run_medians(run_path: Path) -> dict[str, float]:
    data = json.loads(run_path.read_text())
    per_metric: dict[str, list[float]] = {}
    for it in data["iterations"]:
        for k, v in it.items():
            per_metric.setdefault(k, []).append(float(v))
    return {k: summarize_run(v) for k, v in per_metric.items()}


def theil_sen_slope(y: np.ndarray) -> float:
    """Median of pairwise slopes. Units: y-units per index step."""
    n = len(y)
    slopes = []
    for i in range(n):
        for j in range(i + 1, n):
            slopes.append((y[j] - y[i]) / (j - i))
    return float(np.median(slopes))


def mann_kendall_tau(y: np.ndarray) -> tuple[float, float]:
    """Kendall's tau + normal-approx p-value (two-sided)."""
    n = len(y)
    s = 0
    for i in range(n):
        for j in range(i + 1, n):
            s += np.sign(y[j] - y[i])
    var_s = n * (n - 1) * (2 * n + 5) / 18
    if s > 0:
        z = (s - 1) / np.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / np.sqrt(var_s)
    else:
        z = 0.0
    # Two-sided p
    from math import erf, sqrt
    p = 2 * (1 - 0.5 * (1 + erf(abs(z) / sqrt(2))))
    tau = s / (0.5 * n * (n - 1))
    return float(tau), float(p)


def main() -> None:
    cfg, specs = load_config(str(ROOT / "perf-budget.yaml"))
    spec_by_name = {s.name: s for s in specs}
    metric_names = [s.name for s in specs]

    # Load per-run medians (one row per run)
    run_files = sorted(RUNS.glob("run-*.json"))
    per_run = [load_run_medians(f) for f in run_files]
    n_runs = len(per_run)

    # Time series matrix: metrics × runs
    series = np.zeros((len(metric_names), n_runs))
    for i, name in enumerate(metric_names):
        for j, row in enumerate(per_run):
            series[i, j] = row.get(name, np.nan)

    # For each run r >= BASELINE_WINDOW, evaluate against the previous 7 runs
    scorecards: list[list[dict]] = []
    for r in range(n_runs):
        run_score = []
        for i, name in enumerate(metric_names):
            current = series[i, r]
            if r >= BASELINE_WINDOW:
                baseline = list(series[i, r - BASELINE_WINDOW:r])
            else:
                baseline = list(series[i, :r])
            res = evaluate_metric(spec_by_name[name], current, baseline, cfg.get("gate", {}))
            run_score.append(asdict(res))
        scorecards.append(run_score)
    (RESULTS / "per_run_scorecards.json").write_text(json.dumps(scorecards, indent=2))

    # --- Trend statistics per metric ---
    trend_rows = []
    # Drift-vs-first-7-run mean matrix for the heatmap (percent)
    drift_pct = np.full_like(series, np.nan)
    for i, name in enumerate(metric_names):
        spec = spec_by_name[name]
        y = series[i]
        anchor = y[:BASELINE_WINDOW].mean()
        drift_pct[i] = 100.0 * (y - anchor) / anchor

        slope = theil_sen_slope(y)
        tau, p = mann_kendall_tau(y)
        # Projected drift at day 30 in % of anchor
        projected_pct = 100.0 * slope * (n_runs - 1) / anchor
        # Budget consumed = projected_pct / fail_threshold_pct
        if spec.fail_relative is not None:
            fail_pct = spec.fail_relative * 100.0
        else:
            fail_pct = None
        if fail_pct is not None and fail_pct != 0:
            # Stored as a percentage of the fail budget (100 = fully consumed)
            consumed = 100.0 * projected_pct / fail_pct
        else:
            consumed = None

        # For decrease_is_bad metrics, flip sign so "% budget consumed" is
        # positive when the metric is moving in the BAD direction.
        signed_projection = projected_pct if spec.direction == "increase_is_bad" else -projected_pct
        signed_consumed = consumed if spec.direction == "increase_is_bad" else (-consumed if consumed is not None else None)

        trend_rows.append({
            "metric": name,
            "direction": spec.direction,
            "anchor_first7_mean": anchor,
            "final_run_value": y[-1],
            "theil_sen_slope_per_run": slope,
            "projected_drift_pct_30d": projected_pct,
            "signed_drift_pct_30d_bad_positive": signed_projection,
            "mann_kendall_tau": tau,
            "mk_p_value": p,
            "fail_threshold_pct": fail_pct,
            "pct_of_fail_budget_consumed": signed_consumed,
        })

    # Save CSV
    import csv
    with open(RESULTS / "trend_summary.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(trend_rows[0].keys()))
        w.writeheader()
        for row in trend_rows:
            w.writerow(row)

    # --- Heatmap: metrics × runs, colored by drift % vs first-7 anchor ---
    # Flip sign for decrease_is_bad rows so red=bad universally.
    display = drift_pct.copy()
    for i, name in enumerate(metric_names):
        if spec_by_name[name].direction == "decrease_is_bad":
            display[i] = -display[i]

    vmax = max(3.0, float(np.nanmax(np.abs(display))))
    norm = TwoSlopeNorm(vmin=-vmax, vcenter=0, vmax=vmax)

    fig, ax = plt.subplots(figsize=(14, 8))
    im = ax.imshow(display, aspect="auto", cmap="RdBu_r", norm=norm)
    ax.set_yticks(range(len(metric_names)))
    ax.set_yticklabels(metric_names, fontsize=9)
    ax.set_xticks(range(0, n_runs, 2))
    ax.set_xticklabels([f"D{i+1}" for i in range(0, n_runs, 2)], fontsize=8)
    ax.set_xlabel("Nightly run (Day 1 → Day 30)")
    ax.set_title(
        "OTel Perf — 30-day drift heatmap (SYNTHETIC template data)\n"
        "Cell = % drift vs first-7-run anchor, sign-adjusted so red = moving toward failure",
        fontsize=11,
    )
    cbar = plt.colorbar(im, ax=ax, shrink=0.85)
    cbar.set_label("Drift toward failure (%)  →  red = bad")

    # Overlay markers where the evaluator flagged warn/fail
    warn_x, warn_y, fail_x, fail_y = [], [], [], []
    for r, run_score in enumerate(scorecards):
        for i, m in enumerate(run_score):
            if m["status"] == "warn":
                warn_x.append(r); warn_y.append(i)
            elif m["status"] == "fail":
                fail_x.append(r); fail_y.append(i)
    if warn_x:
        ax.scatter(warn_x, warn_y, marker="o", s=25, facecolors="none",
                   edgecolors="black", linewidths=0.8, label="warn")
    if fail_x:
        ax.scatter(fail_x, fail_y, marker="x", s=40, c="black",
                   linewidths=1.4, label="fail")
    if warn_x or fail_x:
        ax.legend(loc="upper right", fontsize=8, framealpha=0.9)

    plt.tight_layout()
    plt.savefig(RESULTS / "heatmap.png", dpi=150)
    print(f"Wrote heatmap: {RESULTS / 'heatmap.png'}")

    # --- Top-3 structural risks ---
    # Rank by signed % budget consumed (positive = moving toward failure),
    # requiring MK monotonicity (|tau| >= 0.3, p < 0.1) AND that the metric
    # has NOT already tripped (so this is a preemptive brief).
    candidates = []
    for row, name in zip(trend_rows, metric_names):
        i = metric_names.index(name)
        already_tripped = any(scorecards[r][i]["status"] == "fail" for r in range(n_runs))
        if already_tripped:
            continue
        if row["pct_of_fail_budget_consumed"] is None:
            continue
        if row["pct_of_fail_budget_consumed"] <= 0:
            continue
        if abs(row["mann_kendall_tau"]) < 0.3 or row["mk_p_value"] > 0.1:
            continue
        candidates.append(row)
    candidates.sort(key=lambda r: r["pct_of_fail_budget_consumed"], reverse=True)
    top3 = candidates[:3]

    # Write brief
    lines = [
        "# OTel Perf — 30-day Structural Efficiency Risk Brief",
        "",
        "> **SYNTHETIC TEMPLATE.** This brief was produced from a synthetic 30-run dataset "
        "with deliberately injected slow drift. Replace the input files in `runs/` with real "
        "scorecard exports from your GitHub Actions artifact history and re-run "
        "`analyze_trend.py` to regenerate against production data.",
        "",
        "## Method",
        "",
        f"- **Data:** 30 nightly runs × 10 iterations, trimmed-median per run.",
        f"- **Baseline per run:** rolling 7 previous runs.",
        f"- **Trend statistics per metric:** Theil–Sen slope (robust to outliers), "
        "Mann-Kendall τ with normal-approx p-value (monotonicity test), "
        "projected drift at day 30 as % of first-7-run anchor.",
        f"- **Ranking:** signed % of fail-threshold budget consumed by the fitted trend, "
        "filtered to metrics that (a) have NOT already tripped the gate, "
        "(b) show statistically significant monotonic drift (|τ|≥0.3, p<0.10), "
        "and (c) are moving toward failure.",
        "",
        "## Top 3 Structural Risks",
        "",
    ]
    for rank, row in enumerate(top3, 1):
        lines += [
            f"### {rank}. `{row['metric']}` — {row['pct_of_fail_budget_consumed']:.1f}% of fail budget consumed",
            "",
            f"- Direction: `{row['direction']}` · Fail threshold: `{row['fail_threshold_pct']:+.1f}%` per-run vs baseline",
            f"- Anchor (first 7 runs): **{row['anchor_first7_mean']:.4g}** → final run: **{row['final_run_value']:.4g}**",
            f"- Projected 30-day drift toward failure: **{row['signed_drift_pct_30d_bad_positive']:+.2f}%**",
            f"- Monotonicity: Kendall τ = **{row['mann_kendall_tau']:+.2f}**, p = **{row['mk_p_value']:.3f}**",
            f"- Theil–Sen slope: **{row['theil_sen_slope_per_run']:+.4g}** per run",
            "",
            "**Interpretation:** " + risk_narrative(row["metric"], row),
            "",
        ]
    if not top3:
        lines += ["*No metric met all three risk criteria in this dataset.*", ""]

    lines += [
        "## How to swap this template for real data",
        "",
        "1. In `otel-perf-nightly.yml`, artifacts named `otel-perf-scorecard-<run_id>` are uploaded "
        "with 90-day retention on every run. Once you have ≥30 successful `main` runs, batch-download them:",
        "   ```bash",
        "   gh run list --workflow otel-perf-nightly.yml --branch main --status success \\",
        "     --limit 30 --json databaseId --jq '.[].databaseId' \\",
        "     | xargs -I{} gh run download {} -n otel-perf-scorecard-{} -D runs/{}",
        "   ```",
        "2. Convert each `scorecard.json` into the `{iterations: [...]}` shape expected by "
        "`analyze_trend.py`. If you emit raw iteration data alongside the scorecard (add a "
        "`--raw-out` flag to `run-bench.sh`), skip this step and point the analyzer directly at those files.",
        "3. Delete `runs/*.json` from this workspace, drop your real files in, and re-run:",
        "   ```bash",
        "   python scripts/analyze_trend.py",
        "   ```",
        "4. Review `results/heatmap.png` and `results/brief.md`. Metrics ranked in the brief "
        "are the ones to address BEFORE they trip the gate.",
        "",
        "## Files produced",
        "",
        "- `results/per_run_scorecards.json` — full evaluator output for every (run, metric) pair",
        "- `results/trend_summary.csv` — one row per metric with all trend statistics",
        "- `results/heatmap.png` — 17 metrics × 30 runs drift heatmap",
        "- `results/brief.md` — this document",
    ]
    (RESULTS / "brief.md").write_text("\n".join(lines))
    print(f"Wrote brief: {RESULTS / 'brief.md'}")
    print(f"Top-3 risks:")
    for rank, row in enumerate(top3, 1):
        print(f"  {rank}. {row['metric']}: {row['pct_of_fail_budget_consumed']:.1f}% budget consumed, τ={row['mann_kendall_tau']:+.2f}, p={row['mk_p_value']:.4f}")


NARRATIVES = {
    "cpu_ns_per_span":
        "CPU cost per span is climbing monotonically. This usually indicates growing "
        "per-span work — a new processor stage, an attribute enrichment path added recently, "
        "or a regression in span-processor hot loops. Investigate recent processor-chain "
        "changes and profile the collector under load to identify the added path.",
    "exporter_send_latency_p99_ms":
        "Tail export latency is drifting up. Likely causes: exporter batch size and "
        "flush interval no longer matched to downstream throughput, growing payload size per "
        "batch, or TCP/TLS handshake churn if connection pooling regressed. Check batch "
        "processor tuning and exporter connection reuse.",
    "heap_bytes_per_span":
        "Heap footprint per span is growing. Prime suspects: attribute cardinality creeping "
        "up (new high-cardinality labels), string-interning regressions, or a processor "
        "retaining references longer than it should. Compare a heap profile from run 1 vs "
        "run 30 and look for growth in map/slice types owned by processors.",
    "rss_peak_mib":
        "Peak RSS is trending up. Combined with heap growth this points to structural "
        "memory bloat; combined with stable heap it points to native/off-heap growth "
        "(e.g. batching queue high-water marks, buffer pools).",
    "exporter_send_latency_p95_ms":
        "p95 latency drift alongside p99 suggests the whole exporter latency distribution "
        "is shifting, not just the tail. Tune batch flush interval and check downstream "
        "backpressure signals.",
    "cpu_peak_percent":
        "Peak CPU% climbing indicates the collector is losing headroom under the same load. "
        "Pair with cpu_ns_per_span to distinguish per-work-unit cost from workload growth.",
    "queue_saturation_max":
        "Queue saturation trending up means the pipeline is edging toward backpressure. "
        "Left unaddressed this leads to dropped spans once saturation hits 1.0.",
    "exporter_send_latency_p50_ms":
        "Median latency drift means the typical request is getting slower — often the "
        "earliest signal of an exporter-side or downstream slowdown.",
    "processor_batch_send_latency_p99_ms":
        "Batch processor flush latency drift usually points to batch size vs interval "
        "tuning drift, or a downstream (exporter) slowdown backing pressure into the batcher.",
    "spans_per_second":
        "Throughput regressing without a workload change indicates lost CPU efficiency; "
        "cross-check against cpu_ns_per_span.",
}


def risk_narrative(name: str, row: dict) -> str:
    return NARRATIVES.get(
        name,
        f"`{name}` shows monotonic drift toward its fail threshold. Investigate recent "
        "changes to the pipeline stage that owns this metric.",
    )


if __name__ == "__main__":
    main()
