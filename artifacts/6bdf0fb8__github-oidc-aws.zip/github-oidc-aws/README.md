# GitHub OIDC → AWS for OTel Collector deploys

Deploy the OpenTelemetry Collector from GitHub Actions to AWS with **zero long-lived credentials**. This bundle gives you:

1. A **Terraform module** (`terraform/`) that provisions the GitHub OIDC identity provider and a repository-scoped IAM role.
2. A **CloudFormation template** (`cloudformation/github-oidc-role.yaml`) that does the same job for teams that don't use Terraform.
3. A **hardened GitHub Actions workflow** (`.github/workflows/deploy-otel-collector.yml`) that uses `aws-actions/configure-aws-credentials` to assume the role via OIDC and deploy the collector to ECS.

---

## How the trust chain works

```
GitHub Actions job
  └─ mints OIDC JWT (iss: token.actions.githubusercontent.com,
                     aud: sts.amazonaws.com,
                     sub: repo:<org>/<repo>:environment:prod, ...)
        │
        ▼
aws-actions/configure-aws-credentials
  └─ calls sts:AssumeRoleWithWebIdentity with the JWT
        │
        ▼
AWS STS validates the token against the OIDC provider,
then checks the trust policy's Condition:
  StringEquals { aud == sts.amazonaws.com, sub == repo:<org>/<repo>:environment:prod }
        │
        ▼
Returns short-lived (≤1h) AWS credentials scoped by the role's inline policies.
```

Because the `sub` claim is **cryptographically bound** to the workflow context (repo, branch, tag, environment), no other repo — even in the same org — can assume this role. See the [GitHub docs on OIDC in AWS](https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-amazon-web-services) for the full claim reference.

---

## Deploy the AWS side

### Option A — Terraform

```bash
cd terraform
terraform init
terraform apply -var-file=example.tfvars
```

Copy the `role_arn` output into a **GitHub Actions repository variable** named `AWS_DEPLOY_ROLE_ARN` (Settings → Secrets and variables → Actions → Variables). Do the same for `AWS_REGION`, `ECS_CLUSTER`, `ECS_SERVICE`, `ECR_REPOSITORY`, and `OTEL_CONFIG_SSM_PARAM`.

Key variables in `variables.tf`:

| Variable | Purpose |
|---|---|
| `github_org`, `github_repo` | Restricts the sub claim. |
| `allowed_refs` | e.g. `["ref:refs/heads/main"]` or `["ref:refs/tags/v*"]`. Wildcards auto-switch the condition to `StringLike`. |
| `allowed_environments` | e.g. `["prod"]` — pair with GitHub Environment protection rules for approvals. |
| `use_immutable_subject_claims` | Turn on for repos created after 2026-07-15 (uses `repo:org@ID/repo@ID:...`). |
| `otel_deployment_target` | `ecs`, `eks`, `ec2_ssm`, `lambda`, or `none`. Controls which least-privilege policy is attached. |

### Option B — CloudFormation

```bash
aws cloudformation deploy \
  --stack-name github-oidc-otel-collector \
  --template-file cloudformation/github-oidc-role.yaml \
  --capabilities CAPABILITY_NAMED_IAM \
  --parameter-overrides \
      GitHubOrg=odisena \
      GitHubRepo=otel-collector-infra \
      AllowedRef=environment:prod \
      AwsRegion=us-east-1 \
      EcsClusterName=observability \
      EcsServiceName=otel-collector \
      EcsTaskExecutionRoleArn=arn:aws:iam::111122223333:role/otel-collector-task-execution \
      EcsTaskRoleArn=arn:aws:iam::111122223333:role/otel-collector-task \
      EcrRepositoryArn=arn:aws:ecr:us-east-1:111122223333:repository/otel-collector
```

If a `token.actions.githubusercontent.com` OIDC provider already exists in the account, pass `CreateOIDCProvider=false ExistingOIDCProviderArn=arn:aws:iam::…:oidc-provider/token.actions.githubusercontent.com`.

---

## Sub-claim recipes

Pick the tightest one that works for your workflow. All examples assume `github_org=odisena`, `github_repo=otel-collector-infra`.

| Goal | `allowed_*` inputs | Resulting sub value |
|---|---|---|
| Only pushes to `main` | `allowed_refs = ["ref:refs/heads/main"]` | `repo:odisena/otel-collector-infra:ref:refs/heads/main` |
| Only signed release tags | `allowed_refs = ["ref:refs/tags/v*"]` | `repo:.../otel-collector-infra:ref:refs/tags/v*` (StringLike) |
| Only the `prod` Environment (recommended) | `allowed_environments = ["prod"]` | `repo:.../otel-collector-infra:environment:prod` |
| PR-preview deploys | `allowed_pull_request = true` | `repo:.../otel-collector-infra:pull_request` |
| Prod env, immutable claims | `use_immutable_subject_claims=true` + IDs | `repo:odisena@12345/otel-collector-infra@67890:environment:prod` |

**Never** use `repo:<org>/<repo>:*` in production — it lets any branch, any PR, any environment assume the role.

---

## The workflow file

`/.github/workflows/deploy-otel-collector.yml` is the template you drop into your app repo. Hardening highlights:

- `permissions: {}` at the top → each job re-declares only what it needs (`id-token: write`, `contents: read`).
- Every third-party action is **SHA-pinned** (not tag-pinned), preventing tag hijacking.
- `step-security/harden-runner` enforces egress policy and disables sudo on the runner.
- `configure-aws-credentials@v4` is called with:
  - `role-to-assume` from a **repository variable**, not a secret (it's not sensitive, and vars are visible in logs which aids audits).
  - `audience: sts.amazonaws.com` matching the trust policy.
  - `role-session-name` that includes `run_id` + `run_attempt`, so CloudTrail rows are traceable to a specific run.
  - `mask-aws-account-id: true` so the account ID never leaks in logs.
  - `role-duration-seconds: 1800` (30 min) — smaller than the role's `max_session_duration`.
- `concurrency` group + `cancel-in-progress: false` prevents overlapping prod deploys.
- `environment: prod` enforces GitHub-side approvals **before** the OIDC token is minted with the `environment:prod` sub claim, so protection rules can't be bypassed.
- `wait-for-service-stability: true` blocks the job until ECS reports a successful rollout, and a post-deploy check asserts `rolloutState == COMPLETED`.

### GitHub-side setup checklist

1. **Environment `prod`**: Settings → Environments → New environment → `prod`.
   - Required reviewers: at least 1.
   - Deployment branches: `Selected branches` → `main`.
2. **Environment variables** on `prod`:
   - `AWS_DEPLOY_ROLE_ARN`, `AWS_REGION`, `ECS_CLUSTER`, `ECS_SERVICE`, `ECR_REPOSITORY`, `OTEL_CONFIG_SSM_PARAM`.
3. **Actions permissions**: Settings → Actions → General → Workflow permissions → *Read repository contents and packages permissions*.
4. **Fork PR policy**: Settings → Actions → General → *Require approval for all outside collaborators*.

---

## Security notes

- **Thumbprints.** Since 2023 AWS validates GitHub's OIDC tokens against a library-managed CA bundle rather than the IAM thumbprint, so a stale thumbprint no longer breaks auth. The Terraform module still fetches the current one dynamically via the `tls_certificate` data source; the CloudFormation template hardcodes both currently-published thumbprints, which is safe.
- **One provider per account.** `AWS::IAM::OIDCProvider` / `aws_iam_openid_connect_provider` for `token.actions.githubusercontent.com` is a singleton per account. If one already exists, set `create_oidc_provider = false` (Terraform) or `CreateOIDCProvider=false` (CloudFormation).
- **PassRole is scoped.** The ECS policy's `iam:PassRole` is limited to the specific task/execution role ARNs you pass in, and further constrained by `iam:PassedToService = ecs-tasks.amazonaws.com`.
- **CloudTrail.** Every assumption shows up as `AssumeRoleWithWebIdentity` with the session name `gha-otel-…-<run_id>-<run_attempt>`. Alert on any assumption where `userIdentity.sessionContext.sessionIssuer` matches this role but the session name doesn't match the expected pattern.
- **Rotate nothing, revoke by policy.** To immediately kill all outstanding sessions, add an inline `Deny *` policy to the role or delete it. There are no keys to rotate.

---

## File layout

```
github-oidc-aws/
├── README.md
├── terraform/
│   ├── versions.tf
│   ├── variables.tf
│   ├── oidc-provider.tf
│   ├── iam-role.tf
│   ├── iam-policies.tf
│   ├── outputs.tf
│   └── example.tfvars
├── cloudformation/
│   └── github-oidc-role.yaml
└── .github/workflows/
    └── deploy-otel-collector.yml
```
