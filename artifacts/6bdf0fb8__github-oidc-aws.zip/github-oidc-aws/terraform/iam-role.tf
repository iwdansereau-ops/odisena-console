########################################
# Trust policy — restrict sts:AssumeRoleWithWebIdentity
# to a specific repo + refs/environments
########################################

locals {
  repo_prefix = var.use_immutable_subject_claims ? "repo:${var.github_org}@${var.github_owner_id}/${var.github_repo}@${var.github_repo_id}" : "repo:${var.github_org}/${var.github_repo}"

  ref_subs = [for r in var.allowed_refs : "${local.repo_prefix}:${r}"]
  env_subs = [for e in var.allowed_environments : "${local.repo_prefix}:environment:${e}"]
  pr_subs  = var.allowed_pull_request ? ["${local.repo_prefix}:pull_request"] : []

  allowed_subs = concat(local.ref_subs, local.env_subs, local.pr_subs)

  # Use StringLike if any sub contains a wildcard, else StringEquals for
  # strict matching. Wildcards are only allowed on refs (e.g. refs/tags/v*).
  uses_wildcard = length([for s in local.allowed_subs : s if can(regex("\\*", s))]) > 0
}

# Guardrail: fail plan if the caller didn't restrict the trust policy.
resource "terraform_data" "guard_trust_policy" {
  lifecycle {
    precondition {
      condition     = length(local.allowed_subs) > 0
      error_message = "You must set at least one of allowed_refs, allowed_environments, or allowed_pull_request. Untargeted trust policies let any workflow in the repo assume this role."
    }
  }
}

data "aws_iam_policy_document" "trust" {
  statement {
    sid     = "GitHubOIDCAssumeRole"
    effect  = "Allow"
    actions = ["sts:AssumeRoleWithWebIdentity"]

    principals {
      type        = "Federated"
      identifiers = [local.oidc_provider_arn]
    }

    # Always pin the audience.
    condition {
      test     = "StringEquals"
      variable = "token.actions.githubusercontent.com:aud"
      values   = var.github_oidc_audience
    }

    # Pin the sub claim(s). StringLike only when a wildcard is present.
    condition {
      test     = local.uses_wildcard ? "StringLike" : "StringEquals"
      variable = "token.actions.githubusercontent.com:sub"
      values   = local.allowed_subs
    }
  }
}

########################################
# The role
########################################

resource "aws_iam_role" "github_actions" {
  name                 = var.role_name
  description          = var.role_description
  assume_role_policy   = data.aws_iam_policy_document.trust.json
  max_session_duration = var.max_session_duration
  permissions_boundary = var.permissions_boundary_arn != "" ? var.permissions_boundary_arn : null

  tags = merge(
    var.tags,
    {
      Name      = var.role_name
      ManagedBy = "terraform"
      Purpose   = "otel-collector-deploy"
    },
  )
}
