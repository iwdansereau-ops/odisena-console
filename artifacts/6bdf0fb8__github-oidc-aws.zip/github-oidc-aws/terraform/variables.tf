########################################
# GitHub OIDC provider inputs
########################################

variable "create_oidc_provider" {
  description = <<-EOT
    Whether to create the GitHub OIDC identity provider in this account.
    Set to false if another module/stack already manages it (there can only
    be one provider per URL per AWS account).
  EOT
  type        = bool
  default     = true
}

variable "existing_oidc_provider_arn" {
  description = "ARN of a pre-existing GitHub OIDC provider. Required when create_oidc_provider = false."
  type        = string
  default     = ""
}

variable "github_oidc_audience" {
  description = "OIDC audience. Must be sts.amazonaws.com for aws-actions/configure-aws-credentials."
  type        = list(string)
  default     = ["sts.amazonaws.com"]
}

variable "additional_thumbprints" {
  description = <<-EOT
    Extra thumbprints to attach to the OIDC provider. AWS no longer performs
    strict thumbprint verification for token.actions.githubusercontent.com,
    but the field is still required by the API. The module dynamically fetches
    the current thumbprint from the OIDC issuer; use this only to pin extras.
  EOT
  type        = list(string)
  default     = []
}

########################################
# Repository / role trust inputs
########################################

variable "github_org" {
  description = "GitHub organization or user that owns the repository (e.g. odisena)."
  type        = string
}

variable "github_repo" {
  description = "GitHub repository name (e.g. otel-collector-infra)."
  type        = string
}

variable "allowed_refs" {
  description = <<-EOT
    List of git refs that may assume the role, e.g.
    ["ref:refs/heads/main", "ref:refs/tags/v*"].
    Leave empty if you are pinning via `allowed_environments` instead.
  EOT
  type        = list(string)
  default     = []
}

variable "allowed_environments" {
  description = <<-EOT
    List of GitHub Environments allowed to assume the role, e.g. ["prod"].
    When set, the `sub` claim must be
    `repo:<org>/<repo>:environment:<name>`. Recommended for production.
  EOT
  type        = list(string)
  default     = []
}

variable "allowed_pull_request" {
  description = "Whether to allow role assumption from pull_request events (repo:org/repo:pull_request)."
  type        = bool
  default     = false
}

variable "use_immutable_subject_claims" {
  description = <<-EOT
    For repositories created after 2026-07-15 or opted in to immutable
    subject claims. When true, github_owner_id and github_repo_id must be set.
  EOT
  type        = bool
  default     = false
}

variable "github_owner_id" {
  description = "Numeric owner ID (only used when use_immutable_subject_claims = true)."
  type        = string
  default     = ""
}

variable "github_repo_id" {
  description = "Numeric repository ID (only used when use_immutable_subject_claims = true)."
  type        = string
  default     = ""
}

########################################
# IAM role inputs
########################################

variable "role_name" {
  description = "Name of the IAM role assumed by GitHub Actions."
  type        = string
  default     = "github-actions-otel-collector-deploy"
}

variable "role_description" {
  description = "Description of the IAM role."
  type        = string
  default     = "Assumed by GitHub Actions via OIDC to deploy the OpenTelemetry Collector."
}

variable "max_session_duration" {
  description = "Maximum session duration for the assumed role, in seconds (900 – 43200)."
  type        = number
  default     = 3600
}

variable "permissions_boundary_arn" {
  description = "Optional permissions boundary ARN for the role."
  type        = string
  default     = ""
}

########################################
# OTel Collector deployment scope
########################################

variable "otel_deployment_target" {
  description = <<-EOT
    Deployment target for the OTel Collector. Determines the least-privilege
    policy attached to the role:

    - "ecs"        : update an ECS service (task definition + service).
    - "eks"        : deploy via Helm/kubectl by describing the cluster.
    - "ec2_ssm"    : push config to instances via SSM Run Command.
    - "lambda"     : update a Lambda extension layer.
    - "none"       : attach no deployment policy (bring your own).
  EOT
  type        = string
  default     = "ecs"

  validation {
    condition     = contains(["ecs", "eks", "ec2_ssm", "lambda", "none"], var.otel_deployment_target)
    error_message = "otel_deployment_target must be one of: ecs, eks, ec2_ssm, lambda, none."
  }
}

variable "aws_region" {
  description = "AWS region where the OTel Collector is deployed (used to scope resource ARNs)."
  type        = string
}

variable "ecs_cluster_name" {
  description = "ECS cluster name (required when otel_deployment_target = ecs)."
  type        = string
  default     = ""
}

variable "ecs_service_name" {
  description = "ECS service name for the OTel Collector (required when otel_deployment_target = ecs)."
  type        = string
  default     = ""
}

variable "ecs_task_execution_role_arn" {
  description = "ARN of the ECS task execution role (needed so the deploy role can PassRole it)."
  type        = string
  default     = ""
}

variable "ecs_task_role_arn" {
  description = "ARN of the ECS task role used by the collector task."
  type        = string
  default     = ""
}

variable "eks_cluster_name" {
  description = "EKS cluster name (required when otel_deployment_target = eks)."
  type        = string
  default     = ""
}

variable "ssm_target_tag_key" {
  description = "EC2 tag key used to target SSM Run Command (required when otel_deployment_target = ec2_ssm)."
  type        = string
  default     = "otel-collector"
}

variable "ssm_target_tag_value" {
  description = "EC2 tag value used to target SSM Run Command (required when otel_deployment_target = ec2_ssm)."
  type        = string
  default     = "true"
}

variable "ssm_parameter_prefix" {
  description = "SSM parameter path prefix that stores the collector configuration (e.g. /otel/collector/)."
  type        = string
  default     = "/otel/collector/"
}

variable "lambda_function_names" {
  description = "Lambda function names to update (required when otel_deployment_target = lambda)."
  type        = list(string)
  default     = []
}

variable "artifact_s3_bucket" {
  description = "Optional S3 bucket that holds collector configs / Helm charts / ECR-adjacent artifacts."
  type        = string
  default     = ""
}

variable "ecr_repository_arns" {
  description = "Optional list of ECR repository ARNs the workflow may push collector images to."
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Tags applied to all created resources."
  type        = map(string)
  default     = {}
}
