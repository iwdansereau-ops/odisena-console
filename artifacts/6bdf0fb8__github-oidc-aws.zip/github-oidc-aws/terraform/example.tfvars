########################################
# Example: OTel Collector on ECS Fargate,
# only main branch and prod environment
# in the odisena/otel-collector-infra repo.
########################################

aws_region = "us-east-1"

github_org  = "odisena"
github_repo = "otel-collector-infra"

# Tightest possible: only the prod GitHub Environment on main.
allowed_refs         = ["ref:refs/heads/main"]
allowed_environments = ["prod"]

# ECS target
otel_deployment_target      = "ecs"
ecs_cluster_name            = "observability"
ecs_service_name            = "otel-collector"
ecs_task_execution_role_arn = "arn:aws:iam::111122223333:role/otel-collector-task-execution"
ecs_task_role_arn           = "arn:aws:iam::111122223333:role/otel-collector-task"

# Optional artifact plumbing
artifact_s3_bucket = "odisena-otel-artifacts"
ecr_repository_arns = [
  "arn:aws:ecr:us-east-1:111122223333:repository/otel-collector",
]

# Config parameters
ssm_parameter_prefix = "/otel/collector/"

tags = {
  Owner       = "platform-observability"
  Environment = "prod"
  Component   = "otel-collector"
}
