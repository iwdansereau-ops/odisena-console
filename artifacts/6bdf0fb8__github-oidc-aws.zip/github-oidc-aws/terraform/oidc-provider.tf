########################################
# GitHub OIDC identity provider
########################################

# Dynamically fetch the current thumbprint from the OIDC issuer so we never
# hardcode a certificate that could be rotated by GitHub. AWS no longer
# strictly validates this thumbprint for token.actions.githubusercontent.com,
# but the API still requires the field.
data "tls_certificate" "github" {
  count = var.create_oidc_provider ? 1 : 0
  url   = "https://token.actions.githubusercontent.com/.well-known/openid-configuration"
}

resource "aws_iam_openid_connect_provider" "github" {
  count = var.create_oidc_provider ? 1 : 0

  url            = "https://token.actions.githubusercontent.com"
  client_id_list = var.github_oidc_audience

  # The thumbprint_list field is required by the API but AWS no longer
  # strictly verifies it for token.actions.githubusercontent.com — token
  # signatures are validated against a library-managed CA bundle. We still
  # populate it dynamically from the current OIDC issuer certificate chain
  # so plans stay clean even if GitHub rotates its cert.
  thumbprint_list = distinct(concat(
    [for c in data.tls_certificate.github[0].certificates : c.sha1_fingerprint],
    var.additional_thumbprints,
  ))

  tags = merge(
    var.tags,
    {
      Name      = "github-actions-oidc"
      ManagedBy = "terraform"
    },
  )
}

locals {
  oidc_provider_arn = var.create_oidc_provider ? aws_iam_openid_connect_provider.github[0].arn : var.existing_oidc_provider_arn
}
