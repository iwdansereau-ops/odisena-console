output "oidc_provider_arn" {
  description = "ARN of the GitHub OIDC identity provider used by the role."
  value       = local.oidc_provider_arn
}

output "role_arn" {
  description = "ARN of the IAM role. Set this as the AWS_DEPLOY_ROLE_ARN GitHub Actions secret/variable."
  value       = aws_iam_role.github_actions.arn
}

output "role_name" {
  description = "Name of the IAM role."
  value       = aws_iam_role.github_actions.name
}

output "trust_policy_json" {
  description = "Rendered trust policy JSON (useful for auditing)."
  value       = data.aws_iam_policy_document.trust.json
}

output "allowed_subject_claims" {
  description = "List of sub-claim values allowed by the trust policy."
  value       = local.allowed_subs
}
