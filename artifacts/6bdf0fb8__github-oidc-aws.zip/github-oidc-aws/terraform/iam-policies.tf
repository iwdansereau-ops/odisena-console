########################################
# Least-privilege deployment policies for the OTel Collector
########################################

data "aws_caller_identity" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  region     = var.aws_region
}

########################################
# Shared: pull collector config from SSM Parameter Store + KMS decrypt
########################################

data "aws_iam_policy_document" "ssm_params_read" {
  statement {
    sid     = "ReadCollectorConfigParams"
    effect  = "Allow"
    actions = ["ssm:GetParameter", "ssm:GetParameters", "ssm:GetParametersByPath"]
    resources = [
      "arn:aws:ssm:${local.region}:${local.account_id}:parameter${var.ssm_parameter_prefix}*",
    ]
  }
}

resource "aws_iam_policy" "ssm_params_read" {
  name        = "${var.role_name}-ssm-config-read"
  description = "Read OTel Collector configuration from SSM Parameter Store."
  policy      = data.aws_iam_policy_document.ssm_params_read.json
  tags        = var.tags
}

resource "aws_iam_role_policy_attachment" "ssm_params_read" {
  role       = aws_iam_role.github_actions.name
  policy_arn = aws_iam_policy.ssm_params_read.arn
}

########################################
# Optional: S3 artifact bucket (Helm charts, configs, plans)
########################################

data "aws_iam_policy_document" "artifact_s3" {
  count = var.artifact_s3_bucket != "" ? 1 : 0

  statement {
    sid       = "ListArtifactBucket"
    effect    = "Allow"
    actions   = ["s3:ListBucket", "s3:GetBucketLocation"]
    resources = ["arn:aws:s3:::${var.artifact_s3_bucket}"]
  }

  statement {
    sid    = "ReadWriteArtifacts"
    effect = "Allow"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:AbortMultipartUpload",
    ]
    resources = ["arn:aws:s3:::${var.artifact_s3_bucket}/*"]
  }
}

resource "aws_iam_policy" "artifact_s3" {
  count       = var.artifact_s3_bucket != "" ? 1 : 0
  name        = "${var.role_name}-artifact-s3"
  description = "Access to OTel Collector artifact bucket."
  policy      = data.aws_iam_policy_document.artifact_s3[0].json
  tags        = var.tags
}

resource "aws_iam_role_policy_attachment" "artifact_s3" {
  count      = var.artifact_s3_bucket != "" ? 1 : 0
  role       = aws_iam_role.github_actions.name
  policy_arn = aws_iam_policy.artifact_s3[0].arn
}

########################################
# Optional: ECR push (build & publish collector image)
########################################

data "aws_iam_policy_document" "ecr" {
  count = length(var.ecr_repository_arns) > 0 ? 1 : 0

  statement {
    sid       = "ECRAuth"
    effect    = "Allow"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid    = "ECRPush"
    effect = "Allow"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:BatchGetImage",
      "ecr:CompleteLayerUpload",
      "ecr:DescribeImages",
      "ecr:DescribeRepositories",
      "ecr:GetDownloadUrlForLayer",
      "ecr:InitiateLayerUpload",
      "ecr:PutImage",
      "ecr:UploadLayerPart",
    ]
    resources = var.ecr_repository_arns
  }
}

resource "aws_iam_policy" "ecr" {
  count       = length(var.ecr_repository_arns) > 0 ? 1 : 0
  name        = "${var.role_name}-ecr-push"
  description = "Push OTel Collector images to ECR."
  policy      = data.aws_iam_policy_document.ecr[0].json
  tags        = var.tags
}

resource "aws_iam_role_policy_attachment" "ecr" {
  count      = length(var.ecr_repository_arns) > 0 ? 1 : 0
  role       = aws_iam_role.github_actions.name
  policy_arn = aws_iam_policy.ecr[0].arn
}

########################################
# Target: ECS service update
########################################

data "aws_iam_policy_document" "ecs" {
  count = var.otel_deployment_target == "ecs" ? 1 : 0

  statement {
    sid    = "ECSRegisterTaskDefinition"
    effect = "Allow"
    actions = [
      "ecs:RegisterTaskDefinition",
      "ecs:DescribeTaskDefinition",
      "ecs:DeregisterTaskDefinition",
      "ecs:ListTaskDefinitions",
    ]
    # ECS API requires "*" for RegisterTaskDefinition — cannot be resource-scoped.
    resources = ["*"]
  }

  statement {
    sid    = "ECSUpdateCollectorService"
    effect = "Allow"
    actions = [
      "ecs:UpdateService",
      "ecs:DescribeServices",
      "ecs:DescribeTasks",
      "ecs:ListTasks",
    ]
    resources = [
      "arn:aws:ecs:${local.region}:${local.account_id}:service/${var.ecs_cluster_name}/${var.ecs_service_name}",
      "arn:aws:ecs:${local.region}:${local.account_id}:task/${var.ecs_cluster_name}/*",
    ]
  }

  statement {
    sid       = "PassECSRoles"
    effect    = "Allow"
    actions   = ["iam:PassRole"]
    resources = compact([var.ecs_task_execution_role_arn, var.ecs_task_role_arn])

    condition {
      test     = "StringEquals"
      variable = "iam:PassedToService"
      values   = ["ecs-tasks.amazonaws.com"]
    }
  }
}

resource "aws_iam_policy" "ecs" {
  count       = var.otel_deployment_target == "ecs" ? 1 : 0
  name        = "${var.role_name}-ecs-deploy"
  description = "Deploy the OTel Collector to ECS."
  policy      = data.aws_iam_policy_document.ecs[0].json
  tags        = var.tags
}

resource "aws_iam_role_policy_attachment" "ecs" {
  count      = var.otel_deployment_target == "ecs" ? 1 : 0
  role       = aws_iam_role.github_actions.name
  policy_arn = aws_iam_policy.ecs[0].arn
}

########################################
# Target: EKS (assumes IRSA/aws-auth grants k8s-level perms separately)
########################################

data "aws_iam_policy_document" "eks" {
  count = var.otel_deployment_target == "eks" ? 1 : 0

  statement {
    sid       = "DescribeCluster"
    effect    = "Allow"
    actions   = ["eks:DescribeCluster", "eks:ListClusters"]
    resources = ["arn:aws:eks:${local.region}:${local.account_id}:cluster/${var.eks_cluster_name}"]
  }
}

resource "aws_iam_policy" "eks" {
  count       = var.otel_deployment_target == "eks" ? 1 : 0
  name        = "${var.role_name}-eks-deploy"
  description = "Describe EKS cluster for OTel Collector Helm/kubectl deploys."
  policy      = data.aws_iam_policy_document.eks[0].json
  tags        = var.tags
}

resource "aws_iam_role_policy_attachment" "eks" {
  count      = var.otel_deployment_target == "eks" ? 1 : 0
  role       = aws_iam_role.github_actions.name
  policy_arn = aws_iam_policy.eks[0].arn
}

########################################
# Target: EC2 + SSM Run Command
########################################

data "aws_iam_policy_document" "ec2_ssm" {
  count = var.otel_deployment_target == "ec2_ssm" ? 1 : 0

  statement {
    sid    = "SendRunCommandToTaggedInstances"
    effect = "Allow"
    actions = [
      "ssm:SendCommand",
    ]
    resources = [
      "arn:aws:ec2:${local.region}:${local.account_id}:instance/*",
    ]

    condition {
      test     = "StringEquals"
      variable = "ssm:resourceTag/${var.ssm_target_tag_key}"
      values   = [var.ssm_target_tag_value]
    }
  }

  statement {
    sid    = "AllowManagedDocuments"
    effect = "Allow"
    actions = [
      "ssm:SendCommand",
    ]
    resources = [
      "arn:aws:ssm:${local.region}::document/AWS-RunShellScript",
      "arn:aws:ssm:${local.region}::document/AWS-RunPowerShellScript",
      "arn:aws:ssm:${local.region}::document/AmazonCloudWatch-ManageAgent",
    ]
  }

  statement {
    sid    = "TrackCommandExecution"
    effect = "Allow"
    actions = [
      "ssm:ListCommands",
      "ssm:ListCommandInvocations",
      "ssm:GetCommandInvocation",
      "ssm:DescribeInstanceInformation",
    ]
    resources = ["*"]
  }
}

resource "aws_iam_policy" "ec2_ssm" {
  count       = var.otel_deployment_target == "ec2_ssm" ? 1 : 0
  name        = "${var.role_name}-ec2-ssm-deploy"
  description = "Push OTel Collector config to EC2 instances via SSM Run Command."
  policy      = data.aws_iam_policy_document.ec2_ssm[0].json
  tags        = var.tags
}

resource "aws_iam_role_policy_attachment" "ec2_ssm" {
  count      = var.otel_deployment_target == "ec2_ssm" ? 1 : 0
  role       = aws_iam_role.github_actions.name
  policy_arn = aws_iam_policy.ec2_ssm[0].arn
}

########################################
# Target: Lambda extension update
########################################

data "aws_iam_policy_document" "lambda" {
  count = var.otel_deployment_target == "lambda" ? 1 : 0

  statement {
    sid    = "UpdateCollectorLambdas"
    effect = "Allow"
    actions = [
      "lambda:UpdateFunctionConfiguration",
      "lambda:UpdateFunctionCode",
      "lambda:GetFunction",
      "lambda:GetFunctionConfiguration",
      "lambda:PublishLayerVersion",
      "lambda:GetLayerVersion",
    ]
    resources = [for name in var.lambda_function_names : "arn:aws:lambda:${local.region}:${local.account_id}:function:${name}"]
  }

  statement {
    sid       = "PublishLayer"
    effect    = "Allow"
    actions   = ["lambda:PublishLayerVersion"]
    resources = ["arn:aws:lambda:${local.region}:${local.account_id}:layer:otel-collector-*"]
  }
}

resource "aws_iam_policy" "lambda" {
  count       = var.otel_deployment_target == "lambda" ? 1 : 0
  name        = "${var.role_name}-lambda-deploy"
  description = "Update OTel Collector Lambda extensions."
  policy      = data.aws_iam_policy_document.lambda[0].json
  tags        = var.tags
}

resource "aws_iam_role_policy_attachment" "lambda" {
  count      = var.otel_deployment_target == "lambda" ? 1 : 0
  role       = aws_iam_role.github_actions.name
  policy_arn = aws_iam_policy.lambda[0].arn
}
