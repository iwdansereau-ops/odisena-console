#!/usr/bin/env python3
"""
validate_oidc_trust.py

Confirms that the IAM roles provisioned by the terraform-aws-github-oidc
module can be assumed *only* by GitHub-signed OIDC tokens whose claims
match the trust policy — across both staging and production accounts.

The script runs a matrix of negative and positive assertions against each
role:

    1. NEGATIVE: sts:AssumeRoleWithWebIdentity using a locally-minted
       (self-signed) JWT whose payload claims to be from
       token.actions.githubusercontent.com. AWS must reject it because
       the token is not signed by GitHub's OIDC keys.

    2. NEGATIVE: sts:AssumeRoleWithWebIdentity using a *real* GitHub
       Actions ID token from another repository / another branch / a
       pull_request context. AWS must reject it because `sub` does not
       match the allowlist.

    3. NEGATIVE: sts:AssumeRoleWithWebIdentity using a real GitHub token
       minted with a custom audience (`aud != sts.amazonaws.com`). AWS
       must reject it because of the audience condition.

    4. POSITIVE (only when running inside GitHub Actions): use the ambient
       ACTIONS_ID_TOKEN_REQUEST_URL/TOKEN to mint a real OIDC token that
       matches the trust policy and assume the role.

    5. NEGATIVE: sts:AssumeRole (long-lived-credentials path) against the
       same role using whatever credentials the shell is running with.
       AWS must reject it — the trust policy only lists a Federated
       principal.

Every negative case is *expected* to fail with a specific error code
(InvalidIdentityToken / AccessDenied). If AWS ever returns credentials
for a negative case, the script exits non-zero.

Requires: python >= 3.9, boto3, PyJWT, requests.

Usage:
    python validate_oidc_trust.py \\
        --staging-role-arn arn:aws:iam::111:role/github-actions-otel-staging \\
        --production-role-arn arn:aws:iam::222:role/github-actions-otel-production \\
        --github-org my-org --github-repo otel-pipeline

When invoked from a GitHub Actions workflow, the environment variables
ACTIONS_ID_TOKEN_REQUEST_URL and ACTIONS_ID_TOKEN_REQUEST_TOKEN are used
to fetch real OIDC tokens for the positive assertions.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
from dataclasses import dataclass
from typing import Optional

import boto3
import botocore
import jwt  # PyJWT
import requests
from botocore.config import Config
from botocore.exceptions import ClientError

GITHUB_OIDC_ISSUER = "https://token.actions.githubusercontent.com"
GITHUB_OIDC_AUDIENCE = "sts.amazonaws.com"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def mint_self_signed_token(sub: str, aud: str = GITHUB_OIDC_AUDIENCE) -> str:
    """Mint a locally-signed JWT that *claims* to be from GitHub.

    Because it is signed with a random HS256 key (not GitHub's private OIDC
    signing key), AWS STS will fail signature verification and return
    InvalidIdentityToken. This is the check we want.
    """
    now = int(time.time())
    payload = {
        "iss": GITHUB_OIDC_ISSUER.removeprefix("https://"),
        "sub": sub,
        "aud": aud,
        "iat": now,
        "nbf": now,
        "exp": now + 300,
        "jti": base64.urlsafe_b64encode(os.urandom(12)).decode("ascii"),
    }
    # Deliberately bogus signing key — the whole point is that STS must
    # reject this token.
    return jwt.encode(payload, "not-githubs-private-key", algorithm="HS256")


def get_github_actions_token(audience: str = GITHUB_OIDC_AUDIENCE) -> Optional[str]:
    """Fetch a real GitHub Actions OIDC ID token if running in CI.

    Requires the workflow to declare `permissions: id-token: write`.
    """
    url = os.environ.get("ACTIONS_ID_TOKEN_REQUEST_URL")
    tok = os.environ.get("ACTIONS_ID_TOKEN_REQUEST_TOKEN")
    if not url or not tok:
        return None
    resp = requests.get(
        url,
        params={"audience": audience},
        headers={"Authorization": f"Bearer {tok}"},
        timeout=10,
    )
    resp.raise_for_status()
    return resp.json()["value"]


def decode_unverified(token: str) -> dict:
    return jwt.decode(token, options={"verify_signature": False})


# ---------------------------------------------------------------------------
# Assertions
# ---------------------------------------------------------------------------

@dataclass
class Result:
    name: str
    passed: bool
    detail: str


def assume_with_web_identity(role_arn: str, token: str) -> tuple[bool, str]:
    """Attempt sts:AssumeRoleWithWebIdentity. Returns (succeeded, detail)."""
    # Deliberately use an unsigned STS client — AssumeRoleWithWebIdentity
    # does not require caller credentials, and this ensures our own env
    # doesn't accidentally satisfy the request.
    sts = boto3.client(
        "sts",
        region_name="us-east-1",
        config=Config(signature_version=botocore.UNSIGNED),
    )
    try:
        sts.assume_role_with_web_identity(
            RoleArn=role_arn,
            RoleSessionName="oidc-validation",
            WebIdentityToken=token,
            DurationSeconds=900,
        )
        return True, "STS returned credentials (UNEXPECTED for negative test)"
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "UnknownError")
        msg = e.response.get("Error", {}).get("Message", "")
        return False, f"{code}: {msg}"


def expect_reject(name: str, role_arn: str, token: str, expected_codes: set[str]) -> Result:
    ok, detail = assume_with_web_identity(role_arn, token)
    if ok:
        return Result(name, False, f"role assumed unexpectedly: {detail}")
    # Extract code
    code = detail.split(":", 1)[0]
    if code in expected_codes:
        return Result(name, True, f"rejected as expected ({code})")
    return Result(name, False, f"rejected with unexpected code: {detail}")


def expect_accept(name: str, role_arn: str, token: str) -> Result:
    ok, detail = assume_with_web_identity(role_arn, token)
    if ok:
        return Result(name, True, "STS returned temporary credentials")
    return Result(name, False, f"STS refused a token that should have been accepted: {detail}")


def test_static_creds_rejected(role_arn: str) -> Result:
    """sts:AssumeRole (non-federated) against the same role must be denied."""
    name = f"static-creds-rejected [{role_arn.split(':')[-1]}]"
    try:
        sts = boto3.client("sts")
        sts.assume_role(RoleArn=role_arn, RoleSessionName="oidc-validation-static")
        return Result(name, False, "AssumeRole succeeded — trust policy is too permissive")
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "UnknownError")
        if code == "AccessDenied":
            return Result(name, True, "AssumeRole denied as expected")
        return Result(name, False, f"unexpected error code: {code}")
    except Exception as e:  # noqa: BLE001
        return Result(name, False, f"unexpected exception: {e!r}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run_matrix(
    role_arn: str,
    env_label: str,
    github_org: str,
    github_repo: str,
    valid_sub: str,
) -> list[Result]:
    results: list[Result] = []

    # (1) Locally-signed JWT with otherwise-valid claims.
    forged = mint_self_signed_token(sub=valid_sub)
    results.append(expect_reject(
        f"self-signed-JWT-rejected [{env_label}]",
        role_arn,
        forged,
        expected_codes={"InvalidIdentityToken", "AccessDenied"},
    ))

    # (2) Locally-signed JWT with a *foreign* repo sub — even if signing
    #     worked, sub would not match. Belt-and-suspenders.
    foreign = mint_self_signed_token(sub="repo:attacker-org/attacker-repo:ref:refs/heads/main")
    results.append(expect_reject(
        f"foreign-repo-sub-rejected [{env_label}]",
        role_arn,
        foreign,
        expected_codes={"InvalidIdentityToken", "AccessDenied"},
    ))

    # (3) Locally-signed JWT with wrong audience.
    wrong_aud = mint_self_signed_token(sub=valid_sub, aud="my-service")
    results.append(expect_reject(
        f"wrong-audience-rejected [{env_label}]",
        role_arn,
        wrong_aud,
        expected_codes={"InvalidIdentityToken", "AccessDenied"},
    ))

    # (4) Real GitHub token, but only if we're in Actions AND the caller
    #     asked us to run positive assertions from this workflow. We also
    #     run the "wrong-aud but real signature" negative test here since
    #     it requires GitHub to actually mint the token.
    real_ok = get_github_actions_token(audience=GITHUB_OIDC_AUDIENCE)
    if real_ok:
        claims = decode_unverified(real_ok)
        sub = claims.get("sub", "")
        if sub == valid_sub:
            results.append(expect_accept(
                f"real-github-token-accepted [{env_label}]",
                role_arn,
                real_ok,
            ))
        else:
            # Real signature but different sub (e.g. running on a PR
            # branch). Must still be rejected.
            results.append(expect_reject(
                f"real-github-token-wrong-sub-rejected [{env_label}] (sub={sub})",
                role_arn,
                real_ok,
                expected_codes={"AccessDenied"},
            ))

        # Real signature with a custom audience must fail the aud check.
        real_wrong_aud = get_github_actions_token(audience=f"validation-{github_org}-{github_repo}")
        if real_wrong_aud:
            results.append(expect_reject(
                f"real-github-token-wrong-aud-rejected [{env_label}]",
                role_arn,
                real_wrong_aud,
                expected_codes={"AccessDenied"},
            ))
    else:
        results.append(Result(
            f"real-github-token-skipped [{env_label}]",
            True,
            "not running inside GitHub Actions (ACTIONS_ID_TOKEN_REQUEST_* unset)",
        ))

    # (5) Non-federated AssumeRole must be denied.
    results.append(test_static_creds_rejected(role_arn))

    return results


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--staging-role-arn", required=True)
    p.add_argument("--production-role-arn", required=True)
    p.add_argument("--github-org", required=True)
    p.add_argument("--github-repo", required=True)
    p.add_argument(
        "--staging-valid-sub",
        default=None,
        help="Expected valid sub for staging (default: repo:<org>/<repo>:environment:staging)",
    )
    p.add_argument(
        "--production-valid-sub",
        default=None,
        help="Expected valid sub for production (default: repo:<org>/<repo>:environment:production)",
    )
    args = p.parse_args()

    staging_sub = args.staging_valid_sub or f"repo:{args.github_org}/{args.github_repo}:environment:staging"
    prod_sub = args.production_valid_sub or f"repo:{args.github_org}/{args.github_repo}:environment:production"

    all_results: list[Result] = []
    all_results += run_matrix(args.staging_role_arn, "staging", args.github_org, args.github_repo, staging_sub)
    all_results += run_matrix(args.production_role_arn, "production", args.github_org, args.github_repo, prod_sub)

    width = max(len(r.name) for r in all_results)
    failed = 0
    for r in all_results:
        status = "PASS" if r.passed else "FAIL"
        print(f"[{status}] {r.name.ljust(width)}  {r.detail}")
        if not r.passed:
            failed += 1

    print()
    print(f"Total: {len(all_results)}   Failed: {failed}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
