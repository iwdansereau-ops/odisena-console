# terraform-aws-github-oidc

Reusable IaC module that provisions:

1. An **IAM OIDC identity provider** for `token.actions.githubusercontent.com`.
2. An **IAM role** with a strict trust policy pinned to a specific repo and to enumerated branches / tags / GitHub deployment environments — no wildcards, no cross-repo access.
3. A **least-privilege inline policy** for a sample OpenTelemetry (OTel) telemetry pipeline.
4. A **validation script** that proves — from both staging and production accounts — that only genuine, GitHub-signed OIDC tokens matching the trust policy can assume the role.

```
terraform-aws-github-oidc/
├── modules/github-oidc/          # the reusable module (provider + role + trust policy)
├── policies/                     # least-privilege OTel pipeline policy
├── examples/otel-pipeline/       # staging + prod wiring, dual-provider
└── scripts/
    ├── validate_oidc_trust.py    # negative + positive assertion matrix
    ├── requirements.txt
    └── validate.yml              # reference GitHub Actions workflow
```

## Why this design

`sts:AssumeRoleWithWebIdentity` is only as safe as the trust policy attached to the target role. The common mistakes are:

- Using `StringLike` on `sub` with `repo:my-org/*` — this hands the role to every repo in the org.
- Omitting the `aud` condition — a workflow can then request a token with a custom audience and bypass third-party audience checks.
- Sharing one role between environments — a `main`-branch push can then affect production.

This module fails closed against all three:

| Trust-policy control            | Enforced by                                                                 |
| ------------------------------- | --------------------------------------------------------------------------- |
| Correct issuer                  | `StringEquals` on `token.actions.githubusercontent.com:iss`                 |
| Correct audience                | `StringEquals` on `...:aud = sts.amazonaws.com`                             |
| Only this repo                  | `sub` prefix always `repo:<org>/<repo>:...`                                 |
| Only these branches/tags/envs   | `StringEquals` (never `StringLike`) on `sub` against an enumerated list     |
| No accidental wildcard          | Module rejects `*` / `?` in `allowed_branches` and `allowed_tags`           |
| No accidental empty allowlist   | `precondition` on `aws_iam_role` fails plan if no `sub` values are supplied |
| Only Federated principal        | Trust policy names no IAM users, roles, or root                             |

## Usage

Minimal:

```hcl
module "gha_role" {
  source = "github.com/your-org/terraform-aws-github-oidc//modules/github-oidc"

  github_org  = "my-org"
  github_repo = "otel-pipeline"
  role_name   = "github-actions-otel-staging"
  environment = "staging"

  allowed_branches     = ["main"]
  allowed_environments = ["staging"]

  inline_policies = {
    "otel-pipeline" = data.aws_iam_policy_document.otel.json
  }
}
```

See [`examples/otel-pipeline`](examples/otel-pipeline/main.tf) for a full dual-account (staging + production) wiring, including the least-privilege OTel policy.

### Re-using an existing OIDC provider

AWS only permits one OIDC provider per issuer per account. If the provider already exists:

```hcl
module "gha_role" {
  source = "..."

  create_oidc_provider       = false
  existing_oidc_provider_arn = "arn:aws:iam::123456789012:oidc-provider/token.actions.githubusercontent.com"
  # ...
}
```

## OTel pipeline policy

`policies/otel-pipeline-policy.tf` is a `data "aws_iam_policy_document"` that grants exactly what a GitHub Actions job needs to build and deploy an OTel collector:

- CloudWatch Logs writes scoped to `/otel/pipeline*`
- `cloudwatch:PutMetricData` scoped to a single namespace via a `Condition`
- X-Ray `Put*` (no ARN-level authz exists — this is the AWS API's limit)
- ECR pull for one specific repository (plus the unavoidable global `ecr:GetAuthorizationToken`)
- `ecs:UpdateService` / `RegisterTaskDefinition` scoped to one cluster + service, with `ecs:cluster` condition
- `iam:PassRole` scoped to the two ECS roles the task actually needs, restricted to `ecs-tasks.amazonaws.com`
- Terraform state read/write scoped to one bucket + prefix, with the DynamoDB lock table pinned

No `Resource = "*"` on any write action unless the AWS service literally does not support ARN-level authorization for it — and in those cases the statement is either read-only or scoped with a `Condition`.

## Validation

The validation script proves the trust policy behaves as advertised. It runs a matrix of assertions against each role and exits non-zero if any negative case is accepted or any positive case is rejected:

| # | Scenario                                                       | Expected result   |
|---|----------------------------------------------------------------|-------------------|
| 1 | Locally-signed JWT with otherwise-valid claims                 | `InvalidIdentityToken` |
| 2 | Locally-signed JWT with foreign repo `sub`                     | `InvalidIdentityToken` |
| 3 | Locally-signed JWT with wrong `aud`                            | `InvalidIdentityToken` |
| 4 | Real GitHub token, matching `sub`, correct `aud`               | **credentials returned** |
| 5 | Real GitHub token, wrong `sub` (e.g. different environment)    | `AccessDenied`    |
| 6 | Real GitHub token, wrong `aud` (custom audience)               | `AccessDenied`    |
| 7 | `sts:AssumeRole` (long-lived IAM creds path)                   | `AccessDenied`    |

Cases 1–3 and 5–7 all succeed *without* being logged into GitHub Actions and are safe to run from anywhere with network access to STS. Case 4 (the positive path) requires the script to run inside GitHub Actions with `permissions: id-token: write` so it can mint a real OIDC token — the provided [`scripts/validate.yml`](scripts/validate.yml) workflow does this for both the staging and production environments.

### Running locally (negative cases only)

```bash
pip install -r scripts/requirements.txt

python scripts/validate_oidc_trust.py \
    --staging-role-arn    arn:aws:iam::111111111111:role/github-actions-otel-staging \
    --production-role-arn arn:aws:iam::222222222222:role/github-actions-otel-production \
    --github-org          my-org \
    --github-repo         otel-pipeline
```

### Running in CI (full matrix)

Copy `scripts/validate.yml` to `.github/workflows/validate-oidc-trust.yml` in the repo whose role you are validating, then set the repo variables `STAGING_ROLE_ARN` and `PRODUCTION_ROLE_ARN`. The workflow runs the matrix twice — once inside the `staging` environment and once inside `production` — so real OIDC tokens for both `sub` values are exercised.

## Security notes

- The default `max_session_duration` is **1 hour**. Increase only when a specific deploy job needs it.
- Thumbprints for GitHub's OIDC certificate chain are variables so they can be rotated without a module release. AWS also validates the cert against Amazon's own trust store when the issuer is GitHub, so thumbprint drift will not cause an outage.
- Never set `allow_pull_requests = true` on a production role. PR workflows run untrusted contributor code with repository write access to the workflow file only in limited scenarios, but the safe default is to block them entirely.
- Prefer GitHub deployment environments (`allowed_environments`) over branch allowlists in production — environments can require manual approval and secret gating, which branch pushes cannot.
