##############################################################################
# Example: deploy the GitHub OIDC role for an OTel pipeline into both
# staging and production accounts.
#
# Assumes you have two AWS provider configurations (e.g. via
# `aws sts assume-role` profiles) — one per account.
##############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source                = "hashicorp/aws"
      version               = ">= 5.0"
      configuration_aliases = [aws.staging, aws.production]
    }
  }
}

##############################################################################
# Shared inputs
##############################################################################

variable "github_org" {
  type = string
}

variable "github_repo" {
  type = string
}

variable "staging_account_id" {
  type = string
}

variable "production_account_id" {
  type = string
}

variable "aws_region" {
  type    = string
  default = "us-east-1"
}

##############################################################################
# STAGING: allow `main` branch + `staging` environment
##############################################################################

module "otel_policy_staging" {
  source = "../../policies"

  aws_region              = var.aws_region
  aws_account_id          = var.staging_account_id
  log_group_prefix        = "/otel/pipeline"
  metric_namespace        = "OTel/Pipeline/Staging"
  ecr_repository_name     = "otel-collector"
  ecs_cluster_name        = "telemetry-staging"
  ecs_service_name        = "otel-collector"
  task_execution_role_arn = "arn:aws:iam::${var.staging_account_id}:role/otel-task-execution"
  task_role_arn           = "arn:aws:iam::${var.staging_account_id}:role/otel-task"
  tf_state_bucket         = "otel-tfstate-staging"
  tf_state_key_prefix     = "otel-pipeline/"
  tf_state_lock_table     = "otel-tfstate-lock"
}

module "github_oidc_staging" {
  source    = "../../modules/github-oidc"
  providers = { aws = aws.staging }

  github_org  = var.github_org
  github_repo = var.github_repo
  role_name   = "github-actions-otel-staging"
  environment = "staging"

  allowed_branches     = ["main"]
  allowed_environments = ["staging"]
  allow_pull_requests  = false

  inline_policies = {
    "otel-pipeline" = module.otel_policy_staging.otel_pipeline_policy_json
  }

  tags = { Owner = "platform-observability" }
}

##############################################################################
# PRODUCTION: only signed tags + `production` environment.
# PRs and branch pushes explicitly disallowed.
##############################################################################

module "otel_policy_prod" {
  source = "../../policies"

  aws_region              = var.aws_region
  aws_account_id          = var.production_account_id
  log_group_prefix        = "/otel/pipeline"
  metric_namespace        = "OTel/Pipeline/Production"
  ecr_repository_name     = "otel-collector"
  ecs_cluster_name        = "telemetry-production"
  ecs_service_name        = "otel-collector"
  task_execution_role_arn = "arn:aws:iam::${var.production_account_id}:role/otel-task-execution"
  task_role_arn           = "arn:aws:iam::${var.production_account_id}:role/otel-task"
  tf_state_bucket         = "otel-tfstate-production"
  tf_state_key_prefix     = "otel-pipeline/"
  tf_state_lock_table     = "otel-tfstate-lock"
}

module "github_oidc_prod" {
  source    = "../../modules/github-oidc"
  providers = { aws = aws.production }

  github_org  = var.github_org
  github_repo = var.github_repo
  role_name   = "github-actions-otel-production"
  environment = "production"

  # Note: only tags matching the release convention + the `production`
  # GitHub environment (which should require manual approval) can assume
  # this role.
  allowed_tags         = [] # populate with exact tag names per release
  allowed_environments = ["production"]
  allow_pull_requests  = false

  inline_policies = {
    "otel-pipeline" = module.otel_policy_prod.otel_pipeline_policy_json
  }

  tags = { Owner = "platform-observability" }
}

##############################################################################
# Outputs consumed by the validation script
##############################################################################

output "staging_role_arn" {
  value = module.github_oidc_staging.role_arn
}

output "production_role_arn" {
  value = module.github_oidc_prod.role_arn
}

output "staging_allowed_subs" {
  value = module.github_oidc_staging.allowed_subject_claims
}

output "production_allowed_subs" {
  value = module.github_oidc_prod.allowed_subject_claims
}
