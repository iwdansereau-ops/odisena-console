##############################################################################
# GitHub OIDC provider
#
# Creates (or references) the IAM OIDC identity provider for
# token.actions.githubusercontent.com. The audience `sts.amazonaws.com`
# is the value that GitHub's official `configure-aws-credentials` action
# requests by default.
##############################################################################

locals {
  oidc_url         = "token.actions.githubusercontent.com"
  oidc_audience    = "sts.amazonaws.com"
  repo_fully_qual  = "${var.github_org}/${var.github_repo}"
  sub_prefix       = "repo:${local.repo_fully_qual}"

  # Assemble the exact set of allowed `sub` claim values. If nothing is
  # supplied we still fail closed with an empty list — StringEquals against
  # [] never matches, so no principal can assume the role until the caller
  # explicitly opts in.
  branch_subs      = [for b in var.allowed_branches      : "${local.sub_prefix}:ref:refs/heads/${b}"]
  tag_subs         = [for t in var.allowed_tags          : "${local.sub_prefix}:ref:refs/tags/${t}"]
  environment_subs = [for e in var.allowed_environments  : "${local.sub_prefix}:environment:${e}"]
  pr_subs          = var.allow_pull_requests ? ["${local.sub_prefix}:pull_request"] : []

  allowed_subs = concat(
    local.branch_subs,
    local.tag_subs,
    local.environment_subs,
    local.pr_subs,
  )

  provider_arn = var.create_oidc_provider ? aws_iam_openid_connect_provider.github[0].arn : var.existing_oidc_provider_arn

  common_tags = merge(
    {
      "Module"      = "terraform-aws-github-oidc"
      "Environment" = var.environment
      "Repo"        = local.repo_fully_qual
      "ManagedBy"   = "terraform"
    },
    var.tags,
  )
}

resource "aws_iam_openid_connect_provider" "github" {
  count = var.create_oidc_provider ? 1 : 0

  url             = "https://${local.oidc_url}"
  client_id_list  = [local.oidc_audience]
  thumbprint_list = var.oidc_thumbprints

  tags = local.common_tags

  lifecycle {
    precondition {
      condition     = var.create_oidc_provider || var.existing_oidc_provider_arn != null
      error_message = "existing_oidc_provider_arn must be set when create_oidc_provider = false."
    }
  }
}

##############################################################################
# Trust policy
#
# The trust policy is intentionally strict:
#   * Federated principal is pinned to the specific OIDC provider ARN,
#     which itself is bound to the issuer https://token.actions.githubusercontent.com.
#     STS will only accept tokens whose `iss` claim matches the provider's URL,
#     so no separate `iss` condition is required (AWS does not expose `iss` as
#     a policy condition key for this provider anyway).
#   * `aud` must equal sts.amazonaws.com — blocks tokens minted for other
#     audiences (e.g. workflows that request `aud: my-service`).
#   * `sub` must appear in the enumerated list built from allowed_branches
#     et al. — blocks any workflow from another repo / branch / env.
##############################################################################

data "aws_iam_policy_document" "trust" {
  statement {
    sid     = "GitHubActionsOIDCAssumeRole"
    effect  = "Allow"
    actions = ["sts:AssumeRoleWithWebIdentity"]

    principals {
      type        = "Federated"
      identifiers = [local.provider_arn]
    }

    condition {
      test     = "StringEquals"
      variable = "${local.oidc_url}:aud"
      values   = [local.oidc_audience]
    }

    # Exact-match sub claim — no StringLike, no wildcards.
    condition {
      test     = "StringEquals"
      variable = "${local.oidc_url}:sub"
      values   = local.allowed_subs
    }
  }
}

##############################################################################
# Role
##############################################################################

resource "aws_iam_role" "this" {
  name                 = var.role_name
  description          = "GitHub Actions OIDC role for ${local.repo_fully_qual} (${var.environment})"
  assume_role_policy   = data.aws_iam_policy_document.trust.json
  max_session_duration = var.max_session_duration
  permissions_boundary = var.permissions_boundary_arn

  tags = local.common_tags

  lifecycle {
    precondition {
      condition     = length(local.allowed_subs) > 0
      error_message = "You must set at least one of allowed_branches / allowed_tags / allowed_environments / allow_pull_requests. An empty sub list would produce an unassumable role and almost always indicates a misconfiguration."
    }
  }
}

resource "aws_iam_role_policy_attachment" "managed" {
  for_each   = toset(var.attached_policy_arns)
  role       = aws_iam_role.this.name
  policy_arn = each.value
}

resource "aws_iam_role_policy" "inline" {
  for_each = var.inline_policies
  name     = each.key
  role     = aws_iam_role.this.id
  policy   = each.value
}
