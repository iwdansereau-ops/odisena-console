##############################################################################
# Required inputs
##############################################################################

variable "github_org" {
  description = "GitHub organization or user that owns the repository (e.g. \"my-org\")."
  type        = string

  validation {
    condition     = length(var.github_org) > 0 && can(regex("^[A-Za-z0-9][A-Za-z0-9-]{0,38}$", var.github_org))
    error_message = "github_org must be a valid GitHub org/user handle."
  }
}

variable "github_repo" {
  description = "GitHub repository name (without org prefix, e.g. \"otel-pipeline\")."
  type        = string

  validation {
    condition     = length(var.github_repo) > 0 && can(regex("^[A-Za-z0-9._-]+$", var.github_repo))
    error_message = "github_repo must be a valid GitHub repo name."
  }
}

variable "role_name" {
  description = "Name of the IAM role that GitHub Actions will assume."
  type        = string
}

variable "environment" {
  description = "Environment label used for tagging and role differentiation (e.g. \"staging\", \"production\")."
  type        = string

  validation {
    condition     = contains(["staging", "production", "dev", "test"], var.environment)
    error_message = "environment must be one of: dev, test, staging, production."
  }
}

##############################################################################
# Trust-policy scoping
#
# The `sub` claim on GitHub's OIDC JWT looks like:
#   repo:<org>/<repo>:ref:refs/heads/<branch>
#   repo:<org>/<repo>:environment:<env>
#   repo:<org>/<repo>:pull_request
#   repo:<org>/<repo>:ref:refs/tags/<tag>
#
# We build the `sub` list from `allowed_branches`, `allowed_tags`,
# `allowed_environments`, and `allow_pull_requests` so callers cannot
# accidentally leave the role open to `repo:<org>/<repo>:*`.
##############################################################################

variable "allowed_branches" {
  description = "List of branch names allowed to assume the role. Wildcards are rejected."
  type        = list(string)
  default     = []

  validation {
    condition     = alltrue([for b in var.allowed_branches : !can(regex("[*?]", b))])
    error_message = "Wildcards are not allowed in allowed_branches; enumerate exact branch names."
  }
}

variable "allowed_tags" {
  description = "List of tag names allowed to assume the role. Wildcards are rejected."
  type        = list(string)
  default     = []

  validation {
    condition     = alltrue([for t in var.allowed_tags : !can(regex("[*?]", t))])
    error_message = "Wildcards are not allowed in allowed_tags; enumerate exact tag names."
  }
}

variable "allowed_environments" {
  description = "List of GitHub deployment environments allowed to assume the role (e.g. [\"staging\"])."
  type        = list(string)
  default     = []
}

variable "allow_pull_requests" {
  description = "Whether pull_request workflows may assume the role. Defaults to false (recommended)."
  type        = bool
  default     = false
}

##############################################################################
# OIDC provider re-use
#
# Only one IAM OIDC provider for token.actions.githubusercontent.com is
# allowed per AWS account. Set create_oidc_provider = false when a provider
# already exists and supply its ARN via existing_oidc_provider_arn.
##############################################################################

variable "create_oidc_provider" {
  description = "Whether to create the GitHub OIDC provider in this account."
  type        = bool
  default     = true
}

variable "existing_oidc_provider_arn" {
  description = "ARN of a pre-existing GitHub OIDC provider. Required when create_oidc_provider = false."
  type        = string
  default     = null
}

# GitHub's OIDC signing thumbprints. AWS now verifies the OIDC certificate
# against Amazon's trust store when the audience is
# token.actions.githubusercontent.com, so these values are effectively a
# defense-in-depth check. Kept as a variable so operators can rotate.
# See: https://github.blog/changelog/2023-06-27-github-actions-update-on-oidc-integration-with-aws/
variable "oidc_thumbprints" {
  description = "Thumbprints for GitHub's OIDC certificate chain."
  type        = list(string)
  default = [
    "6938fd4d98bab03faadb97b34396831e3780aea1",
    "1c58a3a8518e8759bf075b76b750d4f2df264fcd",
  ]
}

##############################################################################
# Policy attachment
##############################################################################

variable "attached_policy_arns" {
  description = "IAM managed policy ARNs to attach to the role."
  type        = list(string)
  default     = []
}

variable "inline_policies" {
  description = "Map of inline IAM policies (name => JSON) to attach to the role."
  type        = map(string)
  default     = {}
}

variable "max_session_duration" {
  description = "Maximum session duration for the role, in seconds (900 - 43200)."
  type        = number
  default     = 3600

  validation {
    condition     = var.max_session_duration >= 900 && var.max_session_duration <= 43200
    error_message = "max_session_duration must be between 900 and 43200 seconds."
  }
}

variable "permissions_boundary_arn" {
  description = "Optional permissions boundary ARN applied to the role."
  type        = string
  default     = null
}

variable "tags" {
  description = "Tags applied to all managed resources."
  type        = map(string)
  default     = {}
}
