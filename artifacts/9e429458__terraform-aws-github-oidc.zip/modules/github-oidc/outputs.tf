output "role_arn" {
  description = "ARN of the IAM role assumed by GitHub Actions."
  value       = aws_iam_role.this.arn
}

output "role_name" {
  description = "Name of the IAM role."
  value       = aws_iam_role.this.name
}

output "oidc_provider_arn" {
  description = "ARN of the GitHub OIDC provider used by this role."
  value       = local.provider_arn
}

output "allowed_subject_claims" {
  description = "The exact list of `sub` claim values allowed by the trust policy."
  value       = local.allowed_subs
}

output "trust_policy_json" {
  description = "Rendered trust policy JSON — useful for auditing and validation scripts."
  value       = data.aws_iam_policy_document.trust.json
}
