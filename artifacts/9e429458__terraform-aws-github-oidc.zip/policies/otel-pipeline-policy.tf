##############################################################################
# Least-privilege policy for a sample OTel telemetry pipeline deployed
# by GitHub Actions.
#
# Scope of what CI actually needs to do:
#   * Push OTLP data / logs to CloudWatch Logs during smoke tests.
#   * Publish EMF metrics to a dedicated namespace.
#   * Write traces to AWS X-Ray (destination of the OTel exporter).
#   * Read the OTel Collector container image from a specific ECR repo.
#   * Deploy the collector as an ECS service update (register task def +
#     update service), scoped to a single cluster/service.
#   * Read/write the pipeline's Terraform state object in a dedicated
#     S3 prefix, and take the state lock in DynamoDB.
#
# Every statement is resource-scoped. No `Resource = "*"` on write actions
# except where the AWS API itself does not support ARN-level authz
# (e.g. xray:PutTraceSegments, ecr:GetAuthorizationToken), in which case
# a `Condition` is added.
##############################################################################

variable "aws_region" {
  description = "AWS region for the OTel pipeline."
  type        = string
}

variable "aws_account_id" {
  description = "AWS account ID for the OTel pipeline."
  type        = string
}

variable "log_group_prefix" {
  description = "Prefix of CloudWatch log groups the pipeline may write to."
  type        = string
  default     = "/otel/pipeline"
}

variable "metric_namespace" {
  description = "CloudWatch metric namespace the pipeline may publish to."
  type        = string
  default     = "OTel/Pipeline"
}

variable "ecr_repository_name" {
  description = "Name of the ECR repository holding the OTel collector image."
  type        = string
  default     = "otel-collector"
}

variable "ecs_cluster_name" {
  description = "ECS cluster running the OTel collector."
  type        = string
}

variable "ecs_service_name" {
  description = "ECS service name for the OTel collector."
  type        = string
  default     = "otel-collector"
}

variable "task_execution_role_arn" {
  description = "ARN of the ECS task execution role that iam:PassRole must allow."
  type        = string
}

variable "task_role_arn" {
  description = "ARN of the ECS task role that iam:PassRole must allow."
  type        = string
}

variable "tf_state_bucket" {
  description = "S3 bucket holding the OTel pipeline's Terraform state."
  type        = string
}

variable "tf_state_key_prefix" {
  description = "Prefix within the state bucket that the pipeline owns."
  type        = string
  default     = "otel-pipeline/"
}

variable "tf_state_lock_table" {
  description = "DynamoDB table used for Terraform state locking."
  type        = string
}

data "aws_iam_policy_document" "otel_pipeline" {
  # ---- CloudWatch Logs (test traffic + collector self-telemetry) --------
  statement {
    sid    = "OTelLogsWrite"
    effect = "Allow"
    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents",
      "logs:DescribeLogGroups",
      "logs:DescribeLogStreams",
      "logs:PutRetentionPolicy",
    ]
    resources = [
      "arn:aws:logs:${var.aws_region}:${var.aws_account_id}:log-group:${var.log_group_prefix}*",
      "arn:aws:logs:${var.aws_region}:${var.aws_account_id}:log-group:${var.log_group_prefix}*:log-stream:*",
    ]
  }

  # ---- CloudWatch metrics (namespace-scoped via condition) ---------------
  statement {
    sid       = "OTelMetricsPutScoped"
    effect    = "Allow"
    actions   = ["cloudwatch:PutMetricData"]
    resources = ["*"] # PutMetricData does not accept a resource ARN.

    condition {
      test     = "StringEquals"
      variable = "cloudwatch:namespace"
      values   = [var.metric_namespace]
    }
  }

  # ---- X-Ray traces (write-only, no ARN-level authz on Put*) -------------
  statement {
    sid    = "OTelXRayWrite"
    effect = "Allow"
    actions = [
      "xray:PutTraceSegments",
      "xray:PutTelemetryRecords",
      "xray:GetSamplingRules",
      "xray:GetSamplingTargets",
      "xray:GetSamplingStatisticSummaries",
    ]
    resources = ["*"]
  }

  # ---- ECR: pull collector image ----------------------------------------
  statement {
    sid       = "OTelECRAuth"
    effect    = "Allow"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"] # GetAuthorizationToken is not resource-scoped.
  }

  statement {
    sid    = "OTelECRPull"
    effect = "Allow"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:GetDownloadUrlForLayer",
      "ecr:BatchGetImage",
      "ecr:DescribeImages",
      "ecr:DescribeRepositories",
    ]
    resources = [
      "arn:aws:ecr:${var.aws_region}:${var.aws_account_id}:repository/${var.ecr_repository_name}",
    ]
  }

  # ---- ECS deploy: task def + service update -----------------------------
  statement {
    sid    = "OTelECSRegisterTaskDef"
    effect = "Allow"
    # RegisterTaskDefinition does not accept resource ARNs — scope via
    # PassRole below to prevent registering task defs referencing arbitrary
    # roles.
    actions   = ["ecs:RegisterTaskDefinition", "ecs:DescribeTaskDefinition"]
    resources = ["*"]
  }

  statement {
    sid    = "OTelECSServiceUpdate"
    effect = "Allow"
    actions = [
      "ecs:UpdateService",
      "ecs:DescribeServices",
      "ecs:DescribeTasks",
      "ecs:ListTasks",
    ]
    resources = [
      "arn:aws:ecs:${var.aws_region}:${var.aws_account_id}:service/${var.ecs_cluster_name}/${var.ecs_service_name}",
      "arn:aws:ecs:${var.aws_region}:${var.aws_account_id}:task/${var.ecs_cluster_name}/*",
    ]

    condition {
      test     = "ArnEquals"
      variable = "ecs:cluster"
      values = [
        "arn:aws:ecs:${var.aws_region}:${var.aws_account_id}:cluster/${var.ecs_cluster_name}",
      ]
    }
  }

  statement {
    sid       = "OTelPassExecutionAndTaskRoles"
    effect    = "Allow"
    actions   = ["iam:PassRole"]
    resources = [var.task_execution_role_arn, var.task_role_arn]

    condition {
      test     = "StringEquals"
      variable = "iam:PassedToService"
      values   = ["ecs-tasks.amazonaws.com"]
    }
  }

  # ---- Terraform remote state (S3 + DynamoDB lock) -----------------------
  statement {
    sid       = "OTelTFStateBucketList"
    effect    = "Allow"
    actions   = ["s3:ListBucket", "s3:GetBucketVersioning"]
    resources = ["arn:aws:s3:::${var.tf_state_bucket}"]

    condition {
      test     = "StringLike"
      variable = "s3:prefix"
      values   = ["${var.tf_state_key_prefix}*"]
    }
  }

  statement {
    sid    = "OTelTFStateObjectRW"
    effect = "Allow"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:GetObjectVersion",
    ]
    resources = [
      "arn:aws:s3:::${var.tf_state_bucket}/${var.tf_state_key_prefix}*",
    ]
  }

  statement {
    sid    = "OTelTFStateLock"
    effect = "Allow"
    actions = [
      "dynamodb:GetItem",
      "dynamodb:PutItem",
      "dynamodb:DeleteItem",
      "dynamodb:DescribeTable",
    ]
    resources = [
      "arn:aws:dynamodb:${var.aws_region}:${var.aws_account_id}:table/${var.tf_state_lock_table}",
    ]
  }
}

output "otel_pipeline_policy_json" {
  description = "JSON policy document granting least-privilege access for the OTel pipeline."
  value       = data.aws_iam_policy_document.otel_pipeline.json
}
