package routingprocessor_test

import (
	"context"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/require"

	ch "github.com/example/configharness/configharness"
	rp "github.com/example/configharness/example/routingprocessor"
)

// buildRegistry wires the mock receiver/exporter + the real routingprocessor
// factory into a fresh FactoryRegistry. Every test in this file starts from
// a clean registry so mutations don't leak between scenarios.
func buildRegistry() *ch.FactoryRegistry {
	reg := ch.NewFactoryRegistry()
	ch.RegisterDefaults(reg) // mock_receiver, mock_exporter
	reg.RegisterProcessor("routingprocessor", rp.Factory{})
	return reg
}

func loadManifest(t *testing.T, name string) *ch.Manifest {
	t.Helper()
	m, err := ch.LoadManifestFile(filepath.Join("..", "manifests", name))
	require.NoError(t, err)
	return m
}

// TestHealthy_ManifestPassesEndToEnd is the happy path: a fully wired
// manifest across all three signals must build, start, deliver signal,
// and shut down without a single regression.
func TestHealthy_ManifestPassesEndToEnd(t *testing.T) {
	reg := buildRegistry()
	m := loadManifest(t, "healthy.yaml")

	mc := ch.NewMockCollector(t, reg)
	report := mc.Run(context.Background(), m, ch.RunOptions{})

	// The strict form of AssertOK insists every pipeline was actually
	// driven — no "unverified" allowed. That's the strongest possible
	// gate for a healthy config.
	ch.AssertOKStrict(t, report, true)

	// Belt-and-suspenders: every pipeline finished the full lifecycle.
	for _, sig := range ch.AllSignals {
		p := report.Pipelines[sig]
		require.True(t, p.Built, "%s not built", sig)
		require.True(t, p.Started, "%s not started", sig)
		require.True(t, p.SignalDelivered, "%s signal never delivered", sig)
		require.True(t, p.Shutdown, "%s not shut down", sig)
	}
}

// TestRegression_StartFailure verifies that a component whose Start()
// returns an error is flagged as start_failure and does *not* fail the
// entire harness — the report is still produced, and Shutdown is still
// attempted for whatever partial state exists.
func TestRegression_StartFailure(t *testing.T) {
	reg := buildRegistry()
	m := loadManifest(t, "bad_start.yaml")

	mc := ch.NewMockCollector(t, reg)
	report := mc.Run(context.Background(), m, ch.RunOptions{})

	require.False(t, report.OK(), "expected regressions, report was OK:\n%s", report)
	ch.AssertRegressionKind(t, report, ch.RegressionStartFailure)

	// The logs pipeline should have Built=true (init worked) but
	// Started=false (Start failed) and SignalDelivered=false.
	logs := report.Pipelines[ch.SignalLogs]
	require.True(t, logs.Built)
	require.False(t, logs.Started)
	require.False(t, logs.SignalDelivered)
}

// TestRegression_IngestionError verifies that when a component rejects
// the driven batch (here, by requiring a resource attribute the mock
// receiver never sets) the harness reports ingestion_error, not
// ingestion_blocked. Distinguishing "wrong data" from "hung pipeline"
// matters when triaging real regressions.
func TestRegression_IngestionError(t *testing.T) {
	reg := buildRegistry()
	m := loadManifest(t, "bad_ingestion.yaml")

	mc := ch.NewMockCollector(t, reg)
	report := mc.Run(context.Background(), m, ch.RunOptions{})

	require.False(t, report.OK())
	ch.AssertRegressionKind(t, report, ch.RegressionIngestionError)

	// The pipeline still started and shut down cleanly — only the
	// synthetic drive failed. That's the useful discrimination.
	logs := report.Pipelines[ch.SignalLogs]
	require.True(t, logs.Started)
	require.False(t, logs.SignalDelivered)
	require.True(t, logs.Shutdown)
}

// TestRegression_ShutdownFailure verifies that a Shutdown() that returns
// an error is surfaced without preventing the rest of the shutdown
// sequence from completing.
func TestRegression_ShutdownFailure(t *testing.T) {
	reg := buildRegistry()
	m := loadManifest(t, "bad_shutdown.yaml")

	mc := ch.NewMockCollector(t, reg)
	report := mc.Run(context.Background(), m, ch.RunOptions{})

	require.False(t, report.OK())
	ch.AssertRegressionKind(t, report, ch.RegressionShutdownFailure)

	// The signal *was* delivered before the botched shutdown; the harness
	// should not silently downgrade that.
	logs := report.Pipelines[ch.SignalLogs]
	require.True(t, logs.SignalDelivered, "signal delivery should be independent of shutdown health")
}

// TestManifest_ValidationRejectsStructuralBugs ensures the manifest
// loader rejects obviously broken configs *before* the mock collector
// tries to build anything. Missing-receiver / dangling-reference errors
// should surface at parse time with a clear message.
func TestManifest_ValidationRejectsStructuralBugs(t *testing.T) {
	cases := []struct {
		name string
		yaml string
		want string
	}{
		{
			name: "no_pipelines",
			yaml: "receivers: {}\nprocessors: {}\nexporters: {}\n",
			want: "no pipelines",
		},
		{
			name: "unknown_signal",
			yaml: `
pipelines:
  metricz: {receivers: [x], exporters: [y]}
receivers:  {x: {type: mock_receiver}}
exporters:  {y: {type: mock_exporter}}
`,
			want: `unknown pipeline signal "metricz"`,
		},
		{
			name: "no_receivers",
			yaml: `
pipelines:
  logs: {receivers: [], exporters: [y]}
exporters: {y: {type: mock_exporter}}
`,
			want: `pipeline "logs" has no receivers`,
		},
		{
			name: "dangling_ref",
			yaml: `
pipelines:
  logs: {receivers: [ghost], exporters: [y]}
exporters: {y: {type: mock_exporter}}
`,
			want: `undefined receiver "ghost"`,
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			_, err := ch.LoadManifestBytes([]byte(tc.yaml))
			require.Error(t, err)
			require.Contains(t, err.Error(), tc.want)
		})
	}
}
