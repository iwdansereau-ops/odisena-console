// Package routingprocessor is a small example component included with
// configharness so the integration harness has something realistic to
// exercise against a real manifest.
//
// It's a single-signal-safe, three-signal processor that inspects a
// resource attribute (configurable, default "route") and forwards each
// resource group to its single downstream consumer. Real routing
// processors fan out to multiple pipelines; keeping this one linear
// keeps the harness example focused on manifest-level behavior.
package routingprocessor

import (
	"context"
	"errors"
	"fmt"
	"sync"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/plog"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"gopkg.in/yaml.v3"

	ch "github.com/example/configharness/configharness"
)

// Config is the on-manifest configuration for the processor.
type Config struct {
	// RouteAttribute is the resource attribute inspected. Default "route".
	RouteAttribute string `yaml:"route_attribute"`
	// RequireAttribute, if true, causes the processor to error on any
	// resource missing the attribute (rather than pass it through). Used
	// in tests to demonstrate an ingestion-error regression.
	RequireAttribute bool `yaml:"require_attribute"`
	// FailOnStart, if true, causes Start() to return an error. Used to
	// demonstrate a start-failure regression.
	FailOnStart bool `yaml:"fail_on_start"`
}

// Factory implements configharness.ProcessorFactory.
type Factory struct{}

func (Factory) CreateProcessor(_ context.Context, _ component.TelemetrySettings, cfg *yaml.Node, signal ch.SignalKind, next any) (component.Component, error) {
	var c Config
	if cfg != nil && cfg.Kind != 0 {
		if err := cfg.Decode(&c); err != nil {
			return nil, fmt.Errorf("routingprocessor: decode config: %w", err)
		}
	}
	if c.RouteAttribute == "" {
		c.RouteAttribute = "route"
	}

	p := &processor{cfg: c, signal: signal}
	switch signal {
	case ch.SignalLogs:
		lc, ok := next.(consumer.Logs)
		if !ok {
			return nil, errors.New("routingprocessor: downstream is not consumer.Logs")
		}
		p.logsNext = lc
	case ch.SignalMetrics:
		mc, ok := next.(consumer.Metrics)
		if !ok {
			return nil, errors.New("routingprocessor: downstream is not consumer.Metrics")
		}
		p.metricsNext = mc
	case ch.SignalTraces:
		tc, ok := next.(consumer.Traces)
		if !ok {
			return nil, errors.New("routingprocessor: downstream is not consumer.Traces")
		}
		p.tracesNext = tc
	default:
		return nil, fmt.Errorf("routingprocessor: unknown signal %q", signal)
	}
	return p, nil
}

type processor struct {
	cfg    Config
	signal ch.SignalKind

	logsNext    consumer.Logs
	metricsNext consumer.Metrics
	tracesNext  consumer.Traces

	mu      sync.Mutex
	started bool
	stopped bool
}

func (p *processor) Capabilities() consumer.Capabilities {
	return consumer.Capabilities{MutatesData: false}
}

func (p *processor) Start(_ context.Context, _ component.Host) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.cfg.FailOnStart {
		return errors.New("routingprocessor: fail_on_start set")
	}
	p.started = true
	return nil
}

func (p *processor) Shutdown(_ context.Context) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.stopped = true
	return nil
}

func (p *processor) checkAttr(m map[string]any) error {
	if !p.cfg.RequireAttribute {
		return nil
	}
	if _, ok := m[p.cfg.RouteAttribute]; !ok {
		return fmt.Errorf("routingprocessor: resource missing required attribute %q", p.cfg.RouteAttribute)
	}
	return nil
}

func (p *processor) ConsumeLogs(ctx context.Context, l plog.Logs) error {
	rls := l.ResourceLogs()
	for i := 0; i < rls.Len(); i++ {
		if err := p.checkAttr(rls.At(i).Resource().Attributes().AsRaw()); err != nil {
			return err
		}
	}
	return p.logsNext.ConsumeLogs(ctx, l)
}

func (p *processor) ConsumeMetrics(ctx context.Context, m pmetric.Metrics) error {
	rms := m.ResourceMetrics()
	for i := 0; i < rms.Len(); i++ {
		if err := p.checkAttr(rms.At(i).Resource().Attributes().AsRaw()); err != nil {
			return err
		}
	}
	return p.metricsNext.ConsumeMetrics(ctx, m)
}

func (p *processor) ConsumeTraces(ctx context.Context, t ptrace.Traces) error {
	rss := t.ResourceSpans()
	for i := 0; i < rss.Len(); i++ {
		if err := p.checkAttr(rss.At(i).Resource().Attributes().AsRaw()); err != nil {
			return err
		}
	}
	return p.tracesNext.ConsumeTraces(ctx, t)
}
