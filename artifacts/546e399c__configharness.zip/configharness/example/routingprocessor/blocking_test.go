package routingprocessor_test

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/plog"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"gopkg.in/yaml.v3"

	ch "github.com/example/configharness/configharness"
)

// blockingProcessorFactory produces a processor that never calls its
// downstream — it just blocks in Consume* until context expires. The
// harness must catch this as an ingestion_blocked regression rather than
// hang the test indefinitely. This exercises the "blocks signal
// ingestion in a standard pipeline run" path from the harness spec.
type blockingProcessorFactory struct{}

func (blockingProcessorFactory) CreateProcessor(_ context.Context, _ component.TelemetrySettings, _ *yaml.Node, signal ch.SignalKind, next any) (component.Component, error) {
	return &blockingProcessor{signal: signal, next: next}, nil
}

type blockingProcessor struct {
	signal ch.SignalKind
	next   any
}

func (b *blockingProcessor) Capabilities() consumer.Capabilities { return consumer.Capabilities{} }
func (b *blockingProcessor) Start(context.Context, component.Host) error { return nil }
func (b *blockingProcessor) Shutdown(context.Context) error              { return nil }

// blockUntilCancelled swallows the batch and blocks until ctx cancels.
// It never forwards downstream, so the exporter sink stays empty.
func blockUntilCancelled(ctx context.Context) error {
	<-ctx.Done()
	return nil
}

func (b *blockingProcessor) ConsumeLogs(ctx context.Context, _ plog.Logs) error {
	return blockUntilCancelled(ctx)
}
func (b *blockingProcessor) ConsumeMetrics(ctx context.Context, _ pmetric.Metrics) error {
	return blockUntilCancelled(ctx)
}
func (b *blockingProcessor) ConsumeTraces(ctx context.Context, _ ptrace.Traces) error {
	return blockUntilCancelled(ctx)
}

// TestRegression_IngestionBlocked builds a manifest programmatically so
// we can plug in the blocking processor without touching the YAML tree.
// We use a very short IngestionTimeout so this test finishes fast.
func TestRegression_IngestionBlocked(t *testing.T) {
	reg := ch.NewFactoryRegistry()
	ch.RegisterDefaults(reg)
	reg.RegisterProcessor("blocking", blockingProcessorFactory{})

	manifestYAML := `
receivers:
  in:
    type: mock_receiver
    config:
      resource_attrs: {source: block_test}
processors:
  hang:
    type: blocking
exporters:
  out:
    type: mock_exporter
pipelines:
  logs:
    receivers:  [in]
    processors: [hang]
    exporters:  [out]
`
	m, err := ch.LoadManifestBytes([]byte(manifestYAML))
	require.NoError(t, err)

	mc := ch.NewMockCollector(t, reg)
	start := time.Now()
	report := mc.Run(context.Background(), m, ch.RunOptions{
		IngestionTimeout: 100 * time.Millisecond, // fast fail — this is the whole point
	})
	elapsed := time.Since(start)

	// The harness must have caught the block, not hung.
	require.Less(t, elapsed, 2*time.Second, "harness should fail fast on a blocked pipeline")

	require.False(t, report.OK(), "expected regressions:\n%s", report)
	ch.AssertRegressionKind(t, report, ch.RegressionIngestionBlocked)

	// Startup and shutdown should still have succeeded — the pipeline
	// was healthy at both ends. Only the signal-drive step tripped.
	logs := report.Pipelines[ch.SignalLogs]
	require.True(t, logs.Started, "start should have succeeded")
	require.False(t, logs.SignalDelivered)
	require.True(t, logs.Shutdown, "shutdown should have succeeded")

	// Confirm the regression String() includes the timeout duration so
	// the failure message is actionable in CI output.
	found := false
	for _, r := range report.Regressions {
		if r.Kind == ch.RegressionIngestionBlocked {
			require.Contains(t, r.Message, "100ms")
			found = true
		}
	}
	require.True(t, found)

	// Sanity: for debugging, print the report so a maintainer running
	// -v gets a concrete example of the output format.
	fmt.Println(report)
}
