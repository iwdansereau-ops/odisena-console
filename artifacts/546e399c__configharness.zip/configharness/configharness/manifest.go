// Package configharness is a lightweight integration test harness for
// OpenTelemetry Collector configuration manifests.
//
// The idea: given a small YAML manifest that mirrors the shape of a real
// Collector config, plus a registry of component factories, the harness
// builds an in-process "mock collector", starts every declared component,
// drives one batch of each signal through every declared pipeline, and
// then shuts everything down. Anything that goes wrong — failed init,
// unlinked pipelines, blocked ingestion, dirty shutdown — is captured as
// a typed Regression in the final Report.
//
// This is deliberately smaller in scope than running the real
// otelcol/service package. We do not parse full Collector config; we
// don't wire up extensions or telemetry pipelines; we don't support
// connectors. What we do provide is a fast, deterministic gate that
// answers: "does this component still initialize and pass traffic in a
// standard pipeline?"
package configharness

import (
	"fmt"
	"os"

	"gopkg.in/yaml.v3"
)

// SignalKind names the three pdata signals the harness understands.
type SignalKind string

const (
	SignalLogs    SignalKind = "logs"
	SignalMetrics SignalKind = "metrics"
	SignalTraces  SignalKind = "traces"
)

// AllSignals is the canonical iteration order used everywhere in the
// harness. Keeping this constant means Report ordering is stable.
var AllSignals = []SignalKind{SignalLogs, SignalMetrics, SignalTraces}

// Manifest is the on-disk shape the harness expects. It intentionally
// mirrors a stripped-down subset of Collector config:
//
//	receivers:
//	  otlp_in:
//	    type: mock_receiver
//	    config: {...}
//	processors:
//	  route:
//	    type: routingprocessor
//	    config:
//	      route_attribute: route
//	      primary_value: primary
//	exporters:
//	  primary_out:
//	    type: mock_exporter
//	  secondary_out:
//	    type: mock_exporter
//	pipelines:
//	  logs:
//	    receivers:  [otlp_in]
//	    processors: [route]
//	    exporters:  [primary_out, secondary_out]
//	  metrics: {...}
//	  traces:  {...}
//
// The "type" field is a lookup key into the FactoryRegistry passed to
// LoadManifest; "config" is passed through opaquely to the factory.
type Manifest struct {
	Receivers  map[string]ComponentDecl  `yaml:"receivers"`
	Processors map[string]ComponentDecl  `yaml:"processors"`
	Exporters  map[string]ComponentDecl  `yaml:"exporters"`
	Pipelines  map[SignalKind]PipelineDecl `yaml:"pipelines"`
}

// ComponentDecl is one entry under receivers/processors/exporters.
type ComponentDecl struct {
	// Type is the factory registration key.
	Type string `yaml:"type"`
	// Config is passed to the factory verbatim. It's held as a yaml.Node so
	// individual factories can decode it into their own strongly-typed
	// config struct without the harness needing to know the schema.
	Config yaml.Node `yaml:"config"`
}

// PipelineDecl is one signal-typed pipeline definition. Receivers fan in,
// processors run in order, exporters fan out.
type PipelineDecl struct {
	Receivers  []string `yaml:"receivers"`
	Processors []string `yaml:"processors"`
	Exporters  []string `yaml:"exporters"`
}

// LoadManifestFile reads a YAML manifest from disk. Errors bubble up with
// the path attached so a failing test tells you which fixture broke.
func LoadManifestFile(path string) (*Manifest, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("configharness: read manifest %q: %w", path, err)
	}
	m, err := LoadManifestBytes(raw)
	if err != nil {
		return nil, fmt.Errorf("configharness: %q: %w", path, err)
	}
	return m, nil
}

// LoadManifestBytes parses a YAML manifest from a byte slice.
func LoadManifestBytes(raw []byte) (*Manifest, error) {
	var m Manifest
	if err := yaml.Unmarshal(raw, &m); err != nil {
		return nil, fmt.Errorf("parse manifest: %w", err)
	}
	if err := m.validate(); err != nil {
		return nil, err
	}
	return &m, nil
}

// validate performs structural checks that don't require the factory
// registry. Anything requiring the registry (unknown type, config decode
// failure) is deferred to the mock collector so it can be surfaced as a
// named Regression rather than a bare parse error.
func (m *Manifest) validate() error {
	if len(m.Pipelines) == 0 {
		return fmt.Errorf("manifest has no pipelines")
	}
	for kind := range m.Pipelines {
		switch kind {
		case SignalLogs, SignalMetrics, SignalTraces:
		default:
			return fmt.Errorf("unknown pipeline signal %q (want logs|metrics|traces)", kind)
		}
	}
	for name, p := range m.Pipelines {
		// A pipeline with no receivers can't ingest and a pipeline with no
		// exporters can't emit. Either is a structural bug worth catching
		// before we even try to build components.
		if len(p.Receivers) == 0 {
			return fmt.Errorf("pipeline %q has no receivers", name)
		}
		if len(p.Exporters) == 0 {
			return fmt.Errorf("pipeline %q has no exporters", name)
		}
		if err := m.checkRefs(string(name), p); err != nil {
			return err
		}
	}
	return nil
}

func (m *Manifest) checkRefs(pipeline string, p PipelineDecl) error {
	for _, r := range p.Receivers {
		if _, ok := m.Receivers[r]; !ok {
			return fmt.Errorf("pipeline %q references undefined receiver %q", pipeline, r)
		}
	}
	for _, pr := range p.Processors {
		if _, ok := m.Processors[pr]; !ok {
			return fmt.Errorf("pipeline %q references undefined processor %q", pipeline, pr)
		}
	}
	for _, e := range p.Exporters {
		if _, ok := m.Exporters[e]; !ok {
			return fmt.Errorf("pipeline %q references undefined exporter %q", pipeline, e)
		}
	}
	return nil
}
