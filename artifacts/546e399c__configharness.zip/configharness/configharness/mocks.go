package configharness

import (
	"context"
	"fmt"
	"sync/atomic"
	"time"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/consumer/consumertest"
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/plog"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"gopkg.in/yaml.v3"
)

// -----------------------------------------------------------------------------
// MockReceiverFactory
// -----------------------------------------------------------------------------

// MockReceiverFactory produces receivers that synthesize a deterministic
// batch of pdata when Drive() is called. It supports all three signals
// and honors two optional YAML keys:
//
//	resource_attrs:  map[string]string  # applied to the resource
//	record_count:    int                # number of records/points/spans (default 1)
type MockReceiverFactory struct{}

type mockReceiverCfg struct {
	ResourceAttrs map[string]string `yaml:"resource_attrs"`
	RecordCount   int               `yaml:"record_count"`
}

// CreateReceiver satisfies ReceiverFactory.
func (MockReceiverFactory) CreateReceiver(_ context.Context, _ component.TelemetrySettings, cfg *yaml.Node, signal SignalKind, next any) (component.Component, error) {
	var c mockReceiverCfg
	if cfg != nil && cfg.Kind != 0 {
		if err := cfg.Decode(&c); err != nil {
			return nil, fmt.Errorf("mock_receiver: decode config: %w", err)
		}
	}
	if c.RecordCount == 0 {
		c.RecordCount = 1
	}
	if c.ResourceAttrs == nil {
		c.ResourceAttrs = map[string]string{"source": "configharness"}
	}

	r := &mockReceiver{cfg: c, signal: signal}
	switch signal {
	case SignalLogs:
		if _, ok := next.(consumer.Logs); !ok {
			return nil, fmt.Errorf("mock_receiver: expected consumer.Logs downstream")
		}
		r.logsNext, _ = next.(consumer.Logs)
	case SignalMetrics:
		if _, ok := next.(consumer.Metrics); !ok {
			return nil, fmt.Errorf("mock_receiver: expected consumer.Metrics downstream")
		}
		r.metricsNext, _ = next.(consumer.Metrics)
	case SignalTraces:
		if _, ok := next.(consumer.Traces); !ok {
			return nil, fmt.Errorf("mock_receiver: expected consumer.Traces downstream")
		}
		r.tracesNext, _ = next.(consumer.Traces)
	default:
		return nil, fmt.Errorf("mock_receiver: unknown signal %q", signal)
	}
	return r, nil
}

// mockReceiver implements component.Component + TestDriver.
type mockReceiver struct {
	cfg    mockReceiverCfg
	signal SignalKind

	logsNext    consumer.Logs
	metricsNext consumer.Metrics
	tracesNext  consumer.Traces

	started atomic.Bool
	stopped atomic.Bool
}

func (r *mockReceiver) Start(context.Context, component.Host) error {
	if !r.started.CompareAndSwap(false, true) {
		return fmt.Errorf("mock_receiver: already started")
	}
	return nil
}
func (r *mockReceiver) Shutdown(context.Context) error {
	r.stopped.Store(true)
	return nil
}

// Drive synthesizes a batch of the appropriate signal and forwards it
// downstream. Any error from the downstream consumer is returned so the
// harness can flag it as an ingestion error.
func (r *mockReceiver) Drive(ctx context.Context, signal SignalKind) error {
	if !r.started.Load() {
		return fmt.Errorf("mock_receiver: Drive before Start")
	}
	if r.stopped.Load() {
		return fmt.Errorf("mock_receiver: Drive after Shutdown")
	}
	if signal != r.signal {
		return fmt.Errorf("mock_receiver: Drive signal %q does not match bound signal %q", signal, r.signal)
	}
	switch signal {
	case SignalLogs:
		return r.logsNext.ConsumeLogs(ctx, r.buildLogs())
	case SignalMetrics:
		return r.metricsNext.ConsumeMetrics(ctx, r.buildMetrics())
	case SignalTraces:
		return r.tracesNext.ConsumeTraces(ctx, r.buildTraces())
	}
	return fmt.Errorf("mock_receiver: unknown signal %q", signal)
}

func (r *mockReceiver) applyAttrs(m pcommon.Map) {
	for k, v := range r.cfg.ResourceAttrs {
		m.PutStr(k, v)
	}
}

var fixedTS = pcommon.NewTimestampFromTime(time.Unix(1_700_000_000, 0).UTC())

func (r *mockReceiver) buildLogs() plog.Logs {
	logs := plog.NewLogs()
	rl := logs.ResourceLogs().AppendEmpty()
	r.applyAttrs(rl.Resource().Attributes())
	sl := rl.ScopeLogs().AppendEmpty()
	sl.Scope().SetName("configharness/mock")
	for i := 0; i < r.cfg.RecordCount; i++ {
		lr := sl.LogRecords().AppendEmpty()
		lr.SetTimestamp(fixedTS)
		lr.SetObservedTimestamp(fixedTS)
		lr.Body().SetStr(fmt.Sprintf("log-%d", i))
	}
	return logs
}

func (r *mockReceiver) buildMetrics() pmetric.Metrics {
	m := pmetric.NewMetrics()
	rm := m.ResourceMetrics().AppendEmpty()
	r.applyAttrs(rm.Resource().Attributes())
	sm := rm.ScopeMetrics().AppendEmpty()
	sm.Scope().SetName("configharness/mock")
	metric := sm.Metrics().AppendEmpty()
	metric.SetName("configharness.counter")
	g := metric.SetEmptyGauge()
	for i := 0; i < r.cfg.RecordCount; i++ {
		dp := g.DataPoints().AppendEmpty()
		dp.SetTimestamp(fixedTS)
		dp.SetIntValue(int64(i))
	}
	return m
}

func (r *mockReceiver) buildTraces() ptrace.Traces {
	tr := ptrace.NewTraces()
	rs := tr.ResourceSpans().AppendEmpty()
	r.applyAttrs(rs.Resource().Attributes())
	ss := rs.ScopeSpans().AppendEmpty()
	ss.Scope().SetName("configharness/mock")
	var tid pcommon.TraceID
	copy(tid[:], []byte("configharnesstr1"))
	for i := 0; i < r.cfg.RecordCount; i++ {
		s := ss.Spans().AppendEmpty()
		s.SetName(fmt.Sprintf("span-%d", i))
		s.SetKind(ptrace.SpanKindInternal)
		s.SetTraceID(tid)
		var sid pcommon.SpanID
		copy(sid[:], fmt.Sprintf("sp-%04d", i))
		s.SetStartTimestamp(fixedTS)
		s.SetEndTimestamp(fixedTS)
		s.SetSpanID(sid)
	}
	return tr
}

// -----------------------------------------------------------------------------
// MockExporterFactory
// -----------------------------------------------------------------------------

// ExporterSink is the accessor a MockCollector uses to check whether an
// exporter observed the driven batch. It's exposed so third-party
// exporter factories can implement `ExporterSink() *ExporterSink` and
// participate in ingestion verification.
type ExporterSink struct {
	logs    *consumertest.LogsSink
	metrics *consumertest.MetricsSink
	traces  *consumertest.TracesSink
	signal  SignalKind
}

// Count returns the number of signal units (records / data points / spans)
// observed since the last Reset. Unified across signal types so callers
// don't have to switch.
func (s *ExporterSink) Count() int {
	switch s.signal {
	case SignalLogs:
		return s.logs.LogRecordCount()
	case SignalMetrics:
		return s.metrics.DataPointCount()
	case SignalTraces:
		return s.traces.SpanCount()
	}
	return 0
}

// Reset empties the sink. Called by the harness at the start of each
// signal-drive round.
func (s *ExporterSink) Reset() {
	if s.logs != nil {
		s.logs.Reset()
	}
	if s.metrics != nil {
		s.metrics.Reset()
	}
	if s.traces != nil {
		s.traces.Reset()
	}
}

// Logs / Metrics / Traces expose the underlying pdata sinks for tests
// that want to make richer assertions than just counts.
func (s *ExporterSink) Logs() *consumertest.LogsSink       { return s.logs }
func (s *ExporterSink) Metrics() *consumertest.MetricsSink { return s.metrics }
func (s *ExporterSink) Traces() *consumertest.TracesSink   { return s.traces }

// MockExporterFactory produces exporters that record every batch they
// receive into an ExporterSink. Two optional YAML keys are honored:
//
//	fail_on_start:   bool      # Start() returns an error
//	fail_on_shutdown: bool     # Shutdown() returns an error
type MockExporterFactory struct{}

type mockExporterCfg struct {
	FailOnStart    bool `yaml:"fail_on_start"`
	FailOnShutdown bool `yaml:"fail_on_shutdown"`
}

func (MockExporterFactory) CreateExporter(_ context.Context, _ component.TelemetrySettings, cfg *yaml.Node, signal SignalKind) (component.Component, error) {
	var c mockExporterCfg
	if cfg != nil && cfg.Kind != 0 {
		if err := cfg.Decode(&c); err != nil {
			return nil, fmt.Errorf("mock_exporter: decode config: %w", err)
		}
	}
	sink := &ExporterSink{signal: signal}
	switch signal {
	case SignalLogs:
		sink.logs = new(consumertest.LogsSink)
	case SignalMetrics:
		sink.metrics = new(consumertest.MetricsSink)
	case SignalTraces:
		sink.traces = new(consumertest.TracesSink)
	default:
		return nil, fmt.Errorf("mock_exporter: unknown signal %q", signal)
	}
	return &mockExporter{cfg: c, sink: sink, signal: signal}, nil
}

type mockExporter struct {
	cfg    mockExporterCfg
	sink   *ExporterSink
	signal SignalKind
}

func (e *mockExporter) Capabilities() consumer.Capabilities { return consumer.Capabilities{} }

// ExporterSink lets the harness discover the sink.
func (e *mockExporter) ExporterSink() *ExporterSink { return e.sink }

func (e *mockExporter) Start(context.Context, component.Host) error {
	if e.cfg.FailOnStart {
		return fmt.Errorf("mock_exporter: fail_on_start set")
	}
	return nil
}
func (e *mockExporter) Shutdown(context.Context) error {
	if e.cfg.FailOnShutdown {
		return fmt.Errorf("mock_exporter: fail_on_shutdown set")
	}
	return nil
}

func (e *mockExporter) ConsumeLogs(ctx context.Context, l plog.Logs) error {
	return e.sink.logs.ConsumeLogs(ctx, l)
}
func (e *mockExporter) ConsumeMetrics(ctx context.Context, m pmetric.Metrics) error {
	return e.sink.metrics.ConsumeMetrics(ctx, m)
}
func (e *mockExporter) ConsumeTraces(ctx context.Context, t ptrace.Traces) error {
	return e.sink.traces.ConsumeTraces(ctx, t)
}

// -----------------------------------------------------------------------------
// RegisterDefaults registers the mock receiver + mock exporter under the
// canonical type names "mock_receiver" and "mock_exporter". Manifests
// generally reference these for anything they don't want to test in
// isolation, freeing the author to declare only their real component
// under test.
// -----------------------------------------------------------------------------
func RegisterDefaults(reg *FactoryRegistry) {
	reg.RegisterReceiver("mock_receiver", MockReceiverFactory{})
	reg.RegisterExporter("mock_exporter", MockExporterFactory{})
}
