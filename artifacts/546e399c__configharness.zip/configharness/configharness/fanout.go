package configharness

import (
	"context"

	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/plog"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.opentelemetry.io/collector/pdata/ptrace"
)

// The Collector's real consumer package ships fan-out helpers, but pulling
// them in transitively drags in more of the collector than we want. These
// are minimal, correct-for-tests implementations: they forward the same
// pdata object to every downstream in order and return the first error.
// For test-time exporter fan-out that's more than sufficient.

type logsFanout []consumer.Logs

func (f logsFanout) Capabilities() consumer.Capabilities { return consumer.Capabilities{} }
func (f logsFanout) ConsumeLogs(ctx context.Context, l plog.Logs) error {
	for _, c := range f {
		if err := c.ConsumeLogs(ctx, l); err != nil {
			return err
		}
	}
	return nil
}

type metricsFanout []consumer.Metrics

func (f metricsFanout) Capabilities() consumer.Capabilities { return consumer.Capabilities{} }
func (f metricsFanout) ConsumeMetrics(ctx context.Context, m pmetric.Metrics) error {
	for _, c := range f {
		if err := c.ConsumeMetrics(ctx, m); err != nil {
			return err
		}
	}
	return nil
}

type tracesFanout []consumer.Traces

func (f tracesFanout) Capabilities() consumer.Capabilities { return consumer.Capabilities{} }
func (f tracesFanout) ConsumeTraces(ctx context.Context, t ptrace.Traces) error {
	for _, c := range f {
		if err := c.ConsumeTraces(ctx, t); err != nil {
			return err
		}
	}
	return nil
}
