package configharness

import (
	"fmt"
	"sort"
	"strings"
	"time"
)

// RegressionKind is a stable, machine-readable label for each way a
// configuration can fail the harness. Tests assert on these directly.
type RegressionKind string

const (
	// RegressionInitFailure: a factory returned an error, or the returned
	// component didn't implement the consumer interface for its signal.
	RegressionInitFailure RegressionKind = "init_failure"

	// RegressionStartFailure: component.Start returned an error.
	RegressionStartFailure RegressionKind = "start_failure"

	// RegressionPipelineUnlinked: a pipeline was declared but at least one
	// stage couldn't be wired to the next (bad consumer interface, missing
	// registration, etc.). The pipeline never runs.
	RegressionPipelineUnlinked RegressionKind = "pipeline_unlinked"

	// RegressionIngestionBlocked: Drive() on the receiver blocked past the
	// per-signal deadline, or the exporter never observed the signal
	// within the ingestion timeout. A pipeline that quietly swallows data
	// falls into this bucket.
	RegressionIngestionBlocked RegressionKind = "ingestion_blocked"

	// RegressionIngestionError: Drive() or a downstream consumer returned
	// an error while forwarding a synthetic batch.
	RegressionIngestionError RegressionKind = "ingestion_error"

	// RegressionShutdownFailure: Shutdown returned a non-nil error, or
	// blocked past the shutdown deadline.
	RegressionShutdownFailure RegressionKind = "shutdown_failure"

	// RegressionUnverified is not a failure per se — it flags pipelines
	// whose receivers don't implement TestDriver, so the harness could
	// only verify Start/Shutdown, not signal flow. Callers can choose
	// whether to treat this as failing (strict mode) or passing.
	RegressionUnverified RegressionKind = "unverified"
)

// Regression is a single finding in a Report. Component is the manifest
// name of the offending component ("otlp_in", "route", ...); Pipeline is
// the signal it belongs to. Either may be empty when the regression
// applies at manifest scope (e.g. an init failure before any pipeline was
// built).
type Regression struct {
	Kind      RegressionKind
	Pipeline  SignalKind
	Component string
	Message   string
	// Err is the underlying Go error when available. Copied verbatim from
	// factory / Start / Shutdown / Drive so callers can `errors.Is` it.
	Err error
}

func (r Regression) String() string {
	var b strings.Builder
	b.WriteString(string(r.Kind))
	if r.Pipeline != "" {
		b.WriteString(" [")
		b.WriteString(string(r.Pipeline))
		b.WriteString("]")
	}
	if r.Component != "" {
		b.WriteString(" ")
		b.WriteString(r.Component)
	}
	if r.Message != "" {
		b.WriteString(": ")
		b.WriteString(r.Message)
	}
	if r.Err != nil {
		b.WriteString(" (err: ")
		b.WriteString(r.Err.Error())
		b.WriteString(")")
	}
	return b.String()
}

// PipelineStatus is the per-pipeline verdict recorded in the Report.
type PipelineStatus struct {
	Signal        SignalKind
	Built         bool          // pipeline was fully wired
	Started       bool          // every component Start returned nil
	SignalDelivered bool        // synthetic batch reached at least one exporter
	Shutdown      bool          // every component Shutdown returned nil
	Duration      time.Duration // total time from Start to Shutdown
}

// Report is the structured result of a MockCollector run. A Report is
// considered passing iff Regressions is empty. Strict mode (see
// RunOptions.Strict) additionally treats RegressionUnverified as failing.
//
// SecurityPreflight is populated by RunWithSecurityGate; it is nil on
// plain Run() calls that bypass the pre-flight security policy check.
type Report struct {
	ManifestPath      string
	Pipelines         map[SignalKind]*PipelineStatus
	Regressions       []Regression
	Duration          time.Duration
	SecurityPreflight *PreflightVerdict
}

// OK reports whether the run had no regressions. Callers who care about
// Unverified pipelines should check Report.Regressions themselves or use
// FailIfUnverified() as a convenience.
func (r *Report) OK() bool { return len(r.Regressions) == 0 }

// HasKind reports whether any regression of the given kind was recorded.
func (r *Report) HasKind(kind RegressionKind) bool {
	for _, reg := range r.Regressions {
		if reg.Kind == kind {
			return true
		}
	}
	return false
}

// FailIfUnverified upgrades any Unverified pipelines to a hard failure.
// Handy when a caller wants "every pipeline was actually driven" as a
// gate.
func (r *Report) FailIfUnverified() bool {
	return r.OK() && !r.HasKind(RegressionUnverified)
}

// String renders a human-readable summary. Deterministic ordering so
// snapshot tests are stable. If a security pre-flight ran, its report
// is printed first — it's usually what an operator wants to read.
func (r *Report) String() string {
	var b strings.Builder
	if r.SecurityPreflight != nil && r.SecurityPreflight.Security != nil {
		b.WriteString(r.SecurityPreflight.Security.String())
		if !r.SecurityPreflight.PassedGate {
			fmt.Fprintf(&b, "security gate BLOCKED integration tests at severity>=%s\n",
				r.SecurityPreflight.BlockedAt)
			return b.String()
		}
	}
	fmt.Fprintf(&b, "Report(%s) — %s\n", r.ManifestPath, r.Duration)

	// Pipelines sorted by signal name.
	kinds := make([]SignalKind, 0, len(r.Pipelines))
	for k := range r.Pipelines {
		kinds = append(kinds, k)
	}
	sort.Slice(kinds, func(i, j int) bool { return kinds[i] < kinds[j] })
	for _, k := range kinds {
		p := r.Pipelines[k]
		fmt.Fprintf(&b,
			"  %-8s built=%-5t started=%-5t signal=%-5t shutdown=%-5t (%s)\n",
			k, p.Built, p.Started, p.SignalDelivered, p.Shutdown, p.Duration)
	}
	if len(r.Regressions) == 0 {
		b.WriteString("  regressions: none\n")
	} else {
		b.WriteString("  regressions:\n")
		for _, reg := range r.Regressions {
			fmt.Fprintf(&b, "    - %s\n", reg)
		}
	}
	return b.String()
}
