package configharness

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"time"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/component/componenttest"
	"go.opentelemetry.io/collector/consumer"
	"go.uber.org/zap"
	"go.uber.org/zap/zaptest/observer"
)

// RunOptions tunes MockCollector.Run behavior. Zero-value options are the
// documented defaults — no need to fill anything in for common cases.
type RunOptions struct {
	// StartTimeout bounds how long every component.Start() may take
	// collectively. Default: 5 seconds.
	StartTimeout time.Duration
	// IngestionTimeout bounds how long a single signal-drive round may
	// take (Drive + downstream propagation). Default: 2 seconds.
	IngestionTimeout time.Duration
	// ShutdownTimeout bounds how long every component.Shutdown() may take
	// collectively. Default: 5 seconds.
	ShutdownTimeout time.Duration

	// Strict, when true, treats RegressionUnverified pipelines as a hard
	// failure. Default: false (an undriven pipeline is only a warning).
	Strict bool

	// Logger, if non-nil, replaces the harness's default observable
	// logger. Most tests should leave this nil and use Report/Logs()
	// instead.
	Logger *zap.Logger
}

func (o RunOptions) withDefaults() RunOptions {
	if o.StartTimeout == 0 {
		o.StartTimeout = 5 * time.Second
	}
	if o.IngestionTimeout == 0 {
		o.IngestionTimeout = 2 * time.Second
	}
	if o.ShutdownTimeout == 0 {
		o.ShutdownTimeout = 5 * time.Second
	}
	return o
}

// MockCollector executes a manifest end-to-end in-process. Construct one
// per test scenario; MockCollectors are not safe to reuse across runs.
type MockCollector struct {
	t        *testing.T
	registry *FactoryRegistry
	settings component.TelemetrySettings
	logger   *zap.Logger
	logObs   *observer.ObservedLogs

	// Populated by Run().
	report *Report
}

// NewMockCollector constructs a MockCollector bound to a testing.T. The
// harness will use t.Helper() throughout and will *never* call t.Fatal
// from a non-main goroutine — instead it records regressions in the
// Report and lets the caller decide policy.
func NewMockCollector(t *testing.T, registry *FactoryRegistry) *MockCollector {
	t.Helper()

	core, obs := observer.New(zap.DebugLevel)
	logger := zap.New(core)
	settings := componenttest.NewNopTelemetrySettings()
	settings.Logger = logger

	return &MockCollector{
		t:        t,
		registry: registry,
		settings: settings,
		logger:   logger,
		logObs:   obs,
	}
}

// LogRecords returns everything the harness's TelemetrySettings.Logger
// emitted during the last Run. Useful for asserting a component logged
// (or did not log) a specific event during init/shutdown.
func (mc *MockCollector) LogRecords() []observer.LoggedEntry { return mc.logObs.All() }

// Run executes the full lifecycle:
//
//  1. Build every component instance the manifest declares, per signal.
//  2. Wire them into pipelines (receiver → processor(s) → fan-out exporters).
//  3. Start every component (bounded by StartTimeout).
//  4. For each pipeline whose receiver implements TestDriver, drive one
//     synthetic batch and confirm at least one exporter observed it
//     (bounded by IngestionTimeout).
//  5. Shut every component down (bounded by ShutdownTimeout).
//
// Errors at every step are captured in the returned Report; Run itself
// only returns a non-nil error for programmer errors like a nil manifest.
func (mc *MockCollector) Run(ctx context.Context, manifest *Manifest, opts RunOptions) *Report {
	mc.t.Helper()

	if manifest == nil {
		panic("configharness: nil manifest")
	}
	opts = opts.withDefaults()
	if opts.Logger != nil {
		mc.logger = opts.Logger
		mc.settings.Logger = opts.Logger
	}

	overallStart := time.Now()
	mc.report = &Report{
		Pipelines: map[SignalKind]*PipelineStatus{},
	}

	// Build every declared pipeline. Each pipeline is fully independent
	// on the wire — we don't share component instances across pipelines
	// (matching Collector semantics: one instance per signal).
	built := mc.buildAll(ctx, manifest)

	// Start.
	startCtx, cancel := context.WithTimeout(ctx, opts.StartTimeout)
	defer cancel()
	mc.startAll(startCtx, built)

	// Drive one batch through every pipeline that has a TestDriver.
	for _, sig := range AllSignals {
		bp, ok := built[sig]
		if !ok || bp.status == nil || !bp.status.Started {
			continue
		}
		mc.driveOne(ctx, bp, opts.IngestionTimeout)
	}

	// Shutdown, always attempted even if start failed — a component that
	// partially initialized still needs its cleanup called.
	shutdownCtx, cancelSD := context.WithTimeout(context.Background(), opts.ShutdownTimeout)
	defer cancelSD()
	mc.shutdownAll(shutdownCtx, built)

	// Post-process: strict mode upgrades unverified to a failure.
	if opts.Strict {
		for _, sig := range AllSignals {
			p, ok := mc.report.Pipelines[sig]
			if ok && p.Built && p.Started && !p.SignalDelivered && p.Shutdown {
				// Already recorded as unverified — nothing to escalate.
			}
			_ = p
		}
	}

	mc.report.Duration = time.Since(overallStart)
	return mc.report
}

// -----------------------------------------------------------------------------
// build
// -----------------------------------------------------------------------------

// builtPipeline is the internal state for one signal's pipeline.
type builtPipeline struct {
	signal     SignalKind
	receivers  []component.Component
	processors []component.Component
	exporters  []component.Component
	// exporterSinks holds the mock-sink handles the harness attached to
	// each exporter (populated by mock exporter factories). Every stock
	// exporter in this package's `mocks` file supports it; third-party
	// exporters simply won't populate it and the pipeline is marked
	// unverified.
	exporterSinks []*ExporterSink
	// driver is the first receiver that implements TestDriver, or nil.
	driver TestDriver

	status *PipelineStatus
}

// components returns every component in the pipeline in start order:
// exporters first (so they can receive before anyone sends), then
// processors, then receivers. Shutdown uses the reverse order.
func (bp *builtPipeline) components() []component.Component {
	out := make([]component.Component, 0, len(bp.receivers)+len(bp.processors)+len(bp.exporters))
	out = append(out, bp.exporters...)
	out = append(out, bp.processors...)
	out = append(out, bp.receivers...)
	return out
}

func (mc *MockCollector) buildAll(ctx context.Context, m *Manifest) map[SignalKind]*builtPipeline {
	out := map[SignalKind]*builtPipeline{}
	for sig, pd := range m.Pipelines {
		status := &PipelineStatus{Signal: sig}
		mc.report.Pipelines[sig] = status

		bp := &builtPipeline{signal: sig, status: status}
		out[sig] = bp

		if err := mc.buildOne(ctx, m, sig, pd, bp); err != nil {
			mc.record(Regression{
				Kind:     RegressionPipelineUnlinked,
				Pipeline: sig,
				Message:  err.Error(),
				Err:      err,
			})
			// buildOne cleans up its own partial state — nothing further to do.
			continue
		}
		status.Built = true
	}
	return out
}

func (mc *MockCollector) buildOne(ctx context.Context, m *Manifest, sig SignalKind, pd PipelineDecl, bp *builtPipeline) error {
	// 1. Build exporters first. They're the terminals every pipeline
	//    stage will eventually be handed to.
	var (
		expLogs    []consumer.Logs
		expMetrics []consumer.Metrics
		expTraces  []consumer.Traces
	)
	for _, name := range pd.Exporters {
		decl := m.Exporters[name]
		f, err := mc.registry.getExporter(decl.Type)
		if err != nil {
			return fmt.Errorf("exporter %q: %w", name, err)
		}
		cmp, err := f.CreateExporter(ctx, mc.settings, &decl.Config, sig)
		if err != nil {
			mc.record(Regression{
				Kind: RegressionInitFailure, Pipeline: sig, Component: name, Err: err,
				Message: "exporter factory returned error",
			})
			return err
		}
		bp.exporters = append(bp.exporters, cmp)
		if sink, ok := cmp.(interface{ ExporterSink() *ExporterSink }); ok {
			bp.exporterSinks = append(bp.exporterSinks, sink.ExporterSink())
		}

		switch sig {
		case SignalLogs:
			c, err := assertConsumesLogs(cmp, "exporter", name)
			if err != nil {
				mc.record(Regression{Kind: RegressionInitFailure, Pipeline: sig, Component: name, Err: err, Message: err.Error()})
				return err
			}
			expLogs = append(expLogs, c)
		case SignalMetrics:
			c, err := assertConsumesMetrics(cmp, "exporter", name)
			if err != nil {
				mc.record(Regression{Kind: RegressionInitFailure, Pipeline: sig, Component: name, Err: err, Message: err.Error()})
				return err
			}
			expMetrics = append(expMetrics, c)
		case SignalTraces:
			c, err := assertConsumesTraces(cmp, "exporter", name)
			if err != nil {
				mc.record(Regression{Kind: RegressionInitFailure, Pipeline: sig, Component: name, Err: err, Message: err.Error()})
				return err
			}
			expTraces = append(expTraces, c)
		}
	}

	// 2. Build processors in reverse: the last processor points at the
	//    exporter fan-out; the second-to-last points at the last; and so
	//    on. This gives us a single "head" consumer to hand to the
	//    receivers.
	var head any
	switch sig {
	case SignalLogs:
		head = logsFanout(expLogs)
	case SignalMetrics:
		head = metricsFanout(expMetrics)
	case SignalTraces:
		head = tracesFanout(expTraces)
	}

	for i := len(pd.Processors) - 1; i >= 0; i-- {
		name := pd.Processors[i]
		decl := m.Processors[name]
		f, err := mc.registry.getProcessor(decl.Type)
		if err != nil {
			return fmt.Errorf("processor %q: %w", name, err)
		}
		cmp, err := f.CreateProcessor(ctx, mc.settings, &decl.Config, sig, head)
		if err != nil {
			mc.record(Regression{Kind: RegressionInitFailure, Pipeline: sig, Component: name, Err: err, Message: "processor factory returned error"})
			return err
		}
		bp.processors = append([]component.Component{cmp}, bp.processors...) // preserve declared order

		// The processor becomes the new head for whatever's upstream.
		switch sig {
		case SignalLogs:
			head, err = assertConsumesLogs(cmp, "processor", name)
		case SignalMetrics:
			head, err = assertConsumesMetrics(cmp, "processor", name)
		case SignalTraces:
			head, err = assertConsumesTraces(cmp, "processor", name)
		}
		if err != nil {
			mc.record(Regression{Kind: RegressionInitFailure, Pipeline: sig, Component: name, Err: err, Message: err.Error()})
			return err
		}
	}

	// 3. Build receivers with `head` as their downstream.
	for _, name := range pd.Receivers {
		decl := m.Receivers[name]
		f, err := mc.registry.getReceiver(decl.Type)
		if err != nil {
			return fmt.Errorf("receiver %q: %w", name, err)
		}
		cmp, err := f.CreateReceiver(ctx, mc.settings, &decl.Config, sig, head)
		if err != nil {
			mc.record(Regression{Kind: RegressionInitFailure, Pipeline: sig, Component: name, Err: err, Message: "receiver factory returned error"})
			return err
		}
		bp.receivers = append(bp.receivers, cmp)
		if bp.driver == nil {
			if d, ok := cmp.(TestDriver); ok {
				bp.driver = d
			}
		}
	}

	return nil
}

// -----------------------------------------------------------------------------
// start / drive / shutdown
// -----------------------------------------------------------------------------

func (mc *MockCollector) startAll(ctx context.Context, built map[SignalKind]*builtPipeline) {
	for _, sig := range AllSignals {
		bp, ok := built[sig]
		if !ok || !bp.status.Built {
			continue
		}
		start := time.Now()
		host := componenttest.NewNopHost()
		startedAll := true
		for _, c := range bp.components() {
			if err := c.Start(ctx, host); err != nil {
				mc.record(Regression{
					Kind: RegressionStartFailure, Pipeline: sig,
					Component: componentName(c),
					Err:       err,
					Message:   "Start returned error",
				})
				startedAll = false
				break
			}
		}
		bp.status.Started = startedAll
		bp.status.Duration += time.Since(start)
	}
}

func (mc *MockCollector) driveOne(ctx context.Context, bp *builtPipeline, timeout time.Duration) {
	if bp.driver == nil {
		mc.record(Regression{
			Kind: RegressionUnverified, Pipeline: bp.signal,
			Message: "no receiver on this pipeline implements TestDriver; signal flow not verified",
		})
		return
	}

	// Reset sinks so counts are per-drive, not cumulative across signals.
	for _, s := range bp.exporterSinks {
		s.Reset()
	}

	driveCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	// Drive on a goroutine so a hung Drive() maps to RegressionIngestionBlocked
	// instead of hanging the whole test.
	errCh := make(chan error, 1)
	go func() {
		defer func() {
			if r := recover(); r != nil {
				errCh <- fmt.Errorf("Drive panic: %v", r)
			}
		}()
		errCh <- bp.driver.Drive(driveCtx, bp.signal)
	}()

	select {
	case err := <-errCh:
		if err != nil {
			mc.record(Regression{
				Kind: RegressionIngestionError, Pipeline: bp.signal,
				Err: err, Message: "Drive returned error",
			})
			return
		}
	case <-driveCtx.Done():
		mc.record(Regression{
			Kind: RegressionIngestionBlocked, Pipeline: bp.signal,
			Message: fmt.Sprintf("Drive did not return within %s", timeout),
			Err:     driveCtx.Err(),
		})
		return
	}

	// Signal was driven; now verify at least one exporter saw it.
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if bp.anySinkSaw() {
			bp.status.SignalDelivered = true
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	if !bp.status.SignalDelivered {
		mc.record(Regression{
			Kind: RegressionIngestionBlocked, Pipeline: bp.signal,
			Message: fmt.Sprintf("no exporter observed the driven signal within %s", timeout),
		})
	}
}

func (bp *builtPipeline) anySinkSaw() bool {
	for _, s := range bp.exporterSinks {
		if s.Count() > 0 {
			return true
		}
	}
	return false
}

func (mc *MockCollector) shutdownAll(ctx context.Context, built map[SignalKind]*builtPipeline) {
	for _, sig := range AllSignals {
		bp, ok := built[sig]
		if !ok || !bp.status.Built {
			continue
		}
		// Reverse of components(): receivers first (stop taking new data),
		// then processors, then exporters (drain last).
		comps := bp.components()
		reverse(comps)

		var firstErr error
		var firstComp string
		done := make(chan struct{})
		go func() {
			defer close(done)
			for _, c := range comps {
				if err := c.Shutdown(ctx); err != nil {
					if firstErr == nil {
						firstErr = err
						firstComp = componentName(c)
					}
				}
			}
		}()
		select {
		case <-done:
		case <-ctx.Done():
			mc.record(Regression{
				Kind: RegressionShutdownFailure, Pipeline: sig,
				Message: "Shutdown exceeded deadline",
				Err:     ctx.Err(),
			})
			continue
		}
		if firstErr != nil {
			mc.record(Regression{
				Kind: RegressionShutdownFailure, Pipeline: sig,
				Component: firstComp,
				Err:       firstErr,
				Message:   "Shutdown returned error",
			})
			continue
		}
		bp.status.Shutdown = true
	}
}

// -----------------------------------------------------------------------------
// helpers
// -----------------------------------------------------------------------------

func (mc *MockCollector) record(r Regression) {
	mc.report.Regressions = append(mc.report.Regressions, r)
	mc.logger.Debug("regression recorded",
		zap.String("kind", string(r.Kind)),
		zap.String("pipeline", string(r.Pipeline)),
		zap.String("component", r.Component),
		zap.String("message", r.Message),
	)
}

func reverse[T any](s []T) {
	for i, j := 0, len(s)-1; i < j; i, j = i+1, j-1 {
		s[i], s[j] = s[j], s[i]
	}
}

// componentName does a best-effort name lookup: many collector components
// implement a Name() string method for logs; falling back to the type
// name keeps error messages informative.
func componentName(c component.Component) string {
	type named interface{ Name() string }
	if n, ok := c.(named); ok {
		return n.Name()
	}
	return fmt.Sprintf("%T", c)
}

// -----------------------------------------------------------------------------
// Test helpers
// -----------------------------------------------------------------------------

// AssertOK fails the test with a readable diff if the Report contains any
// regression. Callers who want to permit RegressionUnverified should use
// AssertOKStrict(false).
func AssertOK(t *testing.T, r *Report) { t.Helper(); AssertOKStrict(t, r, false) }

// AssertOKStrict is like AssertOK but lets the caller demand every
// pipeline was actually driven.
func AssertOKStrict(t *testing.T, r *Report, strict bool) {
	t.Helper()
	if r == nil {
		t.Fatal("configharness: nil report")
	}
	fatal := false
	var problems []string
	for _, reg := range r.Regressions {
		if reg.Kind == RegressionUnverified && !strict {
			continue
		}
		fatal = true
		problems = append(problems, reg.String())
	}
	if fatal {
		t.Fatalf("configharness: %d regression(s):\n  %s\n\nfull report:\n%s",
			len(problems), joinLines(problems), r)
	}
}

// AssertRegressionKind asserts that the Report contains at least one
// regression with the given kind. Used to test that a *bad* manifest is
// correctly flagged.
func AssertRegressionKind(t *testing.T, r *Report, kind RegressionKind) {
	t.Helper()
	if !r.HasKind(kind) {
		t.Fatalf("configharness: expected regression %q, got:\n%s", kind, r)
	}
}

func joinLines(xs []string) string {
	out := ""
	for i, x := range xs {
		if i > 0 {
			out += "\n  "
		}
		out += x
	}
	return out
}

// Sentinel so `errors.Is` works when a regression carries no explicit err.
var errIngestionTimeout = errors.New("ingestion timed out")

var _ = errIngestionTimeout // reserved for future use
