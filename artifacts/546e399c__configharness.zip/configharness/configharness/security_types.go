package configharness

import (
	"fmt"
	"sort"
	"strings"
)

// Severity classifies how loudly a security finding should be reported and
// whether it should block downstream integration tests. Ordered highest to
// lowest so callers can write `finding.Severity >= SeverityHigh`.
type Severity int

const (
	// SeverityInfo is informational only — style hints, best-practice
	// suggestions. Never blocks.
	SeverityInfo Severity = iota
	// SeverityLow is a weak violation. Report, do not block by default.
	SeverityLow
	// SeverityMedium is a real hardening gap. Report, warn, but do not
	// block by default. Callers can promote to blocking via BlockAt.
	SeverityMedium
	// SeverityHigh is a serious hardening gap (unencrypted transport in a
	// non-loopback exporter, wide-open admin surface). Blocks by default.
	SeverityHigh
	// SeverityCritical is a "do not deploy" finding (credentials in
	// plaintext, no TLS on an internet-facing endpoint). Blocks by default
	// and cannot be silenced without explicit rule-ID allowlisting.
	SeverityCritical
)

func (s Severity) String() string {
	switch s {
	case SeverityInfo:
		return "info"
	case SeverityLow:
		return "low"
	case SeverityMedium:
		return "medium"
	case SeverityHigh:
		return "high"
	case SeverityCritical:
		return "critical"
	}
	return fmt.Sprintf("severity(%d)", s)
}

// Finding is a single policy violation attached to a specific location in
// a manifest. `Path` is a dotted JSON-Pointer-ish string (e.g.
// "exporters.otlp_out.tls.insecure") so operators can jump straight to the
// offending line.
type Finding struct {
	RuleID    string
	Severity  Severity
	Component string   // e.g. "exporters.otlp_out"
	Path      string   // e.g. "exporters.otlp_out.tls.insecure"
	Message   string   // human-readable
	Value     any      // the offending value (redacted for secrets)
	Refs      []string // optional hardening-guide references
}

func (f Finding) String() string {
	var b strings.Builder
	fmt.Fprintf(&b, "[%s] %s (%s)", f.Severity, f.RuleID, f.Path)
	if f.Message != "" {
		b.WriteString(": ")
		b.WriteString(f.Message)
	}
	if f.Value != nil {
		fmt.Fprintf(&b, " (value: %v)", f.Value)
	}
	return b.String()
}

// SecurityReport bundles every finding produced by a policy run. It is
// deliberately separate from the integration Report so callers can render
// it independently — for example, printing the security report first in
// CI output before any test starts.
type SecurityReport struct {
	ManifestPath string
	Findings     []Finding
	// AppliedRules is the ordered list of rule IDs that ran. Useful when
	// a caller wants to prove a specific check was executed (e.g. "the
	// no-plaintext-otlp rule ran against this manifest and passed").
	AppliedRules []string
}

// HighestSeverity returns the max severity across all findings, or
// SeverityInfo when there are none.
func (r *SecurityReport) HighestSeverity() Severity {
	max := SeverityInfo
	for _, f := range r.Findings {
		if f.Severity > max {
			max = f.Severity
		}
	}
	return max
}

// FindingsAtOrAbove returns every finding with severity >= threshold.
// Order is preserved from insertion so tests can rely on deterministic
// output when the rules are applied in a fixed order.
func (r *SecurityReport) FindingsAtOrAbove(threshold Severity) []Finding {
	out := make([]Finding, 0, len(r.Findings))
	for _, f := range r.Findings {
		if f.Severity >= threshold {
			out = append(out, f)
		}
	}
	return out
}

// HasRule reports whether at least one finding has the given rule ID.
// Tests use this to assert that a specific rule fired.
func (r *SecurityReport) HasRule(id string) bool {
	for _, f := range r.Findings {
		if f.RuleID == id {
			return true
		}
	}
	return false
}

// OK reports whether the report has no findings at all. Prefer PassesGate
// for pre-flight decisions.
func (r *SecurityReport) OK() bool { return len(r.Findings) == 0 }

// PassesGate returns true when no finding meets or exceeds `blockAt`.
// This is what MockCollector uses to decide whether to abort before the
// integration phase.
func (r *SecurityReport) PassesGate(blockAt Severity) bool {
	for _, f := range r.Findings {
		if f.Severity >= blockAt {
			return false
		}
	}
	return true
}

// String renders a stable, human-readable summary. Findings are grouped
// by severity descending, then sorted by rule ID within each group so
// snapshot tests are deterministic.
func (r *SecurityReport) String() string {
	var b strings.Builder
	fmt.Fprintf(&b, "SecurityReport(%s): %d finding(s)\n", r.ManifestPath, len(r.Findings))
	if len(r.Findings) == 0 {
		b.WriteString("  no violations\n")
		return b.String()
	}
	// Bucket by severity descending.
	buckets := map[Severity][]Finding{}
	for _, f := range r.Findings {
		buckets[f.Severity] = append(buckets[f.Severity], f)
	}
	sevs := []Severity{SeverityCritical, SeverityHigh, SeverityMedium, SeverityLow, SeverityInfo}
	for _, s := range sevs {
		fs := buckets[s]
		if len(fs) == 0 {
			continue
		}
		sort.SliceStable(fs, func(i, j int) bool {
			if fs[i].RuleID != fs[j].RuleID {
				return fs[i].RuleID < fs[j].RuleID
			}
			return fs[i].Path < fs[j].Path
		})
		fmt.Fprintf(&b, "  %s:\n", s)
		for _, f := range fs {
			fmt.Fprintf(&b, "    - %s\n", f)
		}
	}
	return b.String()
}
