package configharness

import (
	"fmt"
	"strings"

	"gopkg.in/yaml.v3"
)

// -----------------------------------------------------------------------------
// Flattened manifest view
// -----------------------------------------------------------------------------
//
// Rules operate against a ScannedComponent instead of raw yaml.Nodes. The
// scanner turns each component's ComponentDecl into a flat map of dotted
// paths → primitive values, plus a small set of pre-extracted well-known
// keys (endpoint, tls, auth). Doing the walk once means rules stay short
// and easy to review.

// ComponentRole is where in the pipeline a component sits.
type ComponentRole string

const (
	RoleReceiver  ComponentRole = "receivers"
	RoleProcessor ComponentRole = "processors"
	RoleExporter  ComponentRole = "exporters"
	// RoleExtension is included for completeness — real Collector configs
	// often have an `extensions` block (zpages, health_check, pprof) that
	// is a rich source of admin-surface findings. The scanner reads it
	// even though MockCollector doesn't currently build extensions.
	RoleExtension ComponentRole = "extensions"
)

// ScannedComponent is a rule-friendly view of one manifest entry.
type ScannedComponent struct {
	Role ComponentRole
	Name string
	Type string

	// Values is a flat map of "leaf.path" → primitive value. Nested maps
	// are joined with "."; list items get "[i]" indices. Only scalars end
	// up here; container nodes are skipped.
	//
	// Examples:
	//   "endpoint"           -> "0.0.0.0:4317"
	//   "tls.insecure"       -> true
	//   "headers.Authorization" -> "Basic YWRtaW46YWRtaW4="
	Values map[string]any

	// Present is the set of every path (including container nodes) that
	// exists in the config. Lets rules ask "was tls specified at all?"
	// without having to test each key.
	Present map[string]struct{}
}

// FullPath renders the manifest-scope path of a leaf beneath this
// component. Used to build human-readable Finding.Path values.
func (c *ScannedComponent) FullPath(leaf string) string {
	if leaf == "" {
		return fmt.Sprintf("%s.%s", c.Role, c.Name)
	}
	return fmt.Sprintf("%s.%s.%s", c.Role, c.Name, leaf)
}

// GetString returns the string value at `path` if present, else "".
func (c *ScannedComponent) GetString(path string) string {
	if v, ok := c.Values[path]; ok {
		if s, ok := v.(string); ok {
			return s
		}
	}
	return ""
}

// GetBool returns the bool at `path` if present, else (false, false).
func (c *ScannedComponent) GetBool(path string) (bool, bool) {
	if v, ok := c.Values[path]; ok {
		if b, ok := v.(bool); ok {
			return b, true
		}
	}
	return false, false
}

// Has reports whether any leaf exists under `prefix`.
func (c *ScannedComponent) Has(prefix string) bool {
	if _, ok := c.Present[prefix]; ok {
		return true
	}
	// Fallback: prefix might not itself be a node key (some parsers only
	// register leaves). Do a linear check.
	prefixDot := prefix + "."
	for k := range c.Present {
		if k == prefix || strings.HasPrefix(k, prefixDot) {
			return true
		}
	}
	return false
}

// FindPathsWithSuffix returns every leaf path ending with `suffix`.
// Useful for rules that inspect free-form maps like `headers.*` or
// `attributes.*`.
func (c *ScannedComponent) FindPathsWithSuffix(suffix string) []string {
	var out []string
	for k := range c.Values {
		if k == suffix || strings.HasSuffix(k, "."+suffix) {
			out = append(out, k)
		}
	}
	return out
}

// EndpointHost extracts the host portion of "host:port" (or "scheme://host:port").
// Returns "" if the endpoint isn't declared. The check is intentionally
// simple — we don't need net/url's full parser and we want to handle the
// common Collector shorthand `0.0.0.0:4317`.
func (c *ScannedComponent) EndpointHost() string {
	ep := c.GetString("endpoint")
	if ep == "" {
		return ""
	}
	// Strip optional scheme.
	if i := strings.Index(ep, "://"); i >= 0 {
		ep = ep[i+3:]
	}
	// Strip path component.
	if i := strings.Index(ep, "/"); i >= 0 {
		ep = ep[:i]
	}
	// host:port
	if i := strings.LastIndex(ep, ":"); i >= 0 {
		return ep[:i]
	}
	return ep
}

// EndpointScheme returns "grpc", "http", "https" etc. if a scheme prefix
// is present. Empty when none — Collector convention is that the
// component type determines the transport.
func (c *ScannedComponent) EndpointScheme() string {
	ep := c.GetString("endpoint")
	if i := strings.Index(ep, "://"); i >= 0 {
		return strings.ToLower(ep[:i])
	}
	return ""
}

// -----------------------------------------------------------------------------
// Scanner
// -----------------------------------------------------------------------------

// scanManifest turns every ComponentDecl in the manifest into a
// ScannedComponent. The order is stable (receivers → processors →
// exporters → extensions, then alphabetical by name) so rule application
// order is deterministic.
func scanManifest(m *Manifest, extensions map[string]ComponentDecl) []*ScannedComponent {
	var out []*ScannedComponent
	appendRole := func(role ComponentRole, decls map[string]ComponentDecl) {
		names := sortedKeys(decls)
		for _, name := range names {
			d := decls[name]
			sc := &ScannedComponent{
				Role:    role,
				Name:    name,
				Type:    d.Type,
				Values:  map[string]any{},
				Present: map[string]struct{}{},
			}
			walkYAML("", &d.Config, sc)
			out = append(out, sc)
		}
	}
	appendRole(RoleReceiver, m.Receivers)
	appendRole(RoleProcessor, m.Processors)
	appendRole(RoleExporter, m.Exporters)
	if len(extensions) > 0 {
		appendRole(RoleExtension, extensions)
	}
	return out
}

func sortedKeys(m map[string]ComponentDecl) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	// Small deterministic sort without pulling in sort in tight loops.
	// (Go's sort package is fine; this is just to avoid an extra import
	// on hot paths.)
	for i := 1; i < len(keys); i++ {
		for j := i; j > 0 && keys[j] < keys[j-1]; j-- {
			keys[j], keys[j-1] = keys[j-1], keys[j]
		}
	}
	return keys
}

// walkYAML recursively descends a yaml.Node, populating sc.Values with
// every scalar leaf keyed by dotted path and sc.Present with every
// intermediate container node.
func walkYAML(prefix string, node *yaml.Node, sc *ScannedComponent) {
	if node == nil {
		return
	}
	// yaml.v3 wraps everything in a DocumentNode when parsed at
	// top-level; unwrap.
	if node.Kind == yaml.DocumentNode {
		for _, c := range node.Content {
			walkYAML(prefix, c, sc)
		}
		return
	}

	switch node.Kind {
	case yaml.MappingNode:
		if prefix != "" {
			sc.Present[prefix] = struct{}{}
		}
		// yaml.v3 mapping nodes store [k0, v0, k1, v1, ...].
		for i := 0; i+1 < len(node.Content); i += 2 {
			key := node.Content[i].Value
			child := node.Content[i+1]
			next := key
			if prefix != "" {
				next = prefix + "." + key
			}
			walkYAML(next, child, sc)
		}
	case yaml.SequenceNode:
		if prefix != "" {
			sc.Present[prefix] = struct{}{}
		}
		for i, c := range node.Content {
			next := fmt.Sprintf("%s[%d]", prefix, i)
			walkYAML(next, c, sc)
		}
	case yaml.ScalarNode:
		if prefix == "" {
			return
		}
		sc.Present[prefix] = struct{}{}
		sc.Values[prefix] = decodeScalar(node)
	}
}

// decodeScalar interprets a yaml scalar into a Go primitive. yaml.v3
// stores scalars as strings + a tag; we decode into any{} through the
// node's Decode method to get proper bool/int/string classification.
func decodeScalar(n *yaml.Node) any {
	var v any
	if err := n.Decode(&v); err != nil {
		// Fall back to the raw string on error — this only happens for
		// exotic tags (binary, timestamp) which we don't inspect.
		return n.Value
	}
	return v
}
