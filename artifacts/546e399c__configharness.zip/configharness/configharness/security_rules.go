package configharness

import (
	"strings"
)

// Rule is a single security-policy check. It runs against every
// ScannedComponent in isolation and appends zero or more Findings.
//
// Rules should be small, side-effect-free, and reference their own
// documentation via the Refs slice on the Finding so operators can jump
// straight to the internal hardening guide.
type Rule struct {
	ID          string
	Severity    Severity
	Description string
	// Apply is called once per component. It must not mutate `sc`.
	Apply func(sc *ScannedComponent, emit func(Finding))
}

// PolicySet is an ordered list of rules. Order matters only for report
// stability; rule evaluation is otherwise independent.
type PolicySet struct {
	Rules []Rule
	// AllowRuleIDs is an optional allowlist: when non-empty, only these
	// IDs are executed. Handy for narrowing to a single check in tests.
	AllowRuleIDs map[string]bool
	// SuppressRuleIDs, when non-empty, skips these IDs entirely. Use to
	// carve out a documented exception ("this manifest is loopback-only,
	// no-tls is intentional"). Prefer to override severity via a custom
	// rule when possible, since blanket suppression loses forensic value.
	SuppressRuleIDs map[string]bool
}

// scanWith applies the policy set to every scanned component and returns
// findings in a deterministic order (component order first, then rule
// order within a component).
func (ps PolicySet) scanWith(components []*ScannedComponent) ([]Finding, []string) {
	var findings []Finding
	var applied []string
	for _, rule := range ps.Rules {
		if len(ps.AllowRuleIDs) > 0 && !ps.AllowRuleIDs[rule.ID] {
			continue
		}
		if ps.SuppressRuleIDs[rule.ID] {
			continue
		}
		applied = append(applied, rule.ID)
	}
	for _, sc := range components {
		for _, rule := range ps.Rules {
			if len(ps.AllowRuleIDs) > 0 && !ps.AllowRuleIDs[rule.ID] {
				continue
			}
			if ps.SuppressRuleIDs[rule.ID] {
				continue
			}
			rule.Apply(sc, func(f Finding) {
				// Fill in rule-scope fields the rule itself didn't set.
				if f.RuleID == "" {
					f.RuleID = rule.ID
				}
				if f.Severity == 0 {
					f.Severity = rule.Severity
				}
				if f.Component == "" {
					f.Component = sc.FullPath("")
				}
				findings = append(findings, f)
			})
		}
	}
	return findings, applied
}

// -----------------------------------------------------------------------------
// Default hardening rule set
// -----------------------------------------------------------------------------
//
// These implement the "internal hardening guidelines" mentioned in the
// harness spec. Each is documented with the concrete misconfiguration it
// catches so operators reading the report can trace back to intent.

// DefaultPolicySet returns the standard hardening rules. Callers are
// encouraged to embed it into a custom set (append their own rules,
// suppress specific IDs) rather than rewriting from scratch.
func DefaultPolicySet() PolicySet {
	return PolicySet{
		Rules: []Rule{
			ruleUnencryptedOTLPExporter(),
			ruleTLSInsecureFlag(),
			ruleTLSInsecureSkipVerify(),
			ruleMissingTLSOnRemoteReceiver(),
			ruleAuthMissingOnPublicReceiver(),
			rulePlaintextAuthHeader(),
			ruleAdminExtensionExposedNonLoopback(),
			ruleDebugExporterInPipeline(),
			ruleWildcardEndpointBinding(),
			ruleSecretsInPlaintext(),
		},
	}
}

// -----------------------------------------------------------------------------
// Rule implementations
// -----------------------------------------------------------------------------

// ruleUnencryptedOTLPExporter: an OTLP-family exporter with a non-loopback
// endpoint that either explicitly sets tls.insecure=true or uses the
// http:// scheme.
func ruleUnencryptedOTLPExporter() Rule {
	return Rule{
		ID:          "SEC001",
		Severity:    SeverityCritical,
		Description: "OTLP exporter transmits telemetry over an unencrypted channel to a non-loopback destination.",
		Apply: func(sc *ScannedComponent, emit func(Finding)) {
			if sc.Role != RoleExporter {
				return
			}
			if !isOTLPType(sc.Type) {
				return
			}
			host := sc.EndpointHost()
			if host == "" || isLoopback(host) {
				return
			}
			// Insecure explicitly set → violation.
			if v, ok := sc.GetBool("tls.insecure"); ok && v {
				emit(Finding{
					Path:    sc.FullPath("tls.insecure"),
					Message: "OTLP exporter has tls.insecure=true to a non-loopback endpoint",
					Value:   true,
					Refs:    []string{"hardening-guide#TLS-Everywhere"},
				})
				return
			}
			// http:// scheme is plaintext by default.
			if sc.EndpointScheme() == "http" {
				emit(Finding{
					Path:    sc.FullPath("endpoint"),
					Message: "OTLP exporter uses http:// scheme to a non-loopback endpoint (use https:// or grpc+TLS)",
					Value:   sc.GetString("endpoint"),
					Refs:    []string{"hardening-guide#TLS-Everywhere"},
				})
			}
		},
	}
}

// ruleTLSInsecureFlag: any component that turns off certificate validation
// entirely — this is a common footgun during dev that must not ship.
func ruleTLSInsecureFlag() Rule {
	return Rule{
		ID:          "SEC002",
		Severity:    SeverityHigh,
		Description: "Component disables TLS entirely via tls.insecure=true.",
		Apply: func(sc *ScannedComponent, emit func(Finding)) {
			if v, ok := sc.GetBool("tls.insecure"); ok && v {
				// Loopback exporters are downgraded by SEC001; here we
				// only report at High for non-exporter roles or when
				// the endpoint is empty/loopback (still worth flagging
				// so ops can decide).
				sev := SeverityHigh
				if sc.Role == RoleExporter && isLoopback(sc.EndpointHost()) {
					sev = SeverityMedium
				}
				emit(Finding{
					Severity: sev,
					Path:     sc.FullPath("tls.insecure"),
					Message:  "tls.insecure=true disables all transport encryption",
					Value:    true,
					Refs:     []string{"hardening-guide#TLS-Everywhere"},
				})
			}
		},
	}
}

// ruleTLSInsecureSkipVerify: certificate validation disabled but TLS
// itself still active. Downgrade-attack vector.
func ruleTLSInsecureSkipVerify() Rule {
	return Rule{
		ID:          "SEC003",
		Severity:    SeverityHigh,
		Description: "Component sets tls.insecure_skip_verify=true, disabling certificate validation.",
		Apply: func(sc *ScannedComponent, emit func(Finding)) {
			if v, ok := sc.GetBool("tls.insecure_skip_verify"); ok && v {
				emit(Finding{
					Path:    sc.FullPath("tls.insecure_skip_verify"),
					Message: "certificate validation is disabled; man-in-the-middle attacks are possible",
					Value:   true,
					Refs:    []string{"hardening-guide#Certificate-Validation"},
				})
			}
		},
	}
}

// ruleMissingTLSOnRemoteReceiver: a receiver listening on a non-loopback
// address without any tls.* block. This is the reverse of SEC001 — a
// receiver that accepts plaintext traffic from the network.
func ruleMissingTLSOnRemoteReceiver() Rule {
	return Rule{
		ID:          "SEC004",
		Severity:    SeverityHigh,
		Description: "Receiver bound to a non-loopback address without a TLS configuration.",
		Apply: func(sc *ScannedComponent, emit func(Finding)) {
			if sc.Role != RoleReceiver {
				return
			}
			// Only relevant for network receivers that we recognize.
			if !isNetworkReceiverType(sc.Type) {
				return
			}
			host := sc.EndpointHost()
			if host == "" || isLoopback(host) {
				return
			}
			if !sc.Has("tls") {
				emit(Finding{
					Path:    sc.FullPath("endpoint"),
					Message: "network-facing receiver has no tls block; traffic will be accepted in plaintext",
					Value:   sc.GetString("endpoint"),
					Refs:    []string{"hardening-guide#TLS-Everywhere"},
				})
			}
		},
	}
}

// ruleAuthMissingOnPublicReceiver: a network receiver with no auth block.
// We keep this at Medium because internal networks sometimes rely on
// network-level auth; teams should still see it in the report.
func ruleAuthMissingOnPublicReceiver() Rule {
	return Rule{
		ID:          "SEC005",
		Severity:    SeverityMedium,
		Description: "Receiver has no auth block; anonymous producers may push telemetry.",
		Apply: func(sc *ScannedComponent, emit func(Finding)) {
			if sc.Role != RoleReceiver {
				return
			}
			if !isNetworkReceiverType(sc.Type) {
				return
			}
			host := sc.EndpointHost()
			if host == "" || isLoopback(host) {
				return
			}
			if !sc.Has("auth") {
				emit(Finding{
					Path:    sc.FullPath("auth"),
					Message: "no auth block configured for a network-facing receiver",
					Refs:    []string{"hardening-guide#AuthN"},
				})
			}
		},
	}
}

// rulePlaintextAuthHeader: any header called "authorization" or "x-api-key"
// with a literal value hard-coded in the manifest. Real deployments should
// use env-var substitution or a credential provider.
//
// The rule matches value strings that don't look like `${env:*}` or
// `${file:*}` templating.
func rulePlaintextAuthHeader() Rule {
	return Rule{
		ID:          "SEC006",
		Severity:    SeverityCritical,
		Description: "Credential is embedded in the manifest instead of being sourced from an environment variable or secret store.",
		Apply: func(sc *ScannedComponent, emit func(Finding)) {
			// Look under headers.*, auth.headers.*, and top-level api_key/token.
			for _, p := range sc.Values {
				_ = p // silence unused for the case-fallback below
			}
			for _, path := range sc.FindPathsWithSuffix("authorization") {
				checkPlaintextSecret(sc, path, emit)
			}
			for _, path := range sc.FindPathsWithSuffix("Authorization") {
				checkPlaintextSecret(sc, path, emit)
			}
			for _, path := range sc.FindPathsWithSuffix("x-api-key") {
				checkPlaintextSecret(sc, path, emit)
			}
			for _, path := range sc.FindPathsWithSuffix("api_key") {
				checkPlaintextSecret(sc, path, emit)
			}
			for _, path := range sc.FindPathsWithSuffix("token") {
				checkPlaintextSecret(sc, path, emit)
			}
			for _, path := range sc.FindPathsWithSuffix("password") {
				checkPlaintextSecret(sc, path, emit)
			}
		},
	}
}

func checkPlaintextSecret(sc *ScannedComponent, path string, emit func(Finding)) {
	v := sc.GetString(path)
	if v == "" {
		return
	}
	if looksLikeTemplate(v) {
		return
	}
	emit(Finding{
		Path:    sc.FullPath(path),
		Message: "credential value appears to be a plaintext literal; source from ${env:*} or a secret backend",
		Value:   redact(v),
		Refs:    []string{"hardening-guide#Secrets"},
	})
}

// ruleAdminExtensionExposedNonLoopback: admin-plane extensions (pprof,
// zpages, health_check) bound to non-loopback addresses. These leak
// internal state and, for pprof, allow remote code paths that shouldn't
// be reachable from the network.
func ruleAdminExtensionExposedNonLoopback() Rule {
	return Rule{
		ID:          "SEC007",
		Severity:    SeverityHigh,
		Description: "Admin-plane extension exposed on a non-loopback address.",
		Apply: func(sc *ScannedComponent, emit func(Finding)) {
			if sc.Role != RoleExtension {
				return
			}
			if !isAdminExtensionType(sc.Type) {
				return
			}
			// Extensions store their listener under `endpoint` conventionally.
			host := sc.EndpointHost()
			if host == "" {
				// Some admin extensions default to 0.0.0.0:PORT when no
				// endpoint is specified; flag as an explicit warning so
				// operators pin the address themselves.
				emit(Finding{
					Severity: SeverityMedium,
					Path:     sc.FullPath("endpoint"),
					Message:  "admin extension has no endpoint set; default bind may expose it on all interfaces",
					Refs:     []string{"hardening-guide#Admin-Surface"},
				})
				return
			}
			if !isLoopback(host) {
				emit(Finding{
					Path:    sc.FullPath("endpoint"),
					Message: "admin extension listens on a non-loopback address",
					Value:   sc.GetString("endpoint"),
					Refs:    []string{"hardening-guide#Admin-Surface"},
				})
			}
		},
	}
}

// ruleDebugExporterInPipeline: the debug/logging exporter (component types
// `debug`, `logging`) prints every batch to stdout — usually fine for a
// dev environment, but a red flag if it survives into a production
// manifest, since it can log PII/secrets from telemetry attributes.
func ruleDebugExporterInPipeline() Rule {
	return Rule{
		ID:          "SEC008",
		Severity:    SeverityLow,
		Description: "debug/logging exporter present; may write telemetry (including sensitive attributes) to stdout.",
		Apply: func(sc *ScannedComponent, emit func(Finding)) {
			if sc.Role != RoleExporter {
				return
			}
			if sc.Type == "debug" || sc.Type == "logging" {
				emit(Finding{
					Path:    sc.FullPath(""),
					Message: "debug/logging exporter is enabled; ensure this manifest is not used in production",
					Refs:    []string{"hardening-guide#Debug-Surfaces"},
				})
			}
		},
	}
}

// ruleWildcardEndpointBinding: any component bound to 0.0.0.0 or :: is
// listening on every interface. For internal-only deployments operators
// usually want to pin to a specific NIC.
func ruleWildcardEndpointBinding() Rule {
	return Rule{
		ID:          "SEC009",
		Severity:    SeverityMedium,
		Description: "Component binds to a wildcard address (0.0.0.0 or ::), exposing it on every interface.",
		Apply: func(sc *ScannedComponent, emit func(Finding)) {
			host := sc.EndpointHost()
			if host == "0.0.0.0" || host == "::" || host == "" && sc.Has("endpoint") {
				// Skip if we already know the endpoint was empty (that's
				// covered by SEC007's default-bind branch).
				if host == "" {
					return
				}
				emit(Finding{
					Path:    sc.FullPath("endpoint"),
					Message: "wildcard bind address; pin to a specific interface unless intentional",
					Value:   sc.GetString("endpoint"),
					Refs:    []string{"hardening-guide#Bind-Address"},
				})
			}
		},
	}
}

// ruleSecretsInPlaintext: a catch-all for known-suspicious value shapes
// (looks like a JWT, a bearer token, an AWS key) appearing anywhere in
// a component's config. This complements SEC006 which only checks known
// credential *keys*.
func ruleSecretsInPlaintext() Rule {
	return Rule{
		ID:          "SEC010",
		Severity:    SeverityCritical,
		Description: "Value in manifest matches the shape of a bearer credential (JWT, AWS access key, etc.).",
		Apply: func(sc *ScannedComponent, emit func(Finding)) {
			for path, v := range sc.Values {
				s, ok := v.(string)
				if !ok {
					continue
				}
				if looksLikeTemplate(s) {
					continue
				}
				if !looksLikeSecret(s) {
					continue
				}
				emit(Finding{
					Path:    sc.FullPath(path),
					Message: "value matches a credential-shape pattern; move it to a secret store",
					Value:   redact(s),
					Refs:    []string{"hardening-guide#Secrets"},
				})
			}
		},
	}
}

// -----------------------------------------------------------------------------
// Small helpers used by rules
// -----------------------------------------------------------------------------

func isOTLPType(t string) bool {
	switch t {
	case "otlp", "otlphttp":
		return true
	}
	return strings.HasPrefix(t, "otlp/") || strings.HasPrefix(t, "otlphttp/")
}

func isNetworkReceiverType(t string) bool {
	switch t {
	case "otlp", "otlphttp", "jaeger", "zipkin", "opencensus", "prometheus":
		return true
	}
	return strings.HasPrefix(t, "otlp/") || strings.HasPrefix(t, "otlphttp/")
}

func isAdminExtensionType(t string) bool {
	switch t {
	case "pprof", "zpages", "health_check", "http_forwarder":
		return true
	}
	return false
}

func isLoopback(host string) bool {
	switch host {
	case "localhost", "127.0.0.1", "::1", "[::1]":
		return true
	}
	return strings.HasPrefix(host, "127.")
}

// looksLikeTemplate returns true for values that use Collector-standard
// substitution syntax, so rules don't flag ${env:API_KEY}.
func looksLikeTemplate(s string) bool {
	// Accept both ${env:*} and ${file:*} and the plain $ENV style.
	if strings.HasPrefix(s, "${") && strings.HasSuffix(s, "}") {
		return true
	}
	if strings.HasPrefix(s, "$") && !strings.ContainsAny(s, " \t") && len(s) > 1 {
		// $ENV_VAR — bareword env expansion.
		return true
	}
	return false
}

// looksLikeSecret is a conservative heuristic: at least one of the
// well-known credential shapes must match.
func looksLikeSecret(s string) bool {
	// JWT: three base64 segments separated by dots, leading "ey".
	if strings.HasPrefix(s, "ey") && strings.Count(s, ".") == 2 && len(s) > 40 {
		return true
	}
	// AWS access key: AKIA + 16 chars.
	if strings.HasPrefix(s, "AKIA") && len(s) >= 20 {
		return true
	}
	// GitHub PAT prefixes.
	for _, p := range []string{"ghp_", "github_pat_", "gho_", "ghs_", "ghr_"} {
		if strings.HasPrefix(s, p) && len(s) > len(p)+10 {
			return true
		}
	}
	// Slack tokens.
	if strings.HasPrefix(s, "xoxb-") || strings.HasPrefix(s, "xoxa-") || strings.HasPrefix(s, "xoxp-") {
		return true
	}
	return false
}

// redact leaves the first 4 and last 2 characters visible and replaces
// the middle with asterisks. Used so the report is actionable ("your
// key starting with 'AKIA...ZQ' is in the manifest") without printing
// the full credential to CI logs.
func redact(s string) string {
	if len(s) <= 8 {
		return "****"
	}
	return s[:4] + strings.Repeat("*", len(s)-6) + s[len(s)-2:]
}
