package configharness

import (
	"context"
	"os"
	"testing"

	"gopkg.in/yaml.v3"
)

// -----------------------------------------------------------------------------
// Public scan API
// -----------------------------------------------------------------------------

// SecurityScanOptions tunes ScanManifest and RunWithSecurityGate. The
// zero value means: use the default policy set, block integration at
// SeverityHigh, do not print the report anywhere.
type SecurityScanOptions struct {
	// Policy is the rule set to run. When nil, DefaultPolicySet() is used.
	Policy *PolicySet
	// BlockAt sets the minimum severity that will cause the pre-flight
	// gate to reject a manifest. Zero means SeverityHigh.
	BlockAt Severity
	// Extensions, when non-nil, is scanned alongside the manifest's
	// receivers/processors/exporters. LoadManifest doesn't currently
	// parse an `extensions:` block, so callers that want SEC007 coverage
	// pass it in explicitly (or use ScanManifestFile, which sniffs it).
	Extensions map[string]ComponentDecl
}

func (o SecurityScanOptions) withDefaults() SecurityScanOptions {
	if o.Policy == nil {
		p := DefaultPolicySet()
		o.Policy = &p
	}
	if o.BlockAt == 0 {
		o.BlockAt = SeverityHigh
	}
	return o
}

// ScanManifest runs the security policy against an already-loaded
// Manifest and returns the resulting SecurityReport. This function is
// pure — no test lifecycle, no I/O — so CLI tools, pre-commit hooks, and
// linters can use it directly.
func ScanManifest(m *Manifest, opts SecurityScanOptions) *SecurityReport {
	opts = opts.withDefaults()
	scanned := scanManifest(m, opts.Extensions)
	findings, applied := opts.Policy.scanWith(scanned)
	return &SecurityReport{
		Findings:     findings,
		AppliedRules: applied,
	}
}

// ScanManifestFile is the file-oriented convenience: load, sniff any
// `extensions:` block, then scan. The path is stamped onto the report
// so downstream renderers can produce navigable output.
func ScanManifestFile(path string, opts SecurityScanOptions) (*SecurityReport, error) {
	m, err := LoadManifestFile(path)
	if err != nil {
		return nil, err
	}
	if opts.Extensions == nil {
		if ext, err := readExtensionsBlock(path); err == nil {
			opts.Extensions = ext
		}
	}
	rep := ScanManifest(m, opts)
	rep.ManifestPath = path
	return rep, nil
}

// LoadManifestWithExtensions parses a manifest and also returns any
// `extensions:` block it finds. The core Manifest.validate() intentionally
// stays extensions-agnostic (they aren't part of pipeline linkage), but
// the security scanner cares deeply about them, so this helper surfaces
// both halves for callers who want to feed them in together.
func LoadManifestWithExtensions(path string) (*Manifest, map[string]ComponentDecl, error) {
	m, err := LoadManifestFile(path)
	if err != nil {
		return nil, nil, err
	}
	ext, err := readExtensionsBlock(path)
	if err != nil {
		return m, nil, err
	}
	return m, ext, nil
}

func readExtensionsBlock(path string) (map[string]ComponentDecl, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var wrapper struct {
		Extensions map[string]ComponentDecl `yaml:"extensions"`
	}
	if err := yaml.Unmarshal(raw, &wrapper); err != nil {
		return nil, err
	}
	return wrapper.Extensions, nil
}

// -----------------------------------------------------------------------------
// Pre-flight gate + MockCollector integration
// -----------------------------------------------------------------------------

// PreflightVerdict is the outcome of the security gate. When PassedGate
// is false, RunWithSecurityGate refuses to execute integration tests and
// returns immediately with only the security report populated.
type PreflightVerdict struct {
	Security   *SecurityReport
	PassedGate bool
	BlockedAt  Severity
}

// Preflight runs the policy set and produces a verdict without touching
// the mock collector. Callers that just want offline validation use this;
// the pre-flight gate below reuses it.
func Preflight(m *Manifest, opts SecurityScanOptions) *PreflightVerdict {
	opts = opts.withDefaults()
	rep := ScanManifest(m, opts)
	return &PreflightVerdict{
		Security:   rep,
		PassedGate: rep.PassesGate(opts.BlockAt),
		BlockedAt:  opts.BlockAt,
	}
}

// RunWithSecurityGate is the recommended CI entry point. It runs the
// security scan first, aborts the integration phase if the gate rejects
// the manifest, and otherwise runs the mock collector normally.
//
// The returned Report always has SecurityPreflight populated. If the
// gate failed, Pipelines and Regressions are empty — the security
// findings are the sole story, which is exactly what an operator needs
// in order to fix the manifest before re-running.
func (mc *MockCollector) RunWithSecurityGate(ctx context.Context, m *Manifest, runOpts RunOptions, secOpts SecurityScanOptions) *Report {
	mc.t.Helper()

	verdict := Preflight(m, secOpts)
	if !verdict.PassedGate {
		return &Report{
			Pipelines:         map[SignalKind]*PipelineStatus{},
			SecurityPreflight: verdict,
		}
	}

	rep := mc.Run(ctx, m, runOpts)
	rep.SecurityPreflight = verdict
	return rep
}

// -----------------------------------------------------------------------------
// Assertion helpers
// -----------------------------------------------------------------------------

// AssertSecurityGatePasses fails the test with a readable rendering of
// the security report if the gate rejected the manifest.
func AssertSecurityGatePasses(t *testing.T, r *Report) {
	t.Helper()
	if r == nil || r.SecurityPreflight == nil {
		t.Fatal("configharness: no security preflight in report")
	}
	if !r.SecurityPreflight.PassedGate {
		t.Fatalf("configharness: security gate blocked the manifest at severity>=%s:\n%s",
			r.SecurityPreflight.BlockedAt, r.SecurityPreflight.Security)
	}
}

// AssertSecurityFinding fails the test unless the report includes a
// finding for the given rule ID at (or above) the requested severity.
// Used to test that the *rules themselves* fire on insecure manifests.
func AssertSecurityFinding(t *testing.T, r *SecurityReport, ruleID string, minSeverity Severity) {
	t.Helper()
	for _, f := range r.Findings {
		if f.RuleID == ruleID && f.Severity >= minSeverity {
			return
		}
	}
	t.Fatalf("configharness: expected finding %s at severity>=%s, got:\n%s",
		ruleID, minSeverity, r)
}
