package configharness

import (
	"context"
	"fmt"
	"sync"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"gopkg.in/yaml.v3"
)

// -----------------------------------------------------------------------------
// Factory interfaces
// -----------------------------------------------------------------------------
//
// These are deliberately narrower than the real Collector's factory
// interfaces. The harness only needs to know how to construct a component
// bound to a given downstream consumer for a given signal, and how to
// drive test data through a receiver.

// ReceiverFactory builds a receiver bound to `next` for the requested
// signal. A single factory may support only a subset of signals; unsupported
// signals must return an error (not panic).
//
// The returned component must implement `component.Component` (Start/Shutdown).
// Additionally, if the receiver supports being driven by the harness's
// synthetic ingestion phase it should also implement TestDriver — see below.
type ReceiverFactory interface {
	CreateReceiver(ctx context.Context, settings component.TelemetrySettings, cfg *yaml.Node, signal SignalKind, next any) (component.Component, error)
}

// ProcessorFactory builds a processor bound to `next` for the requested
// signal. `next` is typed per signal:
//
//	SignalLogs    -> consumer.Logs
//	SignalMetrics -> consumer.Metrics
//	SignalTraces  -> consumer.Traces
//
// The returned Component must itself implement the matching consumer
// interface — that's how the harness wires it as the receiver's downstream.
type ProcessorFactory interface {
	CreateProcessor(ctx context.Context, settings component.TelemetrySettings, cfg *yaml.Node, signal SignalKind, next any) (component.Component, error)
}

// ExporterFactory builds an exporter for the requested signal. The
// returned Component must implement the matching consumer interface.
type ExporterFactory interface {
	CreateExporter(ctx context.Context, settings component.TelemetrySettings, cfg *yaml.Node, signal SignalKind) (component.Component, error)
}

// TestDriver is an optional interface a receiver may implement to
// participate in the harness's synthetic signal-drive phase. If a receiver
// does not implement it, the harness will still start/stop it but will
// mark the pipeline as "unverified" in the Report rather than failing.
//
// Drive is called once per pipeline. It should synthesize one small batch
// of the appropriate signal, hand it to its downstream consumer, and
// return. Blocking indefinitely, panicking, or returning an error is
// treated as a regression.
type TestDriver interface {
	Drive(ctx context.Context, signal SignalKind) error
}

// -----------------------------------------------------------------------------
// FactoryRegistry
// -----------------------------------------------------------------------------

// FactoryRegistry maps the string "type" values in a manifest onto real
// Go factories. It is safe for concurrent registration but is typically
// populated once at test setup.
type FactoryRegistry struct {
	mu         sync.RWMutex
	receivers  map[string]ReceiverFactory
	processors map[string]ProcessorFactory
	exporters  map[string]ExporterFactory
}

// NewFactoryRegistry returns an empty registry.
func NewFactoryRegistry() *FactoryRegistry {
	return &FactoryRegistry{
		receivers:  map[string]ReceiverFactory{},
		processors: map[string]ProcessorFactory{},
		exporters:  map[string]ExporterFactory{},
	}
}

// RegisterReceiver adds (or replaces) a receiver factory keyed by type.
func (r *FactoryRegistry) RegisterReceiver(typeName string, f ReceiverFactory) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.receivers[typeName] = f
}

// RegisterProcessor adds (or replaces) a processor factory.
func (r *FactoryRegistry) RegisterProcessor(typeName string, f ProcessorFactory) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.processors[typeName] = f
}

// RegisterExporter adds (or replaces) an exporter factory.
func (r *FactoryRegistry) RegisterExporter(typeName string, f ExporterFactory) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.exporters[typeName] = f
}

func (r *FactoryRegistry) getReceiver(t string) (ReceiverFactory, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	f, ok := r.receivers[t]
	if !ok {
		return nil, fmt.Errorf("no receiver factory for type %q", t)
	}
	return f, nil
}

func (r *FactoryRegistry) getProcessor(t string) (ProcessorFactory, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	f, ok := r.processors[t]
	if !ok {
		return nil, fmt.Errorf("no processor factory for type %q", t)
	}
	return f, nil
}

func (r *FactoryRegistry) getExporter(t string) (ExporterFactory, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	f, ok := r.exporters[t]
	if !ok {
		return nil, fmt.Errorf("no exporter factory for type %q", t)
	}
	return f, nil
}

// -----------------------------------------------------------------------------
// Small consumer-type checks used by the pipeline builder
// -----------------------------------------------------------------------------
//
// The registry gives us `any` back from a factory. Before wiring the
// pipeline we need to prove the component actually implements the
// consumer interface matching its signal — otherwise the whole edifice
// silently no-ops.

func assertConsumesLogs(v any, role, name string) (consumer.Logs, error) {
	c, ok := v.(consumer.Logs)
	if !ok {
		return nil, fmt.Errorf("%s %q does not implement consumer.Logs", role, name)
	}
	return c, nil
}

func assertConsumesMetrics(v any, role, name string) (consumer.Metrics, error) {
	c, ok := v.(consumer.Metrics)
	if !ok {
		return nil, fmt.Errorf("%s %q does not implement consumer.Metrics", role, name)
	}
	return c, nil
}

func assertConsumesTraces(v any, role, name string) (consumer.Traces, error) {
	c, ok := v.(consumer.Traces)
	if !ok {
		return nil, fmt.Errorf("%s %q does not implement consumer.Traces", role, name)
	}
	return c, nil
}
