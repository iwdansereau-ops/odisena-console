# configharness

A secondary Go harness for integration-testing OpenTelemetry Collector
component configuration manifests.

Where its companion `otelharness` tests one component in isolation, this
harness deploys a component **inside a mock collector** driven by a real
YAML manifest, and verifies:

1. **Valid startup** — every declared component builds and `Start()`s
   without error.
2. **Healthy pipeline linkage** — the receiver → processor(s) → exporter
   chain is fully wired (correct consumer interfaces on every hop).
3. **Signal flow** — one synthetic batch of the appropriate signal is
   driven through each pipeline and observed at at least one exporter,
   within a bounded timeout.
4. **Graceful shutdown** — every component `Shutdown()`s cleanly within
   its deadline.

Any failure on any axis is captured as a typed `Regression` in the run
report so tests can assert precisely *why* a manifest broke.

As of the security update, the harness also runs a **pre-flight security
policy check** against the manifest before any component is built. If the
manifest violates the hardening policy at or above the configured
severity, the integration run is short-circuited and the collector is
never started — you see the violations immediately instead of a stack of
downstream failures.

## Regression taxonomy

| Kind                        | Meaning                                                          |
|-----------------------------|------------------------------------------------------------------|
| `init_failure`              | A factory errored, or the component doesn't implement the right consumer interface |
| `start_failure`             | `component.Start` returned an error                              |
| `pipeline_unlinked`         | A pipeline stage couldn't be wired to the next (bad type, missing registration) |
| `ingestion_blocked`         | `Drive()` didn't return, or no exporter observed the signal within the ingestion deadline |
| `ingestion_error`           | `Drive()` or a downstream consumer returned an error while forwarding the synthetic batch |
| `shutdown_failure`          | `Shutdown` returned an error or blocked past its deadline        |
| `unverified`                | Not a failure by default: a pipeline whose receiver doesn't implement `TestDriver`, so only start/shutdown were verified |

## Module layout

```
configharness/
├── go.mod
├── README.md
├── configharness/
│   ├── manifest.go        // YAML manifest + validator
│   ├── registry.go        // FactoryRegistry, ReceiverFactory, ProcessorFactory, ExporterFactory
│   ├── mocks.go           // MockReceiverFactory + MockExporterFactory + ExporterSink
│   ├── fanout.go          // in-package fan-out for logs/metrics/traces
│   ├── report.go          // Report, Regression, PipelineStatus, SecurityPreflight
│   ├── mockcollector.go   // MockCollector: preflight → build → start → drive → shutdown
│   ├── security_types.go  // Severity, Finding, SecurityReport, PreflightVerdict
│   ├── security_scan.go   // manifest walker (Values / Present / endpoint parsers)
│   ├── security_rules.go  // Rule, PolicySet, DefaultPolicySet() (SEC001–SEC010)
│   └── security.go        // ScanManifest, Preflight, RunWithSecurityGate, assert helpers
└── example/
    ├── manifests/
    │   ├── healthy.yaml
    │   ├── bad_start.yaml
    │   ├── bad_ingestion.yaml
    │   ├── bad_shutdown.yaml
    │   ├── security_bad.yaml       // example of an insecure manifest
    │   └── security_hardened.yaml  // example that passes the default policy
    └── routingprocessor/
        ├── processor.go         // real component + Factory registration
        ├── harness_test.go      // end-to-end tests for each manifest
        ├── blocking_test.go     // targeted test for the ingestion_blocked path
        └── security_test.go     // security-rule and preflight-gate tests
```

## Quickstart

```go
reg := configharness.NewFactoryRegistry()
configharness.RegisterDefaults(reg)                  // mock_receiver, mock_exporter
reg.RegisterProcessor("routingprocessor", rp.Factory{}) // your component under test

m, err := configharness.LoadManifestFile("manifest.yaml")
require.NoError(t, err)

mc := configharness.NewMockCollector(t, reg)
report := mc.Run(context.Background(), m, configharness.RunOptions{})

configharness.AssertOKStrict(t, report, true) // strict: every pipeline must have delivered signal
```

To test a bad manifest and confirm the harness flags the correct regression:

```go
report := mc.Run(context.Background(), m, configharness.RunOptions{IngestionTimeout: 100 * time.Millisecond})
configharness.AssertRegressionKind(t, report, configharness.RegressionIngestionBlocked)
```

## Manifest schema

```yaml
receivers:
  <name>:
    type: <factory key>
    config: {...}    # opaque; decoded by the factory
processors:
  <name>: {type: ..., config: {...}}
exporters:
  <name>: {type: ..., config: {...}}
pipelines:
  logs:     {receivers: [...], processors: [...], exporters: [...]}
  metrics:  {receivers: [...], processors: [...], exporters: [...]}
  traces:   {receivers: [...], processors: [...], exporters: [...]}
```

Structural bugs (missing pipeline, dangling reference, empty receiver
list, unknown signal name) are rejected at parse time.

## Batteries included

- **`mock_receiver`** — synthesizes a deterministic batch of the pipeline's
  signal when driven; supports `resource_attrs` and `record_count` config
  keys. Implements `TestDriver`.
- **`mock_exporter`** — records everything it receives into an
  `ExporterSink` the harness can query; supports `fail_on_start` and
  `fail_on_shutdown` to simulate lifecycle regressions.
- Custom exporters can participate in signal-flow verification by
  implementing `ExporterSink() *ExporterSink`.

## Design notes

- **The harness never `t.Fatal`s from a goroutine.** Every failure mode
  is captured in the `Report`; only the top-level `AssertOK*` helpers
  call `t.Fatalf`. That means a manifest that's broken in three
  independent ways surfaces three regressions in one run, not one
  cascade of hangs.
- **Shutdown is always attempted**, even when Start failed, so
  partially-initialized components get their cleanup called. This
  mirrors the real Collector's `service` package and catches "Start
  errored, then Shutdown crashed" cascades.
- **Drive is bounded by context**, so a component that blocks its
  downstream call maps cleanly to `ingestion_blocked`. A `Drive()`
  goroutine also has a panic guard, so a nil-deref inside a broken
  processor turns into a readable regression rather than a test-runner
  crash.
- **Every exporter reset happens per-drive**, so the count check
  ("did anyone see the batch?") is exact and doesn't need per-pipeline
  bookkeeping in the caller.

## Running

```sh
go test ./... -count=1 -race -v
```

Requires Go 1.22+; module toolchain will auto-upgrade as needed to
satisfy transitive pdata requirements.

## Security policy pre-flight

The security check parses the manifest YAML, walks every component's
config sub-tree, and evaluates a set of policy rules against it. It runs
**before** `MockCollector.Run` builds any factories, so a manifest that
violates policy is flagged without ever spinning up a receiver.

### Severity ladder

```
info  <  low  <  medium  <  high  <  critical
```

`PolicySet.BlockAt` defines the threshold at which findings block the
integration run. Default is `SeverityHigh`, so `high` and `critical`
findings block; `medium` and below are reported but non-blocking.

### Default rules

| ID     | Severity | Fires when                                                                        |
|--------|----------|-----------------------------------------------------------------------------------|
| SEC001 | Critical | An OTLP/HTTP exporter's `endpoint` uses `http://` to a non-loopback host          |
| SEC002 | High     | Any TLS block has `insecure: true`                                                |
| SEC003 | High     | Any TLS block has `insecure_skip_verify: true`                                    |
| SEC004 | High     | A network-facing receiver has no `tls:` block                                     |
| SEC005 | Medium   | A network-facing receiver has no `auth:` block                                    |
| SEC006 | Critical | A header field (`Authorization`, `api_key`, `token`, `password`, ...) is a plaintext literal instead of `${env:*}` |
| SEC007 | High     | An admin extension (`pprof`, `zpages`, `health_check`) listens on a non-loopback address |
| SEC008 | Low      | A `debug` or `logging` exporter is present in the manifest                        |
| SEC009 | Medium   | Any endpoint binds to a wildcard address (`0.0.0.0` or `::`)                      |
| SEC010 | Critical | Any value matches a credential-shape pattern (JWT, AWS `AKIA…`, GitHub `ghp_…`, Slack `xoxb-…`) |

Critical-severity findings redact the offending value in the report
(first 4 + last 2 characters shown) so logs and CI output don't leak the
secret again.

### Using it in tests

The simplest integration is `RunWithSecurityGate`, which runs the
pre-flight and only calls `Run` when the gate passes:

```go
mc := configharness.NewMockCollector(t, reg)
report := mc.RunWithSecurityGate(context.Background(), m, configharness.RunOptions{}, nil)

if !report.SecurityPreflight.Passed {
    t.Fatalf("manifest failed security policy:\n%s", report.SecurityPreflight.Report)
}
```

Or just gate a CI check on the scan without running the collector at all:

```go
rep := configharness.ScanManifest(m, nil) // nil ⇒ DefaultPolicySet()
if !rep.PassesGate(configharness.SeverityHigh) {
    t.Fatalf("security policy violated:\n%s", rep)
}
```

Assertion helpers:

- `AssertSecurityGatePasses(t, report)` — fails the test if the pre-flight
  did not pass its configured threshold.
- `AssertSecurityFinding(t, report, "SEC006")` — fails if the given rule
  ID did not fire; useful for testing that your custom rules trigger on
  intentionally-bad manifests.

### Customising the policy

```go
policy := configharness.DefaultPolicySet()
policy.SuppressRuleIDs = []string{"SEC008"} // team decision: debug exporter is fine in staging
policy.BlockAt = configharness.SeverityCritical // only critical findings block
policy.Rules = append(policy.Rules, configharness.Rule{
    ID: "ORG001", Severity: configharness.SeverityHigh,
    Description: "internal collectors must set service.namespace",
    Check: func(c configharness.ScannedComponent) []configharness.Finding { /* … */ },
})

rep := configharness.ScanManifest(m, policy)
```

`AllowRuleIDs` (if non-empty) narrows the policy to a specific set — handy
for per-team enforcement where different pipelines have different rules.

### Where the gate sits in the run

```
 LoadManifest ─┐
               ├─▶ Preflight (security policy) ─┐
 Registry ────┘                                 │
                                                ├─▶ blocked?  ─▶ return early, Pipelines empty
                                                │
                                                └─▶ passes ─▶ Build ─▶ Start ─▶ Drive ─▶ Shutdown ─▶ Report
```

The user-visible contract: **a manifest that fails the security gate
never starts a component.** That's the point — teams get the security
report before spending CI minutes on an integration run that would have
shipped an insecure collector.
