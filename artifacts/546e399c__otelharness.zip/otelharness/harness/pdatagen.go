package harness

import (
	"time"

	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/plog"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.opentelemetry.io/collector/pdata/ptrace"
)

// This file contains small deterministic fixture builders that tests can use
// to synthesize pdata without pulling in a heavier generator. Every builder
// takes only the minimal amount of information needed to distinguish records
// in assertions; everything else is filled in with stable defaults.

// fixedTS is a stable timestamp used for every generated record. Using a
// constant means tests that diff pdata JSON don't need to normalize times.
var fixedTS = pcommon.NewTimestampFromTime(time.Unix(1_700_000_000, 0).UTC())

// NewLogs returns a plog.Logs with a single resource and a single scope
// containing `n` log records. The resource carries `resAttrs` and each
// record's body is set to a fmt-like "log-<i>" string.
func NewLogs(n int, resAttrs map[string]string) plog.Logs {
	logs := plog.NewLogs()
	rl := logs.ResourceLogs().AppendEmpty()
	setStringAttrs(rl.Resource().Attributes(), resAttrs)
	sl := rl.ScopeLogs().AppendEmpty()
	sl.Scope().SetName("otelharness/pdatagen")
	for i := 0; i < n; i++ {
		lr := sl.LogRecords().AppendEmpty()
		lr.SetTimestamp(fixedTS)
		lr.SetObservedTimestamp(fixedTS)
		lr.SetSeverityNumber(plog.SeverityNumberInfo)
		lr.SetSeverityText("INFO")
		lr.Body().SetStr(indexed("log", i))
	}
	return logs
}

// NewMetrics returns a pmetric.Metrics with a single resource, a single scope,
// and a single gauge metric containing `n` int data points. Useful for
// verifying that data-point-level routing preserves counts.
func NewMetrics(n int, resAttrs map[string]string) pmetric.Metrics {
	m := pmetric.NewMetrics()
	rm := m.ResourceMetrics().AppendEmpty()
	setStringAttrs(rm.Resource().Attributes(), resAttrs)
	sm := rm.ScopeMetrics().AppendEmpty()
	sm.Scope().SetName("otelharness/pdatagen")
	metric := sm.Metrics().AppendEmpty()
	metric.SetName("harness.counter")
	metric.SetUnit("1")
	g := metric.SetEmptyGauge()
	for i := 0; i < n; i++ {
		dp := g.DataPoints().AppendEmpty()
		dp.SetTimestamp(fixedTS)
		dp.SetStartTimestamp(fixedTS)
		dp.SetIntValue(int64(i))
	}
	return m
}

// NewTraces returns a ptrace.Traces with a single resource, a single scope,
// and `n` internal spans, each with a distinct span ID. All spans share the
// same trace ID so tests can group them.
func NewTraces(n int, resAttrs map[string]string) ptrace.Traces {
	tr := ptrace.NewTraces()
	rs := tr.ResourceSpans().AppendEmpty()
	setStringAttrs(rs.Resource().Attributes(), resAttrs)
	ss := rs.ScopeSpans().AppendEmpty()
	ss.Scope().SetName("otelharness/pdatagen")

	var traceID pcommon.TraceID
	copy(traceID[:], []byte("harnesstrace0001"))

	for i := 0; i < n; i++ {
		s := ss.Spans().AppendEmpty()
		s.SetName(indexed("span", i))
		s.SetKind(ptrace.SpanKindInternal)
		s.SetTraceID(traceID)
		var sid pcommon.SpanID
		copy(sid[:], indexed("sp", i))
		s.SetSpanID(sid)
		s.SetStartTimestamp(fixedTS)
		s.SetEndTimestamp(fixedTS)
	}
	return tr
}

// setStringAttrs writes m into attrs as string values, in a stable order that
// depends only on the underlying map iteration. This is fine for tests
// because pdata's JSON marshaler sorts keys before emitting.
func setStringAttrs(attrs pcommon.Map, m map[string]string) {
	for k, v := range m {
		attrs.PutStr(k, v)
	}
}

// indexed formats a stem + index into a short fixed-width string without
// importing fmt (keeps this file tidy and avoids allocations in tight loops).
func indexed(stem string, i int) string {
	// Small manual itoa for i in [0, 9999]; tests never use larger values.
	if i < 0 {
		i = 0
	}
	digits := []byte{'0', '0', '0', '0'}
	pos := 3
	for i > 0 && pos >= 0 {
		digits[pos] = byte('0' + i%10)
		i /= 10
		pos--
	}
	return stem + "-" + string(digits)
}
