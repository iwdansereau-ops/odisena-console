// Package harness provides a reusable test harness for OpenTelemetry Collector
// components (receivers, processors, exporters, and connectors).
//
// The harness centralizes the setup and teardown work that is normally
// duplicated across component tests:
//
//   - Building TelemetrySettings with an observable zap.Logger so tests can
//     assert on log output.
//   - Wiring up in-memory consumers for logs, metrics, and traces via
//     consumertest.Sink*.
//   - Spinning up ephemeral OTLP/gRPC and OTLP/HTTP servers on random ports
//     that accept traffic for all three signals and forward the decoded pdata
//     objects to the same sinks.
//   - Providing a single Shutdown() that tears everything down in the correct
//     order and fails the test if any component reports an error.
//
// The intent is that a component author can write:
//
//	tel := harness.NewTestTelemetry(t)
//	defer tel.Shutdown()
//
//	proc := newMyProcessor(tel.Settings(), tel.Logs(), tel.Metrics(), tel.Traces())
//	require.NoError(t, proc.Start(ctx, componenttest.NewNopHost()))
//	// ... feed pdata in ...
//	harness.AssertLogRecordCount(t, tel.Logs(), 3)
//
// and get end-to-end coverage of a component without having to hand-roll the
// plumbing every time.
package harness

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/component/componenttest"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/consumer/consumertest"
	"go.uber.org/zap"
	"go.uber.org/zap/zaptest/observer"
)

// TestTelemetry bundles everything a Collector component needs during a test:
// a TelemetrySettings, in-memory sinks for all three signals, and (optionally)
// live OTLP servers that a real exporter can push data into.
//
// A TestTelemetry is created via NewTestTelemetry and must be released with
// Shutdown() — typically via t.Cleanup or a defer.
type TestTelemetry struct {
	t *testing.T

	settings   component.TelemetrySettings
	logger     *zap.Logger
	logObs     *observer.ObservedLogs
	buildInfo  component.BuildInfo
	shutdownFn []func(context.Context) error

	// Signal sinks. These are the "downstream" consumers your component
	// under test will push data into. They keep everything in memory so
	// tests can inspect the resulting pdata objects directly.
	logsSink    *consumertest.LogsSink
	metricsSink *consumertest.MetricsSink
	tracesSink  *consumertest.TracesSink

	// Optional network servers. Populated only when StartOTLPGRPCServer
	// or StartOTLPHTTPServer is called. Multiple servers can be started
	// (e.g. one per pipeline being routed to).
	servers []Server
}

// Option customizes a TestTelemetry at construction time.
type Option func(*testTelemetryConfig)

type testTelemetryConfig struct {
	buildInfo   component.BuildInfo
	extraFields []zap.Field
}

// WithBuildInfo overrides the default component.BuildInfo attached to the
// TelemetrySettings. This is occasionally useful for components that read
// BuildInfo out of settings (for example, to stamp a version label onto
// exported metrics).
func WithBuildInfo(bi component.BuildInfo) Option {
	return func(c *testTelemetryConfig) { c.buildInfo = bi }
}

// WithLoggerFields attaches persistent zap.Fields to every log record
// produced by the harness logger. Handy for tagging test output.
func WithLoggerFields(fields ...zap.Field) Option {
	return func(c *testTelemetryConfig) { c.extraFields = append(c.extraFields, fields...) }
}

// NewTestTelemetry builds a TestTelemetry with sensible defaults:
//
//   - An observable zap.Logger at Debug level (accessible via LogRecords()).
//   - A no-op TracerProvider and MeterProvider so components that record
//     internal telemetry don't blow up but also don't produce noise.
//   - Fresh sinks for logs, metrics, and traces.
//
// The returned TestTelemetry is automatically shut down via t.Cleanup, but
// callers are free to call Shutdown() earlier if they want to assert on
// teardown behavior.
func NewTestTelemetry(t *testing.T, opts ...Option) *TestTelemetry {
	t.Helper()

	cfg := &testTelemetryConfig{
		buildInfo: component.BuildInfo{
			Command:     "otelharness-test",
			Description: "OpenTelemetry Collector test harness",
			Version:     "0.0.0-test",
		},
	}
	for _, o := range opts {
		o(cfg)
	}

	core, obs := observer.New(zap.DebugLevel)
	logger := zap.New(core)
	if len(cfg.extraFields) > 0 {
		logger = logger.With(cfg.extraFields...)
	}

	// componenttest.NewNopTelemetrySettings returns a TelemetrySettings with
	// no-op providers; we swap in our observable logger so tests can assert
	// on what the component logged.
	settings := componenttest.NewNopTelemetrySettings()
	settings.Logger = logger

	tt := &TestTelemetry{
		t:           t,
		settings:    settings,
		logger:      logger,
		logObs:      obs,
		buildInfo:   cfg.buildInfo,
		logsSink:    new(consumertest.LogsSink),
		metricsSink: new(consumertest.MetricsSink),
		tracesSink:  new(consumertest.TracesSink),
	}

	t.Cleanup(tt.Shutdown)
	return tt
}

// Settings returns the TelemetrySettings that should be passed to the
// component under test (typically via its Settings.TelemetrySettings field).
func (tt *TestTelemetry) Settings() component.TelemetrySettings { return tt.settings }

// BuildInfo returns the component.BuildInfo the harness was built with.
func (tt *TestTelemetry) BuildInfo() component.BuildInfo { return tt.buildInfo }

// Logger returns the underlying zap.Logger. Prefer LogRecords() for assertions.
func (tt *TestTelemetry) Logger() *zap.Logger { return tt.logger }

// LogRecords returns every log record produced by the harness logger since
// construction. Use it to assert that a component logged (or did not log)
// a specific event.
func (tt *TestTelemetry) LogRecords() []observer.LoggedEntry { return tt.logObs.All() }

// Logs returns the in-memory log sink. Wire this into your component as its
// consumer.Logs downstream when testing log pipelines.
func (tt *TestTelemetry) Logs() *consumertest.LogsSink { return tt.logsSink }

// Metrics returns the in-memory metrics sink.
func (tt *TestTelemetry) Metrics() *consumertest.MetricsSink { return tt.metricsSink }

// Traces returns the in-memory traces sink.
func (tt *TestTelemetry) Traces() *consumertest.TracesSink { return tt.tracesSink }

// LogsConsumer, MetricsConsumer, TracesConsumer return the sinks typed as
// their consumer interfaces. This is what most component constructors expect.
func (tt *TestTelemetry) LogsConsumer() consumer.Logs       { return tt.logsSink }
func (tt *TestTelemetry) MetricsConsumer() consumer.Metrics { return tt.metricsSink }
func (tt *TestTelemetry) TracesConsumer() consumer.Traces   { return tt.tracesSink }

// ResetSinks empties every in-memory sink. Useful between sub-tests when you
// want to reuse the same TestTelemetry across scenarios.
func (tt *TestTelemetry) ResetSinks() {
	tt.logsSink.Reset()
	tt.metricsSink.Reset()
	tt.tracesSink.Reset()
}

// RegisterShutdown lets callers hook additional cleanup into the harness's
// lifecycle. Functions run in LIFO order during Shutdown.
func (tt *TestTelemetry) RegisterShutdown(fn func(context.Context) error) {
	tt.shutdownFn = append(tt.shutdownFn, fn)
}

// Shutdown stops every server started by the harness and runs every
// registered shutdown hook. It is safe to call multiple times; the second
// and subsequent calls are no-ops.
func (tt *TestTelemetry) Shutdown() {
	tt.t.Helper()

	// LIFO: stop servers first (they hold refs to the sinks), then hooks.
	for i := len(tt.servers) - 1; i >= 0; i-- {
		if err := tt.servers[i].Shutdown(context.Background()); err != nil {
			tt.t.Errorf("harness: server shutdown: %v", err)
		}
	}
	tt.servers = nil

	for i := len(tt.shutdownFn) - 1; i >= 0; i-- {
		if err := tt.shutdownFn[i](context.Background()); err != nil {
			tt.t.Errorf("harness: shutdown hook: %v", err)
		}
	}
	tt.shutdownFn = nil
}

// MustNoError is a small convenience that mirrors require.NoError but keeps
// the harness's t.Helper() semantics consistent across the package.
func (tt *TestTelemetry) MustNoError(err error, msgAndArgs ...any) {
	tt.t.Helper()
	require.NoError(tt.t, err, msgAndArgs...)
}
