package harness

import (
	"context"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"sync"
	"time"

	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/plog"
	"go.opentelemetry.io/collector/pdata/plog/plogotlp"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.opentelemetry.io/collector/pdata/pmetric/pmetricotlp"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"go.opentelemetry.io/collector/pdata/ptrace/ptraceotlp"
	"google.golang.org/grpc"
)

// Server is the common interface exposed by every test server started by the
// harness. Endpoint() returns a "host:port" string suitable for handing to
// an OTLP exporter's endpoint config.
type Server interface {
	Endpoint() string
	Shutdown(ctx context.Context) error
}

// SignalConsumers bundles the downstream consumers a test server will forward
// decoded pdata into. Any field may be nil, in which case that signal will be
// rejected with an "Unimplemented"-style error.
type SignalConsumers struct {
	Logs    consumer.Logs
	Metrics consumer.Metrics
	Traces  consumer.Traces
}

// defaultConsumers returns SignalConsumers pointing at the harness's own
// in-memory sinks. This is what StartOTLP*Server uses when the caller does
// not pass explicit consumers.
func (tt *TestTelemetry) defaultConsumers() SignalConsumers {
	return SignalConsumers{
		Logs:    tt.logsSink,
		Metrics: tt.metricsSink,
		Traces:  tt.tracesSink,
	}
}

// -----------------------------------------------------------------------------
// gRPC server
// -----------------------------------------------------------------------------

// otlpGRPCServer implements the three OTLP export services on top of a
// user-supplied SignalConsumers bundle.
//
// Note: we intentionally do NOT embed the three UnimplementedGRPCServer
// types on this struct — they share the same Go type name across the three
// otlp packages, which would produce a redeclaration error. The three shim
// types below embed the correct Unimplemented server individually.
type otlpGRPCServer struct {
	consumers SignalConsumers

	grpcSrv  *grpc.Server
	listener net.Listener
	endpoint string
	stopped  sync.Once
}

// Export implementations for logs, metrics, traces.
func (s *otlpGRPCServer) exportLogs(ctx context.Context, req plogotlp.ExportRequest) (plogotlp.ExportResponse, error) {
	if s.consumers.Logs == nil {
		return plogotlp.NewExportResponse(), fmt.Errorf("no logs consumer registered")
	}
	if err := s.consumers.Logs.ConsumeLogs(ctx, req.Logs()); err != nil {
		return plogotlp.NewExportResponse(), err
	}
	return plogotlp.NewExportResponse(), nil
}

func (s *otlpGRPCServer) exportMetrics(ctx context.Context, req pmetricotlp.ExportRequest) (pmetricotlp.ExportResponse, error) {
	if s.consumers.Metrics == nil {
		return pmetricotlp.NewExportResponse(), fmt.Errorf("no metrics consumer registered")
	}
	if err := s.consumers.Metrics.ConsumeMetrics(ctx, req.Metrics()); err != nil {
		return pmetricotlp.NewExportResponse(), err
	}
	return pmetricotlp.NewExportResponse(), nil
}

func (s *otlpGRPCServer) exportTraces(ctx context.Context, req ptraceotlp.ExportRequest) (ptraceotlp.ExportResponse, error) {
	if s.consumers.Traces == nil {
		return ptraceotlp.NewExportResponse(), fmt.Errorf("no traces consumer registered")
	}
	if err := s.consumers.Traces.ConsumeTraces(ctx, req.Traces()); err != nil {
		return ptraceotlp.NewExportResponse(), err
	}
	return ptraceotlp.NewExportResponse(), nil
}

// Endpoint returns the host:port the server is listening on.
func (s *otlpGRPCServer) Endpoint() string { return s.endpoint }

// Shutdown gracefully stops the gRPC server, falling back to a hard stop if
// graceful shutdown takes longer than the caller's context deadline.
func (s *otlpGRPCServer) Shutdown(ctx context.Context) error {
	var err error
	s.stopped.Do(func() {
		done := make(chan struct{})
		go func() {
			s.grpcSrv.GracefulStop()
			close(done)
		}()
		select {
		case <-done:
		case <-ctx.Done():
			s.grpcSrv.Stop()
			err = ctx.Err()
		case <-time.After(5 * time.Second):
			s.grpcSrv.Stop()
		}
	})
	return err
}

// grpcServerShim adapts our export methods to the generated server interfaces.
// The generated *GRPCServer interfaces each require a single Export method;
// because Go doesn't allow the same method name on the same struct with
// different signatures, we register three lightweight shims instead.
type logsGRPCShim struct {
	plogotlp.UnimplementedGRPCServer
	srv *otlpGRPCServer
}
type metricsGRPCShim struct {
	pmetricotlp.UnimplementedGRPCServer
	srv *otlpGRPCServer
}
type tracesGRPCShim struct {
	ptraceotlp.UnimplementedGRPCServer
	srv *otlpGRPCServer
}

func (s *logsGRPCShim) Export(ctx context.Context, req plogotlp.ExportRequest) (plogotlp.ExportResponse, error) {
	return s.srv.exportLogs(ctx, req)
}
func (s *metricsGRPCShim) Export(ctx context.Context, req pmetricotlp.ExportRequest) (pmetricotlp.ExportResponse, error) {
	return s.srv.exportMetrics(ctx, req)
}
func (s *tracesGRPCShim) Export(ctx context.Context, req ptraceotlp.ExportRequest) (ptraceotlp.ExportResponse, error) {
	return s.srv.exportTraces(ctx, req)
}

// StartOTLPGRPCServer starts an OTLP/gRPC server on a random loopback port
// and returns it. If consumers is nil the harness's own sinks are used, so
// data pushed to this server shows up in tt.Logs(), tt.Metrics(), tt.Traces().
//
// The returned Server is also registered for automatic teardown.
func (tt *TestTelemetry) StartOTLPGRPCServer(consumers *SignalConsumers) Server {
	tt.t.Helper()

	c := tt.defaultConsumers()
	if consumers != nil {
		c = *consumers
	}

	lis, err := net.Listen("tcp", "127.0.0.1:0")
	tt.MustNoError(err, "listen on loopback")

	grpcSrv := grpc.NewServer()
	srv := &otlpGRPCServer{
		consumers: c,
		grpcSrv:   grpcSrv,
		listener:  lis,
		endpoint:  lis.Addr().String(),
	}

	plogotlp.RegisterGRPCServer(grpcSrv, &logsGRPCShim{srv: srv})
	pmetricotlp.RegisterGRPCServer(grpcSrv, &metricsGRPCShim{srv: srv})
	ptraceotlp.RegisterGRPCServer(grpcSrv, &tracesGRPCShim{srv: srv})

	go func() {
		if err := grpcSrv.Serve(lis); err != nil && !errors.Is(err, grpc.ErrServerStopped) {
			// Serve errors after Stop are expected; anything else is a real
			// failure. We can't call t.Fatal from a goroutine, so log it.
			tt.logger.Sugar().Errorf("harness: grpc serve: %v", err)
		}
	}()

	tt.servers = append(tt.servers, srv)
	return srv
}

// -----------------------------------------------------------------------------
// HTTP server
// -----------------------------------------------------------------------------

// otlpHTTPServer accepts OTLP/HTTP (protobuf) POSTs on the standard paths.
// Only the binary protobuf content type is supported; that's what production
// exporters default to and it keeps the harness dependency-free.
type otlpHTTPServer struct {
	consumers SignalConsumers

	httpSrv  *http.Server
	listener net.Listener
	endpoint string
	stopped  sync.Once
}

// Standard OTLP/HTTP paths per the OTLP spec.
const (
	otlpPathLogs    = "/v1/logs"
	otlpPathMetrics = "/v1/metrics"
	otlpPathTraces  = "/v1/traces"

	otlpContentTypeProto = "application/x-protobuf"
)

func (s *otlpHTTPServer) Endpoint() string { return s.endpoint }

func (s *otlpHTTPServer) Shutdown(ctx context.Context) error {
	var err error
	s.stopped.Do(func() { err = s.httpSrv.Shutdown(ctx) })
	return err
}

// handleLogs / handleMetrics / handleTraces share the same shape: read the
// request body, unmarshal into an OTLP ExportRequest via pdata, forward to
// the registered consumer, and write an empty successful response.
func (s *otlpHTTPServer) handleLogs(w http.ResponseWriter, r *http.Request) {
	if !checkOTLPRequest(w, r) {
		return
	}
	body, err := readBody(w, r)
	if err != nil {
		return
	}
	req := plogotlp.NewExportRequest()
	if err := req.UnmarshalProto(body); err != nil {
		http.Error(w, "invalid protobuf: "+err.Error(), http.StatusBadRequest)
		return
	}
	if s.consumers.Logs == nil {
		http.Error(w, "logs signal not enabled", http.StatusNotImplemented)
		return
	}
	if err := s.consumers.Logs.ConsumeLogs(r.Context(), req.Logs()); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	writeEmptyProto(w, plogotlp.NewExportResponse())
}

func (s *otlpHTTPServer) handleMetrics(w http.ResponseWriter, r *http.Request) {
	if !checkOTLPRequest(w, r) {
		return
	}
	body, err := readBody(w, r)
	if err != nil {
		return
	}
	req := pmetricotlp.NewExportRequest()
	if err := req.UnmarshalProto(body); err != nil {
		http.Error(w, "invalid protobuf: "+err.Error(), http.StatusBadRequest)
		return
	}
	if s.consumers.Metrics == nil {
		http.Error(w, "metrics signal not enabled", http.StatusNotImplemented)
		return
	}
	if err := s.consumers.Metrics.ConsumeMetrics(r.Context(), req.Metrics()); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	writeEmptyProto(w, pmetricotlp.NewExportResponse())
}

func (s *otlpHTTPServer) handleTraces(w http.ResponseWriter, r *http.Request) {
	if !checkOTLPRequest(w, r) {
		return
	}
	body, err := readBody(w, r)
	if err != nil {
		return
	}
	req := ptraceotlp.NewExportRequest()
	if err := req.UnmarshalProto(body); err != nil {
		http.Error(w, "invalid protobuf: "+err.Error(), http.StatusBadRequest)
		return
	}
	if s.consumers.Traces == nil {
		http.Error(w, "traces signal not enabled", http.StatusNotImplemented)
		return
	}
	if err := s.consumers.Traces.ConsumeTraces(r.Context(), req.Traces()); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	writeEmptyProto(w, ptraceotlp.NewExportResponse())
}

// protoMarshaler is implemented by every OTLP ExportResponse.
type protoMarshaler interface {
	MarshalProto() ([]byte, error)
}

func writeEmptyProto(w http.ResponseWriter, resp protoMarshaler) {
	b, err := resp.MarshalProto()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", otlpContentTypeProto)
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(b)
}

func checkOTLPRequest(w http.ResponseWriter, r *http.Request) bool {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return false
	}
	if ct := r.Header.Get("Content-Type"); ct != otlpContentTypeProto {
		http.Error(w, "unsupported content type: "+ct, http.StatusUnsupportedMediaType)
		return false
	}
	return true
}

func readBody(w http.ResponseWriter, r *http.Request) ([]byte, error) {
	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "read body: "+err.Error(), http.StatusBadRequest)
		return nil, err
	}
	return body, nil
}

// StartOTLPHTTPServer starts an OTLP/HTTP server on a random loopback port.
// The returned Server.Endpoint() is of the form "127.0.0.1:PORT" — callers
// building an exporter should prepend "http://" when constructing an endpoint
// URL. If consumers is nil, the harness's default sinks are used.
func (tt *TestTelemetry) StartOTLPHTTPServer(consumers *SignalConsumers) Server {
	tt.t.Helper()

	c := tt.defaultConsumers()
	if consumers != nil {
		c = *consumers
	}

	lis, err := net.Listen("tcp", "127.0.0.1:0")
	tt.MustNoError(err, "listen on loopback")

	srv := &otlpHTTPServer{
		consumers: c,
		listener:  lis,
		endpoint:  lis.Addr().String(),
	}

	mux := http.NewServeMux()
	mux.HandleFunc(otlpPathLogs, srv.handleLogs)
	mux.HandleFunc(otlpPathMetrics, srv.handleMetrics)
	mux.HandleFunc(otlpPathTraces, srv.handleTraces)

	srv.httpSrv = &http.Server{
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
	}

	go func() {
		if err := srv.httpSrv.Serve(lis); err != nil && !errors.Is(err, http.ErrServerClosed) {
			tt.logger.Sugar().Errorf("harness: http serve: %v", err)
		}
	}()

	tt.servers = append(tt.servers, srv)
	return srv
}

// -----------------------------------------------------------------------------
// Debug helpers
// -----------------------------------------------------------------------------

// FormatTraceID renders a pdata TraceID as a lowercase hex string. Handy in
// test failure messages where the raw byte slice is unreadable.
func FormatTraceID(logs plog.Logs) []string {
	seen := map[string]struct{}{}
	var out []string
	rls := logs.ResourceLogs()
	for i := 0; i < rls.Len(); i++ {
		sls := rls.At(i).ScopeLogs()
		for j := 0; j < sls.Len(); j++ {
			lrs := sls.At(j).LogRecords()
			for k := 0; k < lrs.Len(); k++ {
				tid := lrs.At(k).TraceID()
				if tid.IsEmpty() {
					continue
				}
				s := hex.EncodeToString(tid[:])
				if _, ok := seen[s]; ok {
					continue
				}
				seen[s] = struct{}{}
				out = append(out, s)
			}
		}
	}
	return out
}

// Ensure the pdata packages are actually referenced when only debug helpers
// use them, so the build stays clean.
var (
	_ = plog.NewLogs
	_ = pmetric.NewMetrics
	_ = ptrace.NewTraces
)
