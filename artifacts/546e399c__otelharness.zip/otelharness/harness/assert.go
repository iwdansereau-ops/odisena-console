package harness

import (
	"fmt"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/collector/consumer/consumertest"
	"go.opentelemetry.io/collector/pdata/pcommon"
	"go.opentelemetry.io/collector/pdata/plog"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.opentelemetry.io/collector/pdata/ptrace"
)

// -----------------------------------------------------------------------------
// Count assertions
// -----------------------------------------------------------------------------
//
// These wrap the raw *Sink counters in ways that produce readable failure
// messages. All of them are t.Helper()-safe.

// AssertLogRecordCount asserts the total number of log records (across all
// resource/scope groupings) present in a LogsSink.
func AssertLogRecordCount(t *testing.T, sink *consumertest.LogsSink, want int) {
	t.Helper()
	got := sink.LogRecordCount()
	assert.Equal(t, want, got, "unexpected log record count")
}

// AssertMetricDataPointCount asserts the total number of individual metric
// data points (numbers/histogram buckets don't add — just point objects).
func AssertMetricDataPointCount(t *testing.T, sink *consumertest.MetricsSink, want int) {
	t.Helper()
	got := sink.DataPointCount()
	assert.Equal(t, want, got, "unexpected metric data point count")
}

// AssertSpanCount asserts the total span count across all resource/scope
// groupings in a TracesSink.
func AssertSpanCount(t *testing.T, sink *consumertest.TracesSink, want int) {
	t.Helper()
	got := sink.SpanCount()
	assert.Equal(t, want, got, "unexpected span count")
}

// -----------------------------------------------------------------------------
// Waiting helpers
// -----------------------------------------------------------------------------

// EventuallyLogRecordCount blocks until the sink contains at least `want`
// log records or the timeout elapses. It is meant for cases where a component
// forwards data asynchronously (e.g. batched exporters).
func EventuallyLogRecordCount(t *testing.T, sink *consumertest.LogsSink, want int, timeout time.Duration) {
	t.Helper()
	require.Eventually(t, func() bool {
		return sink.LogRecordCount() >= want
	}, timeout, 10*time.Millisecond, "waiting for %d log records, have %d", want, sink.LogRecordCount())
}

// EventuallyMetricDataPointCount is the metrics analog of
// EventuallyLogRecordCount.
func EventuallyMetricDataPointCount(t *testing.T, sink *consumertest.MetricsSink, want int, timeout time.Duration) {
	t.Helper()
	require.Eventually(t, func() bool {
		return sink.DataPointCount() >= want
	}, timeout, 10*time.Millisecond, "waiting for %d data points, have %d", want, sink.DataPointCount())
}

// EventuallySpanCount is the traces analog of EventuallyLogRecordCount.
func EventuallySpanCount(t *testing.T, sink *consumertest.TracesSink, want int, timeout time.Duration) {
	t.Helper()
	require.Eventually(t, func() bool {
		return sink.SpanCount() >= want
	}, timeout, 10*time.Millisecond, "waiting for %d spans, have %d", want, sink.SpanCount())
}

// -----------------------------------------------------------------------------
// Attribute assertions
// -----------------------------------------------------------------------------
//
// The following helpers assert that *every* resource-level element in a sink
// carries a particular attribute. This is the typical shape of assertions
// on routing processors ("everything on pipeline A should have tenant=foo").

// AssertAllLogsHaveResourceAttr scans every ResourceLogs and fails if any of
// them is missing the requested attribute or has a mismatched value.
func AssertAllLogsHaveResourceAttr(t *testing.T, sink *consumertest.LogsSink, key string, want any) {
	t.Helper()
	for i, logs := range sink.AllLogs() {
		rls := logs.ResourceLogs()
		for j := 0; j < rls.Len(); j++ {
			assertResourceAttr(t, rls.At(j).Resource().Attributes(), key, want,
				"logs batch %d resource %d", i, j)
		}
	}
}

// AssertAllMetricsHaveResourceAttr is the metrics analog.
func AssertAllMetricsHaveResourceAttr(t *testing.T, sink *consumertest.MetricsSink, key string, want any) {
	t.Helper()
	for i, m := range sink.AllMetrics() {
		rms := m.ResourceMetrics()
		for j := 0; j < rms.Len(); j++ {
			assertResourceAttr(t, rms.At(j).Resource().Attributes(), key, want,
				"metrics batch %d resource %d", i, j)
		}
	}
}

// AssertAllTracesHaveResourceAttr is the traces analog.
func AssertAllTracesHaveResourceAttr(t *testing.T, sink *consumertest.TracesSink, key string, want any) {
	t.Helper()
	for i, tr := range sink.AllTraces() {
		rss := tr.ResourceSpans()
		for j := 0; j < rss.Len(); j++ {
			assertResourceAttr(t, rss.At(j).Resource().Attributes(), key, want,
				"traces batch %d resource %d", i, j)
		}
	}
}

func assertResourceAttr(t *testing.T, attrs pcommon.Map, key string, want any, msg string, args ...any) {
	t.Helper()
	v, ok := attrs.Get(key)
	// assert.True/Equal treat the tail as a single fmt string + args pair,
	// so we pre-format the human-readable prefix once and pass it as a
	// no-arg message.
	prefix := formatPrefix(msg, args...)
	if !assert.Truef(t, ok, "%s: missing attribute %q", prefix, key) {
		return
	}
	assert.Equalf(t, want, valueOf(v), "%s: attribute %q mismatch", prefix, key)
}

func formatPrefix(msg string, args ...any) string {
	if len(args) == 0 {
		return msg
	}
	return fmt.Sprintf(msg, args...)
}

// valueOf coerces a pcommon.Value into a native Go value for comparison. It
// only handles the subset that shows up in tests (string, int, float, bool);
// everything else falls back to AsString.
func valueOf(v pcommon.Value) any {
	switch v.Type() {
	case pcommon.ValueTypeStr:
		return v.Str()
	case pcommon.ValueTypeInt:
		return v.Int()
	case pcommon.ValueTypeDouble:
		return v.Double()
	case pcommon.ValueTypeBool:
		return v.Bool()
	default:
		return v.AsString()
	}
}

// -----------------------------------------------------------------------------
// Structural equality
// -----------------------------------------------------------------------------

// AssertLogsEqual compares two plog.Logs using the canonical pdata equality
// helpers exposed by the ptrace/plog packages. Falls back to string diffing
// on mismatch so failure output is actually readable.
func AssertLogsEqual(t *testing.T, want, got plog.Logs) {
	t.Helper()
	if want.ResourceLogs().Len() != got.ResourceLogs().Len() {
		t.Fatalf("resource logs count: want %d got %d",
			want.ResourceLogs().Len(), got.ResourceLogs().Len())
	}
	// Use JSON encoding as a canonical form for readable diffs.
	assertPdataJSONEqual(t, logsToJSON(t, want), logsToJSON(t, got), "logs")
}

// AssertMetricsEqual is the metrics analog of AssertLogsEqual.
func AssertMetricsEqual(t *testing.T, want, got pmetric.Metrics) {
	t.Helper()
	if want.ResourceMetrics().Len() != got.ResourceMetrics().Len() {
		t.Fatalf("resource metrics count: want %d got %d",
			want.ResourceMetrics().Len(), got.ResourceMetrics().Len())
	}
	assertPdataJSONEqual(t, metricsToJSON(t, want), metricsToJSON(t, got), "metrics")
}

// AssertTracesEqual is the traces analog of AssertLogsEqual.
func AssertTracesEqual(t *testing.T, want, got ptrace.Traces) {
	t.Helper()
	if want.ResourceSpans().Len() != got.ResourceSpans().Len() {
		t.Fatalf("resource spans count: want %d got %d",
			want.ResourceSpans().Len(), got.ResourceSpans().Len())
	}
	assertPdataJSONEqual(t, tracesToJSON(t, want), tracesToJSON(t, got), "traces")
}

func logsToJSON(t *testing.T, l plog.Logs) []byte {
	t.Helper()
	b, err := (&plog.JSONMarshaler{}).MarshalLogs(l)
	require.NoError(t, err)
	return b
}
func metricsToJSON(t *testing.T, m pmetric.Metrics) []byte {
	t.Helper()
	b, err := (&pmetric.JSONMarshaler{}).MarshalMetrics(m)
	require.NoError(t, err)
	return b
}
func tracesToJSON(t *testing.T, tr ptrace.Traces) []byte {
	t.Helper()
	b, err := (&ptrace.JSONMarshaler{}).MarshalTraces(tr)
	require.NoError(t, err)
	return b
}

func assertPdataJSONEqual(t *testing.T, want, got []byte, kind string) {
	t.Helper()
	// pdata JSON is deterministic within a single process, so a byte compare
	// is enough for equality. We keep the JSON around for the failure message.
	if string(want) != string(got) {
		t.Fatalf("%s not equal:\nwant: %s\ngot:  %s", kind, string(want), string(got))
	}
}
