# otelharness

A reusable Go test harness for OpenTelemetry Collector components. It
provides shared setup and teardown logic for logs, metrics, and trace
pipelines, so component authors can focus on testing behavior instead of
wiring up plumbing.

## What's in the box

| Package                                | Purpose                                                              |
|----------------------------------------|----------------------------------------------------------------------|
| `harness/telemetry.go`                 | `TestTelemetry` — observable logger, sinks, lifecycle management     |
| `harness/server.go`                    | Ephemeral OTLP/gRPC and OTLP/HTTP servers on random loopback ports   |
| `harness/assert.go`                    | pdata-aware assertion helpers (counts, attributes, structural eq.)   |
| `harness/pdatagen.go`                  | Deterministic pdata fixtures (`NewLogs`, `NewMetrics`, `NewTraces`)  |
| `example/routingprocessor/`            | A runnable custom processor + full end-to-end tests using the harness |

## Design at a glance

`TestTelemetry` is the single entry point:

```go
tel := harness.NewTestTelemetry(t)   // auto-cleanup via t.Cleanup
```

From it you can obtain:

- **`tel.Settings()`** — a `component.TelemetrySettings` with an observable
  `zap.Logger` and no-op tracer/meter providers. Feed this to any component
  constructor that takes `TelemetrySettings`.
- **`tel.Logs()` / `tel.Metrics()` / `tel.Traces()`** — the harness's
  in-memory `consumertest.Sink*` instances. These are the "downstream"
  targets a component under test can push into.
- **`tel.StartOTLPGRPCServer(nil)` / `tel.StartOTLPHTTPServer(nil)`** —
  full OTLP servers on random loopback ports that decode incoming pdata
  and forward it to either the harness's default sinks or any user-supplied
  `SignalConsumers` bundle. Handy when the component under test is an
  exporter and you want to receive its output.
- **`tel.RegisterShutdown(fn)`** — hook additional cleanup into the harness
  lifecycle so it runs (LIFO) alongside server teardown.
- **`tel.LogRecords()`** — every zap log the component produced, for
  behavior assertions on internal telemetry.

All of it is automatically torn down via `t.Cleanup`, and `Shutdown()` is
idempotent so tests may call it early if they want to assert teardown
behavior.

## Assertion helpers

The harness exposes three categories of pdata-aware assertions:

1. **Counts**: `AssertLogRecordCount`, `AssertMetricDataPointCount`,
   `AssertSpanCount`, plus `Eventually*` variants for asynchronous
   components.
2. **Attribute presence**: `AssertAllLogsHaveResourceAttr` and its metrics
   and traces analogs walk every resource group and fail if any is missing
   the requested key or has a mismatched value.
3. **Structural equality**: `AssertLogsEqual` / `AssertMetricsEqual` /
   `AssertTracesEqual` compare two pdata objects via the canonical pdata
   JSON marshalers, producing readable diffs on mismatch.

## The runnable example

`example/routingprocessor/` implements a small multi-signal processor that
inspects a resource attribute (`route`) and forwards each resource group
either to a "primary" or "secondary" downstream consumer. It's not
feature-complete — it exists to demonstrate the harness against a
realistic component with:

- its own `Start` / `Shutdown` lifecycle,
- three `Consume*` methods on one struct,
- per-resource routing logic worth verifying.

The tests in `example/routingprocessor/processor_test.go` cover:

- **`TestRoutingProcessor_AllSignals`** — feeds a mix of primary/secondary
  resources across logs, metrics, and traces, and asserts each landed on
  the correct side with the correct resource attribute preserved.
- **`TestRoutingProcessor_LifecycleGuards`** — verifies that
  `Consume*`-before-`Start` and `Consume*`-after-`Shutdown` produce clear
  errors, and that double-`Start` is rejected.
- **`TestRoutingProcessor_OTLPBridging`** — brings up both OTLP endpoints,
  wires the processor's "secondary" side into the harness's own logs
  consumer, and verifies data flows end-to-end while the servers are
  managed by the harness.

## Running

```sh
go test ./... -count=1 -v
```

## Requirements

- Go 1.22+ (the module toolchain will auto-upgrade to satisfy transitive
  pdata requirements).
- Modules pinned:
  - `go.opentelemetry.io/collector/pdata v1.38.0`
  - `go.opentelemetry.io/collector/component v0.132.0`
  - `go.opentelemetry.io/collector/consumer v1.38.0`
  - `google.golang.org/grpc v1.68.0`

Bump these together if you upgrade — the OTel Collector releases ship
`v1.X` and `v0.(X-1)` pairs that must stay aligned.

## Notes and caveats

- The OTLP/HTTP server only accepts `application/x-protobuf` — that's the
  production default for the collector's own exporter and keeps the
  harness free of extra JSON dependencies.
- The gRPC server registers three shim types (one per signal) because the
  generated `UnimplementedGRPCServer` types share the same Go type name
  across the three otlp packages and cannot be embedded on a single struct.
- `pdatagen` fixtures use a fixed timestamp so JSON-based equality
  assertions don't need clock normalization.
