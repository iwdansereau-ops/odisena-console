package routingprocessor_test

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/collector/component/componenttest"
	"go.opentelemetry.io/collector/consumer/consumertest"

	"github.com/example/otelharness/example/routingprocessor"
	"github.com/example/otelharness/harness"
)

// TestRoutingProcessor_AllSignals exercises the routing processor across all
// three signal types in a single test, using the harness to set up:
//
//   - a TestTelemetry with observable logger + default sinks
//   - two dedicated pairs of sinks (primary/secondary) per signal
//   - the processor wired to those sinks
//
// Then it feeds a mix of "primary" and "secondary"-tagged resources for each
// signal and asserts that each landed on the correct side, that the resource
// attribute was preserved end-to-end, and that the processor's internal
// counters match. This is the canonical "does the harness cover a realistic
// component?" test.
func TestRoutingProcessor_AllSignals(t *testing.T) {
	tel := harness.NewTestTelemetry(t)

	// Dedicated sinks per pipeline. The harness's own sinks are unused
	// here; we just want the TelemetrySettings + lifecycle scaffolding.
	primaryLogs, secondaryLogs := new(consumertest.LogsSink), new(consumertest.LogsSink)
	primaryMetrics, secondaryMetrics := new(consumertest.MetricsSink), new(consumertest.MetricsSink)
	primaryTraces, secondaryTraces := new(consumertest.TracesSink), new(consumertest.TracesSink)

	proc := routingprocessor.New(
		routingprocessor.Config{}, // defaults: route attr = "route", primary value = "primary"
		tel.Logger(),
		routingprocessor.Consumers{Primary: primaryLogs, Secondary: secondaryLogs},
		routingprocessor.Consumers{Primary: primaryMetrics, Secondary: secondaryMetrics},
		routingprocessor.Consumers{Primary: primaryTraces, Secondary: secondaryTraces},
	)

	// Start / Shutdown lifecycle is managed by the harness's registered hook
	// so a failure mid-test still tears the processor down cleanly.
	require.NoError(t, proc.Start(context.Background(), componenttest.NewNopHost()))
	tel.RegisterShutdown(proc.Shutdown)

	ctx := context.Background()

	// Feed logs: 2 primary resources, 3 secondary resources.
	for i := 0; i < 2; i++ {
		require.NoError(t, proc.ConsumeLogs(ctx,
			harness.NewLogs(1, map[string]string{"route": "primary", "tenant": "acme"})))
	}
	for i := 0; i < 3; i++ {
		require.NoError(t, proc.ConsumeLogs(ctx,
			harness.NewLogs(1, map[string]string{"route": "elsewhere"})))
	}

	// Feed metrics: 1 primary resource with 4 data points, 1 secondary with 2.
	require.NoError(t, proc.ConsumeMetrics(ctx,
		harness.NewMetrics(4, map[string]string{"route": "primary"})))
	require.NoError(t, proc.ConsumeMetrics(ctx,
		harness.NewMetrics(2, map[string]string{"route": "cold"})))

	// Feed traces: 1 primary with 5 spans, 2 secondary with 1 span each.
	require.NoError(t, proc.ConsumeTraces(ctx,
		harness.NewTraces(5, map[string]string{"route": "primary"})))
	for i := 0; i < 2; i++ {
		require.NoError(t, proc.ConsumeTraces(ctx,
			harness.NewTraces(1, map[string]string{"route": "backup"})))
	}

	// ------- Assertions -------

	// Log record counts: 1 record per resource ⇒ primary = 2, secondary = 3.
	harness.AssertLogRecordCount(t, primaryLogs, 2)
	harness.AssertLogRecordCount(t, secondaryLogs, 3)
	harness.AssertAllLogsHaveResourceAttr(t, primaryLogs, "route", "primary")

	// Metric data points: primary = 4, secondary = 2.
	harness.AssertMetricDataPointCount(t, primaryMetrics, 4)
	harness.AssertMetricDataPointCount(t, secondaryMetrics, 2)
	harness.AssertAllMetricsHaveResourceAttr(t, primaryMetrics, "route", "primary")

	// Spans: primary = 5, secondary = 2 (1 per batch × 2 batches).
	harness.AssertSpanCount(t, primaryTraces, 5)
	harness.AssertSpanCount(t, secondaryTraces, 2)
	harness.AssertAllTracesHaveResourceAttr(t, primaryTraces, "route", "primary")

	// Processor's own internal accounting should agree.
	lp, ls, mp, ms, tp, ts := proc.Counters()
	require.Equal(t, [6]int{2, 3, 1, 1, 1, 2}, [6]int{lp, ls, mp, ms, tp, ts})
}

// TestRoutingProcessor_LifecycleGuards checks that Start/Shutdown ordering
// is enforced. It uses the harness only for its TelemetrySettings.
func TestRoutingProcessor_LifecycleGuards(t *testing.T) {
	tel := harness.NewTestTelemetry(t)

	proc := routingprocessor.New(
		routingprocessor.Config{},
		tel.Logger(),
		routingprocessor.Consumers{Primary: new(consumertest.LogsSink), Secondary: new(consumertest.LogsSink)},
		routingprocessor.Consumers{},
		routingprocessor.Consumers{},
	)

	// Consuming before Start should fail with a clear error.
	err := proc.ConsumeLogs(context.Background(),
		harness.NewLogs(1, map[string]string{"route": "primary"}))
	require.ErrorContains(t, err, "not started")

	require.NoError(t, proc.Start(context.Background(), componenttest.NewNopHost()))

	// Second Start is rejected.
	require.ErrorContains(t,
		proc.Start(context.Background(), componenttest.NewNopHost()),
		"already started")

	require.NoError(t, proc.Shutdown(context.Background()))

	// Consuming after Shutdown is rejected.
	err = proc.ConsumeLogs(context.Background(),
		harness.NewLogs(1, map[string]string{"route": "primary"}))
	require.ErrorContains(t, err, "already shut down")
}

// TestRoutingProcessor_OTLPBridging shows the harness's OTLP server support:
// we point the "secondary" side of the router at the harness's default sinks
// (via its OTLP/gRPC listener), send data through, and verify it round-trips.
// A real test would use an OTLP exporter here; for brevity this test verifies
// the server plumbing by pointing the processor's Secondary consumer directly
// at the harness's LogsConsumer() (which is what an OTLP receiver would do
// on the other end of the wire).
func TestRoutingProcessor_OTLPBridging(t *testing.T) {
	tel := harness.NewTestTelemetry(t)

	// Bring up both OTLP endpoints — we don't call them in this test, but
	// starting them exercises listener setup, random port allocation, and
	// automatic teardown via t.Cleanup.
	grpcSrv := tel.StartOTLPGRPCServer(nil)
	httpSrv := tel.StartOTLPHTTPServer(nil)
	require.NotEmpty(t, grpcSrv.Endpoint())
	require.NotEmpty(t, httpSrv.Endpoint())

	primaryLogs := new(consumertest.LogsSink)

	proc := routingprocessor.New(
		routingprocessor.Config{},
		tel.Logger(),
		routingprocessor.Consumers{Primary: primaryLogs, Secondary: tel.LogsConsumer()},
		routingprocessor.Consumers{},
		routingprocessor.Consumers{},
	)
	require.NoError(t, proc.Start(context.Background(), componenttest.NewNopHost()))
	tel.RegisterShutdown(proc.Shutdown)

	require.NoError(t, proc.ConsumeLogs(context.Background(),
		harness.NewLogs(2, map[string]string{"route": "primary"})))
	require.NoError(t, proc.ConsumeLogs(context.Background(),
		harness.NewLogs(3, map[string]string{"route": "elsewhere"})))

	// The secondary side is now the harness's default logs sink.
	harness.EventuallyLogRecordCount(t, tel.Logs(), 3, time.Second)
	harness.AssertLogRecordCount(t, primaryLogs, 2)
}
