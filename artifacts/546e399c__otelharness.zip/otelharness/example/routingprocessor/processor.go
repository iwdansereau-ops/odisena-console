// Package routingprocessor is a small example OpenTelemetry Collector
// processor. Given a combined telemetry stream, it inspects each resource's
// "route" attribute and forwards the resource group either to a "primary"
// or a "secondary" downstream consumer for that signal.
//
// The point of this package is not to be feature-complete — it's to give the
// otelharness test harness something realistic to exercise: a component with
// its own lifecycle (Start/Shutdown), multi-signal support, and non-trivial
// per-resource routing logic that tests will want to verify.
package routingprocessor

import (
	"context"
	"errors"
	"sync"

	"go.opentelemetry.io/collector/component"
	"go.opentelemetry.io/collector/consumer"
	"go.opentelemetry.io/collector/pdata/plog"
	"go.opentelemetry.io/collector/pdata/pmetric"
	"go.opentelemetry.io/collector/pdata/ptrace"
	"go.uber.org/zap"
)

// Config controls how the processor routes.
type Config struct {
	// RouteAttribute is the resource attribute inspected on every incoming
	// resource group. Defaults to "route" if empty.
	RouteAttribute string
	// PrimaryValue is the attribute value that selects the primary consumer.
	// Everything else (including missing) goes to the secondary consumer.
	// Defaults to "primary" if empty.
	PrimaryValue string
}

// Consumers is the routing target set for a single signal. Both may be nil
// if that signal is not being processed by this instance.
type Consumers struct {
	Primary   any // consumer.Logs | consumer.Metrics | consumer.Traces
	Secondary any
}

// Processor is a multi-signal routing processor. It intentionally implements
// consumer.Logs, consumer.Metrics, and consumer.Traces on the same struct so
// that a single instance can be dropped into all three pipelines.
type Processor struct {
	cfg    Config
	logger *zap.Logger

	logs    Consumers
	metrics Consumers
	traces  Consumers

	mu      sync.Mutex
	started bool
	stopped bool

	// counters is exposed only for tests: it lets the tests verify that a
	// specific number of resource groups were routed to each destination
	// without inspecting the sinks. The processor itself never reads it.
	counters routingCounters
}

type routingCounters struct {
	logsPrimary, logsSecondary       int
	metricsPrimary, metricsSecondary int
	tracesPrimary, tracesSecondary   int
}

// New constructs a Processor. Any of the Consumers targets may be zero
// value; the corresponding Consume method will then error out with a clear
// message rather than panicking.
func New(cfg Config, logger *zap.Logger, logs, metrics, traces Consumers) *Processor {
	if cfg.RouteAttribute == "" {
		cfg.RouteAttribute = "route"
	}
	if cfg.PrimaryValue == "" {
		cfg.PrimaryValue = "primary"
	}
	if logger == nil {
		logger = zap.NewNop()
	}
	return &Processor{
		cfg:     cfg,
		logger:  logger,
		logs:    logs,
		metrics: metrics,
		traces:  traces,
	}
}

// -----------------------------------------------------------------------------
// component.Component lifecycle
// -----------------------------------------------------------------------------

// Capabilities marks the processor as mutating: it edits the incoming pdata
// object by splitting resources between two downstream consumers.
func (p *Processor) Capabilities() consumer.Capabilities {
	return consumer.Capabilities{MutatesData: true}
}

// Start marks the processor as ready to consume. Consuming before Start is
// a programming error and is rejected.
func (p *Processor) Start(_ context.Context, _ component.Host) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.started {
		return errors.New("routingprocessor: already started")
	}
	if p.stopped {
		return errors.New("routingprocessor: cannot restart after shutdown")
	}
	p.started = true
	p.logger.Debug("routingprocessor started",
		zap.String("route_attr", p.cfg.RouteAttribute),
		zap.String("primary_value", p.cfg.PrimaryValue),
	)
	return nil
}

// Shutdown flips the processor into a stopped state. Consuming after
// Shutdown is a programming error and is rejected.
func (p *Processor) Shutdown(_ context.Context) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	if !p.started {
		// Shutting down before Start is tolerated so tests that fail early
		// don't cascade into a second failure during t.Cleanup.
		p.stopped = true
		return nil
	}
	p.stopped = true
	p.logger.Debug("routingprocessor shut down")
	return nil
}

func (p *Processor) checkRunning() error {
	p.mu.Lock()
	defer p.mu.Unlock()
	if !p.started {
		return errors.New("routingprocessor: not started")
	}
	if p.stopped {
		return errors.New("routingprocessor: already shut down")
	}
	return nil
}

// -----------------------------------------------------------------------------
// Logs
// -----------------------------------------------------------------------------

// ConsumeLogs splits the incoming logs by resource-attribute routing rules
// and hands each half to the matching downstream consumer. If either side
// ends up empty it is skipped entirely so we don't churn downstream code
// with empty ResourceLogs slices.
func (p *Processor) ConsumeLogs(ctx context.Context, in plog.Logs) error {
	if err := p.checkRunning(); err != nil {
		return err
	}

	primary := plog.NewLogs()
	secondary := plog.NewLogs()

	rls := in.ResourceLogs()
	for i := 0; i < rls.Len(); i++ {
		rl := rls.At(i)
		if p.matchesPrimary(rl.Resource().Attributes().AsRaw()) {
			rl.CopyTo(primary.ResourceLogs().AppendEmpty())
			p.counters.logsPrimary++
		} else {
			rl.CopyTo(secondary.ResourceLogs().AppendEmpty())
			p.counters.logsSecondary++
		}
	}

	if primary.ResourceLogs().Len() > 0 {
		c, ok := p.logs.Primary.(consumer.Logs)
		if !ok || c == nil {
			return errors.New("routingprocessor: no primary logs consumer")
		}
		if err := c.ConsumeLogs(ctx, primary); err != nil {
			return err
		}
	}
	if secondary.ResourceLogs().Len() > 0 {
		c, ok := p.logs.Secondary.(consumer.Logs)
		if !ok || c == nil {
			return errors.New("routingprocessor: no secondary logs consumer")
		}
		if err := c.ConsumeLogs(ctx, secondary); err != nil {
			return err
		}
	}
	return nil
}

// -----------------------------------------------------------------------------
// Metrics
// -----------------------------------------------------------------------------

// ConsumeMetrics is the metrics analog of ConsumeLogs.
func (p *Processor) ConsumeMetrics(ctx context.Context, in pmetric.Metrics) error {
	if err := p.checkRunning(); err != nil {
		return err
	}

	primary := pmetric.NewMetrics()
	secondary := pmetric.NewMetrics()

	rms := in.ResourceMetrics()
	for i := 0; i < rms.Len(); i++ {
		rm := rms.At(i)
		if p.matchesPrimary(rm.Resource().Attributes().AsRaw()) {
			rm.CopyTo(primary.ResourceMetrics().AppendEmpty())
			p.counters.metricsPrimary++
		} else {
			rm.CopyTo(secondary.ResourceMetrics().AppendEmpty())
			p.counters.metricsSecondary++
		}
	}

	if primary.ResourceMetrics().Len() > 0 {
		c, ok := p.metrics.Primary.(consumer.Metrics)
		if !ok || c == nil {
			return errors.New("routingprocessor: no primary metrics consumer")
		}
		if err := c.ConsumeMetrics(ctx, primary); err != nil {
			return err
		}
	}
	if secondary.ResourceMetrics().Len() > 0 {
		c, ok := p.metrics.Secondary.(consumer.Metrics)
		if !ok || c == nil {
			return errors.New("routingprocessor: no secondary metrics consumer")
		}
		if err := c.ConsumeMetrics(ctx, secondary); err != nil {
			return err
		}
	}
	return nil
}

// -----------------------------------------------------------------------------
// Traces
// -----------------------------------------------------------------------------

// ConsumeTraces is the traces analog of ConsumeLogs.
func (p *Processor) ConsumeTraces(ctx context.Context, in ptrace.Traces) error {
	if err := p.checkRunning(); err != nil {
		return err
	}

	primary := ptrace.NewTraces()
	secondary := ptrace.NewTraces()

	rss := in.ResourceSpans()
	for i := 0; i < rss.Len(); i++ {
		rs := rss.At(i)
		if p.matchesPrimary(rs.Resource().Attributes().AsRaw()) {
			rs.CopyTo(primary.ResourceSpans().AppendEmpty())
			p.counters.tracesPrimary++
		} else {
			rs.CopyTo(secondary.ResourceSpans().AppendEmpty())
			p.counters.tracesSecondary++
		}
	}

	if primary.ResourceSpans().Len() > 0 {
		c, ok := p.traces.Primary.(consumer.Traces)
		if !ok || c == nil {
			return errors.New("routingprocessor: no primary traces consumer")
		}
		if err := c.ConsumeTraces(ctx, primary); err != nil {
			return err
		}
	}
	if secondary.ResourceSpans().Len() > 0 {
		c, ok := p.traces.Secondary.(consumer.Traces)
		if !ok || c == nil {
			return errors.New("routingprocessor: no secondary traces consumer")
		}
		if err := c.ConsumeTraces(ctx, secondary); err != nil {
			return err
		}
	}
	return nil
}

// matchesPrimary reports whether a resource attribute map should route to
// the primary consumer. Absent attribute or mismatched value → secondary.
func (p *Processor) matchesPrimary(attrs map[string]any) bool {
	v, ok := attrs[p.cfg.RouteAttribute]
	if !ok {
		return false
	}
	s, ok := v.(string)
	if !ok {
		return false
	}
	return s == p.cfg.PrimaryValue
}

// Counters is exposed only for tests.
func (p *Processor) Counters() (logsPrimary, logsSecondary, metricsPrimary, metricsSecondary, tracesPrimary, tracesSecondary int) {
	p.mu.Lock()
	defer p.mu.Unlock()
	c := p.counters
	return c.logsPrimary, c.logsSecondary, c.metricsPrimary, c.metricsSecondary, c.tracesPrimary, c.tracesSecondary
}
